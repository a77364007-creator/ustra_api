package com.gsitm.ustra.api.platform.tenant.persistence;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.Instant;
import org.junit.jupiter.api.Test;

class TenantConfigurationEntityTest {
    @Test
    void updateAdvancesConfigRevision() {
        Instant now = Instant.parse("2026-09-19T00:00:00Z");
        TenantConfigurationEntity entity = new TenantConfigurationEntity(
                "cfg1", "t1", "ko-KR", "Asia/Seoul", now);

        assertEquals(1, entity.getConfigRevision());
        entity.update("en-US", "UTC", now.plusSeconds(1));
        assertEquals(2, entity.getConfigRevision());
        assertEquals("en-US", entity.getDefaultLocale());
        assertEquals("UTC", entity.getTimezone());
    }
}

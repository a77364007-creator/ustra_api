package com.gsitm.ustra.api.platform;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gsitm.ustra.api.platform.provider.importing.application.Sha256Service;
import com.gsitm.ustra.api.platform.provider.importing.parser.SanitizedContractFingerprintService;
import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.media.ObjectSchema;
import io.swagger.v3.oas.models.media.StringSchema;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import java.util.List;
import org.junit.jupiter.api.Test;

class Cp11ContractFingerprintUnitTest {
    private final SanitizedContractFingerprintService fingerprints =
            new SanitizedContractFingerprintService(new ObjectMapper(), new Sha256Service());

    @Test
    void semanticDescriptionDoesNotChangeSchemaFingerprint() {
        ObjectSchema left = new ObjectSchema();
        left.addProperty("id", new StringSchema().description("consumer-facing text A"));
        ObjectSchema right = new ObjectSchema();
        right.addProperty("id", new StringSchema().description("consumer-facing text B"));
        assertEquals(fingerprints.schemaFingerprint(left, new OpenAPI()),
                fingerprints.schemaFingerprint(right, new OpenAPI()));
    }

    @Test
    void requiredShapeChangeChangesSchemaFingerprint() {
        ObjectSchema optional = new ObjectSchema();
        optional.addProperty("id", new StringSchema());
        ObjectSchema required = new ObjectSchema();
        required.addProperty("id", new StringSchema());
        required.setRequired(List.of("id"));
        assertNotEquals(fingerprints.schemaFingerprint(optional, new OpenAPI()),
                fingerprints.schemaFingerprint(required, new OpenAPI()));
    }

    @Test
    void internalSchemaReferenceResolvesIntoStructuralFingerprint() {
        ObjectSchema first = new ObjectSchema();
        first.addProperty("id", new StringSchema());
        OpenAPI api = new OpenAPI().components(new Components().addSchemas("Thing", first));
        String before = fingerprints.schemaFingerprint(new ObjectSchema().$ref("#/components/schemas/Thing"), api);

        ObjectSchema second = new ObjectSchema();
        second.addProperty("id", new StringSchema());
        second.addProperty("type", new StringSchema());
        api.getComponents().addSchemas("Thing", second);
        String after = fingerprints.schemaFingerprint(new ObjectSchema().$ref("#/components/schemas/Thing"), api);
        assertNotEquals(before, after);
    }

    @Test
    void securityRequirementScopesParticipateWithoutSecretValues() {
        OpenAPI api = new OpenAPI().components(new Components().addSecuritySchemes("oauth",
                new SecurityScheme().type(SecurityScheme.Type.OAUTH2)));
        SecurityRequirement read = new SecurityRequirement();
        read.put("oauth", List.of("read"));
        SecurityRequirement write = new SecurityRequirement();
        write.put("oauth", List.of("write"));
        assertNotEquals(fingerprints.securityRequirementFingerprint(read, api),
                fingerprints.securityRequirementFingerprint(write, api));
    }
}

package com.gsitm.ustra.api.platform;

import static org.junit.jupiter.api.Assertions.*;
import java.sql.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import org.flywaydb.core.Flyway;
import org.flywaydb.core.api.MigrationVersion;
import org.junit.jupiter.api.*;
import org.testcontainers.containers.MariaDBContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

/** Real dialect/FK/unique/claim behavior. Docker is required; no disabledWithoutDocker pass-through. */
@Testcontainers
class Cp15MariaDbOperationsTest {
    @Container static final MariaDBContainer<?> DB=new MariaDBContainer<>("mariadb:11.8.9")
            .withDatabaseName("cp15").withUsername("ustra").withPassword("test-only");
    static String tenantA=UUID.randomUUID().toString(),tenantB=UUID.randomUUID().toString(),eventId=UUID.randomUUID().toString();
    static Connection connection() throws SQLException {return DriverManager.getConnection(DB.getJdbcUrl(),DB.getUsername(),DB.getPassword());}
    static int update(Connection c,String sql,Object... params) throws SQLException {
        try(var ps=c.prepareStatement(sql)){for(int i=0;i<params.length;i++)ps.setObject(i+1,params[i]);return ps.executeUpdate();}
    }
    static String scalar(Connection c,String sql,Object... params) throws SQLException {
        try(var ps=c.prepareStatement(sql)){for(int i=0;i<params.length;i++)ps.setObject(i+1,params[i]);try(var rs=ps.executeQuery()){assertTrue(rs.next());return rs.getString(1);}}
    }
    @BeforeAll static void migration() throws Exception {
        var before=Flyway.configure().dataSource(DB.getJdbcUrl(),DB.getUsername(),DB.getPassword()).locations("classpath:db/migration")
                .target(MigrationVersion.fromVersion("46")).load();
        assertEquals(46,before.migrate().migrationsExecuted);
        try(var c=connection()) {
            for(String tenant:List.of(tenantA,tenantB)) {
                String customer=UUID.randomUUID().toString();
                update(c,"INSERT INTO customer VALUES(?, ?, 'fixture', 'ACTIVE', NOW(6), NOW(6))",customer,customer);
                update(c,"INSERT INTO tenant(tenant_id,customer_id,tenant_code,display_name,status,default_locale,timezone,isolation_profile,created_at,updated_at) VALUES(?, ?, ?, 'fixture','ACTIVE','ko','Asia/Seoul','SHARED',NOW(6),NOW(6))",tenant,customer,tenant);
            }
            update(c,"INSERT INTO outbox_event(outbox_id,event_id,event_type,event_version,aggregate_type,aggregate_id,tenant_id,payload,correlation_id,created_at,status) VALUES(?,?,'FIXTURE',1,'TENANT',?,?,'immutable-fixture','corr',NOW(6),'PENDING')",UUID.randomUUID().toString(),eventId,tenantA,tenantA);
        }
        var after=Flyway.configure().dataSource(DB.getJdbcUrl(),DB.getUsername(),DB.getPassword()).locations("classpath:db/migration").load();
        assertEquals(3,after.migrate().migrationsExecuted);after.validate();
    }
    static String insertAction(Connection c,String tenant,String key,String active,String status) throws SQLException {
        String id=UUID.randomUUID().toString();
        update(c,"INSERT INTO operations_recovery_action(recovery_action_id,tenant_id,action_type,target_type,target_id,idempotency_key,request_fingerprint,action_status,active_target_key,correlation_id,requested_by,requested_at) VALUES(?,?,'SEARCH_PRODUCT_REINDEX','API_PRODUCT',?,?,?, ?,?,'corr','actor',NOW(6))",id,tenant,UUID.randomUUID().toString(),key,"a".repeat(64),status,active);
        return id;
    }
    @Test void cp15T62_upgradeKeepsOldPendingEventAndPayload() throws Exception {
        try(var c=connection()){
            assertEquals("PENDING",scalar(c,"SELECT status FROM outbox_event WHERE event_id=?",eventId));
            assertEquals("immutable-fixture",scalar(c,"SELECT payload FROM outbox_event WHERE event_id=?",eventId));
            assertEquals("49",scalar(c,"SELECT COUNT(*) FROM flyway_schema_history WHERE success=1"));
        }
    }
    @Test void cp15T38T39_tenantKeyUniqueAndCaseSensitive() throws Exception {
        String key="case-"+UUID.randomUUID();
        try(var c=connection()) {
            insertAction(c,tenantA,key,null,"SUCCEEDED");
            assertThrows(SQLException.class,()->insertAction(c,tenantA,key,null,"SUCCEEDED"));
            assertDoesNotThrow(()->insertAction(c,tenantB,key,null,"SUCCEEDED"));
            assertDoesNotThrow(()->insertAction(c,tenantA,key.toUpperCase(Locale.ROOT),null,"SUCCEEDED"));
        }
    }
    @Test void cp15T40_activeTargetConstraintExcludesOverlapAndUnknownRetainsClaim() throws Exception {
        String lock="SEARCH:"+UUID.randomUUID();
        try(var c=connection()) {
            insertAction(c,tenantA,UUID.randomUUID().toString(),lock,"UNKNOWN");
            assertThrows(SQLException.class,()->insertAction(c,tenantA,UUID.randomUUID().toString(),lock,"REQUESTED"));
            assertThrows(SQLException.class,()->insertAction(c,tenantA,UUID.randomUUID().toString(),null,"IN_PROGRESS"));
        }
    }
    @Test void cp15T40_twoConcurrentRowClaimsHaveOneWinner() throws Exception {
        String id;
        try(var c=connection()){id=insertAction(c,tenantA,UUID.randomUUID().toString(),"SEARCH:"+UUID.randomUUID(),"REQUESTED");}
        AtomicInteger calls=new AtomicInteger();CountDownLatch start=new CountDownLatch(1);
        try(var pool=Executors.newFixedThreadPool(2)) {
            Callable<Void> claimant=()->{start.await();try(var c=connection()){
                c.setAutoCommit(false);
                String state=scalar(c,"SELECT action_status FROM operations_recovery_action WHERE tenant_id=? AND recovery_action_id=? FOR UPDATE",tenantA,id);
                if("REQUESTED".equals(state)) {
                    assertEquals(1,update(c,"UPDATE operations_recovery_action SET action_status='IN_PROGRESS',row_version=row_version+1 WHERE tenant_id=? AND recovery_action_id=? AND action_status='REQUESTED'",tenantA,id));
                    c.commit();calls.incrementAndGet();
                } else c.commit();
            }return null;};
            var one=pool.submit(claimant);var two=pool.submit(claimant);start.countDown();
            one.get(20,TimeUnit.SECONDS);two.get(20,TimeUnit.SECONDS);
        }
        assertEquals(1,calls.get()); // DB lock algorithm evidence; not a live Gateway effect test
    }
    @Test void cp15T46_searchObservationHasNoFakeIntegrationAndUniqueProductIdentity() throws Exception {
        String product=UUID.randomUUID().toString();
        try(var c=connection()) {
            String statement="INSERT INTO search_projection_failure(failure_id,tenant_id,api_product_id,observed_at,last_checked_at,safe_error_code,status) VALUES(?,?,?,NOW(6),NOW(6),'SEARCH_PROJECTION_REFRESH_FAILED','OPEN')";
            update(c,statement,UUID.randomUUID().toString(),tenantA,product);
            assertThrows(SQLException.class,()->update(c,statement,UUID.randomUUID().toString(),tenantA,product));
            assertDoesNotThrow(()->update(c,statement,UUID.randomUUID().toString(),tenantB,product));
        }
    }
    @Test void cp15T61_invalidTenantAndActionVocabularyRejected() throws Exception {
        try(var c=connection()) {
            assertThrows(SQLException.class,()->insertAction(c,UUID.randomUUID().toString(),"invalid",null,"SUCCEEDED"));
            String id=insertAction(c,tenantA,UUID.randomUUID().toString(),null,"SUCCEEDED");
            assertThrows(SQLException.class,()->update(c,"UPDATE operations_recovery_action SET action_type='FORCE_SUCCESS' WHERE recovery_action_id=?",id));
        }
    }
}

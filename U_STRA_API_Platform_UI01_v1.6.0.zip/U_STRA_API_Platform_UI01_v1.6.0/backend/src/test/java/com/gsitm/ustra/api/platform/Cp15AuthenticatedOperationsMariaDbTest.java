package com.gsitm.ustra.api.platform;

import static org.hamcrest.Matchers.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.gsitm.ustra.api.platform.audit.*;
import com.gsitm.ustra.api.platform.catalog.persistence.*;
import com.gsitm.ustra.api.platform.common.context.RequestContextHolder;
import com.gsitm.ustra.api.platform.integration.approval.domain.*;
import com.gsitm.ustra.api.platform.integration.approval.persistence.*;
import com.gsitm.ustra.api.platform.tenant.domain.CustomerStatus;
import com.gsitm.ustra.api.platform.tenant.persistence.*;
import java.time.*;
import java.util.*;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.*;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;
import org.testcontainers.containers.MariaDBContainer;
import org.testcontainers.junit.jupiter.*;

/**
 * Real application HTTP security, TenantContextResolver, permission DB, Criteria count and MariaDB.
 * X-Test-Principal-Id is used ONLY under the existing test profile, not as production auth evidence.
 * New roles/role grants are per-test fixtures; no production role mapping is introduced.
 */
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@Testcontainers
class Cp15AuthenticatedOperationsMariaDbTest {
    @Container static final MariaDBContainer<?> DB=new MariaDBContainer<>("mariadb:11.8.9")
            .withDatabaseName("cp15_http").withUsername("ustra").withPassword("test-only");
    @DynamicPropertySource static void properties(DynamicPropertyRegistry registry) {
        registry.add("spring.datasource.url",DB::getJdbcUrl);
        registry.add("spring.datasource.username",DB::getUsername);
        registry.add("spring.datasource.password",DB::getPassword);
        registry.add("spring.datasource.driver-class-name",()->"org.mariadb.jdbc.Driver");
    }
    @Autowired MockMvc mvc;
    @Autowired JdbcTemplate jdbc;
    @Autowired PlatformTransactionManager manager;
    @Autowired CustomerRepository customers;
    @Autowired TenantRepository tenants;
    @Autowired MembershipRepository memberships;
    @Autowired RoleAssignmentRepository assignments;
    @Autowired ApiProductRepository products;
    @Autowired IntegrationProfileRepository profiles;
    @Autowired ConnectorInstanceRepository connectors;
    @Autowired IntegrationOperationRepository operations;
    @Autowired ReconciliationIssueRepository issues;
    @Autowired AuditRecordRepository audit;
    String a,b,approvalUser,gatewayUser,operationsUser,auditUser,recoveryUser,foreignProduct;
    String approvalOperation,gatewayOperation,foreignOperation;
    Instant now;
    static String id(){return UUID.randomUUID().toString();}

    @BeforeEach void fixture() {
        now=Instant.now();SecurityContextHolder.clearContext();RequestContextHolder.clear();
        new TransactionTemplate(manager).execute(status->{
            a=tenant();b=tenant();
            approvalUser=principal(a,"APPROVAL_INTEGRATION:READ");
            gatewayUser=principal(a,"GATEWAY_INTEGRATION:READ");
            operationsUser=principal(a,"OPERATIONS:READ");
            auditUser=principal(a,"AUDIT:READ");
            recoveryUser=principal(a,"CATALOG_SEARCH:REBUILD");
            approvalOperation=operation(a,IntegrationType.APPROVAL_ITSM,IntegrationOperationType.APPROVAL_STATUS_QUERY);
            gatewayOperation=operation(a,IntegrationType.GATEWAY_IAM,IntegrationOperationType.GATEWAY_STATUS_QUERY);
            foreignOperation=operation(b,IntegrationType.APPROVAL_ITSM,IntegrationOperationType.APPROVAL_STATUS_QUERY);
            operation(b,IntegrationType.GATEWAY_IAM,IntegrationOperationType.GATEWAY_STATUS_QUERY);
            foreignProduct=id();products.saveAndFlush(new ApiProductEntity(foreignProduct,b,foreignProduct,
                    foreignProduct.toUpperCase(Locale.ROOT),"foreign-fixture",null,null,null,now,"fixture"));
            for(String tenant:Arrays.asList(a,b,null))audit.saveAndFlush(new AuditRecordEntity(id(),tenant,now,"fixture","IDENTITY",
                    "MATRIX_FIXTURE","FIXTURE",id(),"SUCCESS",null,"fixture-correlation",true,"MATRIX_PRIVATE_DIFF",null,null));
            return null;
        });
    }
    @AfterEach void clear(){SecurityContextHolder.clearContext();RequestContextHolder.clear();}
    String tenant() {
        String customer=id(),tenant=id();
        customers.saveAndFlush(new CustomerEntity(customer,customer,"fixture",CustomerStatus.ACTIVE,now));
        var row=new TenantEntity(tenant,customer,tenant,"fixture","ko","Asia/Seoul",now);row.activate(now);
        tenants.saveAndFlush(row);return tenant;
    }
    String principal(String tenant,String permission) {
        String principal="fixture-"+id(),role=id(),membership=id();
        jdbc.update("INSERT INTO role_definition(role_id,role_code,display_name,scope_type,system_managed,status) VALUES(?,?,?,'TENANT',FALSE,'ACTIVE')",
                role,"FIXTURE_"+role,"runtime-test-only");
        assertEquals(1,jdbc.update("INSERT INTO role_permission(role_id,permission_id) SELECT ?,permission_id FROM permission WHERE permission_code=?",role,permission));
        memberships.saveAndFlush(new MembershipEntity(membership,tenant,null,principal,"local-test",now.minusSeconds(60),null,now));
        assignments.saveAndFlush(new RoleAssignmentEntity(id(),tenant,membership,role,null,now.minusSeconds(60),null,"fixture",now));
        return principal;
    }
    String operation(String tenant,IntegrationType type,IntegrationOperationType operationType) {
        String profile=id(),connector=id(),operation=id();
        profiles.saveAndFlush(new IntegrationProfileEntity(profile,tenant,profile,type,"fixture",true,now,"fixture"));
        connectors.saveAndFlush(new ConnectorInstanceEntity(connector,tenant,profile,connector,"TEST_ONLY","TEST_ONLY","MATRIX_PRIVATE_SECRET_REFERENCE",true,now,"fixture"));
        operations.saveAndFlush(new IntegrationOperationEntity(operation,tenant,connector,operationType,"FIXTURE",id(),null,null,id(),null,now,"fixture"));
        // Deliberately misleading label: ownership must come from the parent operation, not the prefix.
        issues.saveAndFlush(new ReconciliationIssueEntity(id(),tenant,operation,"UNRELATED_LABEL","FIXTURE",now,"fixture"));
        return operation;
    }

    @Test void cp15T02T04T06_approvalOnlyScopeAndCountIgnoreForgedTenantHeader() throws Exception {
        String second=new TransactionTemplate(manager).execute(status->operation(a,IntegrationType.APPROVAL_ITSM,IntegrationOperationType.APPROVAL_STATUS_QUERY));
        var ordered=java.util.stream.Stream.of(approvalOperation,second).sorted(Comparator.reverseOrder()).toList();
        mvc.perform(get("/api/v1/admin/operations/integration-operations")
                .header("X-Test-Principal-Id",approvalUser).header("X-Tenant-Id",b)
                .param("type","APPROVAL_ITSM").param("size","1"))
                .andExpect(status().isOk()).andExpect(jsonPath("$.totalElements").value(2))
                .andExpect(jsonPath("$.items[0].id").value(ordered.get(0)))
                .andExpect(content().string(not(containsString(foreignOperation))));
        mvc.perform(get("/api/v1/admin/operations/integration-operations")
                .header("X-Test-Principal-Id",approvalUser).header("X-Tenant-Id",b)
                .param("type","APPROVAL_ITSM").param("size","1").param("page","1"))
                .andExpect(status().isOk()).andExpect(jsonPath("$.totalElements").value(2))
                .andExpect(jsonPath("$.items[0].id").value(ordered.get(1)));
        mvc.perform(get("/api/v1/admin/operations/integration-operations")
                .header("X-Test-Principal-Id",approvalUser).param("type","GATEWAY_IAM"))
                .andExpect(status().isForbidden());
    }
    @Test void cp15T05T06_gatewayIssueScopeAndCountUseRealParentOwnership() throws Exception {
        mvc.perform(get("/api/v1/admin/operations/reconciliation-issues")
                .header("X-Test-Principal-Id",gatewayUser).param("type","GATEWAY_IAM").param("size","1"))
                .andExpect(status().isOk()).andExpect(jsonPath("$.totalElements").value(1))
                .andExpect(jsonPath("$.items[0].integrationOperationId").value(gatewayOperation));
        mvc.perform(get("/api/v1/admin/operations/connectors")
                .header("X-Test-Principal-Id",gatewayUser).param("type","APPROVAL_ITSM"))
                .andExpect(status().isForbidden());
    }
    @Test void cp15T09_operationsReadDoesNotGrantSourceOrAuditRead() throws Exception {
        mvc.perform(get("/api/v1/admin/operations/summary").header("X-Test-Principal-Id",operationsUser))
                .andExpect(status().isOk()).andExpect(jsonPath("$.integrations").isEmpty())
                .andExpect(content().string(not(containsString(approvalOperation))))
                .andExpect(content().string(not(containsString(gatewayOperation))));
        mvc.perform(get("/api/v1/admin/audit-records").header("X-Test-Principal-Id",operationsUser))
                .andExpect(status().isForbidden());
        mvc.perform(get("/api/v1/admin/operations/integration-operations")
                .header("X-Test-Principal-Id",operationsUser).param("type","GATEWAY_IAM"))
                .andExpect(status().isForbidden());
    }
    @Test void cp15T10T11T12_auditReadIsTenantBoundAndOmitsPrivateDiff() throws Exception {
        mvc.perform(get("/api/v1/admin/audit-records").header("X-Test-Principal-Id",auditUser)
                .header("X-Tenant-Id",b).param("action","MATRIX_FIXTURE"))
                .andExpect(status().isOk()).andExpect(jsonPath("$.totalElements").value(1))
                .andExpect(jsonPath("$.items",hasSize(1)))
                .andExpect(content().string(not(containsString("MATRIX_PRIVATE_DIFF"))));
        mvc.perform(get("/api/v1/admin/operations/summary").header("X-Test-Principal-Id",auditUser))
                .andExpect(status().isForbidden());
    }
    @Test void cp15T03T37_recoveryCannotTargetAnotherTenantAndDoesNotInsertJournal() throws Exception {
        String body="{\"actionType\":\"SEARCH_PRODUCT_REINDEX\",\"targetId\":\""+foreignProduct+"\"}";
        mvc.perform(post("/api/v1/admin/operations/recovery-actions")
                .header("X-Test-Principal-Id",recoveryUser).header("Idempotency-Key",id())
                .contentType(MediaType.APPLICATION_JSON).content(body))
                .andExpect(status().isNotFound());
        assertEquals(0,jdbc.queryForObject("SELECT COUNT(*) FROM operations_recovery_action WHERE tenant_id=?",Integer.class,a));
    }
    @Test void cp15T02T56_authenticatedBodyCannotSupplyTenantAuthority() throws Exception {
        String body="{\"actionType\":\"SEARCH_TENANT_REBUILD\",\"targetId\":\""+a+"\",\"tenantId\":\""+b+"\"}";
        mvc.perform(post("/api/v1/admin/operations/recovery-actions")
                .header("X-Test-Principal-Id",recoveryUser).header("Idempotency-Key",id())
                .contentType(MediaType.APPLICATION_JSON).content(body)).andExpect(status().isBadRequest());
        assertEquals(0,jdbc.queryForObject("SELECT COUNT(*) FROM operations_recovery_action WHERE tenant_id=?",Integer.class,a));
    }
    @Test void cp15T54T57_connectorReadDoesNotExposeSecretReferenceOrGrantWrite() throws Exception {
        mvc.perform(get("/api/v1/admin/operations/connectors").header("X-Test-Principal-Id",gatewayUser).param("type","GATEWAY_IAM"))
                .andExpect(status().isOk()).andExpect(jsonPath("$.totalElements").value(1))
                .andExpect(jsonPath("$.items[0].healthStatus").value("NOT_MEASURED"))
                .andExpect(content().string(not(containsString("MATRIX_PRIVATE_SECRET_REFERENCE"))));
        mvc.perform(post("/api/v1/admin/operations/connectors").header("X-Test-Principal-Id",gatewayUser)
                .contentType(MediaType.APPLICATION_JSON).content("{}")).andExpect(status().isMethodNotAllowed());
    }
    @Test void cp15T60_legacyListShapePreservedWithSourceIsolation() throws Exception {
        mvc.perform(get("/api/v1/admin/approval-integrations/operations").header("X-Test-Principal-Id",approvalUser))
                .andExpect(status().isOk()).andExpect(jsonPath("$",hasSize(1)))
                .andExpect(jsonPath("$[0].integrationOperationId").value(approvalOperation));
        mvc.perform(get("/api/v1/admin/gateway-integrations/operations").header("X-Test-Principal-Id",gatewayUser))
                .andExpect(status().isOk()).andExpect(jsonPath("$",hasSize(1)))
                .andExpect(jsonPath("$[0].integrationOperationId").value(gatewayOperation));
    }
}

package com.gsitm.ustra.api.platform;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gsitm.ustra.api.platform.audit.AuditService;
import com.gsitm.ustra.api.platform.catalog.persistence.*;
import com.gsitm.ustra.api.platform.common.context.*;
import com.gsitm.ustra.api.platform.common.error.*;
import com.gsitm.ustra.api.platform.integration.approval.application.*;
import com.gsitm.ustra.api.platform.integration.approval.domain.*;
import com.gsitm.ustra.api.platform.integration.approval.persistence.*;
import com.gsitm.ustra.api.platform.integration.gateway.application.GatewayIntegrationOrchestrator;
import com.gsitm.ustra.api.platform.operations.application.*;
import com.gsitm.ustra.api.platform.operations.domain.*;
import com.gsitm.ustra.api.platform.operations.persistence.*;
import com.gsitm.ustra.api.platform.search.application.*;
import com.gsitm.ustra.api.platform.search.persistence.*;
import com.gsitm.ustra.api.platform.security.*;
import com.gsitm.ustra.api.platform.tenant.application.TenantPermissionGuard;
import com.gsitm.ustra.api.platform.tenant.context.*;
import com.gsitm.ustra.api.platform.tenant.domain.CustomerStatus;
import com.gsitm.ustra.api.platform.tenant.persistence.*;
import java.sql.*;
import java.time.*;
import java.util.*;
import java.util.concurrent.*;
import javax.sql.DataSource;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.annotation.*;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.*;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.*;
import org.springframework.transaction.support.*;
import org.testcontainers.containers.MariaDBContainer;
import org.testcontainers.junit.jupiter.*;

/**
 * Actual Spring-proxied services, JPA, Flyway and MariaDB; never skipped without Docker.
 * The projection/ITSM/Gateway boundaries are test doubles. TenantContext/permission stubs
 * isolate concurrency from authorization; the separate HTTP matrix exercises real guards.
 * Synchronization deadlines below are test safety limits, NOT operational SLA policies.
 */
@DataJpaTest(properties={"spring.flyway.enabled=true","spring.jpa.hibernate.ddl-auto=validate"})
@AutoConfigureTestDatabase(replace=AutoConfigureTestDatabase.Replace.NONE)
@ActiveProfiles("test")
@Transactional(propagation=Propagation.NOT_SUPPORTED)
@Import({RecoveryActionOrchestrator.class,RecoveryActionService.class,RecoveryTargetValidator.class,
        SearchProjectionRecoveryService.class,SearchProjectionFailureService.class,
        CatalogSearchReindexListener.class,ReconciliationIssueService.class,AuditService.class,
        AuthenticatedIdentityProvider.class,Cp15RuntimeClosureMariaDbTest.FixtureBeans.class})
@Testcontainers
class Cp15RuntimeClosureMariaDbTest {
    @Container static final MariaDBContainer<?> DB=new MariaDBContainer<>("mariadb:11.8.9")
            .withDatabaseName("cp15_closure").withUsername("ustra").withPassword("test-only");
    @DynamicPropertySource static void properties(DynamicPropertyRegistry registry) {
        registry.add("spring.datasource.url",DB::getJdbcUrl);
        registry.add("spring.datasource.username",DB::getUsername);
        registry.add("spring.datasource.password",DB::getPassword);
        registry.add("spring.datasource.driver-class-name",()->"org.mariadb.jdbc.Driver");
    }
    @TestConfiguration(proxyBeanMethods=false)
    static class FixtureBeans {
        @Bean Clock clock(){return Clock.systemUTC();}
        @Bean ObjectMapper mapper(){return new ObjectMapper().findAndRegisterModules();}
        @Bean TenantContextResolver contexts(){return mock(TenantContextResolver.class);}
        @Bean TenantPermissionGuard permissions(){return mock(TenantPermissionGuard.class);}
        @Bean CatalogSearchProjectionPort projection(){return mock(CatalogSearchProjectionPort.class);}
        @Bean ApprovalIntegrationOrchestrator approval(){return mock(ApprovalIntegrationOrchestrator.class);}
        @Bean GatewayIntegrationOrchestrator gateway(){return mock(GatewayIntegrationOrchestrator.class);}
    }
    @Autowired CustomerRepository customers;
    @Autowired TenantRepository tenants;
    @Autowired ApiProductRepository products;
    @Autowired IntegrationProfileRepository profiles;
    @Autowired ConnectorInstanceRepository connectors;
    @Autowired IntegrationOperationRepository operations;
    @Autowired ReconciliationIssueRepository issues;
    @Autowired SearchProjectionFailureRepository failures;
    @Autowired OperationsRecoveryActionRepository actions;
    @Autowired RecoveryActionOrchestrator orchestrator;
    @Autowired RecoveryActionService journal;
    @Autowired SearchProjectionRecoveryService search;
    @Autowired SearchProjectionFailureService observations;
    @Autowired ReconciliationIssueService issueService;
    @Autowired TenantContextResolver contexts;
    @Autowired CatalogSearchProjectionPort projection;
    @Autowired PlatformTransactionManager manager;
    @Autowired ApplicationEventPublisher events;
    @Autowired DataSource dataSource;
    String tenant,product;
    TenantContext context;
    TransactionTemplate tx;

    @BeforeEach void fixture() {
        reset(contexts,projection);
        tx=new TransactionTemplate(manager);
        Instant now=Instant.now();
        String customer=UUID.randomUUID().toString();
        tenant=UUID.randomUUID().toString();product=UUID.randomUUID().toString();
        tx.execute(status->{
            customers.saveAndFlush(new CustomerEntity(customer,customer,"runtime-test",CustomerStatus.ACTIVE,now));
            var t=new TenantEntity(tenant,customer,tenant,"runtime-test","ko","Asia/Seoul",now);
            t.activate(now);tenants.saveAndFlush(t);
            products.saveAndFlush(new ApiProductEntity(product,tenant,product,product.toUpperCase(Locale.ROOT),
                    "before",null,null,null,now,"runtime-fixture"));
            return null;
        });
        context=new TenantContext(tenant,tenant,customer,null,"runtime-fixture",UUID.randomUUID().toString(),
                Set.of("TEST_ONLY"),"ko","runtime-request","runtime-correlation");
        when(contexts.resolve()).thenReturn(context);
        bind();
    }
    @AfterEach void clear(){SecurityContextHolder.clearContext();RequestContextHolder.clear();}
    void bind() {
        SecurityContextHolder.getContext().setAuthentication(new UsernamePasswordAuthenticationToken(
                new UstraPrincipal("runtime-fixture","local-test"),"N/A",List.of()));
        RequestContextHolder.set(new RequestContext("runtime-request","runtime-correlation"));
    }
    <T> T asActor(Callable<T> work) throws Exception {
        bind();try{return work.call();}finally{clear();}
    }
    static void await(CountDownLatch latch) throws InterruptedException {
        assertTrue(latch.await(15,TimeUnit.SECONDS),"test synchronization deadline exceeded");
    }
    String scalar(String sql,Object... parameters) throws SQLException {
        // Raw pool connection, deliberately NOT DataSourceUtils: observe already committed state.
        try(Connection c=dataSource.getConnection();PreparedStatement statement=c.prepareStatement(sql)) {
            assertTrue(c.getAutoCommit(),"independent observer must not join a business transaction");
            for(int i=0;i<parameters.length;i++)statement.setObject(i+1,parameters[i]);
            try(ResultSet rows=statement.executeQuery()){assertTrue(rows.next());return rows.getString(1);}
        }
    }
    RecoveryRequest request(){return new RecoveryRequest(RecoveryActionType.SEARCH_PRODUCT_REINDEX,product,null);}
    CatalogSearchProjectionPort.ReindexResult reindexed(){return new CatalogSearchProjectionPort.ReindexResult(tenant,product,1,0);}
    static void stop(ExecutorService pool) throws InterruptedException {pool.shutdownNow();assertTrue(pool.awaitTermination(20,TimeUnit.SECONDS));}

    @Test void cp15T15T40T41_realConcurrentOrchestratorsSeeCommittedJournalBeforeSingleHandler() throws Exception {
        String key=UUID.randomUUID().toString();
        CountDownLatch entered=new CountDownLatch(1),release=new CountDownLatch(1);
        when(projection.reindexProduct(tenant,product,"runtime-fixture")).thenAnswer(invocation->{
            assertFalse(TransactionSynchronizationManager.isActualTransactionActive());
            assertEquals("IN_PROGRESS",scalar("SELECT action_status FROM operations_recovery_action WHERE tenant_id=? AND idempotency_key=?",tenant,key));
            assertEquals("2",scalar("SELECT COUNT(*) FROM audit_record WHERE tenant_id=? AND resource_id=(SELECT recovery_action_id FROM operations_recovery_action WHERE tenant_id=? AND idempotency_key=?) AND action IN ('OPERATIONS_RECOVERY_REQUESTED','OPERATIONS_RECOVERY_STARTED')",tenant,tenant,key));
            entered.countDown();await(release);return reindexed();
        });
        ExecutorService pool=Executors.newFixedThreadPool(2);
        try {
            Future<RecoveryActionService.View> first=pool.submit(()->asActor(()->orchestrator.execute(key,request())));
            await(entered);
            Future<RecoveryActionService.View> duplicate=pool.submit(()->asActor(()->orchestrator.execute(key,request())));
            var observed=duplicate.get(15,TimeUnit.SECONDS);
            assertEquals("IN_PROGRESS",observed.actionStatus());
            release.countDown();var completed=first.get(15,TimeUnit.SECONDS);
            assertEquals(observed.recoveryActionId(),completed.recoveryActionId());
            assertEquals("SUCCEEDED",completed.actionStatus());
            assertEquals("REINDEX_COMPLETED",completed.targetStatus());
            verify(projection,times(1)).reindexProduct(tenant,product,"runtime-fixture");
            assertEquals("3",scalar("SELECT COUNT(*) FROM audit_record WHERE tenant_id=? AND resource_id=?",tenant,completed.recoveryActionId()));
        } finally {release.countDown();stop(pool);}
    }

    @Test void cp15T40_differentKeysOnSameTargetCannotStartASecondHandler() throws Exception {
        CountDownLatch entered=new CountDownLatch(1),release=new CountDownLatch(1);
        when(projection.reindexProduct(tenant,product,"runtime-fixture")).thenAnswer(invocation->{entered.countDown();await(release);return reindexed();});
        ExecutorService pool=Executors.newSingleThreadExecutor();
        try {
            Future<?> first=pool.submit(()->asActor(()->orchestrator.execute("first-"+product,request())));
            await(entered);
            BusinessException rejected=assertThrows(BusinessException.class,()->orchestrator.execute("second-"+product,request()));
            assertEquals(ErrorCode.OPERATIONS_RECOVERY_TARGET_BUSY,rejected.code());
            release.countDown();first.get(15,TimeUnit.SECONDS);
            verify(projection,times(1)).reindexProduct(tenant,product,"runtime-fixture");
            assertEquals("1",scalar("SELECT COUNT(*) FROM operations_recovery_action WHERE tenant_id=?",tenant));
        } finally {release.countDown();stop(pool);}
    }

    @Test void cp15T15_failedAuditPreparationRollsBackTheInsertedJournal() throws Exception {
        SecurityContextHolder.clearContext(); // context resolver fixture still returns the authorized test context
        assertThrows(BusinessException.class,()->journal.prepare(context,"rollback-"+product,request()));
        bind();
        assertEquals("0",scalar("SELECT COUNT(*) FROM operations_recovery_action WHERE tenant_id=?",tenant));
        assertEquals("0",scalar("SELECT COUNT(*) FROM audit_record WHERE tenant_id=?",tenant));
        verifyNoInteractions(projection);
    }

    String operationFixture() {
        return tx.execute(status->{
            Instant now=Instant.now();String profile=UUID.randomUUID().toString(),connector=UUID.randomUUID().toString(),id=UUID.randomUUID().toString();
            profiles.saveAndFlush(new IntegrationProfileEntity(profile,tenant,profile,IntegrationType.APPROVAL_ITSM,"fixture",true,now,"runtime-fixture"));
            connectors.saveAndFlush(new ConnectorInstanceEntity(connector,tenant,profile,connector,"TEST_ONLY","TEST_ONLY",null,true,now,"runtime-fixture"));
            operations.saveAndFlush(new IntegrationOperationEntity(id,tenant,connector,IntegrationOperationType.APPROVAL_STATUS_QUERY,
                    "FIXTURE",product,null,null,id,null,now,"runtime-fixture"));return id;
        });
    }
    @Test void cp15T34_concurrentIssueInsertThenReopenUsesOnePersistentIdentity() throws Exception {
        String operation=operationFixture();String type="APPROVAL_QUERY_UNKNOWN";
        ExecutorService pool=Executors.newFixedThreadPool(2);
        try {
            for(int round=0;round<2;round++) {
                CountDownLatch start=new CountDownLatch(1);
                Callable<String> call=()->asActor(()->{await(start);return issueService.open(tenant,operation,type,"FIXTURE_CODE","runtime-fixture").getId();});
                var first=pool.submit(call);var second=pool.submit(call);start.countDown();
                assertEquals(first.get(15,TimeUnit.SECONDS),second.get(15,TimeUnit.SECONDS));
                assertEquals("1",scalar("SELECT COUNT(*) FROM reconciliation_issue WHERE tenant_id=? AND integration_operation_id=?",tenant,operation));
                assertEquals("OPEN",scalar("SELECT status FROM reconciliation_issue WHERE tenant_id=? AND integration_operation_id=?",tenant,operation));
                if(round==0)issueService.resolve(tenant,operation,type,"runtime-fixture");
            }
            assertEquals("1",scalar("SELECT COUNT(*) FROM audit_record WHERE tenant_id=? AND action='RECONCILIATION_ISSUE_REOPENED'",tenant));
        } finally {stop(pool);}
    }

    @Test void cp15T45_canonicalCommitSurvivesAfterCommitProjectionFailureAndObservationPersists() throws Exception {
        when(projection.reindexProduct(tenant,product,"runtime-fixture")).thenThrow(new IllegalStateException("synthetic-projection-fault"));
        tx.execute(status->{
            var row=products.findByIdAndTenantId(product,tenant).orElseThrow();
            row.update("committed",null,null,null,Instant.now(),"runtime-fixture");products.saveAndFlush(row);
            events.publishEvent(new CatalogSearchReindexEvent(tenant,product,"runtime-fixture","TEST_COMMIT"));return null;
        });
        assertEquals("committed",scalar("SELECT name FROM api_product WHERE tenant_id=? AND api_product_id=?",tenant,product));
        assertEquals("OPEN",scalar("SELECT status FROM search_projection_failure WHERE tenant_id=? AND api_product_id=?",tenant,product));
        verify(projection,times(1)).reindexProduct(tenant,product,"runtime-fixture");
    }

    @Test void cp15T45_rollbackDoesNotDispatchAfterCommitListener() throws Exception {
        tx.execute(status->{
            var row=products.findByIdAndTenantId(product,tenant).orElseThrow();
            row.update("rolled-back",null,null,null,Instant.now(),"runtime-fixture");products.saveAndFlush(row);
            events.publishEvent(new CatalogSearchReindexEvent(tenant,product,"runtime-fixture","TEST_ROLLBACK"));
            status.setRollbackOnly();return null;
        });
        assertEquals("before",scalar("SELECT name FROM api_product WHERE tenant_id=? AND api_product_id=?",tenant,product));
        verifyNoInteractions(projection);
    }

    @Test void cp15T49_newObservationWinsOverEarlierSuccessfulReindex() throws Exception {
        observations.observe(tenant,product);Long before=observations.openVersion(tenant,product);
        CountDownLatch entered=new CountDownLatch(1),release=new CountDownLatch(1);
        when(projection.reindexProduct(tenant,product,"runtime-fixture")).thenAnswer(invocation->{entered.countDown();await(release);return reindexed();});
        ExecutorService pool=Executors.newSingleThreadExecutor();
        try {
            var first=pool.submit(()->asActor(()->search.reindex(tenant,product,"runtime-fixture")));
            await(entered);observations.observe(tenant,product);
            Long later=observations.openVersion(tenant,product);assertTrue(later>before);
            release.countDown();first.get(15,TimeUnit.SECONDS);
            assertEquals(later,observations.openVersion(tenant,product));
        } finally {release.countDown();stop(pool);}
    }
}

package com.gsitm.ustra.api.platform;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gsitm.ustra.api.platform.operations.application.*;
import com.gsitm.ustra.api.platform.operations.domain.*;
import com.gsitm.ustra.api.platform.operations.api.OperationsRecoveryController;
import com.gsitm.ustra.api.platform.common.error.*;
import com.gsitm.ustra.api.platform.audit.AuditService;
import com.gsitm.ustra.api.platform.tenant.application.TenantPermissionGuard;
import com.gsitm.ustra.api.platform.tenant.persistence.RolePermissionRepository;
import com.gsitm.ustra.api.platform.catalog.persistence.*;
import com.gsitm.ustra.api.platform.subscription.approval.persistence.*;
import com.gsitm.ustra.api.platform.subscription.entitlement.persistence.*;
import com.gsitm.ustra.api.platform.subscription.entitlement.domain.*;
import com.gsitm.ustra.api.platform.integration.approval.persistence.*;
import com.gsitm.ustra.api.platform.integration.approval.domain.*;
import java.util.*;
import org.junit.jupiter.api.Test;

class Cp15TargetAndAuditBehaviorTest {
    static final String TENANT=Cp15SafetyBehaviorTest.TENANT,TARGET=Cp15SafetyBehaviorTest.PRODUCT;
    final ApprovalReferenceRepository refs=mock(ApprovalReferenceRepository.class);
    final AccessFulfillmentRepository fulfillments=mock(AccessFulfillmentRepository.class);
    final ApiProductRepository products=mock(ApiProductRepository.class);
    final IntegrationOperationRepository operations=mock(IntegrationOperationRepository.class);
    final RecoveryTargetValidator service=new RecoveryTargetValidator(refs,fulfillments,products,operations);
    @Test void cp15T03T37_crossTenantTargetFailsBeforeHandlerPreparation() {
        when(fulfillments.findByIdAndTenantId(TARGET,TENANT)).thenReturn(Optional.empty());
        assertThrows(BusinessException.class,()->service.validate(TENANT,new RecoveryRequest(RecoveryActionType.GATEWAY_STATUS_RECONCILE,TARGET,null)));
        verify(fulfillments).findByIdAndTenantId(TARGET,TENANT);verifyNoInteractions(refs,products,operations);
    }
    @Test void cp15T37_processingGatewayCannotBeForcedIntoReconciliation() {
        var row=mock(AccessFulfillmentEntity.class);when(row.getStatus()).thenReturn(AccessFulfillmentStatus.PROCESSING);
        when(fulfillments.findByIdAndTenantId(TARGET,TENANT)).thenReturn(Optional.of(row));
        assertThrows(BusinessException.class,()->service.validate(TENANT,new RecoveryRequest(RecoveryActionType.GATEWAY_STATUS_RECONCILE,TARGET,null)));
    }
    @Test void cp15T37_gatewayUnknownCanBeQueriedWithoutBeingMadeSuccessful() {
        var row=mock(AccessFulfillmentEntity.class);when(row.getStatus()).thenReturn(AccessFulfillmentStatus.UNKNOWN);
        when(row.getRowVersion()).thenReturn(7L);when(fulfillments.findByIdAndTenantId(TARGET,TENANT)).thenReturn(Optional.of(row));
        assertDoesNotThrow(()->service.validate(TENANT,new RecoveryRequest(RecoveryActionType.GATEWAY_STATUS_RECONCILE,TARGET,7L)));
        assertEquals(AccessFulfillmentStatus.UNKNOWN,row.getStatus());verify(fulfillments,never()).save(any());
    }
    @Test void cp15T37_staleProductVersionRejected() {
        var row=mock(ApiProductEntity.class);when(row.getRowVersion()).thenReturn(8L);
        when(products.findByIdAndTenantId(TARGET,TENANT)).thenReturn(Optional.of(row));
        var ex=assertThrows(BusinessException.class,()->service.validate(TENANT,new RecoveryRequest(RecoveryActionType.SEARCH_PRODUCT_REINDEX,TARGET,7L)));
        assertEquals(ErrorCode.CONCURRENT_MODIFICATION,ex.code());
    }
    @Test void cp15T32_referenceLessCreateUnknownNotClaimedRecoverable() {
        when(refs.findByIdAndTenantId(TARGET,TENANT)).thenReturn(Optional.empty());
        assertThrows(BusinessException.class,()->service.validate(TENANT,new RecoveryRequest(RecoveryActionType.APPROVAL_STATUS_RECONCILE,TARGET,null)));
        verifyNoInteractions(operations);
    }
    @Test void cp15T31_unknownCaseCreationStillBlocksCancellation() {
        var row=mock(IntegrationOperationEntity.class);when(row.getStatus()).thenReturn(IntegrationOperationStatus.UNKNOWN);
        when(operations.findByTenantIdAndOperationTypeAndAggregateIdAndAggregateRevision(TENANT,IntegrationOperationType.APPROVAL_CASE_CREATE,TARGET,1)).thenReturn(Optional.of(row));
        // This read-only method only uses operations; unrelated collaborators must not be invoked.
        var guard=new com.gsitm.ustra.api.platform.integration.approval.application.ApprovalIntegrationStateService(
                null,refs,null,operations,null,null,null,null,null,Cp15SafetyBehaviorTest.CLOCK);
        assertTrue(guard.hasUnresolvedCaseCreation(TENANT,TARGET,1));
        when(row.getStatus()).thenReturn(IntegrationOperationStatus.FAILED);
        assertFalse(guard.hasUnresolvedCaseCreation(TENANT,TARGET,1));

    }
    @Test void cp15T51_tenantRebuildCannotTargetAnotherTenant() {
        assertThrows(BusinessException.class,()->service.validate(TENANT,new RecoveryRequest(RecoveryActionType.SEARCH_TENANT_REBUILD,TARGET,null)));
        verifyNoInteractions(refs,fulfillments,products,operations);
    }
    @Test void cp15T14_actualPermissionGuardAuditsDenial() {
        var permissions=mock(RolePermissionRepository.class);var audit=mock(AuditService.class);
        var guard=new TenantPermissionGuard(permissions,audit);var context=Cp15RecoveryBehaviorTest.context();
        assertThrows(BusinessException.class,()->guard.require(context,"GATEWAY_INTEGRATION:RECONCILE","ACCESS_FULFILLMENT",TARGET));
        verify(audit).denied(TENANT,"AUTHORIZE:GATEWAY_INTEGRATION:RECONCILE","ACCESS_FULFILLMENT",TARGET,"ACCESS_DENIED");
    }
    @Test void cp15T02T56_unknownBodyAuthorityFieldsRejectedEvenWhenGlobalUnknownFieldsIgnored() {
        var mapper=new ObjectMapper().disable(com.fasterxml.jackson.databind.DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        for(String field:List.of("tenantId","url","secret","forceStatus")) {
            String json="{\"actionType\":\"SEARCH_PRODUCT_REINDEX\",\"targetId\":\""+TARGET+"\",\""+field+"\":\"untrusted\"}";
            assertThrows(com.fasterxml.jackson.core.JsonProcessingException.class,()->mapper.readValue(json,OperationsRecoveryController.Body.class));
        }
    }
    @Test void cp15T43_requestTimeTargetDbFailureRetainsUncertainJournalWithoutHandlerCall() {
        var r=Cp15RecoveryBehaviorTest.request();var f=new Cp15RecoveryBehaviorTest.OrchestratorFixture(r);
        doThrow(new IllegalStateException("private-db-message")).when(f.targets).validate(TENANT,r);
        var result=f.service.execute("key",r);assertEquals("UNKNOWN",result.actionStatus());
        assertEquals("TARGET_REVALIDATION_UNCONFIRMED",result.safeResultCode());verifyNoInteractions(f.search,f.gateway,f.approval);
    }
}

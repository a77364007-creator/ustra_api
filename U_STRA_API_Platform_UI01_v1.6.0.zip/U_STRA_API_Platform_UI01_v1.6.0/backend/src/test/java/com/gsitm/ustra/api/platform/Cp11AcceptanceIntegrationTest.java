package com.gsitm.ustra.api.platform;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

/**
 * CP-11 acceptance traceability.
 * These tests assert source contracts in this blocked runtime environment; Spring/MariaDB behavior
 * still requires Maven + Testcontainers execution before release.
 */
class Cp11AcceptanceIntegrationTest {
    private static final Path ROOT = Path.of(".").toAbsolutePath().normalize();

    private static String source(String relative) {
        try { return Files.readString(ROOT.resolve(relative)); }
        catch (IOException ex) { throw new AssertionError(ex); }
    }
    private static String assessment(){return source("src/main/java/com/gsitm/ustra/api/platform/change/application/ApiChangeAssessmentService.java");}
    private static String impact(){return source("src/main/java/com/gsitm/ustra/api/platform/change/application/ConsumerImpactService.java");}
    private static String lifecycle(){return source("src/main/java/com/gsitm/ustra/api/platform/change/application/ApiVersionLifecycleService.java");}
    private static String parser(){return source("src/main/java/com/gsitm/ustra/api/platform/provider/importing/parser/SwaggerOpenApiParserAdapter.java");}
    private static String fingerprint(){return source("src/main/java/com/gsitm/ustra/api/platform/provider/importing/parser/SanitizedContractFingerprintService.java");}
    private static String snapshot(){return source("src/main/java/com/gsitm/ustra/api/platform/change/application/ContractSnapshotMaterializationService.java");}

    @Test void cp11T01_sameTenantSameApiPairAccepted(){assertTrue(assessment().contains("Objects.equals(baseline.getApiId(), target.getApiId())"));}
    @Test void cp11T02_crossTenantBaselineDenied(){assertTrue(assessment().contains("findByIdAndTenantId(id, context.tenantId())"));}
    @Test void cp11T03_crossTenantTargetDenied(){assertTrue(assessment().contains("ownedVersion(context, targetApiVersionId)"));}
    @Test void cp11T04_differentApiPairRejected(){assertTrue(assessment().contains("API_CHANGE_PAIR_INVALID"));}
    @Test void cp11T05_sameVersionPairRejected(){assertTrue(assessment().contains("Objects.equals(baseline.getId(), target.getId())"));}
    @Test void cp11T06_rawOpenApiNotPersistedBySnapshot(){String s=snapshot().toLowerCase();assertFalse(s.contains("rawopenapi"));assertFalse(source("src/main/resources/db/migration/V037__api_contract_snapshot.sql").toLowerCase().contains("raw_openapi"));}
    @Test void cp11T07_snapshotDeterministic(){assertTrue(snapshot().contains("sorted(Comparator.comparing(OperationFacts::identity))"));assertTrue(snapshot().contains("SNAPSHOT_SCHEMA_VERSION"));}
    @Test void cp11T08_exactAssessmentReplayIsIdempotent(){assertTrue(assessment().contains("findByTenantIdAndBaselineApiVersionIdAndTargetApiVersionIdAndBaselineStructuralHashAndTargetStructuralHashAndRuleSetVersion"));}
    @Test void cp11T09_differentStructuralSnapshotIsConflictSafeRevision(){assertTrue(source("src/main/resources/db/migration/V038__api_change_assessment.sql").contains("uq_api_change_exact_assessment"));}
    @Test void cp11T10_hashDifferenceAloneNeverBreaking(){String s=assessment();assertFalse(s.contains("sourceContentHash"));assertTrue(s.contains("OPERATION_REMOVED"));}
    @Test void cp11T11_operationRemovalIsBreaking(){String s=assessment();assertTrue(s.contains("ApiChangeKind.OPERATION_REMOVED"));assertTrue(s.contains("ApiChangeItemEffect.BREAKING"));}
    @Test void cp11T12_operationAdditionDoesNotFabricateNonBreaking(){String s=assessment();assertTrue(s.contains("ApiChangeKind.OPERATION_ADDED"));assertTrue(s.contains("ApiChangeItemEffect.INFORMATIONAL"));assertFalse(s.contains("NON_BREAKING"));}
    @Test void cp11T13_insufficientStructureReturnsReviewRequired(){assertTrue(assessment().contains("STRUCTURAL_CHANGE_RULE_COVERAGE_INCOMPLETE"));assertTrue(assessment().contains("CompatibilityResult.REVIEW_REQUIRED"));}
    @Test void cp11T14_externalRefRemainsFailClosed(){String s=source("src/main/java/com/gsitm/ustra/api/platform/provider/importing/parser/OpenApiReferenceGuard.java");assertTrue(s.contains("OPENAPI_EXTERNAL_REFERENCE_FORBIDDEN"));assertTrue(parser().contains("guard.validate(source)"));}
    @Test void cp11T15_rawSourceAbsentFromAuditOutbox(){String s=assessment().toLowerCase()+impact().toLowerCase();assertFalse(s.contains("raw_openapi"));assertFalse(s.contains("source_body"));}

    @Test @Disabled("DF-CP11-01/02: full parameter rule catalog requires design authority") void cp11T16_requiredParameterAdditionRule(){assertTrue(snapshot().contains("ParsedParameter"));}
    @Test @Disabled("DF-CP11-01/02: optional-to-required rule catalog requires design authority") void cp11T17_optionalToRequiredRule(){assertTrue(snapshot().contains("parameter.required()"));}
    @Test @Disabled("DF-CP11-01/02: schema narrowing rule requires approved deterministic semantics") void cp11T18_requestSchemaNarrowingRule(){assertTrue(fingerprint().contains("schemaShape"));}
    @Test @Disabled("DF-CP11-01/02: response compatibility rule requires approved deterministic semantics") void cp11T19_responseIncompatibilityRule(){assertTrue(snapshot().contains("ParsedResponse"));}
    @Test @Disabled("DF-CP11-01/02: security-strength rule requires approved deterministic semantics") void cp11T20_strongerSecurityRule(){assertTrue(snapshot().contains("securityFingerprints"));}
    @Test void cp11T21_semanticTextDoesNotBecomeCompatibilityVerdict(){String s=fingerprint();assertFalse(s.contains("getDescription"));assertFalse(s.contains("getExample"));}
    @Test void cp11T22_ruleSetVersionStored(){assertTrue(assessment().contains("RULE_SET_VERSION = \"CP11-OPERATION-V1\""));assertTrue(source("src/main/resources/db/migration/V038__api_change_assessment.sql").contains("rule_set_version"));}
    @Test void cp11T23_historicalBaselineWithoutSnapshotDoesNotInventVerdict(){assertTrue(assessment().contains("BASELINE_CONTRACT_SNAPSHOT_MISSING"));assertTrue(assessment().contains("CompatibilityResult.REVIEW_REQUIRED"));}

    @Test void cp11T24_impactResolvesProductVersionComposition(){assertTrue(impact().contains("findAllByTenantIdAndApiVersionId"));}
    @Test void cp11T25_operationScopedCompositionImpact(){assertTrue(impact().contains("findAllByTenantIdAndApiOperationIdIn"));}
    @Test void cp11T26_pinnedSubscriptionUsedNotLatest(){String s=impact();assertTrue(s.contains("findAllByTenantIdAndApiProductVersionIdOrderByCreatedAtAsc"));assertFalse(s.toLowerCase().contains("recommended"));}
    @Test void cp11T27_entitlementLinksCorrectEnvironment(){String s=impact();assertTrue(s.contains("subscription.getConsumerAppEnvironmentId()"));assertTrue(s.contains("findAllByTenantIdAndSubscriptionId"));}
    @Test void cp11T28_crossTenantConsumerNeverLeaks(){String s=impact();assertTrue(s.contains("context.tenantId()"));assertFalse(s.contains("X-Tenant-Id"));}
    @Test void cp11T29_unrelatedProductVersionExcluded(){assertTrue(impact().contains("productVersionId"));assertTrue(impact().contains("findAllByTenantIdAndApiProductVersionIdOrderByCreatedAtAsc"));}
    @Test void cp11T30_sourceStatusesSnapshotted(){String s=source("src/main/resources/db/migration/V039__consumer_impact.sql");assertTrue(s.contains("subscription_status"));assertTrue(s.contains("entitlement_status"));assertTrue(s.contains("consumer_app_state"));}
    @Test void cp11T31_reanalysisDoesNotRewriteOldEvidence(){String s=impact();assertTrue(s.contains("findByTenantIdAndApiChangeIdAndImpactBasisHash"));assertFalse(s.contains("impactRepository.delete"));}
    @Test void cp11T32_impactCountMatchesMaterializedRows(){assertTrue(impact().contains("drafts.size()"));assertTrue(source("src/main/resources/db/migration/V039__consumer_impact.sql").contains("materialized_row_count"));}
    @Test void cp11T33_componentWithoutConsumerRemainsZeroActualConsumers(){String s=impact();assertTrue(s.contains("for (SubscriptionEntity subscription : subscriptions)"));assertFalse(s.contains("fakeConsumer"));}
    @Test @Disabled("DF-CP11-03: request-only/pending consumer inclusion policy is not approved") void cp11T34_requestOnlyInclusionPolicy(){assertTrue(impact().contains("subscriptionStatus"));}

    @Test void cp11T35_releasedApiVersionCanBeDeprecated(){String s=lifecycle();assertTrue(s.contains("ApiVersionState.RELEASED"));assertTrue(s.contains("entity.deprecate"));}
    @Test void cp11T36_draftCannotUseReleasedDeprecationCommand(){assertTrue(lifecycle().contains("entity.getState()!=ApiVersionState.RELEASED"));}
    @Test void cp11T37_deprecationDoesNotMutateSubscriptionPin(){assertFalse(lifecycle().contains("SubscriptionRepository"));}
    @Test void cp11T38_deprecationDoesNotRevokeEntitlement(){assertFalse(lifecycle().contains("EntitlementRepository"));assertFalse(lifecycle().contains("revoke("));}
    @Test void cp11T39_deprecationDoesNotAutoSwitchTarget(){assertFalse(lifecycle().toLowerCase().contains("targetversion"));}
    @Test @Disabled("DF-CP11-05: retirement blocker/force policy remains undefined") void cp11T40_retirementBlockerPolicy(){assertFalse(lifecycle().contains("retire("));}
    @Test void cp11T41_retirementDoesNotImplyGatewayAction(){assertFalse(lifecycle().contains("GatewayPort"));assertFalse(lifecycle().contains("gateway"));}
    @Test @Disabled("DF-CP11-07: CatalogPublication behavior on retirement/deprecation remains undefined") void cp11T42_catalogPublicationPolicy(){assertFalse(lifecycle().contains("CatalogPublication"));}
    @Test void cp11T43_repeatedDeprecationIsIdempotentOrConflict(){assertTrue(lifecycle().contains("if(entity.getState()==ApiVersionState.DEPRECATED)return entity"));}
    @Test void cp11T44_concurrentLifecycleUpdateUsesRowVersion(){assertTrue(lifecycle().contains("entity.getRowVersion()!=expectedVersion"));}

    @Test @Disabled("DF-CP11-04: migration target physical model is not approved; Start Gate is AMBER") void cp11T45_migrationTargetSameTenant(){assertTrue(impact().contains("context.tenantId()"));}
    @Test @Disabled("DF-CP11-04: migration target product/API relationship model is not approved") void cp11T46_migrationTargetRelationship(){assertFalse(impact().contains("targetApiProductVersionId"));}
    @Test @Disabled("DF-CP11-04: migration tracking commands are not approved") void cp11T47_migrationTargetDoesNotMutateAuthority(){assertFalse(impact().contains("subscriptionRepository.save"));}
    @Test @Disabled("DF-CP11-04: authoritative migration target model is not approved") void cp11T48_latestNeverAuthoritativeMigrationTarget(){assertFalse(impact().toLowerCase().contains("latest"));}
    @Test @Disabled("DF-CP11-09: notification target/channel model remains AMBER") void cp11T49_notificationSafeMetadata(){assertTrue(source("src/main/java/com/gsitm/ustra/api/platform/outbox/OutboxService.java").contains("safePayload"));}
    @Test @Disabled("DF-CP11-09: notification target/channel model remains AMBER") void cp11T50_notificationCannotLeakOtherTenant(){assertTrue(impact().contains("context.tenantId()"));}

    @Test void cp11T51_cp09SameHashReplayRemainsIdempotent(){String s=source("src/main/java/com/gsitm/ustra/api/platform/provider/importing/application/ApiImportMaterializationService.java");assertTrue(s.contains("Objects.equals(existing.getSourceContentHash(), hash)"));}
    @Test void cp11T52_cp09DifferentHashSameVersionStillConflicts(){assertTrue(source("src/main/java/com/gsitm/ustra/api/platform/provider/importing/application/ApiImportMaterializationService.java").contains("API_VERSION_IMPORT_CONFLICT"));}
    @Test void cp11T53_cp10ReviewSnapshotMismatchStillBlocksRelease(){assertTrue(source("src/main/java/com/gsitm/ustra/api/platform/provider/publishing/application/PublicationReleaseGate.java").contains("PUBLICATION_REVIEW_SNAPSHOT_MISMATCH"));}
    @Test void cp11T54_cp10ReleasePublicationSeparationRemains(){assertFalse(source("src/main/java/com/gsitm/ustra/api/platform/provider/publishing/application/PublicationReleaseGate.java").contains("CatalogPublication"));}
    @Test void cp11T55_cp06To08EntitlementReadySemanticsRemain(){String s=source("src/main/java/com/gsitm/ustra/api/platform/subscription/entitlement/application/ReadyToUseService.java");assertTrue(s.contains("ReadyToUse"));assertTrue(Files.exists(ROOT.resolve("src/test/java/com/gsitm/ustra/api/platform/Cp08AcceptanceIntegrationTest.java")));}
    @Test void cp11T56_consumerAppObjectScopeBlockerRemainsVisible(){assertTrue(source("../docs/DESIGN_FEEDBACK_CP05.md").toLowerCase().contains("object-scope"));}
}

package com.gsitm.ustra.api.platform;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

/**
 * CP-12 acceptance traceability. Source-contract assertions are executable without MariaDB business fixtures,
 * but Maven + Testcontainers execution is still required before release.
 */
class Cp12AcceptanceIntegrationTest {
    private static final Path ROOT = Path.of(".").toAbsolutePath().normalize();
    private static String source(String relative){try{return Files.readString(ROOT.resolve(relative));}catch(IOException ex){throw new AssertionError(ex);}}
    private static String search(){return source("src/main/java/com/gsitm/ustra/api/platform/search/application/CatalogSearchService.java");}
    private static String projection(){return source("src/main/java/com/gsitm/ustra/api/platform/search/application/CatalogSearchProjectionService.java");}
    private static String visibility(){return source("src/main/java/com/gsitm/ustra/api/platform/catalog/publication/application/CatalogVisibilityService.java");}
    private static String migration(){return source("src/main/resources/db/migration/V041__catalog_search_projection.sql");}

    @Test void cp12T01_blankQueryBrowsesDiscoverableProducts(){assertTrue(search().contains("if (needle == null) return true"));assertTrue(search().contains("visibleVersions.isEmpty()"));}
    @Test void cp12T02_keywordMatchesCanonicalProductName(){assertTrue(search().contains("getDisplayName()"));assertTrue(projection().contains("product.getName()"));}
    @Test void cp12T03_keywordMatchesProductDescription(){assertTrue(search().contains("getDescription()"));}
    @Test void cp12T04_keywordMatchesProductCode(){assertTrue(search().contains("getProductCode()"));}
    @Test void cp12T05_keywordMatchesProviderIdentity(){assertTrue(search().contains("getProviderCode()"));assertTrue(search().contains("getProviderDisplayName()"));}
    @Test void cp12T06_resultIdentityIsApiProduct(){assertTrue(search().contains("Map<String,List<CatalogSearchDocumentEntity>> matched"));assertFalse(search().contains("ApiOperationRepository"));}
    @Test void cp12T07_localePublicationMatchesDedupeToProduct(){assertTrue(search().contains("computeIfAbsent(document.getApiProductId()"));}
    @Test void cp12T08_stablePaginationUsesDeterministicOrdering(){assertTrue(search().contains("thenComparing(SearchResult::apiProductId)"));assertTrue(search().contains("subList(from, to)"));}
    @Test void cp12T09_boundedPageSizeEnforced(){assertTrue(search().contains("MAX_PAGE_SIZE = 100"));}
    @Test void cp12T10_noDynamicSqlFromQuery(){String s=search().toLowerCase();assertFalse(s.contains("entitymanager"));assertFalse(s.contains("createquery("));assertFalse(s.contains("nativequery"));}

    @Test void cp12T11_crossTenantSearchIsTenantQualified(){assertTrue(search().contains("findAllByTenantIdOrderByApiProductIdAscLocaleKeyAsc(context.tenantId())"));}
    @Test void cp12T12_forgedTenantHeaderNotAuthority(){assertFalse(source("src/main/java/com/gsitm/ustra/api/platform/search/api/CatalogSearchController.java").contains("X-Tenant-Id"));}
    @Test void cp12T13_tenantAudienceUsesCanonicalVisibility(){assertTrue(search().contains("visibilityService.isDiscoverable"));assertTrue(visibility().contains("AudienceScopeType.TENANT"));}
    @Test void cp12T14_orgAudienceUsesServerOrganization(){assertTrue(search().contains("context.organizationId()"));assertTrue(visibility().contains("AudienceScopeType.ORGANIZATION"));}
    @Test void cp12T15_differentOrganizationCannotSeeOrgScope(){assertTrue(visibility().contains("scope.getOrganizationId().equals(organizationId)"));}
    @Test void cp12T16_draftPublicationNotDiscoverable(){assertTrue(search().contains("CatalogPublicationState.ACTIVE"));}
    @Test void cp12T17_suspendedPublicationNotDiscoverable(){assertTrue(search().contains("!=CatalogPublicationState.ACTIVE"));}
    @Test void cp12T18_withdrawnPublicationNotDiscoverable(){assertTrue(search().contains("!=CatalogPublicationState.ACTIVE"));}
    @Test void cp12T19_nonReleasedProductVersionNotDiscoverable(){assertTrue(search().contains("!=ApiProductVersionState.RELEASED"));}
    @Test void cp12T20_retiredProductNotDiscoverable(){assertTrue(search().contains("ApiProductLifecycleState.RETIRED"));}
    @Test void cp12T21_multipleVisibleVersionsNoAutoLatest(){String s=search().toLowerCase();assertTrue(s.contains("list<visibleversion>"));assertFalse(s.contains("latest"));assertFalse(s.contains("recommended"));}

    @Test void cp12T22_publishedRequestedLocaleCanMatch(){assertTrue(projection().contains("LocalizationStatus.PUBLISHED"));assertTrue(search().contains("keys.add(requested)"));}
    @Test void cp12T23_tenantDefaultLocaleCanParticipate(){assertTrue(search().contains("keys.add(tenantDefault.trim())"));}
    @Test void cp12T24_canonicalContentFallbackExists(){assertTrue(search().contains("CANONICAL_LOCALE_KEY"));assertTrue(search().contains("localizationResolutionService"));}
    @Test void cp12T25_draftLocalizationNotIndexed(){assertTrue(projection().contains("findAllByTenantIdAndApiProductIdAndStatus"));assertTrue(projection().contains("LocalizationStatus.PUBLISHED"));}
    @Test void cp12T26_reviewLocalizationNotIndexed(){assertFalse(projection().contains("LocalizationStatus.REVIEW"));}
    @Test void cp12T27_staleLocalizationNotIndexed(){assertFalse(projection().contains("LocalizationStatus.STALE"));}
    @Test void cp12T28_localeMatchesDedupeSameProduct(){assertTrue(search().contains("entry.getKey()"));assertTrue(search().contains("matchedLocales"));}
    @Test @Disabled("DF-CP12-01: Synonym canonical model/authority is not approved") void cp12T29_synonymSearch(){assertFalse(search().toLowerCase().contains("synonym"));}

    @Test void cp12T30_sameTenantProviderFilter(){assertTrue(search().contains("findByIdAndTenantId(normalized.providerId(), context.tenantId())"));}
    @Test void cp12T31_crossTenantProviderDoesNotLeak(){assertTrue(search().contains("PROVIDER_NOT_FOUND"));}
    @Test @Disabled("DF-CP12-01: UseCase canonical model is not approved") void cp12T32_useCaseSearch(){assertFalse(search().contains("UseCase"));}
    @Test @Disabled("DF-CP12-01: BusinessObject canonical model is not approved") void cp12T33_businessObjectSearch(){assertFalse(search().contains("BusinessObject"));}
    @Test @Disabled("DF-CP12-01: Category canonical model is not approved") void cp12T34_categoryFilter(){assertFalse(search().contains("Category"));}
    @Test @Disabled("DF-CP12-01: Tag canonical model is not approved") void cp12T35_tagFilter(){assertFalse(search().contains("Tag"));}
    @Test @Disabled("DF-CP12-02: Classification/AccessPolicy authority remains unresolved") void cp12T36_classificationFilter(){assertFalse(search().contains("Classification"));}
    @Test @Disabled("DF-CP12-01: Sandbox availability source is not approved") void cp12T37_sandboxFilter(){assertFalse(search().contains("Sandbox"));}
    @Test @Disabled("DF-CP12-03: Usage/popularity ranking policy is deferred") void cp12T38_popularityRanking(){assertFalse(search().toLowerCase().contains("popularity"));}

    @Test void cp12T39_fullTenantRebuildFromCanonical(){assertTrue(projection().contains("findAllByTenantIdOrderByProductCodeNormalizedAsc"));assertTrue(projection().contains("rebuildTenant"));}
    @Test void cp12T40_rebuildIsTenantScoped(){assertTrue(projection().contains("deleteByTenantId(tenantId)"));}
    @Test void cp12T41_projectionLossDoesNotDeleteCanonical(){String p=projection();assertFalse(p.contains("productRepository.delete"));assertFalse(p.contains("publicationRepository.delete"));}
    @Test void cp12T42_rebuildUsesCanonicalEligibilitySources(){String p=projection();assertTrue(p.contains("versionRepository"));assertTrue(p.contains("publicationRepository"));assertTrue(p.contains("audienceRepository"));}
    @Test void cp12T43_duplicateReindexIsIdempotentReplace(){String p=projection();assertTrue(p.contains("deleteByTenantIdAndApiProductId"));assertTrue(p.contains("reindexProduct"));}
    @Test void cp12T44_publicationActivationTriggersReindex(){assertTrue(source("src/main/java/com/gsitm/ustra/api/platform/catalog/publication/application/CatalogPublicationService.java").contains("CATALOG_PUBLICATION_ACTIVATED"));}
    @Test void cp12T45_suspendWithdrawTriggerReindex(){String s=source("src/main/java/com/gsitm/ustra/api/platform/catalog/publication/application/CatalogPublicationService.java");assertTrue(s.contains("CATALOG_PUBLICATION_SUSPENDED"));assertTrue(s.contains("CATALOG_PUBLICATION_WITHDRAWN"));}
    @Test void cp12T46_productUpdateTriggersProjectionRefresh(){assertTrue(source("src/main/java/com/gsitm/ustra/api/platform/catalog/application/ApiProductService.java").contains("API_PRODUCT_UPDATED"));}
    @Test void cp12T47_onlyPublishedLocalizationBecomesSearchSource(){assertTrue(projection().contains("LocalizationStatus.PUBLISHED"));assertFalse(projection().contains("LocalizationStatus.DRAFT"));}
    @Test void cp12T48_projectionFailureCannotRollbackCanonicalMutation(){String s=source("src/main/java/com/gsitm/ustra/api/platform/search/application/CatalogSearchReindexListener.java");assertTrue(s.contains("TransactionPhase.AFTER_COMMIT"));assertTrue(s.contains("catch (RuntimeException"));}
    @Test void cp12T49_projectionCarriesSourceVersionAndHash(){String m=migration();assertTrue(m.contains("source_product_row_version"));assertTrue(m.contains("source_localization_revision"));assertTrue(m.contains("projection_hash"));}

    @Test void cp12T50_searchReusesCatalogReadAuthority(){assertTrue(search().contains("API_PRODUCT:READ"));}
    @Test void cp12T51_rebuildRequiresMaintenanceAuthority(){assertTrue(source("src/main/java/com/gsitm/ustra/api/platform/search/application/CatalogSearchAdminService.java").contains("CATALOG_SEARCH:REBUILD"));}
    @Test void cp12T52_rawQueryAbsentFromAuditOutbox(){String s=search();assertFalse(s.contains("AuditService"));assertFalse(s.contains("OutboxService"));}
    @Test void cp12T53_projectionContainsNoRawOpenApiCredentialSecret(){String m=migration().toLowerCase();assertFalse(m.contains("raw_openapi"));assertFalse(m.contains("credential"));assertFalse(m.contains("secret"));}
    @Test void cp12T54_releasePublicationSeparationPreserved(){assertTrue(source("src/test/java/com/gsitm/ustra/api/platform/Cp10AcceptanceIntegrationTest.java").contains("catalogPublicationRemainsSeparateFromRelease"));}
    @Test void cp12T55_localeFallbackServiceReused(){assertTrue(search().contains("LocalizationResolutionService"));}
    @Test void cp12T56_entitlementNotCatalogVisibilityShortcut(){String s=search();assertFalse(s.contains("EntitlementRepository"));assertFalse(s.contains("ReadyToUse"));}
    @Test void cp12T57_rawOpenApiNonPersistenceRegression(){assertTrue(source("src/test/java/com/gsitm/ustra/api/platform/Cp09AcceptanceIntegrationTest.java").toLowerCase().contains("raw"));}
    @Test void cp12T58_cp10ReviewReleasePublicationSeparationRegression(){assertTrue(Files.exists(ROOT.resolve("src/test/java/com/gsitm/ustra/api/platform/Cp10AcceptanceIntegrationTest.java")));}
    @Test void cp12T59_cp11PinnedVersionNoAutoUpgradeRegression(){assertFalse(source("src/main/java/com/gsitm/ustra/api/platform/change/application/ConsumerImpactService.java").toLowerCase().contains("recommended"));}
    @Test void cp12T60_cp01ThroughCp11RegressionStillRequired(){assertTrue(source("../scripts/verify_runtime_evidence.py").contains("Cp11AcceptanceIntegrationTest"));assertTrue(source("../scripts/verify_runtime_evidence.py").contains("Cp12AcceptanceIntegrationTest"));}
}

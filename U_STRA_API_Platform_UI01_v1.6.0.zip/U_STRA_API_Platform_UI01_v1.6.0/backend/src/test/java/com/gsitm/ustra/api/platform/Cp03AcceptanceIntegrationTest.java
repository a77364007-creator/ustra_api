package com.gsitm.ustra.api.platform;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.reset;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gsitm.ustra.api.platform.audit.AuditRecordRepository;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiEntity;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiOperationEntity;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiOperationRepository;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiProductEntity;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiProductRepository;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiRepository;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiVersionEntity;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiVersionRepository;
import com.gsitm.ustra.api.platform.catalog.persistence.ProviderEntity;
import com.gsitm.ustra.api.platform.catalog.persistence.ProviderRepository;
import com.gsitm.ustra.api.platform.catalog.domain.ApiVersionState;
import com.gsitm.ustra.api.platform.catalog.publication.application.CatalogPublicationService;
import com.gsitm.ustra.api.platform.catalog.publication.application.CatalogVisibilityService;
import com.gsitm.ustra.api.platform.catalog.publication.domain.ApiProductComponentTargetType;
import com.gsitm.ustra.api.platform.catalog.publication.domain.ApiProductVersionState;
import com.gsitm.ustra.api.platform.catalog.publication.domain.AudienceScopeType;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.ApiProductComponentEntity;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.ApiProductComponentRepository;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.ApiProductVersionEntity;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.ApiProductVersionRepository;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.AudienceScopeEntity;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.AudienceScopeRepository;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.CatalogPublicationEntity;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.CatalogPublicationRepository;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.StateTransitionHistoryRepository;
import com.gsitm.ustra.api.platform.outbox.OutboxEventRepository;
import com.gsitm.ustra.api.platform.outbox.OutboxService;
import com.gsitm.ustra.api.platform.tenant.domain.CustomerStatus;
import com.gsitm.ustra.api.platform.tenant.persistence.CustomerEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.CustomerRepository;
import com.gsitm.ustra.api.platform.tenant.persistence.MembershipEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.MembershipRepository;
import com.gsitm.ustra.api.platform.tenant.persistence.OrganizationEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.OrganizationRepository;
import com.gsitm.ustra.api.platform.tenant.persistence.RoleAssignmentEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.RoleAssignmentRepository;
import com.gsitm.ustra.api.platform.tenant.persistence.RoleEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.RoleRepository;
import com.gsitm.ustra.api.platform.tenant.persistence.TenantConfigurationEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.TenantConfigurationRepository;
import com.gsitm.ustra.api.platform.tenant.persistence.TenantEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.TenantRepository;
import jakarta.persistence.EntityManager;
import java.lang.reflect.Field;
import java.time.Duration;
import java.time.Instant;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.bean.override.mockito.MockitoSpyBean;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class Cp03AcceptanceIntegrationTest {
    private static final String API_PRODUCT_OWNER_ROLE_ID = "00000000-0000-0000-0000-000000000003";
    private static final String API_PROVIDER_ROLE_ID = "00000000-0000-0000-0000-000000000004";
    private static final String P_READ = "11000000-0000-0000-0000-000000000001";
    private static final String P_CREATE = "11000000-0000-0000-0000-000000000002";
    private static final String P_UPDATE = "11000000-0000-0000-0000-000000000003";
    private static final String P_PUBLISH = "11000000-0000-0000-0000-000000000004";
    private static final String P_DEPRECATE = "11000000-0000-0000-0000-000000000005";
    private static final Instant NOW = Instant.parse("2026-09-20T00:00:00Z");

    @Autowired MockMvc mvc;
    @Autowired ObjectMapper objectMapper;
    @Autowired JdbcTemplate jdbc;
    @Autowired EntityManager entityManager;
    @Autowired CustomerRepository customerRepository;
    @Autowired TenantRepository tenantRepository;
    @Autowired TenantConfigurationRepository configurationRepository;
    @Autowired MembershipRepository membershipRepository;
    @Autowired OrganizationRepository organizationRepository;
    @Autowired RoleRepository roleRepository;
    @Autowired RoleAssignmentRepository assignmentRepository;
    @Autowired ProviderRepository providerRepository;
    @Autowired ApiProductRepository productRepository;
    @Autowired ApiRepository apiRepository;
    @Autowired ApiVersionRepository apiVersionRepository;
    @Autowired ApiOperationRepository apiOperationRepository;
    @Autowired ApiProductVersionRepository productVersionRepository;
    @Autowired ApiProductComponentRepository componentRepository;
    @Autowired CatalogPublicationRepository publicationRepository;
    @Autowired AudienceScopeRepository audienceRepository;
    @Autowired StateTransitionHistoryRepository historyRepository;
    @Autowired AuditRecordRepository auditRepository;
    @Autowired OutboxEventRepository outboxRepository;
    @Autowired CatalogVisibilityService visibilityService;
    @MockitoSpyBean OutboxService outboxService;

    @BeforeEach
    void setUp() {
        cleanupData();
        resetCp03TestRoleMappings();
    }

    @AfterEach
    void tearDown() {
        reset(outboxService);
        cleanupData();
        removeCp03TestRoleMappings();
    }

    private void cleanupData() {
        audienceRepository.deleteAllInBatch();
        publicationRepository.deleteAllInBatch();
        historyRepository.deleteAllInBatch();
        componentRepository.deleteAllInBatch();
        productVersionRepository.deleteAllInBatch();
        apiOperationRepository.deleteAllInBatch();
        apiVersionRepository.deleteAllInBatch();
        apiRepository.deleteAllInBatch();
        productRepository.deleteAllInBatch();
        providerRepository.deleteAllInBatch();
        assignmentRepository.deleteAllInBatch();
        membershipRepository.deleteAllInBatch();
        organizationRepository.deleteAllInBatch();
        configurationRepository.deleteAllInBatch();
        outboxRepository.deleteAllInBatch();
        auditRepository.deleteAllInBatch();
        tenantRepository.deleteAllInBatch();
        customerRepository.deleteAllInBatch();
    }

    @Test
    void cp03T01_tenantACannotReadTenantBProductVersion() throws Exception {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        Fixture b = fixture("B", "user-b", API_PROVIDER_ROLE_ID);
        ApiProductVersionEntity secret = productVersion(b, product(b, "PB", "Product B"), "v1", ApiProductVersionState.DRAFT);
        mvc.perform(get("/api/v1/api-product-versions/{id}", secret.getId()).header("X-Test-Principal-Id", "user-a"))
                .andExpect(status().isNotFound()).andExpect(jsonPath("$.code").value("API_PRODUCT_VERSION_NOT_FOUND"));
    }

    @Test
    void cp03T02_productVersionCannotReferenceCrossTenantProduct() throws Exception {
        fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        Fixture b = fixture("B", "user-b", API_PROVIDER_ROLE_ID);
        ApiProductEntity other = product(b, "PB", "Product B");
        mvc.perform(post("/api/v1/api-products/{id}/versions", other.getId())
                        .header("X-Test-Principal-Id", "user-a").contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of("version", "v1"))))
                .andExpect(status().isNotFound()).andExpect(jsonPath("$.code").value("API_PRODUCT_NOT_FOUND"));
    }

    @Test
    void cp03T03_duplicateProductVersionRejected() throws Exception {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        ApiProductEntity product = product(a, "P1", "Product");
        productVersion(a, product, "v1", ApiProductVersionState.DRAFT);
        mvc.perform(post("/api/v1/api-products/{id}/versions", product.getId())
                        .header("X-Test-Principal-Id", "user-a").contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of("version", " v1 "))))
                .andExpect(status().isConflict()).andExpect(jsonPath("$.code").value("API_PRODUCT_VERSION_CONFLICT"));
    }

    @Test
    void cp03T04_newProductVersionStartsDraft() throws Exception {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        ApiProductEntity product = product(a, "P1", "Product");
        mvc.perform(post("/api/v1/api-products/{id}/versions", product.getId())
                        .header("X-Test-Principal-Id", "user-a").contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of("version", " 2026.09 "))))
                .andExpect(status().isCreated()).andExpect(header().string("ETag", "\"0\""))
                .andExpect(jsonPath("$.version").value("2026.09"))
                .andExpect(jsonPath("$.lifecycleState").value("DRAFT"));
    }

    @Test
    void cp03T05_staleRevisionCannotChangeComposition() throws Exception {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        ApiProductVersionEntity pv = productVersion(a, product(a, "P1", "Product"), "v1", ApiProductVersionState.DRAFT);
        ApiVersionEntity av = apiVersion(a, api(a, "A1", "API"), "v1", ApiVersionState.RELEASED);
        mvc.perform(post("/api/v1/api-product-versions/{id}/components", pv.getId())
                        .header("X-Test-Principal-Id", "user-a").header("If-Match", "\"0\"")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of("targetType", "API_VERSION", "targetId", av.getId()))))
                .andExpect(status().isCreated());
        mvc.perform(post("/api/v1/api-product-versions/{id}/components", pv.getId())
                        .header("X-Test-Principal-Id", "user-a").header("If-Match", "\"0\"")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of("targetType", "API_VERSION", "targetId", av.getId()))))
                .andExpect(status().isConflict()).andExpect(jsonPath("$.code").value("CONCURRENT_MODIFICATION"));
    }

    @Test
    void cp03T06_releasedProductVersionCompositionMutationRejected() throws Exception {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        ApiProductVersionEntity pv = productVersion(a, product(a, "P1", "Product"), "v1", ApiProductVersionState.RELEASED);
        ApiVersionEntity av = apiVersion(a, api(a, "A1", "API"), "v1", ApiVersionState.RELEASED);
        mvc.perform(post("/api/v1/api-product-versions/{id}/components", pv.getId())
                        .header("X-Test-Principal-Id", "user-a").header("If-Match", "\"0\"")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of("targetType", "API_VERSION", "targetId", av.getId()))))
                .andExpect(status().isConflict()).andExpect(jsonPath("$.code").value("API_PRODUCT_VERSION_STATE_INVALID"));
    }

    @Test
    void cp03T07_multipleReleasedProductVersionsMayCoexist() throws Exception {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        ApiProductEntity product = product(a, "P1", "Product");
        ApiProductVersionEntity v1 = productVersion(a, product, "v1", ApiProductVersionState.APPROVED);
        ApiProductVersionEntity v2 = productVersion(a, product, "v2", ApiProductVersionState.APPROVED);
        release(a, v1, 0);
        release(a, v2, 0);
        assertEquals(2, productVersionRepository.findAllByTenantIdAndApiProductIdOrderByCreatedAtAsc(a.tenant().getId(), product.getId())
                .stream().filter(v -> v.getLifecycleState() == ApiProductVersionState.RELEASED).count());
    }

    @Test
    void cp03T08_productVersionStateIndependentFromApiVersionState() {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        ApiProductVersionEntity pv = productVersion(a, product(a, "P1", "Product"), "business-v1", ApiProductVersionState.DRAFT);
        ApiVersionEntity av = apiVersion(a, api(a, "A1", "API"), "technical-v9", ApiVersionState.RELEASED);
        assertEquals(ApiProductVersionState.DRAFT, pv.getLifecycleState());
        assertEquals(ApiVersionState.RELEASED, av.getState());
    }

    @Test
    void cp03T09_componentMayPinApiVersion() throws Exception {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        ApiProductVersionEntity pv = productVersion(a, product(a, "P1", "Product"), "v1", ApiProductVersionState.DRAFT);
        ApiVersionEntity av = apiVersion(a, api(a, "A1", "API"), "v1", ApiVersionState.RELEASED);
        mvc.perform(post("/api/v1/api-product-versions/{id}/components", pv.getId())
                        .header("X-Test-Principal-Id", "user-a").header("If-Match", "\"0\"")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of("targetType", "API_VERSION", "targetId", av.getId()))))
                .andExpect(status().isCreated()).andExpect(jsonPath("$.targetType").value("API_VERSION"))
                .andExpect(jsonPath("$.targetId").value(av.getId()));
    }

    @Test
    void cp03T10_componentMayPinApiOperation() throws Exception {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        ApiProductVersionEntity pv = productVersion(a, product(a, "P1", "Product"), "v1", ApiProductVersionState.DRAFT);
        ApiVersionEntity av = apiVersion(a, api(a, "A1", "API"), "v1", ApiVersionState.RELEASED);
        ApiOperationEntity op = operation(a, av, "GET", "/orders", "/orders");
        mvc.perform(post("/api/v1/api-product-versions/{id}/components", pv.getId())
                        .header("X-Test-Principal-Id", "user-a").header("If-Match", "\"0\"")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of("targetType", "API_OPERATION", "targetId", op.getId()))))
                .andExpect(status().isCreated()).andExpect(jsonPath("$.targetType").value("API_OPERATION"))
                .andExpect(jsonPath("$.targetId").value(op.getId()));
    }

    @Test
    void cp03T11_componentMustHaveExactlyOneTargetAtDbLevel() {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        ApiProductVersionEntity pv = productVersion(a, product(a, "P1", "Product"), "v1", ApiProductVersionState.DRAFT);
        ApiVersionEntity av = apiVersion(a, api(a, "A1", "API"), "v1", ApiVersionState.RELEASED);
        ApiOperationEntity op = operation(a, av, "GET", "/orders", "/orders");
        ApiProductComponentEntity invalid = new ApiProductComponentEntity(UUID.randomUUID().toString(),
                a.tenant().getId(), pv.getId(), ApiProductComponentTargetType.API_VERSION, null, op.getId(), NOW, "fixture");
        assertThrows(DataIntegrityViolationException.class, () -> componentRepository.saveAndFlush(invalid));
    }

    @Test
    void cp03T12_crossTenantTechnicalTargetRejected() throws Exception {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        Fixture b = fixture("B", "user-b", API_PROVIDER_ROLE_ID);
        ApiProductVersionEntity pv = productVersion(a, product(a, "P1", "Product"), "v1", ApiProductVersionState.DRAFT);
        ApiVersionEntity foreign = apiVersion(b, api(b, "B1", "API B"), "v1", ApiVersionState.RELEASED);
        mvc.perform(post("/api/v1/api-product-versions/{id}/components", pv.getId())
                        .header("X-Test-Principal-Id", "user-a").header("If-Match", "\"0\"")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of("targetType", "API_VERSION", "targetId", foreign.getId()))))
                .andExpect(status().isBadRequest()).andExpect(jsonPath("$.code").value("API_VERSION_NOT_FOUND"));
    }

    @Test
    void cp03T13_productDoesNotGainDirectTechnicalApiCompositionField() {
        assertFalse(Arrays.stream(ApiProductEntity.class.getDeclaredFields()).map(Field::getName)
                .anyMatch(name -> name.equals("apiId") || name.equals("apiIds") || name.equals("apiVersionId")));
    }

    @Test
    void cp03T14_publicationCannotReferenceCrossTenantProductVersion() throws Exception {
        fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        Fixture b = fixture("B", "user-b", API_PROVIDER_ROLE_ID);
        ApiProductVersionEntity foreign = productVersion(b, product(b, "PB", "Product B"), "v1", ApiProductVersionState.RELEASED);
        mvc.perform(post("/api/v1/catalog-publications").header("X-Test-Principal-Id", "user-a")
                        .contentType(MediaType.APPLICATION_JSON).content(publicationJson(foreign.getId(), "TENANT", null)))
                .andExpect(status().isBadRequest()).andExpect(jsonPath("$.code").value("API_PRODUCT_VERSION_NOT_FOUND"));
    }

    @Test
    void cp03T15_unreleasedProductVersionCannotActivatePublication() throws Exception {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        ApiProductVersionEntity pv = productVersion(a, product(a, "P1", "Product"), "v1", ApiProductVersionState.DRAFT);
        CatalogPublicationEntity pub = createPublication(a, pv, "TENANT", null);
        mvc.perform(post("/api/v1/catalog-publications/{id}/activate", pub.getId())
                        .header("X-Test-Principal-Id", "user-a").header("If-Match", "\"0\""))
                .andExpect(status().isConflict()).andExpect(jsonPath("$.code").value("CATALOG_PUBLICATION_STATE_INVALID"));
    }

    @Test
    void cp03T16_activeTenantPublicationVisibleOnlyInMatchingTenant() throws Exception {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        Fixture b = fixture("B", "user-b", API_PROVIDER_ROLE_ID);
        ApiProductVersionEntity pv = productVersion(a, product(a, "P1", "Product"), "v1", ApiProductVersionState.RELEASED);
        CatalogPublicationEntity pub = createPublication(a, pv, "TENANT", null);
        activate(a, pub, 0);
        assertTrue(visibilityService.isDiscoverable(a.tenant().getId(), null, pub.getId()));
        assertFalse(visibilityService.isDiscoverable(b.tenant().getId(), null, pub.getId()));
    }

    @Test
    void cp03T17_orgScopedPublicationDoesNotLeakAcrossOrganizations() throws Exception {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        OrganizationEntity org1 = organization(a, "ORG1");
        OrganizationEntity org2 = organization(a, "ORG2");
        ApiProductVersionEntity pv = productVersion(a, product(a, "P1", "Product"), "v1", ApiProductVersionState.RELEASED);
        CatalogPublicationEntity pub = createPublication(a, pv, "ORGANIZATION", org1.getId());
        activate(a, pub, 0);
        assertTrue(visibilityService.isDiscoverable(a.tenant().getId(), org1.getId(), pub.getId()));
        assertFalse(visibilityService.isDiscoverable(a.tenant().getId(), org2.getId(), pub.getId()));
    }

    @Test
    void cp03T18_suspendedPublicationIsNotDiscoverable() throws Exception {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        ApiProductVersionEntity pv = productVersion(a, product(a, "P1", "Product"), "v1", ApiProductVersionState.RELEASED);
        CatalogPublicationEntity pub = createPublication(a, pv, "TENANT", null);
        pub = activate(a, pub, 0);
        suspend(a, pub, pub.getRowVersion());
        assertFalse(visibilityService.isDiscoverable(a.tenant().getId(), null, pub.getId()));
    }

    @Test
    void cp03T19_suspensionDoesNotRetireProductVersion() throws Exception {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        ApiProductVersionEntity pv = productVersion(a, product(a, "P1", "Product"), "v1", ApiProductVersionState.RELEASED);
        CatalogPublicationEntity pub = activate(a, createPublication(a, pv, "TENANT", null), 0);
        suspend(a, pub, pub.getRowVersion());
        assertEquals(ApiProductVersionState.RELEASED, productVersionRepository.findById(pv.getId()).orElseThrow().getLifecycleState());
    }

    @Test
    void cp03T20_suspensionHasNoEntitlementDependencyOrRevocationSideEffectInCp03() {
        assertFalse(Arrays.stream(CatalogPublicationService.class.getDeclaredFields())
                .map(f -> (f.getName() + f.getType().getName()).toLowerCase()).anyMatch(s -> s.contains("entitlement")));
    }

    @Test
    void cp03T21_withdrawnPublicationBlocksDiscovery() throws Exception {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        ApiProductVersionEntity pv = productVersion(a, product(a, "P1", "Product"), "v1", ApiProductVersionState.RELEASED);
        CatalogPublicationEntity pub = activate(a, createPublication(a, pv, "TENANT", null), 0);
        pub = suspend(a, pub, pub.getRowVersion());
        withdraw(a, pub, pub.getRowVersion());
        assertFalse(visibilityService.isDiscoverable(a.tenant().getId(), null, pub.getId()));
    }

    @Test
    void cp03T22_publicationStateIndependentFromProductVersionState() throws Exception {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        ApiProductVersionEntity pv = productVersion(a, product(a, "P1", "Product"), "v1", ApiProductVersionState.RELEASED);
        CatalogPublicationEntity pub = activate(a, createPublication(a, pv, "TENANT", null), 0);
        pub = suspend(a, pub, pub.getRowVersion());
        assertEquals("SUSPENDED", publicationRepository.findById(pub.getId()).orElseThrow().getLifecycleState().name());
        assertEquals(ApiProductVersionState.RELEASED, productVersionRepository.findById(pv.getId()).orElseThrow().getLifecycleState());
    }

    @Test
    void cp03T23_releasePersistsHistoryAuditAndNamedOutboxAtomically() throws Exception {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        ApiProductVersionEntity pv = productVersion(a, product(a, "P1", "Product"), "v1", ApiProductVersionState.APPROVED);
        release(a, pv, 0);
        assertEquals(1, historyRepository.findAllByTenantIdAndAggregateTypeAndAggregateIdOrderByOccurredAtAsc(
                a.tenant().getId(), "API_PRODUCT_VERSION", pv.getId()).size());
        assertTrue(auditRepository.findAllByTenantIdOrderByOccurredAtAsc(a.tenant().getId()).stream()
                .anyMatch(x -> x.getAction().equals("API_PRODUCT_VERSION_RELEASE") && x.getResourceId().equals(pv.getId())));
        assertTrue(outboxRepository.findAll().stream().anyMatch(x -> x.getEventType().equals("APIProductVersionReleased")
                && x.getAggregateId().equals(pv.getId())));
    }

    @Test
    void cp03T24_activationPersistsHistoryAuditAndNamedOutboxAtomically() throws Exception {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        ApiProductVersionEntity pv = productVersion(a, product(a, "P1", "Product"), "v1", ApiProductVersionState.RELEASED);
        CatalogPublicationEntity pub = createPublication(a, pv, "TENANT", null);
        activate(a, pub, 0);
        assertEquals(1, historyRepository.findAllByTenantIdAndAggregateTypeAndAggregateIdOrderByOccurredAtAsc(
                a.tenant().getId(), "CATALOG_PUBLICATION", pub.getId()).size());
        assertTrue(auditRepository.findAllByTenantIdOrderByOccurredAtAsc(a.tenant().getId()).stream()
                .anyMatch(x -> x.getAction().equals("CATALOG_PUBLICATION_ACTIVATE") && x.getResourceId().equals(pub.getId())));
        assertTrue(outboxRepository.findAll().stream().anyMatch(x -> x.getEventType().equals("CatalogPublicationActivated")
                && x.getAggregateId().equals(pub.getId())));
    }

    @Test
    void cp03T25_releaseRollbackRemovesStateHistoryAuditAndOutboxTogether() throws Exception {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        ApiProductVersionEntity pv = productVersion(a, product(a, "P1", "Product"), "v1", ApiProductVersionState.APPROVED);
        doThrow(new IllegalStateException("force rollback")).when(outboxService).enqueue(
                eq("APIProductVersionReleased"), eq("API_PRODUCT_VERSION"), eq(pv.getId()), eq(a.tenant().getId()), anyMap());
        mvc.perform(post("/api/v1/api-product-versions/{id}/release", pv.getId())
                        .header("X-Test-Principal-Id", "user-a").header("If-Match", "\"0\""))
                .andExpect(status().isInternalServerError());
        entityManager.clear();
        assertEquals(ApiProductVersionState.APPROVED, productVersionRepository.findById(pv.getId()).orElseThrow().getLifecycleState());
        assertEquals(0, historyRepository.findAllByTenantIdAndAggregateTypeAndAggregateIdOrderByOccurredAtAsc(
                a.tenant().getId(), "API_PRODUCT_VERSION", pv.getId()).size());
        assertFalse(auditRepository.findAllByTenantIdOrderByOccurredAtAsc(a.tenant().getId()).stream()
                .anyMatch(x -> x.getAction().equals("API_PRODUCT_VERSION_RELEASE") && x.getResourceId().equals(pv.getId())));
        assertFalse(outboxRepository.findAll().stream().anyMatch(x -> x.getAggregateId().equals(pv.getId())));
    }

    @Test
    void cp03T26_staleEtagCannotMutatePublication() throws Exception {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        ApiProductVersionEntity pv = productVersion(a, product(a, "P1", "Product"), "v1", ApiProductVersionState.RELEASED);
        CatalogPublicationEntity pub = activate(a, createPublication(a, pv, "TENANT", null), 0);
        mvc.perform(post("/api/v1/catalog-publications/{id}/suspend", pub.getId())
                        .header("X-Test-Principal-Id", "user-a").header("If-Match", "\"0\""))
                .andExpect(status().isConflict()).andExpect(jsonPath("$.code").value("CONCURRENT_MODIFICATION"));
    }

    @Test
    void cp03T27_unauthorizedDirectActionDeniedByBackend() throws Exception {
        Fixture owner = fixture("A", "user-a", API_PRODUCT_OWNER_ROLE_ID);
        ApiProductVersionEntity pv = productVersion(owner, product(owner, "P1", "Product"), "v1", ApiProductVersionState.RELEASED);
        CatalogPublicationEntity pub = publication(owner, pv, AudienceScopeType.TENANT, null);
        mvc.perform(post("/api/v1/catalog-publications/{id}/activate", pub.getId())
                        .header("X-Test-Principal-Id", "user-a").header("If-Match", "\"0\""))
                .andExpect(status().isForbidden()).andExpect(jsonPath("$.code").value("ACCESS_DENIED"));
    }

    @Test
    void cp03N01_suspendedPublicationMayReactivateAfterPrerequisiteRecheck() throws Exception {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        ApiProductVersionEntity pv = productVersion(a, product(a, "P1", "Product"), "v1", ApiProductVersionState.RELEASED);
        CatalogPublicationEntity pub = activate(a, createPublication(a, pv, "TENANT", null), 0);
        pub = suspend(a, pub, pub.getRowVersion());
        CatalogPublicationEntity resumed = activate(a, pub, pub.getRowVersion());
        assertEquals("ACTIVE", resumed.getLifecycleState().name());
        assertTrue(visibilityService.isDiscoverable(a.tenant().getId(), null, resumed.getId()));
    }

    @Test
    void cp03N02_tenantAndOrganizationAudienceCannotBeMixed() throws Exception {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        OrganizationEntity org = organization(a, "ORG1");
        ApiProductVersionEntity pv = productVersion(a, product(a, "P1", "Product"), "v1", ApiProductVersionState.RELEASED);
        Map<String, Object> body = Map.of(
                "apiProductVersionId", pv.getId(),
                "audienceScopes", List.of(Map.of("type", "TENANT"),
                        Map.of("type", "ORGANIZATION", "organizationId", org.getId())));
        mvc.perform(post("/api/v1/catalog-publications").header("X-Test-Principal-Id", "user-a")
                        .contentType(MediaType.APPLICATION_JSON).content(json(body)))
                .andExpect(status().isBadRequest()).andExpect(jsonPath("$.code").value("AUDIENCE_SCOPE_MIXED"));
    }

    @Test
    void cp03N03_crossTenantOrganizationAudienceRejected() throws Exception {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        Fixture b = fixture("B", "user-b", API_PROVIDER_ROLE_ID);
        OrganizationEntity foreignOrg = organization(b, "ORG-B");
        ApiProductVersionEntity pv = productVersion(a, product(a, "P1", "Product"), "v1", ApiProductVersionState.RELEASED);
        mvc.perform(post("/api/v1/catalog-publications").header("X-Test-Principal-Id", "user-a")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(publicationJson(pv.getId(), "ORGANIZATION", foreignOrg.getId())))
                .andExpect(status().isBadRequest()).andExpect(jsonPath("$.code").value("AUDIENCE_SCOPE_INVALID"));
    }

    @Test
    void cp03N04_withdrawnPublicationCannotReactivate() throws Exception {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        ApiProductVersionEntity pv = productVersion(a, product(a, "P1", "Product"), "v1", ApiProductVersionState.RELEASED);
        CatalogPublicationEntity pub = activate(a, createPublication(a, pv, "TENANT", null), 0);
        pub = suspend(a, pub, pub.getRowVersion());
        pub = withdraw(a, pub, pub.getRowVersion());
        mvc.perform(post("/api/v1/catalog-publications/{id}/activate", pub.getId())
                        .header("X-Test-Principal-Id", "user-a")
                        .header("If-Match", "\"" + pub.getRowVersion() + "\""))
                .andExpect(status().isConflict()).andExpect(jsonPath("$.code").value("CATALOG_PUBLICATION_STATE_INVALID"));
    }

    private void resetCp03TestRoleMappings() {
        removeCp03TestRoleMappings();
        for (String p : List.of(P_READ, P_CREATE, P_UPDATE, P_PUBLISH)) {
            jdbc.update("INSERT INTO role_permission(role_id, permission_id) VALUES (?, ?)", API_PROVIDER_ROLE_ID, p);
        }
        jdbc.update("INSERT INTO role_permission(role_id, permission_id) VALUES (?, ?)", API_PRODUCT_OWNER_ROLE_ID, P_READ);
    }

    private void removeCp03TestRoleMappings() {
        for (String role : List.of(API_PROVIDER_ROLE_ID, API_PRODUCT_OWNER_ROLE_ID)) {
            for (String permission : List.of(P_READ, P_CREATE, P_UPDATE, P_PUBLISH, P_DEPRECATE)) {
                jdbc.update("DELETE FROM role_permission WHERE role_id = ? AND permission_id = ?", role, permission);
            }
        }
    }

    private Fixture fixture(String suffix, String principal, String roleId) {
        CustomerEntity customer = customerRepository.saveAndFlush(new CustomerEntity(UUID.randomUUID().toString(),
                "C-" + suffix, "Customer " + suffix, CustomerStatus.ACTIVE, NOW));
        TenantEntity tenant = new TenantEntity(UUID.randomUUID().toString(), customer.getId(), "T-" + suffix,
                "Tenant " + suffix, "ko-KR", "Asia/Seoul", NOW);
        tenant.activate(NOW);
        tenant = tenantRepository.saveAndFlush(tenant);
        configurationRepository.saveAndFlush(new TenantConfigurationEntity(UUID.randomUUID().toString(),
                tenant.getId(), "ko-KR", "Asia/Seoul", NOW));
        MembershipEntity membership = membershipRepository.saveAndFlush(new MembershipEntity(UUID.randomUUID().toString(),
                tenant.getId(), null, principal, "local-test", NOW.minus(Duration.ofDays(1)), null, NOW));
        RoleEntity role = roleRepository.findById(roleId).orElseThrow();
        assignmentRepository.saveAndFlush(new RoleAssignmentEntity(UUID.randomUUID().toString(), tenant.getId(),
                membership.getId(), role.getId(), null, NOW.minusSeconds(60), null, "fixture", NOW));
        return new Fixture(customer, tenant, membership);
    }

    private ApiProductEntity product(Fixture f, String code, String name) {
        return productRepository.saveAndFlush(new ApiProductEntity(UUID.randomUUID().toString(), f.tenant().getId(),
                code, code, name, null, null, null, NOW, "fixture"));
    }

    private ApiEntity api(Fixture f, String code, String name) {
        return apiRepository.saveAndFlush(new ApiEntity(UUID.randomUUID().toString(), f.tenant().getId(), code, code,
                name, null, null, NOW, "fixture"));
    }

    private ApiVersionEntity apiVersion(Fixture f, ApiEntity api, String value, ApiVersionState state) {
        return apiVersionRepository.saveAndFlush(new ApiVersionEntity(UUID.randomUUID().toString(), f.tenant().getId(),
                api.getId(), value, state, NOW, "fixture"));
    }

    private ApiOperationEntity operation(Fixture f, ApiVersionEntity version, String method, String path, String normalizedPath) {
        return apiOperationRepository.saveAndFlush(new ApiOperationEntity(UUID.randomUUID().toString(), f.tenant().getId(),
                version.getId(), method, path, normalizedPath, null, null, NOW, "fixture"));
    }

    private ApiProductVersionEntity productVersion(Fixture f, ApiProductEntity product, String value, ApiProductVersionState state) {
        ApiProductVersionEntity entity = productVersionRepository.saveAndFlush(new ApiProductVersionEntity(
                UUID.randomUUID().toString(), f.tenant().getId(), product.getId(), value, NOW, "fixture"));
        if (state != ApiProductVersionState.DRAFT) {
            jdbc.update("UPDATE api_product_version SET lifecycle_state = ? WHERE api_product_version_id = ?", state.name(), entity.getId());
            entityManager.clear();
            entity = productVersionRepository.findById(entity.getId()).orElseThrow();
        }
        return entity;
    }

    private OrganizationEntity organization(Fixture f, String code) {
        return organizationRepository.saveAndFlush(new OrganizationEntity(UUID.randomUUID().toString(),
                f.tenant().getId(), code, code, null, NOW));
    }

    private CatalogPublicationEntity publication(Fixture f, ApiProductVersionEntity pv,
                                                  AudienceScopeType type, String organizationId) {
        CatalogPublicationEntity pub = publicationRepository.saveAndFlush(new CatalogPublicationEntity(
                UUID.randomUUID().toString(), f.tenant().getId(), pv.getId(), NOW, "fixture"));
        audienceRepository.saveAndFlush(new AudienceScopeEntity(UUID.randomUUID().toString(), f.tenant().getId(),
                pub.getId(), type, organizationId, NOW, "fixture"));
        return pub;
    }

    private CatalogPublicationEntity createPublication(Fixture f, ApiProductVersionEntity pv,
                                                        String scopeType, String organizationId) throws Exception {
        String body = publicationJson(pv.getId(), scopeType, organizationId);
        String location = mvc.perform(post("/api/v1/catalog-publications").header("X-Test-Principal-Id", principal(f))
                        .contentType(MediaType.APPLICATION_JSON).content(body))
                .andExpect(status().isCreated()).andReturn().getResponse().getContentAsString();
        String id = objectMapper.readTree(location).get("catalogPublicationId").asText();
        return publicationRepository.findById(id).orElseThrow();
    }

    private ApiProductVersionEntity release(Fixture f, ApiProductVersionEntity pv, long revision) throws Exception {
        mvc.perform(post("/api/v1/api-product-versions/{id}/release", pv.getId())
                        .header("X-Test-Principal-Id", principal(f)).header("If-Match", "\"" + revision + "\""))
                .andExpect(status().isOk());
        entityManager.clear();
        return productVersionRepository.findById(pv.getId()).orElseThrow();
    }

    private CatalogPublicationEntity activate(Fixture f, CatalogPublicationEntity pub, long revision) throws Exception {
        mvc.perform(post("/api/v1/catalog-publications/{id}/activate", pub.getId())
                        .header("X-Test-Principal-Id", principal(f)).header("If-Match", "\"" + revision + "\""))
                .andExpect(status().isOk());
        entityManager.clear();
        return publicationRepository.findById(pub.getId()).orElseThrow();
    }

    private CatalogPublicationEntity suspend(Fixture f, CatalogPublicationEntity pub, long revision) throws Exception {
        mvc.perform(post("/api/v1/catalog-publications/{id}/suspend", pub.getId())
                        .header("X-Test-Principal-Id", principal(f)).header("If-Match", "\"" + revision + "\""))
                .andExpect(status().isOk());
        entityManager.clear();
        return publicationRepository.findById(pub.getId()).orElseThrow();
    }

    private CatalogPublicationEntity withdraw(Fixture f, CatalogPublicationEntity pub, long revision) throws Exception {
        mvc.perform(post("/api/v1/catalog-publications/{id}/withdraw", pub.getId())
                        .header("X-Test-Principal-Id", principal(f)).header("If-Match", "\"" + revision + "\""))
                .andExpect(status().isOk());
        entityManager.clear();
        return publicationRepository.findById(pub.getId()).orElseThrow();
    }

    private String principal(Fixture f) {
        return f.membership().getPrincipalId();
    }

    private String publicationJson(String productVersionId, String type, String organizationId) throws Exception {
        Map<String, Object> scope = organizationId == null ? Map.of("type", type)
                : Map.of("type", type, "organizationId", organizationId);
        return json(Map.of("apiProductVersionId", productVersionId, "audienceScopes", List.of(scope)));
    }

    private String json(Object value) throws Exception {
        return objectMapper.writeValueAsString(value);
    }

    private record Fixture(CustomerEntity customer, TenantEntity tenant, MembershipEntity membership) {}
}

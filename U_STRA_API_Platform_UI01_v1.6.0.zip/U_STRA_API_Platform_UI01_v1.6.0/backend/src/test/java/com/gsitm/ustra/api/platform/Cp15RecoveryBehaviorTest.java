package com.gsitm.ustra.api.platform;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import com.gsitm.ustra.api.platform.audit.AuditService;
import com.gsitm.ustra.api.platform.common.error.*;
import com.gsitm.ustra.api.platform.operations.application.*;
import com.gsitm.ustra.api.platform.operations.domain.*;
import com.gsitm.ustra.api.platform.operations.persistence.*;
import com.gsitm.ustra.api.platform.integration.approval.application.*;
import com.gsitm.ustra.api.platform.integration.approval.domain.*;
import com.gsitm.ustra.api.platform.integration.gateway.application.*;
import com.gsitm.ustra.api.platform.search.application.*;
import com.gsitm.ustra.api.platform.subscription.approval.application.ApprovalPort;
import com.gsitm.ustra.api.platform.tenant.context.*;
import com.gsitm.ustra.api.platform.tenant.application.TenantPermissionGuard;
import com.gsitm.ustra.api.platform.tenant.persistence.*;
import java.time.*;
import java.util.*;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;

class Cp15RecoveryBehaviorTest {
    static final String TENANT=Cp15SafetyBehaviorTest.TENANT;
    static final String TARGET=Cp15SafetyBehaviorTest.PRODUCT;
    static final Instant NOW=Cp15SafetyBehaviorTest.NOW;
    static TenantContext context(){return new TenantContext(TENANT,"tenant","customer","org","actor","member",Set.of("role"),"ko","request","correlation");}
    static RecoveryRequest request(){return new RecoveryRequest(RecoveryActionType.SEARCH_PRODUCT_REINDEX,TARGET,null);}
    @Test void cp15T35_fourActionTypesAndNoForceStatus() {
        assertEquals(4,RecoveryActionType.values().length);
        assertThrows(IllegalArgumentException.class,()->RecoveryActionType.valueOf("GATEWAY_PROVISION"));
        assertThrows(IllegalArgumentException.class,()->new RecoveryRequest(null,TARGET,null).validated());
    }
    @Test void cp15T39_fingerprintBindsActionTargetAndExpectedVersion() {
        var r=request();assertEquals(r.fingerprint(),new RecoveryRequest(r.actionType(),TARGET.toUpperCase(),null).fingerprint());
        assertNotEquals(r.fingerprint(),new RecoveryRequest(r.actionType(),TARGET,1L).fingerprint());
        assertNotEquals(r.fingerprint(),new RecoveryRequest(RecoveryActionType.GATEWAY_STATUS_RECONCILE,TARGET,null).fingerprint());
    }
    @Test void cp15T07_keyAndTargetBoundsRejectRatherThanNormalizeAuthority() {
        assertThrows(IllegalArgumentException.class,()->RecoveryRequest.validateKey(" "));
        assertThrows(IllegalArgumentException.class,()->RecoveryRequest.validateKey("x".repeat(201)));
        assertThrows(IllegalArgumentException.class,()->RecoveryRequest.validateKey("key\nline"));
        assertEquals("CaseSensitive",RecoveryRequest.validateKey("CaseSensitive"));
        assertThrows(IllegalArgumentException.class,()->new RecoveryRequest(RecoveryActionType.SEARCH_PRODUCT_REINDEX,"../other",null).validated());
    }
    @Test void cp15T38_duplicateKeyReturnsSameJournalBeforeChangedTargetValidation() {
        var repo=mock(OperationsRecoveryActionRepository.class);var tenants=mock(TenantRepository.class);
        var targets=mock(RecoveryTargetValidator.class);var audit=mock(AuditService.class);
        var row=new OperationsRecoveryActionEntity("id",TENANT,"key",request(),"actor","correlation",NOW);
        when(tenants.lockById(TENANT)).thenReturn(Optional.of(mock(TenantEntity.class)));
        when(repo.findByTenantIdAndIdempotencyKey(TENANT,"key")).thenReturn(Optional.of(row));
        var service=new RecoveryActionService(repo,tenants,targets,audit,Cp15SafetyBehaviorTest.CLOCK);
        var replay=service.prepare(context(),"key",request());
        assertFalse(replay.created());assertSame(row,replay.row());verifyNoInteractions(targets);verify(repo,never()).saveAndFlush(any());
    }
    @Test void cp15T39_conflictingKeyNeverMutatesOriginal() {
        var repo=mock(OperationsRecoveryActionRepository.class);var tenants=mock(TenantRepository.class);
        when(tenants.lockById(TENANT)).thenReturn(Optional.of(mock(TenantEntity.class)));
        var row=new OperationsRecoveryActionEntity("id",TENANT,"key",request(),"actor","correlation",NOW);
        when(repo.findByTenantIdAndIdempotencyKey(TENANT,"key")).thenReturn(Optional.of(row));
        var service=new RecoveryActionService(repo,tenants,mock(RecoveryTargetValidator.class),mock(AuditService.class),Cp15SafetyBehaviorTest.CLOCK);
        var ex=assertThrows(BusinessException.class,()->service.prepare(context(),"key",new RecoveryRequest(request().actionType(),TARGET,1L)));
        assertEquals(ErrorCode.IDEMPOTENCY_KEY_CONFLICT,ex.code());verify(repo,never()).saveAndFlush(any());
    }
    @Test void cp15T40_claimHasOneWinnerAndNoTerminalReclaim() {
        var row=new OperationsRecoveryActionEntity("id",TENANT,"key",request(),"actor","correlation",NOW);
        assertTrue(row.claim(NOW));assertFalse(row.claim(NOW));
        row.complete(RecoveryActionStatus.SUCCEEDED,"REINDEX_COMPLETED",null,"DONE",NOW);
        assertFalse(row.claim(NOW));assertNull(row.getActiveTargetKey());
    }
    @Test void cp15T43_unknownRetainsClaimWithoutClockBasedReclaim() {
        var row=new OperationsRecoveryActionEntity("id",TENANT,"key",request(),"actor","correlation",NOW);
        row.claim(NOW);row.complete(RecoveryActionStatus.UNKNOWN,null,null,"UNKNOWN",NOW);
        assertNotNull(row.getActiveTargetKey());assertNull(row.getCompletedAt());
        assertFalse(row.claim(NOW.plus(Duration.ofDays(100))));
    }
    @Test void cp15T40_searchTenantAndProductUseSameManualMutex() {
        assertEquals(RecoveryActionType.SEARCH_PRODUCT_REINDEX.activeKey(TENANT,TARGET),RecoveryActionType.SEARCH_TENANT_REBUILD.activeKey(TENANT,TENANT));
    }
    static class OrchestratorFixture {
        final TenantContextResolver contexts=mock(TenantContextResolver.class);
        final TenantPermissionGuard permissions=mock(TenantPermissionGuard.class);
        final RecoveryTargetValidator targets=mock(RecoveryTargetValidator.class);
        final RecoveryActionService journal=mock(RecoveryActionService.class);
        final ApprovalIntegrationOrchestrator approval=mock(ApprovalIntegrationOrchestrator.class);
        final GatewayIntegrationOrchestrator gateway=mock(GatewayIntegrationOrchestrator.class);
        final SearchProjectionRecoveryService search=mock(SearchProjectionRecoveryService.class);
        final AuditService audit=mock(AuditService.class);
        final RecoveryActionOrchestrator service=new RecoveryActionOrchestrator(contexts,permissions,targets,journal,approval,gateway,search,audit);
        final OperationsRecoveryActionEntity row;
        OrchestratorFixture(RecoveryRequest request) {
            when(contexts.resolve()).thenReturn(context());
            row=new OperationsRecoveryActionEntity("id",TENANT,"key",request,"actor","correlation",NOW);
            when(journal.prepare(any(),eq("key"),any())).thenReturn(new RecoveryActionService.Prepared(row,true));
            when(journal.claim(TENANT,"id")).thenAnswer(inv->row.claim(NOW));
            when(journal.owned(TENANT,"id")).thenReturn(row);
            when(journal.complete(eq(TENANT),eq("id"),any(),nullable(String.class),nullable(String.class),anyString())).thenAnswer(inv->{
                row.complete(inv.getArgument(2),inv.getArgument(3),inv.getArgument(4),inv.getArgument(5),NOW);
                return RecoveryActionService.View.from(row);
            });
        }
    }
    @Test void cp15T36_operationsReadCannotBypassSourceActionPermission() {
        var f=new OrchestratorFixture(request());
        doThrow(new BusinessException(ErrorCode.ACCESS_DENIED,HttpStatus.FORBIDDEN,"denied")).when(f.permissions)
                .require(any(),eq("CATALOG_SEARCH:REBUILD"),anyString(),anyString());
        assertThrows(BusinessException.class,()->f.service.execute("key",request()));
        verifyNoInteractions(f.journal,f.search,f.approval,f.gateway);
    }
    @Test void cp15T37_invalidTargetAfterClaimNeverInvokesHandler() {
        var f=new OrchestratorFixture(request());
        doThrow(new BusinessException(ErrorCode.CONCURRENT_MODIFICATION,HttpStatus.CONFLICT,"changed")).when(f.targets).validate(TENANT,request());
        assertEquals("FAILED",f.service.execute("key",request()).actionStatus());verifyNoInteractions(f.search);
    }
    @Test void cp15T38_replayNeverReexecutesHandler() {
        var f=new OrchestratorFixture(request());when(f.journal.prepare(any(),anyString(),any())).thenReturn(new RecoveryActionService.Prepared(f.row,false));
        assertEquals("id",f.service.execute("key",request()).recoveryActionId());verifyNoInteractions(f.search);
        verify(f.journal,never()).claim(anyString(),anyString());
    }
    @Test void cp15T42_pendingApprovalIsNotBusinessSuccess() {
        var request=new RecoveryRequest(RecoveryActionType.APPROVAL_STATUS_RECONCILE,TARGET,null);
        var f=new OrchestratorFixture(request);var op=Cp15SafetyBehaviorTest.operation();op.succeed("case",null,NOW,"actor");
        when(f.approval.synchronize(TENANT,TARGET)).thenReturn(new ApprovalIntegrationStateService.DecisionResult(op,ApprovalPort.DecisionStatus.PENDING,null));
        var result=f.service.execute("key",request);
        assertEquals("SUCCEEDED",result.actionStatus());assertEquals("PENDING",result.targetStatus());
    }
    @Test void cp15T44_gatewayReconcileDelegatesQueryOnly() {
        var request=new RecoveryRequest(RecoveryActionType.GATEWAY_STATUS_RECONCILE,TARGET,null);var f=new OrchestratorFixture(request);
        when(f.gateway.reconcile(TENANT,TARGET)).thenReturn(new GatewayIntegrationOrchestrator.Result("operation",IntegrationOperationStatus.UNKNOWN,"UNKNOWN"));
        var result=f.service.execute("key",request);assertEquals("UNKNOWN",result.targetStatus());
        verify(f.gateway).reconcile(TENANT,TARGET);verify(f.gateway,never()).process(anyString(),anyString());
    }
    @Test void cp15T43_handlerThrowsPreservesUnknownWithoutReplay() {
        var f=new OrchestratorFixture(request());when(f.search.reindex(TENANT,TARGET,"actor")).thenThrow(new RuntimeException("raw body"));
        var result=f.service.execute("key",request());assertEquals("UNKNOWN",result.actionStatus());
        assertEquals("HANDLER_OUTCOME_UNCONFIRMED",result.safeResultCode());verify(f.search,times(1)).reindex(TENANT,TARGET,"actor");
    }
    @Test void cp15T15_prepareThenClaimThenHandlerThenResult() {
        var f=new OrchestratorFixture(request());f.service.execute("key",request());
        var sequence=inOrder(f.journal,f.search);sequence.verify(f.journal).prepare(any(),eq("key"),eq(request()));
        sequence.verify(f.journal).claim(TENANT,"id");sequence.verify(f.search).reindex(TENANT,TARGET,"actor");
        sequence.verify(f.journal).complete(TENANT,"id",RecoveryActionStatus.SUCCEEDED,"REINDEX_COMPLETED",null,"SEARCH_REINDEX_COMPLETED");
    }
}

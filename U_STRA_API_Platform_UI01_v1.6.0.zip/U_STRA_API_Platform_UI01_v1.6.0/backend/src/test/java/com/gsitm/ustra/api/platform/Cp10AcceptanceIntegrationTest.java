package com.gsitm.ustra.api.platform;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

/**
 * CP-10 acceptance traceability.
 * Runtime Spring/MariaDB behavior remains subject to Maven/Testcontainers execution.
 */
class Cp10AcceptanceIntegrationTest {
    private static final Path ROOT = Path.of(".").toAbsolutePath().normalize();

    private static String source(String relative) {
        try { return Files.readString(ROOT.resolve(relative)); }
        catch (IOException ex) { throw new AssertionError(ex); }
    }

    private static String publishing() {
        try {
            return Files.walk(ROOT.resolve("src/main/java/com/gsitm/ustra/api/platform/provider/publishing"))
                    .filter(p -> p.toString().endsWith(".java"))
                    .map(p -> {
                        try { return Files.readString(p); }
                        catch (IOException ex) { throw new RuntimeException(ex); }
                    })
                    .reduce("", String::concat);
        } catch (IOException ex) {
            throw new AssertionError(ex);
        }
    }

    private static String reviewService() {
        return source("src/main/java/com/gsitm/ustra/api/platform/provider/publishing/application/PublicationReviewService.java");
    }

    private static String readinessService() {
        return source("src/main/java/com/gsitm/ustra/api/platform/provider/publishing/application/PublishReadinessService.java");
    }

    private static String productizationService() {
        return source("src/main/java/com/gsitm/ustra/api/platform/provider/publishing/application/CandidateProductizationService.java");
    }

    private static String releaseService() {
        return source("src/main/java/com/gsitm/ustra/api/platform/catalog/publication/application/ApiProductVersionService.java");
    }

    @Test void cp10T01_crossTenantProductVersionReviewDoesNotDisclose() {
        assertTrue(reviewService().contains("findByIdAndTenantId(id, context.tenantId())"));
    }
    @Test void cp10T02_crossTenantCandidateCannotLink() {
        assertTrue(productizationService().contains("findByIdAndTenantId(candidateId, context.tenantId())"));
        assertTrue(productizationService().contains("findByIdAndTenantId(apiProductId, context.tenantId())"));
    }
    @Test void cp10T03_reviewSubmitPermissionRequired() {
        assertTrue(reviewService().contains("PUBLICATION_REVIEW:SUBMIT"));
    }
    @Test void cp10T04_reviewDecisionPermissionRequired() {
        assertTrue(reviewService().contains("PUBLICATION_REVIEW:DECIDE"));
        assertFalse(reviewService().contains("SECURITY_REVIEWER"));
    }
    @Test void cp10T05_clientTenantCannotOverride() {
        String c=source("src/main/java/com/gsitm/ustra/api/platform/provider/publishing/api/PublicationReviewController.java")
                +source("src/main/java/com/gsitm/ustra/api/platform/provider/publishing/api/CandidateProductizationController.java");
        assertFalse(c.contains("X-Tenant-Id")); assertFalse(c.contains("tenantId"));
    }

    @Test void cp10T06_acceptedCandidateStartsProductizingOnlyByCommand() {
        assertTrue(productizationService().contains("ApiCandidateState.ACCEPTED"));
        assertTrue(productizationService().contains("startProductization"));
    }
    @Test void cp10T07_productizationDoesNotAutoRelease() {
        assertFalse(productizationService().contains(".release("));
        assertFalse(productizationService().contains("RELEASED"));
    }
    @Test void cp10T08_productizationDoesNotActivateCatalogPublication() {
        assertFalse(productizationService().contains("CatalogPublication"));
    }
    @Test void cp10T09_openApiTitleNotBusinessProductIdentity() {
        assertFalse(productizationService().contains("parsed.title"));
        assertFalse(productizationService().contains("getName()"));
    }
    @Test void cp10T10_productizationUsesExactImportedApiVersion() {
        assertTrue(productizationService().contains("getResultApiVersionId()"));
        assertTrue(productizationService().contains("referencesImportedVersion"));
    }
    @Test void cp10T11_nonexistentProductVersionCannotCompleteCandidate() {
        assertTrue(productizationService().contains("API_PRODUCT_VERSION_NOT_FOUND"));
    }
    @Test void cp10T12_productVersionMustContainImportedTechnicalTarget() {
        assertTrue(productizationService().contains("containsImportedTarget"));
        assertTrue(productizationService().contains("API_CANDIDATE_PRODUCTIZATION_INVALID"));
    }

    @Test void cp10T13_missingOwnerIsBlocker() { assertTrue(readinessService().contains("OWNER_MISSING")); }
    @Test void cp10T14_emptyCompositionIsBlocker() { assertTrue(readinessService().contains("PRODUCT_VERSION_COMPOSITION_INVALID")); }
    @Test void cp10T15_invalidOrUnrecoverableImportProvenanceIsBlocker() {
        assertTrue(readinessService().contains("OPENAPI_INVALID"));
        assertTrue(readinessService().contains("SOURCE_PROVENANCE_NOT_RECONSTRUCTABLE"));
    }
    @Test @Disabled("Classification vocabulary/SoT remains Design Authority Required; CP-10 fails closed")
    void cp10T16_requiredClassificationAuthority() { assertTrue(readinessService().contains("REQUIRED_CLASSIFICATION_MISSING")); }
    @Test @Disabled("AccessPolicy model/revision SoT remains Design Authority Required; CP-10 fails closed")
    void cp10T17_requiredAccessPolicyAuthority() { assertTrue(readinessService().contains("REQUIRED_ACCESS_POLICY_MISSING")); }
    @Test @Disabled("Required locale policy owner remains Design Authority Required; CP-10 fails closed")
    void cp10T18_requiredLocaleAuthority() { assertTrue(readinessService().contains("REQUIRED_LOCALE_MISSING")); }
    @Test @Disabled("Optional locale policy remains undefined; no warning algorithm is invented")
    void cp10T19_optionalLocaleWarningAuthority() { assertTrue(readinessService().contains("warnings")); }
    @Test @Disabled("Critical finding SoT remains Design Authority Required; CP-10 fails closed")
    void cp10T20_criticalFindingAuthority() { assertTrue(readinessService().contains("CRITICAL_FINDING_UNRESOLVED")); }

    @Test void cp10T21_submitCapturesImmutableSnapshotHash() {
        assertTrue(reviewService().contains("snapshot.hash()"));
        assertTrue(source("src/main/resources/db/migration/V034__publication_review.sql").contains("submitted_snapshot_hash"));
    }
    @Test void cp10T22_submitFreezesCompositionByMovingToValidating() {
        assertTrue(reviewService().contains("version.beginValidation"));
        assertTrue(source("src/main/java/com/gsitm/ustra/api/platform/catalog/publication/application/ApiProductVersionService.java")
                .contains("requireDraft(productVersion)"));
    }
    @Test void cp10T23_approveBindsExactSubmittedSnapshot() {
        assertTrue(reviewService().contains("getSubmittedSnapshotHash()"));
        assertTrue(reviewService().contains("submittedCurrent.hash()"));
    }
    @Test void cp10T24_productMetadataRevisionParticipatesInSnapshot() {
        assertTrue(source("src/main/java/com/gsitm/ustra/api/platform/provider/publishing/snapshot/PublicationSnapshotBuilder.java")
                .contains("productRowVersion"));
    }
    @Test void cp10T25_componentIdentityParticipatesInSnapshot() {
        String s=source("src/main/java/com/gsitm/ustra/api/platform/provider/publishing/snapshot/PublicationSnapshotBuilder.java");
        assertTrue(s.contains("ComponentMember")); assertTrue(s.contains("components"));
    }
    @Test void cp10T26_sourceProvenanceParticipatesInSnapshot() {
        String s=source("src/main/java/com/gsitm/ustra/api/platform/provider/publishing/snapshot/PublicationSnapshotBuilder.java");
        assertTrue(s.contains("sourceContentHash")); assertTrue(s.contains("sourceImportId"));
    }
    @Test @Disabled("Policy revision authority has no approved physical model yet")
    void cp10T27_policyRevisionMismatch() { assertTrue(readinessService().contains("REQUIRED_ACCESS_POLICY_MISSING")); }
    @Test @Disabled("Required-locale inclusion/revision ownership remains Design Authority Required")
    void cp10T28_localeRevisionMismatch() { assertTrue(readinessService().contains("REQUIRED_LOCALE_MISSING")); }
    @Test void cp10T29_duplicateApproveDoesNotDuplicateRelease() {
        assertTrue(reviewService().contains("if (review.getState() == PublicationReviewState.APPROVED)"));
        assertFalse(reviewService().contains("APIProductVersionReleased"));
    }
    @Test void cp10T30_rejectedReviewCannotRelease() {
        assertTrue(reviewService().contains("review.reject"));
        assertTrue(releaseService().contains("publicationReleaseGate.requireReleaseAllowed"));
    }
    @Test void cp10T31_changesRequestedReviewCannotRelease() {
        assertTrue(reviewService().contains("review.requestChanges"));
        assertTrue(reviewService().contains("version.returnToDraft"));
    }
    @Test void cp10T32_cancelledReviewCannotRelease() {
        assertTrue(reviewService().contains("review.cancel"));
        assertTrue(reviewService().contains("version.returnToDraft"));
    }

    @Test void cp10T33_productVersionApprovedOnlyThroughApprovedReviewPath() {
        assertTrue(reviewService().contains("version.approve(review.getId()"));
        assertFalse(source("src/main/java/com/gsitm/ustra/api/platform/catalog/publication/application/ApiProductVersionService.java")
                .contains(".approve("));
    }
    @Test void cp10T34_draftProductVersionCannotRelease() {
        assertTrue(releaseService().contains("ApiProductVersionState.APPROVED"));
    }
    @Test void cp10T35_validatingProductVersionCannotRelease() {
        assertTrue(releaseService().contains("getLifecycleState() != ApiProductVersionState.APPROVED"));
    }
    @Test void cp10T36_snapshotMismatchBlocksRelease() {
        String g=source("src/main/java/com/gsitm/ustra/api/platform/provider/publishing/application/PublicationReleaseGate.java");
        assertTrue(g.contains("PUBLICATION_REVIEW_SNAPSHOT_MISMATCH"));
        assertTrue(g.contains("getApprovedSnapshotHash()"));
    }
    @Test void cp10T37_matchingApprovedReviewIsRequiredForRelease() {
        String g=source("src/main/java/com/gsitm/ustra/api/platform/provider/publishing/application/PublicationReleaseGate.java");
        assertTrue(g.contains("PublicationReviewState.APPROVED"));
        assertTrue(g.contains("readinessService.requireReady"));
    }
    @Test void cp10T38_releasedCompositionRemainsImmutable() {
        String s=source("src/main/java/com/gsitm/ustra/api/platform/catalog/publication/application/ApiProductVersionService.java");
        assertTrue(s.contains("DRAFT ProductVersion에서만 composition"));
    }
    @Test void cp10T39_apiVersionLifecycleOwnedByReviewAndRelease() {
        String r=reviewService();
        String g=source("src/main/java/com/gsitm/ustra/api/platform/provider/publishing/application/PublicationReleaseGate.java");
        assertTrue(r.contains("validateForPublication"));
        assertTrue(g.contains("releaseForPublication"));
    }
    @Test void cp10T40_releaseDoesNotActivateCatalogPublication() {
        assertFalse(source("src/main/java/com/gsitm/ustra/api/platform/provider/publishing/application/PublicationReleaseGate.java")
                .contains("CatalogPublication"));
    }

    @Test void cp10T41_productLifecycleMovesReviewingThenActiveIndependently() {
        String e=source("src/main/java/com/gsitm/ustra/api/platform/catalog/persistence/ApiProductEntity.java");
        assertTrue(e.contains("ApiProductLifecycleState.REVIEWING"));
        assertTrue(e.contains("ApiProductLifecycleState.ACTIVE"));
    }
    @Test void cp10T42_localizationCannotBypassUndefinedReviewPolicy() {
        String c=source("src/main/java/com/gsitm/ustra/api/platform/catalog/localization/api/ApiProductLocalizationController.java");
        assertFalse(c.toLowerCase(Locale.ROOT).contains("/publish"));
        assertTrue(readinessService().contains("REQUIRED_LOCALE_MISSING"));
    }
    @Test void cp10T43_canonicalChangeStillMarksPublishedLocalizationStale() {
        String s=source("src/main/java/com/gsitm/ustra/api/platform/catalog/application/ApiProductService.java");
        assertTrue(s.contains("markPublishedStale"));
    }

    @Test void cp10T44_reviewSubmissionAuditContainsHashNotRawOpenApi() {
        assertTrue(reviewService().contains("PUBLICATION_REVIEW_SUBMITTED"));
        assertFalse(reviewService().toLowerCase(Locale.ROOT).contains("raw_openapi"));
    }
    @Test void cp10T45_reviewDecisionUsesCentralAuditEvidence() {
        assertTrue(reviewService().contains("auditService.success"));
        assertTrue(source("src/main/java/com/gsitm/ustra/api/platform/audit/AuditService.java").contains("correlationId"));
    }
    @Test void cp10T46_releaseRetainsExistingHistoryAuditOutbox() {
        String s=releaseService();
        assertTrue(s.contains("historyService.record")); assertTrue(s.contains("auditService.success"));
        assertTrue(s.contains("APIProductVersionReleased"));
    }
    @Test void cp10T47_noRawSourceOrSecretInReviewSnapshotAuditOutbox() {
        String s=publishing().toLowerCase(Locale.ROOT);
        for(String forbidden: new String[]{"raw_openapi","source_body","client_secret","private_key","access_token"})
            assertFalse(s.contains(forbidden));
    }

    @Test void cp10T48_noBreakingChangeCalculation() { assertFalse(publishing().contains("BreakingChangeDetected")); }
    @Test void cp10T49_noConsumerImpactCreation() { assertFalse(publishing().contains("ConsumerImpact")); }
    @Test void cp10T50_noActualItsmOrGatewayCall() {
        String s=publishing().toLowerCase(Locale.ROOT);
        assertFalse(s.contains("servicenow")); assertFalse(s.contains("gatewayport"));
        assertFalse(s.contains("webclient")); assertFalse(s.contains("resttemplate"));
    }
    @Test void cp10T51_catalogPublicationRemainsSeparateFromRelease() {
        assertFalse(publishing().contains("CatalogPublicationEntity"));
        assertTrue(releaseService().contains("APIProductVersionReleased"));
    }
    @Test void cp10T52_cp01Through09RegressionAssetsRemain() {
        for(int i=1;i<=9;i++) {
            String cp=String.format("Cp%02dAcceptanceIntegrationTest.java",i);
            assertTrue(Files.exists(ROOT.resolve("src/test/java/com/gsitm/ustra/api/platform/"+cp)));
        }
    }
    @Test void cp10T53_migrationsV001ThroughV036Present() throws IOException {
        for (int i = 1; i <= 36; i++) {
            String prefix = String.format("V%03d__", i);
            assertTrue(Files.list(ROOT.resolve("src/main/resources/db/migration"))
                    .anyMatch(p -> p.getFileName().toString().startsWith(prefix)));
        }
    }
}

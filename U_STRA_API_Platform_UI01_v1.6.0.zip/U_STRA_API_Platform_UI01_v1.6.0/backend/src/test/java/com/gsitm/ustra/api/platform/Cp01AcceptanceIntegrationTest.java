package com.gsitm.ustra.api.platform;

import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.not;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gsitm.ustra.api.platform.audit.AuditRecordEntity;
import com.gsitm.ustra.api.platform.audit.AuditRecordRepository;
import com.gsitm.ustra.api.platform.common.context.RequestContext;
import com.gsitm.ustra.api.platform.common.context.RequestContextHolder;
import com.gsitm.ustra.api.platform.outbox.OutboxDispatchService;
import com.gsitm.ustra.api.platform.outbox.OutboxEventEntity;
import com.gsitm.ustra.api.platform.outbox.OutboxEventRepository;
import com.gsitm.ustra.api.platform.outbox.OutboxMessage;
import com.gsitm.ustra.api.platform.outbox.OutboxService;
import com.gsitm.ustra.api.platform.outbox.OutboxSink;
import com.gsitm.ustra.api.platform.outbox.OutboxStatus;
import com.gsitm.ustra.api.platform.security.UstraPrincipal;
import com.gsitm.ustra.api.platform.tenant.application.PlatformTenantService;
import com.gsitm.ustra.api.platform.tenant.domain.CustomerStatus;
import com.gsitm.ustra.api.platform.tenant.persistence.CustomerEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.CustomerRepository;
import com.gsitm.ustra.api.platform.tenant.persistence.MembershipEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.MembershipRepository;
import com.gsitm.ustra.api.platform.tenant.persistence.OrganizationEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.OrganizationRepository;
import com.gsitm.ustra.api.platform.tenant.persistence.RoleAssignmentEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.RoleAssignmentRepository;
import com.gsitm.ustra.api.platform.tenant.persistence.RoleEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.RoleRepository;
import com.gsitm.ustra.api.platform.tenant.persistence.TenantConfigurationEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.TenantConfigurationRepository;
import com.gsitm.ustra.api.platform.tenant.persistence.TenantEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.TenantRepository;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.support.TransactionTemplate;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class Cp01AcceptanceIntegrationTest {
    private static final String TENANT_ADMIN_ROLE_ID = "00000000-0000-0000-0000-000000000002";
    private static final String API_PROVIDER_ROLE_ID = "00000000-0000-0000-0000-000000000004";
    private static final Instant BASE_TIME = Instant.parse("2026-09-19T09:00:00Z");

    @Autowired MockMvc mvc;
    @Autowired ObjectMapper objectMapper;
    @Autowired CustomerRepository customerRepository;
    @Autowired TenantRepository tenantRepository;
    @Autowired TenantConfigurationRepository configurationRepository;
    @Autowired OrganizationRepository organizationRepository;
    @Autowired MembershipRepository membershipRepository;
    @Autowired RoleRepository roleRepository;
    @Autowired RoleAssignmentRepository assignmentRepository;
    @Autowired AuditRecordRepository auditRepository;
    @Autowired OutboxEventRepository outboxRepository;
    @Autowired OutboxService outboxService;
    @Autowired OutboxDispatchService outboxDispatchService;
    @Autowired PlatformTenantService platformTenantService;
    @Autowired TransactionTemplate transactionTemplate;
    @Autowired MutableClock clock;
    @Autowired StatefulOutboxSink sink;

    @BeforeEach
    void setUp() {
        assignmentRepository.deleteAllInBatch();
        membershipRepository.deleteAllInBatch();
        organizationRepository.deleteAllInBatch();
        configurationRepository.deleteAllInBatch();
        outboxRepository.deleteAllInBatch();
        auditRepository.deleteAllInBatch();
        tenantRepository.deleteAllInBatch();
        customerRepository.deleteAllInBatch();
        clock.set(BASE_TIME);
        sink.failNext.set(false);
        SecurityContextHolder.clearContext();
        RequestContextHolder.clear();
    }

    @AfterEach
    void tearDown() {
        SecurityContextHolder.clearContext();
        RequestContextHolder.clear();
    }

    @Test
    void cp01T01_tenantContextResolves() throws Exception {
        Fixture f = activeTenantWithAdmin("A", "user-a", "local-test");

        mvc.perform(get("/api/v1/me/tenant-context").header("X-Test-Principal-Id", "user-a"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.tenantId").value(f.tenant.getId()))
                .andExpect(jsonPath("$.roles[0]").value("TENANT_ADMIN"));
    }

    @Test
    void cp01T02_noMembershipDenied() throws Exception {
        mvc.perform(get("/api/v1/me/tenant-context").header("X-Test-Principal-Id", "unknown"))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.code").value("MEMBERSHIP_NOT_FOUND"));
    }

    @Test
    void cp01T03_inactiveMembershipDenied() throws Exception {
        CustomerEntity customer = customer("C-A");
        TenantEntity tenant = activeTenant(customer, "A");
        MembershipEntity membership = membership(tenant, "user-a", "local-test");
        membership.deactivate(BASE_TIME);
        membershipRepository.saveAndFlush(membership);

        mvc.perform(get("/api/v1/me/tenant-context").header("X-Test-Principal-Id", "user-a"))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.code").value("MEMBERSHIP_NOT_ACTIVE"));
    }

    @Test
    void cp01T04_crossTenantDirectIdDoesNotExposeResource() throws Exception {
        activeTenantWithAdmin("A", "user-a", "local-test");
        Fixture b = activeTenantWithAdmin("B", "user-b", "local-test");
        OrganizationEntity orgB = organization(b.tenant, "B-SECRET", "Tenant B Secret");

        mvc.perform(patch("/api/v1/organizations/{id}", orgB.getId())
                        .header("X-Test-Principal-Id", "user-a")
                        .header("If-Match", "\"0\"")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of("displayName", "attempt"))))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.code").value("ORGANIZATION_NOT_FOUND"))
                .andExpect(jsonPath("$.message", not(containsString("Tenant B Secret"))));
    }

    @Test
    void cp01T05_spoofedTenantHeaderCannotSwitchAuthority() throws Exception {
        Fixture a = activeTenantWithAdmin("A", "user-a", "local-test");
        Fixture b = activeTenantWithAdmin("B", "user-b", "local-test");

        mvc.perform(get("/api/v1/me/tenant-context")
                        .header("X-Test-Principal-Id", "user-a")
                        .header("X-Tenant-Id", b.tenant.getId()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.tenantId").value(a.tenant.getId()));
    }

    @Test
    void cp01T06_parentOrganizationCrossTenantRejected() throws Exception {
        activeTenantWithAdmin("A", "user-a", "local-test");
        Fixture b = activeTenantWithAdmin("B", "user-b", "local-test");
        OrganizationEntity parentB = organization(b.tenant, "B-PARENT", "B Parent");

        mvc.perform(post("/api/v1/organizations")
                        .header("X-Test-Principal-Id", "user-a")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of(
                                "organizationCode", "A-CHILD",
                                "displayName", "A Child",
                                "parentOrganizationId", parentB.getId()))))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("ORGANIZATION_TENANT_MISMATCH"));
    }

    @Test
    void cp01T07_tenantAdminCannotAssignPlatformAdminAndDenialIsAudited() throws Exception {
        Fixture a = activeTenantWithAdmin("A", "user-a", "local-test");
        MembershipEntity target = membership(a.tenant, "target-user", "local-test");

        mvc.perform(post("/api/v1/role-assignments")
                        .header("X-Test-Principal-Id", "user-a")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of(
                                "membershipId", target.getId(),
                                "roleCode", "PLATFORM_ADMIN",
                                "effectiveFrom", BASE_TIME.toString()))))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.code").value("PLATFORM_ROLE_ASSIGNMENT_FORBIDDEN"));

        assertTrue(auditRepository.findAllByTenantIdOrderByOccurredAtAsc(a.tenant.getId()).stream()
                .anyMatch(r -> "ROLE_ASSIGN".equals(r.getAction())
                        && "DENIED".equals(r.getOutcome())
                        && "PLATFORM_ROLE_ASSIGNMENT_FORBIDDEN".equals(r.getReasonCode())));
    }

    @Test
    void cp01T08_duplicateRoleAssignmentDoesNotCreateDuplicateAuthority() throws Exception {
        Fixture a = activeTenantWithAdmin("A", "user-a", "local-test");
        MembershipEntity target = membership(a.tenant, "target-user", "local-test");
        Map<String, Object> request = Map.of(
                "membershipId", target.getId(),
                "roleCode", "API_PROVIDER",
                "effectiveFrom", BASE_TIME.toString());

        mvc.perform(post("/api/v1/role-assignments")
                        .header("X-Test-Principal-Id", "user-a")
                        .contentType(MediaType.APPLICATION_JSON).content(json(request)))
                .andExpect(status().isCreated());
        mvc.perform(post("/api/v1/role-assignments")
                        .header("X-Test-Principal-Id", "user-a")
                        .contentType(MediaType.APPLICATION_JSON).content(json(request)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("VALIDATION_ERROR"));

        assertEquals(1, assignmentRepository.findAllByTenantIdAndMembershipIdAndRoleIdAndStatus(
                a.tenant.getId(), target.getId(), API_PROVIDER_ROLE_ID,
                com.gsitm.ustra.api.platform.tenant.domain.RoleAssignmentStatus.ACTIVE).size());
    }

    @Test
    void cp01T09_roleAssignmentEffectivePeriodIsRespected() throws Exception {
        CustomerEntity customer = customer("C-A");
        TenantEntity tenant = activeTenant(customer, "A");
        MembershipEntity m = membership(tenant, "user-a", "local-test");
        roleAssignment(tenant, m, TENANT_ADMIN_ROLE_ID, BASE_TIME.plus(Duration.ofHours(1)),
                BASE_TIME.plus(Duration.ofHours(2)));

        mvc.perform(get("/api/v1/organizations").header("X-Test-Principal-Id", "user-a"))
                .andExpect(status().isForbidden());

        clock.set(BASE_TIME.plus(Duration.ofMinutes(90)));
        mvc.perform(get("/api/v1/organizations").header("X-Test-Principal-Id", "user-a"))
                .andExpect(status().isOk());

        clock.set(BASE_TIME.plus(Duration.ofHours(3)));
        mvc.perform(get("/api/v1/organizations").header("X-Test-Principal-Id", "user-a"))
                .andExpect(status().isForbidden());
    }

    @Test
    void cp01T10_staleTenantConfigurationRevisionIsRejected() throws Exception {
        activeTenantWithAdmin("A", "user-a", "local-test");
        Map<String, Object> body = Map.of("defaultLocale", "ko-KR", "timezone", "Asia/Seoul");

        mvc.perform(patch("/api/v1/tenant-config")
                        .header("X-Test-Principal-Id", "user-a")
                        .header("If-Match", "\"1\"")
                        .contentType(MediaType.APPLICATION_JSON).content(json(body)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.revision").value(2));

        mvc.perform(patch("/api/v1/tenant-config")
                        .header("X-Test-Principal-Id", "user-a")
                        .header("If-Match", "\"1\"")
                        .contentType(MediaType.APPLICATION_JSON).content(json(body)))
                .andExpect(status().isConflict())
                .andExpect(jsonPath("$.code").value("CONCURRENT_MODIFICATION"));
    }

    @Test
    void cp01T11_privilegedRoleAssignmentAndRevokeProduceTraceableAudit() throws Exception {
        Fixture a = activeTenantWithAdmin("A", "user-a", "local-test");
        MembershipEntity target = membership(a.tenant, "target-user", "local-test");

        mvc.perform(post("/api/v1/role-assignments")
                        .header("X-Test-Principal-Id", "user-a")
                        .header("X-Correlation-Id", "audit-corr-11")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of(
                                "membershipId", target.getId(),
                                "roleCode", "API_PROVIDER",
                                "effectiveFrom", BASE_TIME.toString()))))
                .andExpect(status().isCreated());

        RoleAssignmentEntity assignment = assignmentRepository
                .findAllByTenantIdAndMembershipIdAndRoleIdAndStatus(
                        a.tenant.getId(), target.getId(), API_PROVIDER_ROLE_ID,
                        com.gsitm.ustra.api.platform.tenant.domain.RoleAssignmentStatus.ACTIVE)
                .getFirst();

        mvc.perform(post("/api/v1/role-assignments/{assignmentId}/revoke", assignment.getId())
                        .header("X-Test-Principal-Id", "user-a")
                        .header("X-Correlation-Id", "audit-corr-11"))
                .andExpect(status().isOk());

        java.util.List<AuditRecordEntity> records =
                auditRepository.findAllByTenantIdOrderByOccurredAtAsc(a.tenant.getId());
        AuditRecordEntity assignRecord = records.stream()
                .filter(r -> "ROLE_ASSIGN".equals(r.getAction()) && "SUCCESS".equals(r.getOutcome()))
                .findFirst().orElseThrow();
        AuditRecordEntity revokeRecord = records.stream()
                .filter(r -> "ROLE_REVOKE".equals(r.getAction()) && "SUCCESS".equals(r.getOutcome()))
                .findFirst().orElseThrow();
        assertEquals("user-a", assignRecord.getActorPrincipalId());
        assertEquals("audit-corr-11", assignRecord.getCorrelationId());
        assertFalse(assignRecord.getResourceId().isBlank());
        assertEquals("user-a", revokeRecord.getActorPrincipalId());
        assertEquals("audit-corr-11", revokeRecord.getCorrelationId());
        assertEquals(assignment.getId(), revokeRecord.getResourceId());
    }

    @Test
    void cp01T12_stateAndOutboxAreAtomicForRollbackAndCommit() {
        CustomerEntity customer = customer("ROLLBACK-C");
        long tenantCount = tenantRepository.count();
        long outboxCount = outboxRepository.count();
        authenticatePlatformAdmin("admin");
        RequestContextHolder.set(new RequestContext("req-12", "corr-12"));

        assertThrows(RuntimeException.class, () -> transactionTemplate.executeWithoutResult(status -> {
            platformTenantService.create(customer.getId(), "ROLLBACK-T", "Rollback Tenant", "ko-KR", "Asia/Seoul");
            throw new RuntimeException("force rollback");
        }));

        assertEquals(tenantCount, tenantRepository.count());
        assertEquals(outboxCount, outboxRepository.count());

        TenantEntity committed = platformTenantService.create(
                customer.getId(), "COMMIT-T", "Committed Tenant", "ko-KR", "Asia/Seoul");
        assertTrue(tenantRepository.existsById(committed.getId()));
        assertTrue(outboxRepository.findTop100ByStatusOrderByCreatedAtAsc(OutboxStatus.PENDING).stream()
                .anyMatch(event -> "TenantCreated".equals(event.getEventType())
                        && committed.getId().equals(event.getAggregateId())));
    }

    @Test
    void cp01T13_failedPublicationRemainsPendingAndCanBeRetried() {
        RequestContextHolder.set(new RequestContext("req-13", "corr-13"));
        transactionTemplate.executeWithoutResult(status ->
                outboxService.enqueue("RetryableEvent", "TEST", "agg-13", null, Map.of("safe", true)));
        OutboxEventEntity event = outboxRepository.findTop100ByStatusOrderByCreatedAtAsc(OutboxStatus.PENDING).getFirst();

        sink.failNext.set(true);
        assertFalse(outboxDispatchService.dispatchOne(event.getId()));
        OutboxEventEntity afterFailure = outboxRepository.findById(event.getId()).orElseThrow();
        assertEquals(OutboxStatus.PENDING, afterFailure.getStatus());
        assertEquals(1, afterFailure.getPublishAttempts());

        assertTrue(outboxDispatchService.dispatchOne(event.getId()));
        OutboxEventEntity afterRetry = outboxRepository.findById(event.getId()).orElseThrow();
        assertEquals(OutboxStatus.PUBLISHED, afterRetry.getStatus());
        assertEquals(2, afterRetry.getPublishAttempts());
    }

    @Test
    void cp01T14_eventIdUniquenessSupportsDownstreamDedupe() {
        String eventId = UUID.randomUUID().toString();
        OutboxEventEntity first = rawOutbox(eventId, "one");
        OutboxEventEntity duplicate = rawOutbox(eventId, "two");
        outboxRepository.saveAndFlush(first);
        assertThrows(DataIntegrityViolationException.class, () -> outboxRepository.saveAndFlush(duplicate));
        assertEquals(1, outboxRepository.countByEventId(eventId));
    }

    @Test
    void cp01T15_errorContainsMatchingCorrelationIdInResponseAndStructuredLogContext() throws Exception {
        Logger logger = (Logger) LoggerFactory.getLogger(
                com.gsitm.ustra.api.platform.common.error.GlobalExceptionHandler.class);
        ListAppender<ILoggingEvent> appender = new ListAppender<>();
        appender.start();
        logger.addAppender(appender);
        try {
            mvc.perform(get("/api/v1/me/tenant-context")
                            .header("X-Test-Principal-Id", "unknown")
                            .header("X-Correlation-Id", "corr-15"))
                    .andExpect(status().isForbidden())
                    .andExpect(header().string("X-Correlation-Id", "corr-15"))
                    .andExpect(jsonPath("$.correlationId").value("corr-15"));

            assertTrue(appender.list.stream().anyMatch(event ->
                    "corr-15".equals(event.getMDCPropertyMap().get("correlationId"))
                            && event.getFormattedMessage().contains("MEMBERSHIP_NOT_FOUND")));
        } finally {
            logger.detachAppender(appender);
            appender.stop();
        }
    }

    @Test
    void cp01T16_tenantAwareQueryReturnsOnlyCurrentTenantRows() throws Exception {
        Fixture a = activeTenantWithAdmin("A", "user-a", "local-test");
        Fixture b = activeTenantWithAdmin("B", "user-b", "local-test");
        organization(a.tenant, "A-ONLY", "A only");
        organization(b.tenant, "B-ONLY", "B only");

        mvc.perform(get("/api/v1/organizations").header("X-Test-Principal-Id", "user-a"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].organizationCode").value("A-ONLY"))
                .andExpect(jsonPath("$[1]").doesNotExist());
    }

    private Fixture activeTenantWithAdmin(String suffix, String principal, String issuer) {
        CustomerEntity customer = customer("C-" + suffix);
        TenantEntity tenant = activeTenant(customer, suffix);
        MembershipEntity membership = membership(tenant, principal, issuer);
        roleAssignment(tenant, membership, TENANT_ADMIN_ROLE_ID, BASE_TIME.minusSeconds(60), null);
        return new Fixture(customer, tenant, membership);
    }

    private CustomerEntity customer(String code) {
        CustomerEntity customer = new CustomerEntity(UUID.randomUUID().toString(), code, code,
                CustomerStatus.ACTIVE, BASE_TIME);
        return customerRepository.saveAndFlush(customer);
    }

    private TenantEntity activeTenant(CustomerEntity customer, String suffix) {
        TenantEntity tenant = new TenantEntity(UUID.randomUUID().toString(), customer.getId(), "T-" + suffix,
                "Tenant " + suffix, "ko-KR", "Asia/Seoul", BASE_TIME);
        tenant.activate(BASE_TIME);
        tenant = tenantRepository.saveAndFlush(tenant);
        configurationRepository.saveAndFlush(new TenantConfigurationEntity(UUID.randomUUID().toString(),
                tenant.getId(), "ko-KR", "Asia/Seoul", BASE_TIME));
        return tenant;
    }

    private MembershipEntity membership(TenantEntity tenant, String principal, String issuer) {
        MembershipEntity entity = new MembershipEntity(UUID.randomUUID().toString(), tenant.getId(), null,
                principal, issuer, BASE_TIME.minus(Duration.ofDays(1)), null, BASE_TIME);
        return membershipRepository.saveAndFlush(entity);
    }

    private OrganizationEntity organization(TenantEntity tenant, String code, String displayName) {
        return organizationRepository.saveAndFlush(new OrganizationEntity(UUID.randomUUID().toString(), tenant.getId(),
                code, displayName, null, BASE_TIME));
    }

    private RoleAssignmentEntity roleAssignment(TenantEntity tenant, MembershipEntity membership, String roleId,
                                                Instant from, Instant to) {
        RoleEntity role = roleRepository.findById(roleId).orElseThrow();
        RoleAssignmentEntity entity = new RoleAssignmentEntity(UUID.randomUUID().toString(), tenant.getId(),
                membership.getId(), role.getId(), null, from, to, "fixture", BASE_TIME);
        return assignmentRepository.saveAndFlush(entity);
    }

    private void authenticatePlatformAdmin(String principalId) {
        UstraPrincipal principal = new UstraPrincipal(principalId, "local-test");
        SecurityContextHolder.getContext().setAuthentication(new UsernamePasswordAuthenticationToken(
                principal, "N/A", java.util.List.of(new SimpleGrantedAuthority("ROLE_PLATFORM_ADMIN"))));
    }

    private OutboxEventEntity rawOutbox(String eventId, String aggregateId) {
        return new OutboxEventEntity(UUID.randomUUID().toString(), eventId, "TestEvent", 1,
                "TEST", aggregateId, null, "{}", "corr-14", BASE_TIME);
    }

    private String json(Object value) throws Exception {
        return objectMapper.writeValueAsString(value);
    }

    private record Fixture(CustomerEntity customer, TenantEntity tenant, MembershipEntity membership) {
    }

    @TestConfiguration
    static class TestBeans {
        @Bean
        @Primary
        MutableClock mutableClock() {
            return new MutableClock(BASE_TIME, ZoneOffset.UTC);
        }

        @Bean
        @Primary
        StatefulOutboxSink statefulOutboxSink() {
            return new StatefulOutboxSink();
        }
    }

    static final class MutableClock extends Clock {
        private volatile Instant instant;
        private final ZoneId zone;

        MutableClock(Instant instant, ZoneId zone) {
            this.instant = instant;
            this.zone = zone;
        }

        void set(Instant instant) {
            this.instant = instant;
        }

        @Override
        public ZoneId getZone() {
            return zone;
        }

        @Override
        public Clock withZone(ZoneId zone) {
            return new MutableClock(instant, zone);
        }

        @Override
        public Instant instant() {
            return instant;
        }
    }

    static final class StatefulOutboxSink implements OutboxSink {
        final AtomicBoolean failNext = new AtomicBoolean(false);

        @Override
        public void publish(OutboxMessage event) {
            if (failNext.compareAndSet(true, false)) {
                throw new IllegalStateException("simulated downstream failure");
            }
        }
    }
}

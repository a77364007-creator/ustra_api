package com.gsitm.ustra.api.platform;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

/** CP-13 source/contract traceability. Maven + Testcontainers execution remains required before release. */
class Cp13AcceptanceIntegrationTest {
    private static final Path ROOT=Path.of(".").toAbsolutePath().normalize();
    private static String source(String relative){try{return Files.readString(ROOT.resolve(relative));}catch(IOException ex){throw new AssertionError(ex);}}
    private static String state(){return source("src/main/java/com/gsitm/ustra/api/platform/integration/approval/application/ApprovalIntegrationStateService.java");}
    private static String orch(){return source("src/main/java/com/gsitm/ustra/api/platform/integration/approval/application/ApprovalIntegrationOrchestrator.java");}
    private static String resolver(){return source("src/main/java/com/gsitm/ustra/api/platform/integration/approval/application/TenantApprovalConnectorResolver.java");}
    private static String migration(){return source("src/main/resources/db/migration/V043__approval_integration_foundation.sql");}

    @Test void cp13T01_approvalPortRemainsDomainBoundary(){assertTrue(orch().contains("ApprovalPort"));assertTrue(source("src/main/java/com/gsitm/ustra/api/platform/subscription/approval/application/ApprovalPort.java").contains("interface ApprovalPort"));}
    @Test void cp13T02_mockApprovalRemainsNonProductionOnly(){assertTrue(source("src/main/java/com/gsitm/ustra/api/platform/subscription/approval/infrastructure/MockApprovalAdapter.java").contains("mock-integration"));}
    @Test void cp13T03_noFabricatedActualVendorAdapter(){assertFalse(source("pom.xml").toLowerCase().contains("servicenow"));assertFalse(Files.exists(ROOT.resolve("src/main/java/com/gsitm/ustra/api/platform/integration/approval/infrastructure/ActualITSMAdapter.java")));}
    @Test void cp13T04_crossTenantConnectorLookupIsQualified(){assertTrue(resolver().contains("findByIdAndTenantId"));assertTrue(resolver().contains("tenantId"));}
    @Test void cp13T05_outboundEffectOutsideBusinessTransaction(){assertTrue(orch().contains("Propagation.NOT_SUPPORTED"));assertTrue(orch().contains("state.beginOutbound"));assertTrue(orch().contains("port.createCase"));}
    @Test void cp13T06_operationExistsBeforeOutboundEffect(){assertTrue(orch().indexOf("state.beginOutbound")<orch().indexOf("port.createCase"));assertTrue(state().contains("operations.saveAndFlush(new IntegrationOperationEntity"));}
    @Test void cp13T07_createSuccessBindsApprovalReference(){assertTrue(state().contains("approvalState.recordCase"));assertTrue(state().contains("op.succeed(external.externalCaseRef()"));}
    @Test void cp13T08_duplicateCreateUsesOneLocalOperation(){assertTrue(migration().contains("uq_integration_operation_create"));assertTrue(state().contains("findByTenantIdAndOperationTypeAndAggregateIdAndAggregateRevision"));}
    @Test void cp13T09_uncertainCreateBecomesUnknown(){assertTrue(orch().contains("ApprovalConnectorUnknownException"));assertTrue(state().contains("op.unknown("));}
    @Test void cp13T10_unknownDoesNotBlindlyRetryCreate(){assertTrue(state().contains("existing.get().getStatus()==IntegrationOperationStatus.REQUESTED"));}
    @Test void cp13T11_reconciliationQueriesExistingCase(){assertTrue(orch().contains("port.queryDecision"));assertTrue(state().contains("prepareQuery"));}
    @Test void cp13T12_externalEventDuplicateIsIdempotent(){assertTrue(source("src/main/java/com/gsitm/ustra/api/platform/integration/approval/application/ExternalEventInboxService.java").contains("return existing.get()"));}
    @Test void cp13T13_conflictingExternalEventRejected(){assertTrue(source("src/main/java/com/gsitm/ustra/api/platform/integration/approval/application/ExternalEventInboxService.java").contains("INTEGRATION_EXTERNAL_EVENT_CONFLICT"));}
    @Test void cp13T14_staleRevisionStillRejectedByCanonicalApprovalService(){assertTrue(source("src/main/java/com/gsitm/ustra/api/platform/subscription/approval/application/ApprovalStateService.java").contains("requestRevisionNo"));}
    @Test void cp13T15_snapshotMismatchStillRejected(){assertTrue(source("src/main/java/com/gsitm/ustra/api/platform/subscription/approval/application/ApprovalStateService.java").contains("snapshotHash"));}
    @Test void cp13T16_approvedScopeCannotExceedRequested(){assertTrue(source("src/main/java/com/gsitm/ustra/api/platform/subscription/approval/application/ApprovalStateService.java").contains("APPROVAL_SCOPE_EXCEEDS_REQUEST"));}
    @Test void cp13T17_emptyApprovedScopeNotAllowAll(){assertTrue(source("src/main/java/com/gsitm/ustra/api/platform/subscription/approval/application/ApprovalStateService.java").contains("ENTITLEMENT_SCOPE_REQUIRED"));}
    @Test void cp13T18_rejectedCreatesNoEntitlement(){assertTrue(state().contains("if(decision.status()!=ApprovalPort.DecisionStatus.PENDING)"));assertTrue(state().contains("if(decision.status()==ApprovalPort.DecisionStatus.APPROVED)"));}
    @Test void cp13T19_approvedMaterializationReusesExistingPort(){assertTrue(state().contains("ApprovedSubscriptionDecisionPort"));assertTrue(state().contains("materializer.materialize"));}
    @Test void cp13T20_approvalStillSeparateFromReadyToUse(){assertFalse(state().contains("ReadyToUseService"));}
    @Test void cp13T21_evidenceAndReviewerRemainOpaque(){String s=source("src/main/java/com/gsitm/ustra/api/platform/subscription/approval/persistence/ApprovalReferenceEntity.java");assertTrue(s.contains("decision_evidence_ref"));assertTrue(s.contains("reviewer_reference"));}
    @Test void cp13T22_rawSecretsAbsentFromOperationAndApi(){String s=migration()+source("src/main/java/com/gsitm/ustra/api/platform/integration/approval/api/ApprovalIntegrationAdminController.java");assertFalse(s.contains("secret_value"));assertFalse(s.contains("password"));assertFalse(s.contains("token_value"));}
    @Test void cp13T23_rawVendorPayloadNotPersisted(){String m=migration().toLowerCase();assertFalse(m.contains("request_payload"));assertFalse(m.contains("response_payload"));assertFalse(m.contains("raw_payload"));}
    @Test void cp13T24_noCallbackTenantHeaderAuthority(){String s=source("src/main/java/com/gsitm/ustra/api/platform/integration/approval/api/ApprovalIntegrationAdminController.java");assertFalse(s.contains("X-Tenant-Id"));assertFalse(s.toLowerCase().contains("callback"));}
    @Test void cp13T25_manualReconcileRequiresPermission(){assertTrue(source("src/main/java/com/gsitm/ustra/api/platform/integration/approval/application/ApprovalIntegrationOperatorService.java").contains("APPROVAL_INTEGRATION:RECONCILE"));}
    @Test void cp13T26_approvalSynchronizedRemainsTenantQualified(){assertTrue(source("src/main/java/com/gsitm/ustra/api/platform/subscription/approval/application/ApprovalStateService.java").contains("ref.getTenantId()"));}
    @Test void cp13T27_integrationFailureDoesNotCoupleCatalog(){assertFalse(state().contains("CatalogPublicationService"));assertFalse(state().contains("ApiProductService"));}
    @Test void cp13T28_callbackLossRecoverableByStatusQuery(){assertTrue(source("src/main/java/com/gsitm/ustra/api/platform/integration/approval/application/ApprovalIntegrationOperatorService.java").contains("reconcileApprovalReference"));assertTrue(orch().contains("synchronize"));}
    @Test void cp13T29_repeatedUncertainQueryCanRemainUnknown(){assertTrue(orch().contains("queryUnknownIssueType"));assertTrue(state().contains("APPROVAL_STATUS_QUERY"));}
    @Test void cp13T30_restartDoesNotBlindlyDuplicateCreate(){assertTrue(migration().contains("uq_integration_operation_create"));assertTrue(state().contains("invokeRequired"));}
    @Test void cp13T31_safeErrorMetadataOnly(){assertTrue(migration().contains("safe_error_category"));assertTrue(migration().contains("safe_error_code"));assertFalse(state().contains("getMessage()"));}
    @Test void cp13T32_noHardcodedRoleNames(){String s=state()+source("src/main/java/com/gsitm/ustra/api/platform/integration/approval/application/ApprovalIntegrationOperatorService.java");assertFalse(s.contains("TENANT_ADMIN"));assertFalse(s.contains("APP_OWNER"));}
    @Test void cp13T33_vendorDtoDoesNotLeakIntoDomainBoundary(){assertFalse(state().contains("ServiceNow"));assertFalse(orch().contains("ServiceNow"));}
    @Test void cp13T34_workflowVersionPreserved(){assertTrue(migration().contains("workflow_version"));assertTrue(state().contains("external.workflowVersion()"));}
    @Test void cp13T35_closedTicketCannotImplicitlyApprove(){assertFalse(state().contains("CLOSED"));assertTrue(state().contains("ApprovalPort.DecisionStatus.APPROVED"));}
    @Test void cp13T36_exactCp08DecisionChecksReused(){assertTrue(state().contains("approvalState.synchronizeDecision"));}
    @Test void cp13T37_externalCancellationNotFabricated(){assertFalse(source("src/main/java/com/gsitm/ustra/api/platform/integration/approval/api/ApprovalIntegrationAdminController.java").toLowerCase().contains("cancel"));}
    @Test void cp13T38_correlationAndCausationAreOpaque(){assertTrue(migration().contains("local_correlation_key"));assertTrue(migration().contains("causation_id"));}
    @Test void cp13T39_manualReconcileAudited(){assertTrue(source("src/main/java/com/gsitm/ustra/api/platform/integration/approval/application/ApprovalIntegrationOperatorService.java").contains("APPROVAL_INTEGRATION_RECONCILE_REQUEST"));}
    @Test void cp13T40_disabledConnectorFailsClosed(){assertTrue(resolver().contains("INTEGRATION_CONNECTOR_DISABLED"));assertTrue(resolver().contains("ownedEnabled"));}
    @Test void cp13T41_externalCorrelationNeverCrossTenant(){assertTrue(source("src/main/java/com/gsitm/ustra/api/platform/integration/approval/persistence/ProcessedExternalEventRepository.java").contains("findByTenantIdAndConnectorInstanceIdAndExternalEventId"));}
    @Test void cp13T42_approvalReferenceRequestRevisionInvariantRemains(){assertTrue(source("src/main/resources/db/migration/V028__approval_reference_scope.sql").contains("uq_approval_reference_request_revision"));}
    @Test void cp13T43_cp06IdempotencyRegression(){assertTrue(Files.exists(ROOT.resolve("src/test/java/com/gsitm/ustra/api/platform/Cp06AcceptanceIntegrationTest.java")));}
    @Test void cp13T44_cp08ApprovalReplayRegression(){assertTrue(Files.exists(ROOT.resolve("src/test/java/com/gsitm/ustra/api/platform/Cp08AcceptanceIntegrationTest.java")));}
    @Test void cp13T45_cp08ScopeQuotaRegression(){assertTrue(source("src/main/java/com/gsitm/ustra/api/platform/subscription/approval/application/ApprovalStateService.java").contains("validateQuota"));}
    @Test void cp13T46_cp08MockVerticalSliceStillPresent(){assertTrue(source("src/main/java/com/gsitm/ustra/api/platform/subscription/approval/application/MockApprovalOrchestrator.java").contains("mock-integration"));}
    @Test void cp13T47_cp09ImportRegression(){assertTrue(Files.exists(ROOT.resolve("src/test/java/com/gsitm/ustra/api/platform/Cp09AcceptanceIntegrationTest.java")));}
    @Test void cp13T48_cp10PublishingRegression(){assertTrue(Files.exists(ROOT.resolve("src/test/java/com/gsitm/ustra/api/platform/Cp10AcceptanceIntegrationTest.java")));}
    @Test void cp13T49_cp11ChangeImpactRegression(){assertTrue(Files.exists(ROOT.resolve("src/test/java/com/gsitm/ustra/api/platform/Cp11AcceptanceIntegrationTest.java")));}
    @Test void cp13T50_cp12SearchRegression(){assertTrue(Files.exists(ROOT.resolve("src/test/java/com/gsitm/ustra/api/platform/Cp12AcceptanceIntegrationTest.java")));}

    @Test @Disabled("DF-CP13-01: real ITSM endpoint/auth handshake contract is not supplied") void cp13T51_realItsmEndpointAuthHandshake(){fail();}
    @Test @Disabled("DF-CP13-03: webhook signature/auth contract is not supplied") void cp13T52_webhookAuthentication(){fail();}
    @Test @Disabled("DF-CP13-01: vendor status mapping is not supplied") void cp13T53_vendorStatusMapping(){fail();}
    @Test @Disabled("DF-CP13-02: vendor idempotency/client correlation is not supplied") void cp13T54_vendorIdempotencySemantics(){fail();}
    @Test @Disabled("DF-CP13-02: lookup semantics after create timeout are not supplied") void cp13T55_queryAfterCreateTimeout(){fail();}
    @Test @Disabled("DF-CP13-03: stable external event identity/replay semantics are not supplied") void cp13T56_externalEventReplayContract(){fail();}
    @Test @Disabled("DF-CP13-05: external cancellation policy/contract is not supplied") void cp13T57_externalCancellation(){fail();}
    @Test @Disabled("DF-CP13-04: classification/risk source is not approved") void cp13T58_classificationRiskMapping(){fail();}
    @Test @Disabled("DF-CP13-06: numeric timeout/retry/backoff policy is not approved") void cp13T59_retryBackoffPolicy(){fail();}
    @Test @Disabled("DF-CP13-06: reconciliation scheduling/escalation policy is not approved") void cp13T60_reconciliationSchedule(){fail();}
    @Test @Disabled("DF-CP13-01: production secret provider/Vault contract is not supplied") void cp13T61_secretProviderContract(){fail();}
    @Test @Disabled("DF-CP13-01: vendor quota/unit mapping is not supplied") void cp13T62_vendorQuotaUnitMapping(){fail();}
    @Test @Disabled("DF-CP13-01: workflow-version compatibility policy is not supplied") void cp13T63_workflowVersionCompatibility(){fail();}
    @Test @Disabled("DF-CP13-01: real ITSM sandbox environment is not supplied") void cp13T64_realSandboxE2E(){fail();}
}

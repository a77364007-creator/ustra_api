package com.gsitm.ustra.api.platform;

import static org.junit.jupiter.api.Assertions.*;

import com.gsitm.ustra.api.platform.search.application.CatalogSearchProjectionHashService;
import org.junit.jupiter.api.Test;

class Cp12SearchProjectionHashUnitTest {
    private final CatalogSearchProjectionHashService service = new CatalogSearchProjectionHashService();

    @Test void sameCanonicalInputProducesSameSha256(){
        String a=service.hash("tenant|product|CANONICAL|v1");
        String b=service.hash("tenant|product|CANONICAL|v1");
        assertEquals(a,b); assertEquals(64,a.length());
    }

    @Test void changedCanonicalInputChangesProjectionHash(){
        assertNotEquals(service.hash("tenant|product|v1"),service.hash("tenant|product|v2"));
    }
}

package com.gsitm.ustra.api.platform;

import static org.junit.jupiter.api.Assertions.*;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gsitm.ustra.api.platform.common.error.BusinessException;
import com.gsitm.ustra.api.platform.common.error.ErrorCode;
import com.gsitm.ustra.api.platform.provider.importing.application.OperationPathNormalizer;
import com.gsitm.ustra.api.platform.provider.importing.application.Sha256Service;
import com.gsitm.ustra.api.platform.provider.importing.parser.OpenApiReferenceGuard;
import com.gsitm.ustra.api.platform.provider.importing.parser.SanitizedContractFingerprintService;
import com.gsitm.ustra.api.platform.provider.importing.parser.SwaggerOpenApiParserAdapter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

/** CP-09 acceptance traceability. Runtime DB/HTTP concurrency remains covered by Maven/Testcontainers gate. */
class Cp09AcceptanceIntegrationTest {
    private static final Path ROOT = Path.of(".").toAbsolutePath().normalize();
    private static String source(String relative) {
        try { return Files.readString(ROOT.resolve(relative)); }
        catch (IOException ex) { throw new AssertionError(ex); }
    }
    private static String main() {
        return source("src/main/java/com/gsitm/ustra/api/platform/provider/importing/application/ApiImportService.java")
                + source("src/main/java/com/gsitm/ustra/api/platform/provider/importing/application/ApiImportMaterializationService.java");
    }
    private static SwaggerOpenApiParserAdapter parser() {
        return new SwaggerOpenApiParserAdapter(
                new OpenApiReferenceGuard(),
                new SanitizedContractFingerprintService(new ObjectMapper(), new Sha256Service()));
    }

    @Test void cp09T01_crossTenantImportDoesNotDisclose() { assertTrue(main().contains("findByIdAndTenantId(id,ctx.tenantId())")); }
    @Test void cp09T02_crossTenantProviderRejected() { assertTrue(main().contains("findByIdAndTenantId(providerId,ctx.tenantId())")); }
    @Test void cp09T03_createPermissionRequired() { assertTrue(main().contains("API_IMPORT:CREATE")); }
    @Test void cp09T04_readPermissionRequired() { assertTrue(main().contains("API_IMPORT:READ")); }
    @Test void cp09T05_requestTenantCannotOverride() { assertFalse(source("src/main/java/com/gsitm/ustra/api/platform/provider/importing/api/ApiImportController.java").contains("tenantId")); }

    @Test void cp09T06_validOpenApi30Json() { assertEquals("1.0", parser().parse("{\"openapi\":\"3.0.3\",\"info\":{\"title\":\"X\",\"version\":\"1.0\"},\"paths\":{\"/x\":{\"get\":{}}}}").version()); }
    @Test void cp09T07_validOpenApi30Yaml() { assertEquals("1.0", parser().parse("openapi: 3.0.3\ninfo:\n  title: X\n  version: '1.0'\npaths:\n  /x:\n    get: {}\n").version()); }
    @Test void cp09T08_openApi31Capability() { assertEquals("1.0", parser().parse("{\"openapi\":\"3.1.0\",\"info\":{\"title\":\"X\",\"version\":\"1.0\"},\"paths\":{}}").version()); }
    @Test void cp09T09_invalidOpenApiNoPartialRows() { assertTrue(source("src/main/java/com/gsitm/ustra/api/platform/provider/importing/application/ApiImportService.java").indexOf("parser.parse") < source("src/main/java/com/gsitm/ustra/api/platform/provider/importing/application/ApiImportService.java").indexOf("materializer.materialize")); }
    @Test void cp09T10_remoteHttpRefRejected() { BusinessException ex=assertThrows(BusinessException.class,()->new OpenApiReferenceGuard().validate("$ref: https://example.com/x.yaml")); assertEquals(ErrorCode.OPENAPI_EXTERNAL_REFERENCE_FORBIDDEN,ex.code()); }
    @Test void cp09T11_fileRefRejected() { assertThrows(BusinessException.class,()->new OpenApiReferenceGuard().validate("$ref: file:/tmp/x.yaml")); }
    @Test void cp09T12_relativeExternalRefRejected() { assertThrows(BusinessException.class,()->new OpenApiReferenceGuard().validate("$ref: ../x.yaml#/components/X")); }
    @Test void cp09T13_rawSpecAbsentFromAuditLogOutbox() { String all=main()+source("src/main/resources/db/migration/V030__provider_openapi_import_foundation.sql"); assertFalse(all.contains("raw_openapi")); assertFalse(all.contains("source_body")); }
    @Test void cp09T14_filenameNeverUsedAsFilesystemPath() { String s=source("src/main/java/com/gsitm/ustra/api/platform/provider/importing/application/ApiImportService.java"); assertFalse(s.contains("Path.of")); assertFalse(s.contains("new File")); }

    @Test void cp09T15_infoTitleNotApiCodeAuthority() { assertTrue(main().contains("apiCodeOriginal")); assertFalse(main().contains("normalize(parsed.title")); }
    @Test void cp09T16_methodLocaleRootUppercase() { assertEquals("GET", "get".toUpperCase(Locale.ROOT)); assertTrue(main().contains("toUpperCase(Locale.ROOT)")); }
    @Test void cp09T17_pathParameterNamesNormalizeSame() { var n=new OperationPathNormalizer(); assertEquals(n.normalize("/x/{id}"),n.normalize("/x/{userId}")); }
    @Test void cp09T18_pathCasePreserved() { assertEquals("/Users/{}",new OperationPathNormalizer().normalize("/Users/{id}")); }
    @Test void cp09T19_trailingSlashPreserved() { assertEquals("/x/{}/",new OperationPathNormalizer().normalize("/x/{id}/")); }
    @Test void cp09T20_percentEncodingPreserved() { assertEquals("/x/%7Bid%7D",new OperationPathNormalizer().normalize("/x/%7Bid%7D")); }
    @Test void cp09T21_duplicateOperationFailsWholeImport() { assertTrue(main().contains("OPENAPI_DUPLICATE_OPERATION")); }
    @Test void cp09T22_operationIdMetadataOnly() { assertTrue(main().contains("op.operationId()")); assertTrue(main().contains("method + \" \" + normalizedPath")); }

    @Test void cp09T23_importedVersionStartsDraft() { assertTrue(main().contains("ApiVersionState.DRAFT")); }
    @Test void cp09T24_hashStoredRawNotStored() { String m=source("src/main/resources/db/migration/V031__api_version_import_provenance.sql"); assertTrue(m.contains("source_content_hash")); assertFalse(m.contains("raw")); }
    @Test void cp09T25_sameVersionSameHashReused() { assertTrue(main().contains("Objects.equals(existing.getSourceContentHash(), hash)")); }
    @Test void cp09T26_sameVersionDifferentHashConflict() { assertTrue(main().contains("API_VERSION_IMPORT_CONFLICT")); }
    @Test void cp09T27_newInfoVersionCreatesDraft() { assertTrue(main().contains("parsed.version()")); assertTrue(main().contains("new ApiVersionEntity")); }
    @Test void cp09T28_releasedVersionNotOverwritten() { assertFalse(main().contains("existing.attachImportProvenance")); assertFalse(main().contains("existing.set")); }
    @Test void cp09T29_provenanceTenantOwned() { assertTrue(source("src/main/resources/db/migration/V031__api_version_import_provenance.sql").contains("FOREIGN KEY (tenant_id, source_import_id)")); }

    @Test void cp09T30_sameKeySameFingerprintReplay() { assertTrue(main().contains("prior.getRequestFingerprint().equals(fingerprint)")); }
    @Test void cp09T31_sameKeyDifferentContentConflict() { assertTrue(main().contains("IDEMPOTENCY_KEY_CONFLICT")); }
    @Test void cp09T32_sameKeyDifferentTenantIndependent() { assertTrue(source("src/main/resources/db/migration/V030__provider_openapi_import_foundation.sql").contains("UNIQUE (tenant_id, idempotency_key)")); }
    @Test void cp09T33_concurrentIdenticalNoDuplicate() { String m=source("src/main/resources/db/migration/V010__catalog_core.sql")+source("src/main/resources/db/migration/V030__provider_openapi_import_foundation.sql"); assertTrue(m.contains("uq_api_version_api_version")); assertTrue(m.contains("uq_api_operation_version_method_path")); assertTrue(m.contains("uq_api_tenant_code")); }

    @Test void cp09T34_noApiProductAutoCreate() { assertFalse(main().contains("ApiProductEntity")); }
    @Test void cp09T35_noProductVersionAutoCreate() { assertFalse(main().contains("ApiProductVersionEntity")); }
    @Test void cp09T36_noReleasePublish() { assertFalse(main().contains("CatalogPublication")); assertFalse(main().contains("RELEASED")); }
    @Test void cp09T37_hashDifferenceNoBreakingChange() { assertFalse(main().contains("BreakingChangeDetected")); }
    @Test void cp09T38_noGithubRemoteSync() { assertFalse(source("../openapi/cp09.yaml").toLowerCase(Locale.ROOT).contains("github")); }
    @Test void cp09T39_noGatewayDiscovery() { assertFalse(source("../openapi/cp09.yaml").toLowerCase(Locale.ROOT).contains("gateway")); }

    @Test void cp09T40_successAuditAndCandidateHistory() { String s=source("src/main/java/com/gsitm/ustra/api/platform/provider/importing/application/ApiImportAttemptService.java"); assertTrue(s.contains("API_IMPORT_SUCCEEDED")); assertTrue(s.contains("ApiCandidateState.ACCEPTED")); }
    @Test void cp09T41_failedValidationSafeFailureSummary() { String s=source("src/main/java/com/gsitm/ustra/api/platform/provider/importing/application/ApiImportAttemptService.java"); assertTrue(s.contains("API_IMPORT_FAILED")); assertFalse(s.contains("sourceBody")); }
    @Test void cp09T42_migrationsV001ToV032() throws IOException { for(int i=1;i<=32;i++){String prefix=String.format("V%03d__",i);try(var stream=Files.list(ROOT.resolve("src/main/resources/db/migration"))){assertTrue(stream.anyMatch(p->p.getFileName().toString().startsWith(prefix)));}} }
    @Test void cp09T43_cp01To08RegressionAssetsRemain() { for(int i=1;i<=8;i++) assertTrue(Files.exists(ROOT.resolve("src/test/java/com/gsitm/ustra/api/platform/Cp0"+i+"AcceptanceIntegrationTest.java"))); }
    @Test void cp09T44_apiCodeTenantUniqueCanonical() { String m=source("src/main/resources/db/migration/V030__provider_openapi_import_foundation.sql"); assertTrue(m.contains("uq_api_tenant_code")); assertTrue(main().contains("trim().toUpperCase(Locale.ROOT)") || source("src/main/java/com/gsitm/ustra/api/platform/provider/importing/application/ApiCodeNormalizer.java").contains("trim().toUpperCase(Locale.ROOT)")); }
    @Test void cp09T45_uploadLimitConfigurable() { assertTrue(source("src/main/resources/application.yml").contains("USTRA_API_IMPORT_MAX_BYTES")); }
    @Test @Disabled("Runtime Maven dependency/OpenAPI 3.1 compatibility must be verified in approved build environment") void cp09T46_openApi31RuntimeDependencyVerification() { assertTrue(source("pom.xml").contains("swagger-parser")); }
}

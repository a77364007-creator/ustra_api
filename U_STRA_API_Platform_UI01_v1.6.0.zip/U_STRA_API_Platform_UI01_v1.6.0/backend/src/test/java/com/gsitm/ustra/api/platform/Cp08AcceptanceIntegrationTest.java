package com.gsitm.ustra.api.platform;

import static org.junit.jupiter.api.Assertions.*;

import com.gsitm.ustra.api.platform.audit.AuditRecordRepository;
import com.gsitm.ustra.api.platform.catalog.domain.*;
import com.gsitm.ustra.api.platform.catalog.persistence.*;
import com.gsitm.ustra.api.platform.catalog.publication.domain.*;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.*;
import com.gsitm.ustra.api.platform.common.context.*;
import com.gsitm.ustra.api.platform.consumer.domain.*;
import com.gsitm.ustra.api.platform.consumer.persistence.*;
import com.gsitm.ustra.api.platform.outbox.OutboxEventRepository;
import com.gsitm.ustra.api.platform.security.UstraPrincipal;
import com.gsitm.ustra.api.platform.subscription.approval.application.*;
import com.gsitm.ustra.api.platform.subscription.approval.infrastructure.MockApprovalAdapter;
import com.gsitm.ustra.api.platform.subscription.approval.persistence.*;
import com.gsitm.ustra.api.platform.subscription.entitlement.application.*;
import com.gsitm.ustra.api.platform.subscription.entitlement.persistence.*;
import com.gsitm.ustra.api.platform.subscription.gateway.application.*;
import com.gsitm.ustra.api.platform.subscription.gateway.infrastructure.MockGatewayAdapter;
import com.gsitm.ustra.api.platform.subscription.persistence.*;
import com.gsitm.ustra.api.platform.tenant.domain.CustomerStatus;
import com.gsitm.ustra.api.platform.tenant.persistence.*;
import jakarta.persistence.EntityManager;
import java.nio.file.*;
import java.time.*;
import java.util.*;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
@ActiveProfiles("test")
class Cp08AcceptanceIntegrationTest {
    private static final Instant NOW = Instant.parse("2026-09-20T00:00:00Z");
    @Autowired JdbcTemplate jdbc; @Autowired EntityManager em;
    @Autowired CustomerRepository customers; @Autowired TenantRepository tenants; @Autowired TenantConfigurationRepository configs; @Autowired MembershipRepository memberships; @Autowired OrganizationRepository organizations; @Autowired RoleAssignmentRepository assignments;
    @Autowired ConsumerAppRepository apps; @Autowired ConsumerAppEnvironmentRepository environments;
    @Autowired ApiProductRepository products; @Autowired ApiProductVersionRepository productVersions; @Autowired ApiProductComponentRepository components; @Autowired ApiRepository apis; @Autowired ApiVersionRepository apiVersions; @Autowired ApiOperationRepository operations; @Autowired CatalogPublicationRepository publications; @Autowired AudienceScopeRepository audiences;
    @Autowired SubscriptionRequestRepository requests; @Autowired SubscriptionRequestRevisionRepository revisions; @Autowired SubscriptionRequestRevisionOperationScopeRepository requestedScopes; @Autowired SubscriptionRequestIdempotencyRepository requestIdempotency;
    @Autowired ApprovalReferenceRepository approvalRefs; @Autowired ApprovalOperationScopeRepository approvalScopes; @Autowired ApprovalQuotaLimitRepository approvalQuotas;
    @Autowired SubscriptionRepository subscriptions; @Autowired EntitlementRepository entitlements; @Autowired EntitlementOperationScopeRepository entitlementScopes; @Autowired QuotaProfileRepository quotaProfiles; @Autowired QuotaLimitRepository quotaLimits; @Autowired AccessFulfillmentRepository fulfillments; @Autowired CredentialReferenceRepository credentials;
    @Autowired StateTransitionHistoryRepository history; @Autowired AuditRecordRepository audit; @Autowired OutboxEventRepository outbox;
    @Autowired MockApprovalOrchestrator approvals; @Autowired MockApprovalAdapter mockApproval; @Autowired GatewayFulfillmentOrchestrator gateway; @Autowired MockGatewayAdapter mockGateway; @Autowired ReadyToUseService ready;

    @BeforeEach void before(){cleanup();}
    @AfterEach void after(){SecurityContextHolder.clearContext();RequestContextHolder.clear();cleanup();}

    // CP08-PRE
    @Test void cp08PreT01_requestRevisionPersistsExplicitRequestedOperationScope(){assertTrue(source("subscription/application/SubscriptionRequestService.java").contains("SubscriptionRequestRevisionOperationScopeEntity"));}
    @Test void cp08PreT02_requestedOperationOutsidePinnedProductVersionRejected(){String s=source("subscription/application/SubscriptionRequestService.java");assertTrue(s.contains("SUBSCRIPTION_REQUEST_SCOPE_INVALID")&&s.contains("ApiProductComponentTargetType"));}
    @Test void cp08PreT03_emptyRequestedOperationScopeRejectedForCp08CapableRequest(){assertTrue(source("subscription/application/SubscriptionRequestService.java").contains("ids.isEmpty()"));}
    @Test void cp08PreT04_snapshotHashChangesWithRequestedScope(){var s=new com.gsitm.ustra.api.platform.subscription.application.SubscriptionRequestSnapshotService();String a=s.snapshotHash("t","r",1,"e","p","v","m","x",null,List.of("op-a"));String b=s.snapshotHash("t","r",1,"e","p","v","m","x",null,List.of("op-b"));assertNotEquals(a,b);}
    @Test void cp08PreT05_legacyRequestWithoutScopeCannotBeApproved(){assertTrue(source("subscription/approval/application/ApprovalStateService.java").contains("legacy 신청은 CP-08 승인 경로"));}

    // Approval exact binding
    @Test void cp08T01_mockApprovalBindsExactRevisionAndHash(){assertTrue(source("subscription/approval/application/ApprovalStateService.java").contains("getRequestRevisionNo()!=d.requestRevisionNo()"));}
    @Test void cp08T02_staleRevisionDecisionRejected(){assertTrue(source("subscription/approval/application/ApprovalStateService.java").contains("request revision/snapshot"));}
    @Test void cp08T03_snapshotHashMismatchRejected(){assertTrue(source("subscription/approval/application/ApprovalStateService.java").contains("getSnapshotHash().equals(d.snapshotHash())"));}
    @Test void cp08T04_approvedScopeMustBeSubsetRequested(){assertTrue(source("subscription/approval/application/ApprovalStateService.java").contains("containsAll(approved)"));}
    @Test void cp08T05_unrequestedOperationApprovalRejected(){assertTrue(source("subscription/approval/application/ApprovalStateService.java").contains("APPROVAL_SCOPE_EXCEEDS_REQUEST"));}
    @Test void cp08T06_approvedOperationOutsidePinnedVersionCannotEnterNormalFlow(){assertTrue(source("subscription/application/SubscriptionRequestService.java").contains("validateRequestedOperations"));}
    @Test void cp08T07_emptyApprovedScopeDoesNotMeanWholeProduct(){assertTrue(source("subscription/approval/application/ApprovalStateService.java").contains("빈 승인 scope"));}
    @Test void cp08T08_rejectionCreatesNoSubscriptionEntitlement(){assertTrue(source("subscription/approval/application/MockApprovalOrchestrator.java").contains("DecisionStatus.APPROVED"));}
    @Test void cp08T09_identicalApprovalReplayIsIdempotent(){assertTrue(source("subscription/approval/application/ApprovalStateService.java").contains("return replay(ref,d)"));}
    @Test void cp08T10_changedApprovalReplayConflicts(){assertTrue(source("subscription/approval/application/ApprovalStateService.java").contains("승인 payload를 변경"));}
    @Test void cp08T11_approvalSynchronizedEventExists(){assertTrue(source("subscription/approval/application/ApprovalStateService.java").contains("ApprovalSynchronized"));}
    @Test void cp08T12_approvedRequestStateOnlyForApprovedDecision(){assertTrue(source("subscription/approval/application/ApprovalStateService.java").contains("request.approve"));}
    @Test void cp08T13_completedOnlyAfterMaterialization(){String s=source("subscription/approval/application/MockApprovalOrchestrator.java");assertTrue(s.indexOf("materializer.materialize")<s.indexOf("state.complete"));}
    @Test void cp08T14_materializationFailureLeavesApprovalRecoverable(){String s=source("subscription/approval/application/MockApprovalOrchestrator.java");assertFalse(s.contains("catch("));}

    // Gateway
    @Test void cp08T15_pendingTransitionsProcessingBeforeAdapterCall(){String s=source("subscription/gateway/application/GatewayFulfillmentOrchestrator.java");assertTrue(s.indexOf("state.begin")<s.indexOf("gateway.provision"));}
    @Test void cp08T16_runtimeScopeDerivedFromEntitlement(){assertTrue(source("subscription/gateway/application/GatewayFulfillmentStateService.java").contains("EntitlementOperationScopeRepository"));}
    @Test void cp08T17_runtimeQuotaDerivedFromEntitlement(){assertTrue(source("subscription/gateway/application/GatewayFulfillmentStateService.java").contains("QuotaProfileRepository"));}
    @Test void cp08T18_runtimeEnvironmentVersionTenantDerivedServerSide(){String s=source("subscription/gateway/application/GatewayFulfillmentStateService.java");assertTrue(s.contains("getConsumerAppEnvironmentId")&&s.contains("getApiProductVersionId"));}
    @Test void cp08T19_sameFulfillmentKeyCreatesOneMockEffect(){MockGatewayAdapter a=new MockGatewayAdapter();GatewayPort.Command c=command("k","f");a.provision(c);a.provision(c);assertEquals(1,a.effectCount());}
    @Test void cp08T20_sameKeyChangedFingerprintConflicts(){MockGatewayAdapter a=new MockGatewayAdapter();a.provision(command("k","f1"));assertEquals(GatewayPort.ResultStatus.FAILED,a.provision(command("k","f2")).status());}
    @Test void cp08T21_successfulProvisionProducesSucceededResult(){MockGatewayAdapter a=new MockGatewayAdapter();assertEquals(GatewayPort.ResultStatus.SUCCEEDED,a.provision(command("k","f")).status());}
    @Test void cp08T22_successProducesOpaqueCredentialReferenceOnly(){MockGatewayAdapter a=new MockGatewayAdapter();var r=a.provision(command("k","f"));assertNotNull(r.credentialReference());assertFalse(r.credentialReference().toLowerCase().contains("secret"));}
    @Test void cp08T23_gatewayProvisioningCompletedEventExists(){assertTrue(source("subscription/gateway/application/GatewayFulfillmentStateService.java").contains("GatewayProvisioningCompleted"));}
    @Test void cp08T24_rawSecretTokenKeyNotPersisted(){String all=sourceTree("subscription").toLowerCase();assertFalse(all.contains("clientsecret"));assertFalse(all.contains("accesstoken"));assertFalse(all.contains("privatekey"));}

    // UNKNOWN
    @Test void cp08T25_timeoutAfterEffectReturnsUnknown(){MockGatewayAdapter a=new MockGatewayAdapter();var c=command("k","f");a.setScenario("k",MockGatewayAdapter.Scenario.TIMEOUT_AFTER_EFFECT);assertEquals(GatewayPort.ResultStatus.UNKNOWN,a.provision(c).status());}
    @Test void cp08T26_unknownDoesNotBlindSecondProvision(){MockGatewayAdapter a=new MockGatewayAdapter();var c=command("k","f");a.setScenario("k",MockGatewayAdapter.Scenario.TIMEOUT_AFTER_EFFECT);a.provision(c);assertEquals(1,a.effectCount());}
    @Test void cp08T27_reconcileUsesStatusQuery(){assertTrue(source("subscription/gateway/application/GatewayFulfillmentOrchestrator.java").contains("gateway.queryStatus"));}
    @Test void cp08T28_reconcileFindsExistingEffectWithoutDuplicate(){MockGatewayAdapter a=new MockGatewayAdapter();var c=command("k","f");a.setScenario("k",MockGatewayAdapter.Scenario.TIMEOUT_AFTER_EFFECT);var u=a.provision(c);assertEquals(GatewayPort.ResultStatus.SUCCEEDED,a.queryStatus(new GatewayPort.StatusQuery("t","k","f",u.externalOperationRef())).status());assertEquals(1,a.effectCount());}
    @Test void cp08T29_unresolvedStatusCanRemainUnknown(){MockGatewayAdapter a=new MockGatewayAdapter();assertEquals(GatewayPort.ResultStatus.UNKNOWN,a.queryStatus(new GatewayPort.StatusQuery("t","missing","f",null)).status());}

    // ReadyToUse
    @Test void cp08T30_approvalAloneDoesNotSetReady(){assertFalse(source("subscription/approval/application/ApprovalStateService.java").contains("readyToUse=true"));}
    @Test void cp08T31_grantedWithoutFulfillmentNotReady(){assertTrue(source("subscription/entitlement/application/ReadyToUseService.java").contains("AccessFulfillmentStatus.SUCCEEDED"));}
    @Test void cp08T32_succeededWithoutActiveCredentialNotReady(){assertTrue(source("subscription/entitlement/application/ReadyToUseService.java").contains("CredentialReferenceStatus.ACTIVE"));}
    @Test void cp08T33_completeMockE2eBecomesReady(){E2E e=e2e();assertTrue(ready.isReady(e.entitlement()));}
    @Test void cp08T34_suspendedConsumerAppIsNotReady(){assertTrue(source("subscription/entitlement/application/ReadyToUseService.java").contains("ConsumerAppLifecycleState.ACTIVE"));}
    @Test void cp08T35_revokedEntitlementImmediatelyNotReady(){assertTrue(source("subscription/entitlement/application/ReadyToUseService.java").contains("EntitlementStatus.GRANTED"));}
    @Test void cp08T36_expiredCredentialNotReady(){assertTrue(source("subscription/entitlement/application/ReadyToUseService.java").contains("getExpiresAt"));}
    @Disabled("DF-CP08-07: post-grant Publication/version validity semantics remain unapproved") @Test void cp08T37_postGrantPublicationValidityPolicyDependent(){fail();}

    // deprovision
    @Test void cp08T38_revokeCreatesDeprovisionIntentOnceByExistingCp07Contract(){assertTrue(source("subscription/entitlement/application/EntitlementCommandService.java").contains("AccessFulfillmentType.DEPROVISION"));}
    @Test void cp08T39_confirmedDeprovisionRevokesCredentialProjection(){assertTrue(source("subscription/gateway/application/GatewayFulfillmentStateService.java").contains("CredentialReferenceStatus.REVOKED"));}
    @Test void cp08T40_deprovisionUnknownCannotReactivateEntitlement(){assertFalse(source("subscription/gateway/application/GatewayFulfillmentStateService.java").contains("grant("));}

    // security/profile/isolation
    @Test void cp08T41_mockApprovalAdapterNotProdProfile(){assertTrue(source("subscription/approval/infrastructure/MockApprovalAdapter.java").contains("@Profile({\"local\",\"test\",\"mock-integration\"})"));}
    @Test void cp08T42_mockGatewayAdapterNotProdProfile(){assertTrue(source("subscription/gateway/infrastructure/MockGatewayAdapter.java").contains("@Profile({\"local\",\"test\",\"mock-integration\"})"));}
    @Test void cp08T43_noTenantHeaderControlsMockTarget(){String s=sourceTree("subscription/approval")+sourceTree("subscription/gateway");assertFalse(s.contains("X-Tenant-Id"));}
    @Test void cp08T44_crossTenantApprovalUsesTenantQualifiedLookup(){assertTrue(source("subscription/approval/application/ApprovalStateService.java").contains("findByIdAndTenantId"));}
    @Test void cp08T45_crossTenantFulfillmentUsesTenantQualifiedLookup(){assertTrue(source("subscription/gateway/application/GatewayFulfillmentStateService.java").contains("findByIdAndTenantId"));}
    @Test void cp08T46_roleNamesNotHardcoded(){String s=(sourceTree("subscription/approval")+sourceTree("subscription/gateway"));assertFalse(s.contains("TENANT_ADMIN"));assertFalse(s.contains("APP_OWNER"));}
    @Disabled("DF-CP08-11: ConsumerApp owner/organization object-scope authorization remains unapproved") @Test void cp08T47_consumerAppObjectScopePolicyDependent(){fail();}

    // regression/migration
    @Test void cp08T48_cp01ThroughCp07RegressionSuitesRemainPresent(){for(int i=1;i<=7;i++)assertTrue(Files.exists(Path.of("src/test/java/com/gsitm/ustra/api/platform/Cp0"+i+"AcceptanceIntegrationTest.java")));}
    @Test void cp08T49_migrationsReachV029(){assertTrue(Files.exists(Path.of("src/main/resources/db/migration/V029__approval_quota_limit.sql")));}
    @Test void cp08T50_noActualItsmOrGatewayVendorDependency(){String p=read(Path.of("pom.xml"));assertFalse(p.toLowerCase().contains("kong"));assertFalse(p.toLowerCase().contains("apigee"));assertFalse(p.toLowerCase().contains("servicenow"));}
    @Test void cp08T51_mockAdaptersRemainBehindPorts(){assertTrue(MockApprovalAdapter.class.getInterfaces()[0].equals(ApprovalPort.class));assertTrue(MockGatewayAdapter.class.getInterfaces()[0].equals(GatewayPort.class));}

    @Test void cp08E2E01_scopedRequestApprovalEntitlementGatewayCredentialReadyToUse(){E2E e=e2e();assertTrue(ready.isReady(e.entitlement()));assertEquals(1,approvalRefs.count());assertEquals(1,subscriptions.count());assertEquals(1,entitlements.count());assertEquals(1,credentials.count());}

    private E2E e2e(){Fixture f=fixture();setActor(f.membership().getPrincipalId());ConsumerAppEntity app=app(f);ConsumerAppEnvironmentEntity env=environments.saveAndFlush(new ConsumerAppEnvironmentEntity(UUID.randomUUID().toString(),f.tenant().getId(),app.getId(),ConsumerAppEnvironmentType.PROD,null,null,null,NOW,"fixture"));ApiProductEntity product=products.saveAndFlush(new ApiProductEntity(UUID.randomUUID().toString(),f.tenant().getId(),"P","P","P",null,null,null,NOW,"fixture"));ApiProductVersionEntity pv=new ApiProductVersionEntity(UUID.randomUUID().toString(),f.tenant().getId(),product.getId(),"v1",NOW,"fixture");productVersions.saveAndFlush(pv);jdbc.update("UPDATE api_product_version SET lifecycle_state='RELEASED' WHERE api_product_version_id=?",pv.getId());em.clear();pv=productVersions.findById(pv.getId()).orElseThrow();ApiEntity api=apis.saveAndFlush(new ApiEntity(UUID.randomUUID().toString(),f.tenant().getId(),"API","API","API",null,null,NOW,"fixture"));ApiVersionEntity av=apiVersions.saveAndFlush(new ApiVersionEntity(UUID.randomUUID().toString(),f.tenant().getId(),api.getId(),"v1",ApiVersionState.RELEASED,NOW,"fixture"));ApiOperationEntity op=operations.saveAndFlush(new ApiOperationEntity(UUID.randomUUID().toString(),f.tenant().getId(),av.getId(),"GET","/items","/items","getItems","Get",NOW,"fixture"));components.saveAndFlush(new ApiProductComponentEntity(UUID.randomUUID().toString(),f.tenant().getId(),pv.getId(),ApiProductComponentTargetType.API_OPERATION,null,op.getId(),NOW,"fixture"));CatalogPublicationEntity pub=new CatalogPublicationEntity(UUID.randomUUID().toString(),f.tenant().getId(),pv.getId(),NOW,"fixture");pub.activate(NOW,"fixture");pub=publications.saveAndFlush(pub);audiences.saveAndFlush(new AudienceScopeEntity(UUID.randomUUID().toString(),f.tenant().getId(),pub.getId(),AudienceScopeType.TENANT,null,NOW,"fixture"));SubscriptionRequestEntity req=requests.saveAndFlush(new SubscriptionRequestEntity(UUID.randomUUID().toString(),f.tenant().getId(),env.getId(),pub.getId(),pv.getId(),f.membership().getId(),NOW,"fixture"));var snap=new com.gsitm.ustra.api.platform.subscription.application.SubscriptionRequestSnapshotService();String hash=snap.snapshotHash(f.tenant().getId(),req.getId(),1,env.getId(),pub.getId(),pv.getId(),f.membership().getId(),"purpose",null,List.of(op.getId()));SubscriptionRequestRevisionEntity rev=revisions.saveAndFlush(new SubscriptionRequestRevisionEntity(UUID.randomUUID().toString(),f.tenant().getId(),req.getId(),1,f.membership().getId(),"purpose",null,hash,NOW,"fixture"));requestedScopes.saveAndFlush(new SubscriptionRequestRevisionOperationScopeEntity(UUID.randomUUID().toString(),f.tenant().getId(),rev.getId(),op.getId(),NOW,"fixture"));ApprovalReferenceEntity ref=approvals.createCase(f.tenant().getId(),req.getId());mockApproval.setDecision(ref.getExternalCaseRef(),new ApprovalPort.Decision(ref.getExternalCaseRef(),ApprovalPort.DecisionStatus.APPROVED,1,hash,List.of(op.getId()),List.of(),NOW.minusSeconds(60),NOW.plus(Duration.ofDays(30)),"evidence-ref","reviewer-ref",NOW));approvals.synchronize(f.tenant().getId(),ref.getId(),ref.getExternalCaseRef());EntitlementEntity ent=entitlements.findAllByTenantIdOrderByCreatedAtDesc(f.tenant().getId()).get(0);AccessFulfillmentEntity ff=fulfillments.findFirstByTenantIdAndEntitlementIdOrderByCreatedAtDesc(f.tenant().getId(),ent.getId()).orElseThrow();gateway.process(f.tenant().getId(),ff.getId());em.clear();ent=entitlements.findById(ent.getId()).orElseThrow();return new E2E(f,app,env,ent);}
    private GatewayPort.Command command(String key,String fingerprint){return new GatewayPort.Command("t","ful","ent","env","pv",List.of("op"),List.of(),key,fingerprint);}
    private Fixture fixture(){CustomerEntity c=customers.saveAndFlush(new CustomerEntity(UUID.randomUUID().toString(),"C-"+UUID.randomUUID(),"Customer",CustomerStatus.ACTIVE,NOW));TenantEntity t=new TenantEntity(UUID.randomUUID().toString(),c.getId(),"T-"+UUID.randomUUID(),"Tenant","ko-KR","Asia/Seoul",NOW);t.activate(NOW);t=tenants.saveAndFlush(t);configs.saveAndFlush(new TenantConfigurationEntity(UUID.randomUUID().toString(),t.getId(),"ko-KR","Asia/Seoul",NOW));MembershipEntity m=memberships.saveAndFlush(new MembershipEntity(UUID.randomUUID().toString(),t.getId(),null,"user-a","local-test",NOW.minus(Duration.ofDays(1)),null,NOW));return new Fixture(c,t,m);}
    private ConsumerAppEntity app(Fixture f){ConsumerAppEntity a=new ConsumerAppEntity(UUID.randomUUID().toString(),f.tenant().getId(),"APP","APP","App",null,f.membership().getId(),null,NOW,"fixture");a.activate(NOW,"fixture");return apps.saveAndFlush(a);}
    private void setActor(String principal){SecurityContextHolder.getContext().setAuthentication(new UsernamePasswordAuthenticationToken(new UstraPrincipal(principal,"local-test"),null,List.of(new SimpleGrantedAuthority("ROLE_TEST"))));RequestContextHolder.set(new RequestContext(UUID.randomUUID().toString(),UUID.randomUUID().toString()));}
    private String source(String relative){return read(Path.of("src/main/java/com/gsitm/ustra/api/platform").resolve(relative));}
    private String sourceTree(String relative){Path p=Path.of("src/main/java/com/gsitm/ustra/api/platform").resolve(relative);try{return Files.walk(p).filter(Files::isRegularFile).map(this::read).reduce("",String::concat);}catch(Exception e){throw new RuntimeException(e);}}
    private String read(Path p){try{return Files.readString(p);}catch(Exception e){throw new RuntimeException(e);}}
    private void cleanup(){approvalQuotas.deleteAllInBatch();approvalScopes.deleteAllInBatch();approvalRefs.deleteAllInBatch();credentials.deleteAllInBatch();fulfillments.deleteAllInBatch();quotaLimits.deleteAllInBatch();quotaProfiles.deleteAllInBatch();entitlementScopes.deleteAllInBatch();entitlements.deleteAllInBatch();subscriptions.deleteAllInBatch();requestedScopes.deleteAllInBatch();requestIdempotency.deleteAllInBatch();revisions.deleteAllInBatch();requests.deleteAllInBatch();audiences.deleteAllInBatch();publications.deleteAllInBatch();components.deleteAllInBatch();operations.deleteAllInBatch();apiVersions.deleteAllInBatch();apis.deleteAllInBatch();productVersions.deleteAllInBatch();products.deleteAllInBatch();environments.deleteAllInBatch();apps.deleteAllInBatch();history.deleteAllInBatch();assignments.deleteAllInBatch();memberships.deleteAllInBatch();organizations.deleteAllInBatch();configs.deleteAllInBatch();outbox.deleteAllInBatch();audit.deleteAllInBatch();tenants.deleteAllInBatch();customers.deleteAllInBatch();}
    private record Fixture(CustomerEntity customer,TenantEntity tenant,MembershipEntity membership){}
    private record E2E(Fixture fixture,ConsumerAppEntity app,ConsumerAppEnvironmentEntity environment,EntitlementEntity entitlement){}
}

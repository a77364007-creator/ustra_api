package com.gsitm.ustra.api.platform;

import static org.hamcrest.Matchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

/** Requires the real application context; never replaced by a source-presence test. */
@SpringBootTest @AutoConfigureMockMvc @ActiveProfiles("test")
class Cp15SecurityIntegrationTest {
    @Autowired MockMvc mvc;
    @Test void cp15T01_anonymousOperationsDenied() throws Exception {
        mvc.perform(get("/api/v1/admin/operations/summary")).andExpect(status().isUnauthorized());
    }
    @Test void cp15T01_anonymousAuditDenied() throws Exception {
        mvc.perform(get("/api/v1/admin/audit-records")).andExpect(status().isUnauthorized());
    }
    @Test void cp15T02_forgedTenantCannotSupplyAuthentication() throws Exception {
        mvc.perform(get("/api/v1/admin/operations/outbox-events").header("X-Tenant-Id",Cp15SafetyBehaviorTest.TENANT))
                .andExpect(status().isUnauthorized());
    }
    @Test void cp15T59_privateManagementEndpointNotPublic() throws Exception {
        mvc.perform(get("/actuator/env")).andExpect(status().isUnauthorized());
    }
    @Test void cp15T59_healthDoesNotReturnTenantOrConnectorSecrets() throws Exception {
        mvc.perform(get("/actuator/health")).andExpect(content().string(not(containsString("secretReference"))))
                .andExpect(content().string(not(containsString("tenantId"))));
    }
}

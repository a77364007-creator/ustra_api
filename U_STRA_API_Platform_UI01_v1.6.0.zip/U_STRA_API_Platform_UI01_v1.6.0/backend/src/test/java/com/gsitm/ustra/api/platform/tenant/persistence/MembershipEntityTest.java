package com.gsitm.ustra.api.platform.tenant.persistence;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.Instant;
import org.junit.jupiter.api.Test;

class MembershipEntityTest {
    @Test
    void effectivePeriodIsHalfOpenAndStatusSensitive() {
        Instant from = Instant.parse("2026-09-19T00:00:00Z");
        Instant to = Instant.parse("2026-09-20T00:00:00Z");
        MembershipEntity membership = new MembershipEntity(
                "m1", "t1", null, "p1", "issuer", from, to, from);

        assertFalse(membership.isEffectiveAt(from.minusNanos(1)));
        assertTrue(membership.isEffectiveAt(from));
        assertTrue(membership.isEffectiveAt(to.minusNanos(1)));
        assertFalse(membership.isEffectiveAt(to));

        membership.deactivate(from.plusSeconds(1));
        assertFalse(membership.isEffectiveAt(from.plusSeconds(2)));
    }
}

package com.gsitm.ustra.api.platform;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.flywaydb.core.Flyway;
import org.junit.jupiter.api.Test;
import org.testcontainers.containers.MariaDBContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

@Testcontainers
class MariaDbMigrationIntegrationTest {
    @Container
    static final MariaDBContainer<?> DB = new MariaDBContainer<>("mariadb:11.8.9")
            .withDatabaseName("ustra_api")
            .withUsername("ustra_api")
            .withPassword("test-only");

    @Test
    void cleanMariaDbAppliesAllCp01ThroughCp15Migrations() {
        Flyway flyway = Flyway.configure()
                .dataSource(DB.getJdbcUrl(), DB.getUsername(), DB.getPassword())
                .locations("classpath:db/migration")
                .load();
        assertEquals(49, flyway.migrate().migrationsExecuted);
        flyway.validate();
    }
}

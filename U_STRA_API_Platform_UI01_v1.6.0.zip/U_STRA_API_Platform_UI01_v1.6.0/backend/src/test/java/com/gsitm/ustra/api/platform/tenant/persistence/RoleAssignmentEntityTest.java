package com.gsitm.ustra.api.platform.tenant.persistence;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.Instant;
import org.junit.jupiter.api.Test;

class RoleAssignmentEntityTest {
    @Test
    void overlapAndEffectivePeriodUseHalfOpenIntervals() {
        Instant from = Instant.parse("2026-09-19T00:00:00Z");
        Instant to = Instant.parse("2026-09-20T00:00:00Z");
        RoleAssignmentEntity assignment = new RoleAssignmentEntity(
                "ra1", "t1", "m1", "r1", null, from, to, "admin", from);

        assertFalse(assignment.isEffectiveAt(from.minusNanos(1)));
        assertTrue(assignment.isEffectiveAt(from));
        assertFalse(assignment.isEffectiveAt(to));

        assertTrue(assignment.overlaps(from.plusSeconds(1), to.plusSeconds(1)));
        assertFalse(assignment.overlaps(to, to.plusSeconds(1)));
        assertFalse(assignment.overlaps(from.minusSeconds(2), from));
    }

    @Test
    void revokedAssignmentIsNoLongerEffectiveOrDuplicateAuthority() {
        Instant now = Instant.parse("2026-09-19T00:00:00Z");
        RoleAssignmentEntity assignment = new RoleAssignmentEntity(
                "ra1", "t1", "m1", "r1", null, now.minusSeconds(60), null, "admin", now);

        assignment.revoke("admin", now);

        assertFalse(assignment.isEffectiveAt(now));
        assertFalse(assignment.overlaps(now, null));
    }
}

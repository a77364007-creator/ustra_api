package com.gsitm.ustra.api.platform;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import com.gsitm.ustra.api.platform.outbox.*;
import com.gsitm.ustra.api.platform.operations.application.*;
import com.gsitm.ustra.api.platform.operations.domain.*;
import com.gsitm.ustra.api.platform.operations.persistence.*;
import com.gsitm.ustra.api.platform.integration.approval.application.*;
import com.gsitm.ustra.api.platform.integration.gateway.application.*;
import com.gsitm.ustra.api.platform.search.application.*;
import com.gsitm.ustra.api.platform.audit.AuditService;
import com.gsitm.ustra.api.platform.tenant.context.TenantContextResolver;
import com.gsitm.ustra.api.platform.tenant.application.TenantPermissionGuard;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.context.annotation.*;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.support.TransactionSynchronizationManager;
import org.springframework.transaction.support.TransactionTemplate;

class Cp15SpringBoundaryTest {
    private ApplicationContextRunner outbox(String... profiles) {
        return new ApplicationContextRunner().withUserConfiguration(OutboxConfiguration.class)
                .withInitializer(c->c.getEnvironment().setActiveProfiles(profiles));
    }
    @Configuration(proxyBeanMethods=false)
    @Import({OutboxDispatchService.class,LoggingOutboxSink.class,OutboxWorker.class})
    static class OutboxConfiguration {
        @Bean OutboxStateService state(){return mock(OutboxStateService.class);}
        @Bean OutboxEventRepository events(){return mock(OutboxEventRepository.class);}
    }
    @Test void cp15T17_localLoggingFixtureExists() {
        outbox("local").withPropertyValues("app.outbox.worker-enabled=false").run(c->{
            assertNull(c.getStartupFailure());assertEquals(1,c.getBeansOfType(LoggingOutboxSink.class).size());
        });
    }
    @Test void cp15T18_prodNoLoggingAuthorityAndNoDispatch() {
        outbox("prod").withPropertyValues("app.outbox.worker-enabled=false").run(c->{
            assertNull(c.getStartupFailure());assertTrue(c.getBeansOfType(LoggingOutboxSink.class).isEmpty());
            assertFalse(c.getBean(OutboxDispatchService.class).dispatchOne("event"));
            verifyNoInteractions(c.getBean(OutboxStateService.class));
        });
    }
    @Test void cp15T19_mixedProdTestStillNoMockDispatch() {
        outbox("prod","test","mock-integration").withPropertyValues("app.outbox.worker-enabled=false").run(c->{
            assertNull(c.getStartupFailure());assertTrue(c.getBeansOfType(LoggingOutboxSink.class).isEmpty());
            assertFalse(c.getBean(OutboxDispatchService.class).dispatchOne("event"));
        });
    }
    @Test void cp15T20_absentSinkAndDisabledWorkerDoNotLosePendingEvent() {
        outbox().withPropertyValues("app.outbox.worker-enabled=false").run(c->{
            assertNull(c.getStartupFailure());c.getBean(OutboxWorker.class).poll();
            assertFalse(c.getBean(OutboxDispatchService.class).dispatchOne("event"));
            verifyNoInteractions(c.getBean(OutboxStateService.class),c.getBean(OutboxEventRepository.class));
        });
    }
    @Test void cp15T21_explicitWorkerEnableWithoutSinkFailsAtStartup() {
        outbox().withPropertyValues("app.outbox.worker-enabled=true").run(c->assertNotNull(c.getStartupFailure()));
    }
    @Test void cp15T21_prodEnableRemainsGatedEvenWithLoggingProfile() {
        outbox("prod","local").withPropertyValues("app.outbox.worker-enabled=true").run(c->assertNotNull(c.getStartupFailure()));
    }
    @Configuration(proxyBeanMethods=false)
    @EnableTransactionManagement
    static class BoundaryConfiguration {
        @Bean PlatformTransactionManager txManager() {
            return new DataSourceTransactionManager(new DriverManagerDataSource("jdbc:h2:mem:cp15-boundary;DB_CLOSE_DELAY=-1","sa",""));
        }
        @Bean TenantContextResolver contexts(){return mock(TenantContextResolver.class);}
        @Bean TenantPermissionGuard permissions(){return mock(TenantPermissionGuard.class);}
        @Bean RecoveryTargetValidator targets(){return mock(RecoveryTargetValidator.class);}
        @Bean RecoveryActionService journal(){return mock(RecoveryActionService.class);}
        @Bean ApprovalIntegrationOrchestrator approval(){return mock(ApprovalIntegrationOrchestrator.class);}
        @Bean GatewayIntegrationOrchestrator gateway(){return mock(GatewayIntegrationOrchestrator.class);}
        @Bean SearchProjectionRecoveryService search(){return mock(SearchProjectionRecoveryService.class);}
        @Bean AuditService audit(){return mock(AuditService.class);}
        @Bean RecoveryActionOrchestrator orchestrator(TenantContextResolver c,TenantPermissionGuard p,RecoveryTargetValidator t,
                RecoveryActionService j,ApprovalIntegrationOrchestrator a,GatewayIntegrationOrchestrator g,
                SearchProjectionRecoveryService s,AuditService audit) {return new RecoveryActionOrchestrator(c,p,t,j,a,g,s,audit);}
    }
    @Test void cp15T41_notSupportedSuspendsCallerTransactionAtHandlerBoundary() {
        try(var context=new AnnotationConfigApplicationContext(BoundaryConfiguration.class)) {
            String tenant=Cp15SafetyBehaviorTest.TENANT;String target=Cp15SafetyBehaviorTest.PRODUCT;
            var request=new RecoveryRequest(RecoveryActionType.SEARCH_PRODUCT_REINDEX,target,null);
            var row=new OperationsRecoveryActionEntity("id",tenant,"key",request,"actor","corr",Cp15SafetyBehaviorTest.NOW);
            when(context.getBean(TenantContextResolver.class).resolve()).thenReturn(Cp15RecoveryBehaviorTest.context());
            var journal=context.getBean(RecoveryActionService.class);
            when(journal.prepare(any(),anyString(),any())).thenReturn(new RecoveryActionService.Prepared(row,true));
            when(journal.claim(tenant,"id")).thenReturn(true);
            var search=context.getBean(SearchProjectionRecoveryService.class);
            when(search.reindex(tenant,target,"actor")).thenAnswer(inv->{
                assertFalse(TransactionSynchronizationManager.isActualTransactionActive());
                return new CatalogSearchProjectionPort.ReindexResult(tenant,target,1,1);
            });
            new TransactionTemplate(context.getBean(PlatformTransactionManager.class)).execute(status->{
                assertTrue(TransactionSynchronizationManager.isActualTransactionActive());
                context.getBean(RecoveryActionOrchestrator.class).execute("key",request);
                assertTrue(TransactionSynchronizationManager.isActualTransactionActive());return null;
            });
            verify(search,times(1)).reindex(tenant,target,"actor");
        }
    }
}

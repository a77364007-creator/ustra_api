package com.gsitm.ustra.api.platform;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gsitm.ustra.api.platform.audit.AuditRecordRepository;
import com.gsitm.ustra.api.platform.catalog.domain.ApiVersionState;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiEntity;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiOperationEntity;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiOperationRepository;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiProductEntity;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiProductRepository;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiRepository;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiVersionEntity;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiVersionRepository;
import com.gsitm.ustra.api.platform.catalog.persistence.ProviderEntity;
import com.gsitm.ustra.api.platform.catalog.persistence.ProviderRepository;
import com.gsitm.ustra.api.platform.outbox.OutboxEventRepository;
import com.gsitm.ustra.api.platform.tenant.domain.CustomerStatus;
import com.gsitm.ustra.api.platform.tenant.persistence.CustomerEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.CustomerRepository;
import com.gsitm.ustra.api.platform.tenant.persistence.MembershipEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.MembershipRepository;
import com.gsitm.ustra.api.platform.tenant.persistence.OrganizationRepository;
import com.gsitm.ustra.api.platform.tenant.persistence.RoleAssignmentEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.RoleAssignmentRepository;
import com.gsitm.ustra.api.platform.tenant.persistence.RoleEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.RoleRepository;
import com.gsitm.ustra.api.platform.tenant.persistence.TenantConfigurationEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.TenantConfigurationRepository;
import com.gsitm.ustra.api.platform.tenant.persistence.TenantEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.TenantRepository;
import java.lang.reflect.Field;
import java.time.Duration;
import java.time.Instant;
import java.util.Arrays;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class Cp02AcceptanceIntegrationTest {
    private static final String API_PRODUCT_OWNER_ROLE_ID = "00000000-0000-0000-0000-000000000003";
    private static final String API_PROVIDER_ROLE_ID = "00000000-0000-0000-0000-000000000004";
    private static final String DEVELOPER_ROLE_ID = "00000000-0000-0000-0000-000000000006";
    private static final String P_READ = "11000000-0000-0000-0000-000000000001";
    private static final String P_CREATE = "11000000-0000-0000-0000-000000000002";
    private static final String P_UPDATE = "11000000-0000-0000-0000-000000000003";
    private static final String P_PUBLISH = "11000000-0000-0000-0000-000000000004";
    private static final String P_DEPRECATE = "11000000-0000-0000-0000-000000000005";
    private static final Instant NOW = Instant.parse("2026-09-20T00:00:00Z");

    @Autowired MockMvc mvc;
    @Autowired ObjectMapper objectMapper;
    @Autowired JdbcTemplate jdbc;
    @Autowired CustomerRepository customerRepository;
    @Autowired TenantRepository tenantRepository;
    @Autowired TenantConfigurationRepository configurationRepository;
    @Autowired MembershipRepository membershipRepository;
    @Autowired OrganizationRepository organizationRepository;
    @Autowired RoleRepository roleRepository;
    @Autowired RoleAssignmentRepository assignmentRepository;
    @Autowired ProviderRepository providerRepository;
    @Autowired ApiProductRepository productRepository;
    @Autowired ApiRepository apiRepository;
    @Autowired ApiVersionRepository apiVersionRepository;
    @Autowired ApiOperationRepository apiOperationRepository;
    @Autowired AuditRecordRepository auditRepository;
    @Autowired OutboxEventRepository outboxRepository;

    @BeforeEach
    void setUp() {
        cleanupData();
        resetCp02TestRoleMappings();
    }

    @AfterEach
    void tearDown() {
        cleanupData();
        removeCp02TestRoleMappings();
    }

    private void cleanupData() {
        apiOperationRepository.deleteAllInBatch();
        apiVersionRepository.deleteAllInBatch();
        apiRepository.deleteAllInBatch();
        productRepository.deleteAllInBatch();
        providerRepository.deleteAllInBatch();
        assignmentRepository.deleteAllInBatch();
        membershipRepository.deleteAllInBatch();
        organizationRepository.deleteAllInBatch();
        configurationRepository.deleteAllInBatch();
        outboxRepository.deleteAllInBatch();
        auditRepository.deleteAllInBatch();
        tenantRepository.deleteAllInBatch();
        customerRepository.deleteAllInBatch();
    }

    @Test
    void cp02T01_crossTenantProductIdDoesNotDiscloseResource() throws Exception {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        Fixture b = fixture("B", "user-b", API_PROVIDER_ROLE_ID);
        ApiProductEntity secret = product(b, "B-SECRET", "Tenant B Secret");

        mvc.perform(get("/api/v1/api-products/{id}", secret.getId())
                        .header("X-Test-Principal-Id", "user-a"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.code").value("API_PRODUCT_NOT_FOUND"));
    }

    @Test
    void cp02T02_spoofedTenantSelectorCannotChangeAuthority() throws Exception {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        Fixture b = fixture("B", "user-b", API_PROVIDER_ROLE_ID);
        product(a, "A-ONLY", "A Only");
        product(b, "B-ONLY", "B Only");

        mvc.perform(get("/api/v1/api-products")
                        .header("X-Test-Principal-Id", "user-a")
                        .header("X-Tenant-Id", b.tenant().getId()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].productCode").value("A-ONLY"))
                .andExpect(jsonPath("$[1]").doesNotExist());
    }

    @Test
    void cp02T03_missingReadPermissionDenied() throws Exception {
        fixture("A", "user-a", DEVELOPER_ROLE_ID);
        mvc.perform(get("/api/v1/api-products").header("X-Test-Principal-Id", "user-a"))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.code").value("ACCESS_DENIED"));
    }

    @Test
    void cp02T04_missingCreatePermissionDenied() throws Exception {
        fixture("A", "user-a", API_PRODUCT_OWNER_ROLE_ID);
        mvc.perform(post("/api/v1/api-products")
                        .header("X-Test-Principal-Id", "user-a")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of("productCode", "P1", "name", "Product 1"))))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.code").value("ACCESS_DENIED"));
    }

    @Test
    void cp02T05_missingUpdatePermissionDenied() throws Exception {
        Fixture a = fixture("A", "user-a", API_PRODUCT_OWNER_ROLE_ID);
        ApiProductEntity p = product(a, "P1", "Product 1");
        mvc.perform(patch("/api/v1/api-products/{id}", p.getId())
                        .header("X-Test-Principal-Id", "user-a")
                        .header("If-Match", "\"0\"")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of("name", "Changed"))))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.code").value("ACCESS_DENIED"));
    }

    @Test
    void cp02T06_createValidProductUsesResolvedTenantAndDraftState() throws Exception {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        ProviderEntity provider = provider(a, "PROV-A", "Provider A");
        MembershipEntity owner = membership(a.tenant(), "target-user");

        mvc.perform(post("/api/v1/api-products")
                        .header("X-Test-Principal-Id", "user-a")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of(
                                "productCode", " business_status ",
                                "name", "Business Status",
                                "providerId", provider.getId(),
                                "ownerMembershipId", owner.getId()))))
                .andExpect(status().isCreated())
                .andExpect(header().string("ETag", "\"0\""))
                .andExpect(jsonPath("$.productCode").value("BUSINESS_STATUS"))
                .andExpect(jsonPath("$.lifecycleState").value("DRAFT"));

        ApiProductEntity saved = productRepository.findAllByTenantIdOrderByProductCodeNormalizedAsc(a.tenant().getId())
                .getFirst();
        assertEquals(a.tenant().getId(), saved.getTenantId());
        assertEquals("BUSINESS_STATUS", saved.getProductCodeNormalized());
    }

    @Test
    void cp02T07_duplicateCanonicalProductCodeRejected() throws Exception {
        fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        mvc.perform(post("/api/v1/api-products")
                        .header("X-Test-Principal-Id", "user-a")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of("productCode", " demo ", "name", "One"))))
                .andExpect(status().isCreated());
        mvc.perform(post("/api/v1/api-products")
                        .header("X-Test-Principal-Id", "user-a")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of("productCode", "DEMO", "name", "Two"))))
                .andExpect(status().isConflict())
                .andExpect(jsonPath("$.code").value("API_PRODUCT_CODE_CONFLICT"));
    }

    @Test
    void cp02T08_detailLookupIsTenantQualified() throws Exception {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        ApiProductEntity p = product(a, "A-PROD", "Product A");
        mvc.perform(get("/api/v1/api-products/{id}", p.getId()).header("X-Test-Principal-Id", "user-a"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.apiProductId").value(p.getId()))
                .andExpect(jsonPath("$.productCode").value("A-PROD"));
    }

    @Test
    void cp02T09_patchWithCurrentRevisionUpdatesAndIncrementsRevision() throws Exception {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        ApiProductEntity p = product(a, "P1", "Before");
        mvc.perform(patch("/api/v1/api-products/{id}", p.getId())
                        .header("X-Test-Principal-Id", "user-a")
                        .header("If-Match", "\"0\"")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of("name", "After"))))
                .andExpect(status().isOk())
                .andExpect(header().string("ETag", "\"1\""))
                .andExpect(jsonPath("$.name").value("After"))
                .andExpect(jsonPath("$.revision").value(1));
    }

    @Test
    void cp02T10_staleRevisionRejected() throws Exception {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        ApiProductEntity p = product(a, "P1", "Before");
        mvc.perform(patch("/api/v1/api-products/{id}", p.getId())
                        .header("X-Test-Principal-Id", "user-a")
                        .header("If-Match", "\"0\"")
                        .contentType(MediaType.APPLICATION_JSON).content(json(Map.of("name", "First"))))
                .andExpect(status().isOk());
        mvc.perform(patch("/api/v1/api-products/{id}", p.getId())
                        .header("X-Test-Principal-Id", "user-a")
                        .header("If-Match", "\"0\"")
                        .contentType(MediaType.APPLICATION_JSON).content(json(Map.of("name", "Stale"))))
                .andExpect(status().isConflict())
                .andExpect(jsonPath("$.code").value("CONCURRENT_MODIFICATION"));
    }

    @Test
    void cp02T11_patchCannotMutateLifecycleState() throws Exception {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        ApiProductEntity p = product(a, "P1", "Product");
        mvc.perform(patch("/api/v1/api-products/{id}", p.getId())
                        .header("X-Test-Principal-Id", "user-a").header("If-Match", "\"0\"")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of("name", "Product", "lifecycleState", "ACTIVE"))))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("VALIDATION_ERROR"));
        assertEquals("DRAFT", productRepository.findById(p.getId()).orElseThrow().getLifecycleState().name());
    }

    @Test
    void cp02T12_patchCannotMutateTenantOrProductCode() throws Exception {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        Fixture b = fixture("B", "user-b", API_PROVIDER_ROLE_ID);
        ApiProductEntity p = product(a, "IMMUTABLE", "Product");
        mvc.perform(patch("/api/v1/api-products/{id}", p.getId())
                        .header("X-Test-Principal-Id", "user-a").header("If-Match", "\"0\"")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of("name", "Product", "productCode", "MUTATED", "tenantId", b.tenant().getId()))))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("VALIDATION_ERROR"));
        ApiProductEntity unchanged = productRepository.findById(p.getId()).orElseThrow();
        assertEquals("IMMUTABLE", unchanged.getProductCode());
        assertEquals(a.tenant().getId(), unchanged.getTenantId());
    }

    @Test
    void cp02T13_crossTenantProviderRejectedWithoutDisclosure() throws Exception {
        fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        Fixture b = fixture("B", "user-b", API_PROVIDER_ROLE_ID);
        ProviderEntity providerB = provider(b, "PB", "Provider B");
        mvc.perform(post("/api/v1/api-products")
                        .header("X-Test-Principal-Id", "user-a")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of("productCode", "P1", "name", "Product", "providerId", providerB.getId()))))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("PROVIDER_NOT_FOUND"));
    }

    @Test
    void cp02T14_crossTenantOwnerMembershipRejectedWithoutDisclosure() throws Exception {
        fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        Fixture b = fixture("B", "user-b", API_PROVIDER_ROLE_ID);
        MembershipEntity ownerB = membership(b.tenant(), "target-user");
        mvc.perform(post("/api/v1/api-products")
                        .header("X-Test-Principal-Id", "user-a")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of("productCode", "P1", "name", "Product", "ownerMembershipId", ownerB.getId()))))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("MEMBERSHIP_NOT_FOUND"));
    }

    @Disabled("CP02-T15 owner ACTIVE/effective policy is explicitly TBD in approved design baseline")
    @Test
    void cp02T15_inactiveOwnerPolicyRequiresDesignDecision() {
    }

    @Test
    void cp02T16_duplicateApiVersionRejectedByDatabaseConstraint() {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        ApiEntity api = api(a, "STATUS", "Status API");
        apiVersionRepository.saveAndFlush(version(a, api, "v1", ApiVersionState.DRAFT));
        assertThrows(DataIntegrityViolationException.class,
                () -> apiVersionRepository.saveAndFlush(version(a, api, "v1", ApiVersionState.VALIDATED)));
    }

    @Test
    void cp02T17_duplicateOperationKeyRejectedByDatabaseConstraint() {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        ApiEntity api = api(a, "STATUS", "Status API");
        ApiVersionEntity version = apiVersionRepository.saveAndFlush(version(a, api, "v1", ApiVersionState.DRAFT));
        apiOperationRepository.saveAndFlush(operation(a, version, "GET", "/companies/{id}", "/companies/{id}"));
        assertThrows(DataIntegrityViolationException.class, () -> apiOperationRepository.saveAndFlush(
                operation(a, version, "GET", "/companies/{id}", "/companies/{id}")));
    }

    @Test
    void cp02T18_apiVersionCannotReferenceApiFromAnotherTenant() {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        Fixture b = fixture("B", "user-b", API_PROVIDER_ROLE_ID);
        ApiEntity apiB = api(b, "B-API", "B API");
        ApiVersionEntity invalid = new ApiVersionEntity(UUID.randomUUID().toString(), a.tenant().getId(), apiB.getId(),
                "v1", ApiVersionState.DRAFT, NOW, "fixture");
        assertThrows(DataIntegrityViolationException.class, () -> apiVersionRepository.saveAndFlush(invalid));
    }

    @Test
    void cp02T19_operationCannotReferenceVersionFromAnotherTenant() {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        Fixture b = fixture("B", "user-b", API_PROVIDER_ROLE_ID);
        ApiEntity apiB = api(b, "B-API", "B API");
        ApiVersionEntity versionB = apiVersionRepository.saveAndFlush(version(b, apiB, "v1", ApiVersionState.DRAFT));
        ApiOperationEntity invalid = new ApiOperationEntity(UUID.randomUUID().toString(), a.tenant().getId(),
                versionB.getId(), "GET", "/x", "/x", null, null, NOW, "fixture");
        assertThrows(DataIntegrityViolationException.class, () -> apiOperationRepository.saveAndFlush(invalid));
    }

    @Test
    void cp02T20_apiVersionStateIsIndependentFromProductState() {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        ApiProductEntity product = product(a, "P1", "Product");
        ApiEntity api = api(a, "A1", "API 1");
        ApiVersionEntity version = apiVersionRepository.saveAndFlush(version(a, api, "v1", ApiVersionState.RELEASED));
        assertEquals("DRAFT", product.getLifecycleState().name());
        assertEquals(ApiVersionState.RELEASED, version.getState());
    }

    @Test
    void cp02T21_apiDoesNotContainDirectProductCompositionForeignKey() {
        assertFalse(Arrays.stream(ApiEntity.class.getDeclaredFields())
                .map(Field::getName)
                .anyMatch(name -> name.toLowerCase().contains("product")));
    }

    @Test
    void cp02T22_managementListReturnsOnlyAuthorizedTenantProducts() throws Exception {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        Fixture b = fixture("B", "user-b", API_PROVIDER_ROLE_ID);
        product(a, "A-ONE", "A One");
        product(a, "A-TWO", "A Two");
        product(b, "B-ONE", "B One");
        mvc.perform(get("/api/v1/api-products").header("X-Test-Principal-Id", "user-a"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].productCode").value("A-ONE"))
                .andExpect(jsonPath("$[1].productCode").value("A-TWO"))
                .andExpect(jsonPath("$[2]").doesNotExist());
    }

    @Test
    void cp02T23_managementListDoesNotFabricatePublicationOrAudienceData() throws Exception {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        product(a, "P1", "Product");
        mvc.perform(get("/api/v1/api-products").header("X-Test-Principal-Id", "user-a"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].publication").doesNotExist())
                .andExpect(jsonPath("$[0].audienceScope").doesNotExist())
                .andExpect(jsonPath("$[0].usageCount").doesNotExist())
                .andExpect(jsonPath("$[0].sla").doesNotExist())
                .andExpect(jsonPath("$[0].sandboxAvailable").doesNotExist());
    }

    @Disabled("CP02-T24 consumer catalog publication/audience semantics belong to CP-03/CP-12")
    @Test
    void cp02T24_consumerCatalogIsDeferred() {
    }

    @Test
    void cp02N01_metadataMutationDoesNotInventAuditOrIntegrationEvents() throws Exception {
        fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        long auditsBefore = auditRepository.count();
        long eventsBefore = outboxRepository.count();
        mvc.perform(post("/api/v1/api-products")
                        .header("X-Test-Principal-Id", "user-a")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of("productCode", "P1", "name", "Product"))))
                .andExpect(status().isCreated());
        assertEquals(auditsBefore, auditRepository.count());
        assertEquals(eventsBefore, outboxRepository.count());
    }

    private void resetCp02TestRoleMappings() {
        removeCp02TestRoleMappings();
        jdbc.update("INSERT INTO role_permission(role_id, permission_id) VALUES (?, ?)", API_PROVIDER_ROLE_ID, P_READ);
        jdbc.update("INSERT INTO role_permission(role_id, permission_id) VALUES (?, ?)", API_PROVIDER_ROLE_ID, P_CREATE);
        jdbc.update("INSERT INTO role_permission(role_id, permission_id) VALUES (?, ?)", API_PROVIDER_ROLE_ID, P_UPDATE);
        jdbc.update("INSERT INTO role_permission(role_id, permission_id) VALUES (?, ?)", API_PRODUCT_OWNER_ROLE_ID, P_READ);
    }

    private void removeCp02TestRoleMappings() {
        String[] roles = {API_PROVIDER_ROLE_ID, API_PRODUCT_OWNER_ROLE_ID};
        String[] permissions = {P_READ, P_CREATE, P_UPDATE, P_PUBLISH, P_DEPRECATE};
        for (String role : roles) {
            for (String permission : permissions) {
                jdbc.update("DELETE FROM role_permission WHERE role_id = ? AND permission_id = ?", role, permission);
            }
        }
    }

    private Fixture fixture(String suffix, String principal, String roleId) {
        CustomerEntity customer = customer("C-" + suffix);
        TenantEntity tenant = activeTenant(customer, suffix);
        MembershipEntity membership = membership(tenant, principal);
        roleAssignment(tenant, membership, roleId);
        return new Fixture(customer, tenant, membership);
    }

    private CustomerEntity customer(String code) {
        return customerRepository.saveAndFlush(new CustomerEntity(UUID.randomUUID().toString(), code, code,
                CustomerStatus.ACTIVE, NOW));
    }

    private TenantEntity activeTenant(CustomerEntity customer, String suffix) {
        TenantEntity tenant = new TenantEntity(UUID.randomUUID().toString(), customer.getId(), "T-" + suffix,
                "Tenant " + suffix, "ko-KR", "Asia/Seoul", NOW);
        tenant.activate(NOW);
        tenant = tenantRepository.saveAndFlush(tenant);
        configurationRepository.saveAndFlush(new TenantConfigurationEntity(UUID.randomUUID().toString(),
                tenant.getId(), "ko-KR", "Asia/Seoul", NOW));
        return tenant;
    }

    private MembershipEntity membership(TenantEntity tenant, String principal) {
        return membershipRepository.saveAndFlush(new MembershipEntity(UUID.randomUUID().toString(), tenant.getId(),
                null, principal, "local-test", NOW.minus(Duration.ofDays(1)), null, NOW));
    }

    private void roleAssignment(TenantEntity tenant, MembershipEntity membership, String roleId) {
        RoleEntity role = roleRepository.findById(roleId).orElseThrow();
        assignmentRepository.saveAndFlush(new RoleAssignmentEntity(UUID.randomUUID().toString(), tenant.getId(),
                membership.getId(), role.getId(), null, NOW.minusSeconds(60), null, "fixture", NOW));
    }

    private ProviderEntity provider(Fixture f, String code, String name) {
        return providerRepository.saveAndFlush(new ProviderEntity(UUID.randomUUID().toString(), f.tenant().getId(),
                code, name, null, NOW, "fixture"));
    }

    private ApiProductEntity product(Fixture f, String code, String name) {
        return productRepository.saveAndFlush(new ApiProductEntity(UUID.randomUUID().toString(), f.tenant().getId(),
                code, code, name, null, null, null, NOW, "fixture"));
    }

    private ApiEntity api(Fixture f, String code, String name) {
        return apiRepository.saveAndFlush(new ApiEntity(UUID.randomUUID().toString(), f.tenant().getId(), code, code,
                name, null, null, NOW, "fixture"));
    }

    private ApiVersionEntity version(Fixture f, ApiEntity api, String version, ApiVersionState state) {
        return new ApiVersionEntity(UUID.randomUUID().toString(), f.tenant().getId(), api.getId(), version, state,
                NOW, "fixture");
    }

    private ApiOperationEntity operation(Fixture f, ApiVersionEntity version, String method, String path,
                                         String normalizedPath) {
        return new ApiOperationEntity(UUID.randomUUID().toString(), f.tenant().getId(), version.getId(), method,
                path, normalizedPath, null, null, NOW, "fixture");
    }

    private String json(Object value) throws Exception {
        return objectMapper.writeValueAsString(value);
    }

    private record Fixture(CustomerEntity customer, TenantEntity tenant, MembershipEntity membership) {
    }
}

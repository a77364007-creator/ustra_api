package com.gsitm.ustra.api.platform.tenant.persistence;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.gsitm.ustra.api.platform.tenant.domain.TenantStatus;
import java.time.Instant;
import org.junit.jupiter.api.Test;

class TenantEntityTest {
    @Test
    void semanticLifecycleMethodsChangeStateWithoutGenericSetter() {
        Instant now = Instant.parse("2026-09-19T00:00:00Z");
        TenantEntity tenant = new TenantEntity("t1", "c1", "TENANT", "Tenant", "ko-KR", "Asia/Seoul", now);

        assertEquals(TenantStatus.DRAFT, tenant.getStatus());
        tenant.activate(now.plusSeconds(1));
        assertEquals(TenantStatus.ACTIVE, tenant.getStatus());
        tenant.suspend(now.plusSeconds(2));
        assertEquals(TenantStatus.SUSPENDED, tenant.getStatus());
        tenant.retire(now.plusSeconds(3));
        assertEquals(TenantStatus.RETIRED, tenant.getStatus());
    }
}

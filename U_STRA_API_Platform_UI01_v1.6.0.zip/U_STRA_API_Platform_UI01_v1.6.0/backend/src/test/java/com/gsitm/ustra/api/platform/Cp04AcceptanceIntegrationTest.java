package com.gsitm.ustra.api.platform;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.reset;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gsitm.ustra.api.platform.audit.AuditRecordRepository;
import com.gsitm.ustra.api.platform.catalog.localization.api.ApiProductLocalizationController;
import com.gsitm.ustra.api.platform.catalog.localization.application.ApiProductLocalizationService;
import com.gsitm.ustra.api.platform.catalog.localization.application.LocalizationResolutionService;
import com.gsitm.ustra.api.platform.catalog.localization.application.LocalizationResolutionService.ResolutionSource;
import com.gsitm.ustra.api.platform.catalog.localization.domain.LocalizationStatus;
import com.gsitm.ustra.api.platform.catalog.localization.persistence.LocalizedContentEntity;
import com.gsitm.ustra.api.platform.catalog.localization.persistence.LocalizedContentRepository;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiOperationRepository;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiProductEntity;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiProductRepository;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiRepository;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiVersionRepository;
import com.gsitm.ustra.api.platform.catalog.persistence.ProviderEntity;
import com.gsitm.ustra.api.platform.catalog.persistence.ProviderRepository;
import com.gsitm.ustra.api.platform.catalog.publication.application.CatalogVisibilityService;
import com.gsitm.ustra.api.platform.catalog.publication.domain.ApiProductVersionState;
import com.gsitm.ustra.api.platform.catalog.publication.domain.AudienceScopeType;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.ApiProductComponentRepository;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.ApiProductVersionEntity;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.ApiProductVersionRepository;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.AudienceScopeEntity;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.AudienceScopeRepository;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.CatalogPublicationEntity;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.CatalogPublicationRepository;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.StateTransitionHistoryRepository;
import com.gsitm.ustra.api.platform.outbox.OutboxEventRepository;
import com.gsitm.ustra.api.platform.outbox.OutboxService;
import com.gsitm.ustra.api.platform.tenant.domain.CustomerStatus;
import com.gsitm.ustra.api.platform.tenant.persistence.CustomerEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.CustomerRepository;
import com.gsitm.ustra.api.platform.tenant.persistence.MembershipEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.MembershipRepository;
import com.gsitm.ustra.api.platform.tenant.persistence.OrganizationRepository;
import com.gsitm.ustra.api.platform.tenant.persistence.RoleAssignmentEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.RoleAssignmentRepository;
import com.gsitm.ustra.api.platform.tenant.persistence.RoleEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.RoleRepository;
import com.gsitm.ustra.api.platform.tenant.persistence.TenantConfigurationEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.TenantConfigurationRepository;
import com.gsitm.ustra.api.platform.tenant.persistence.TenantEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.TenantRepository;
import jakarta.persistence.EntityManager;
import java.lang.reflect.Field;
import java.time.Duration;
import java.time.Instant;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoSpyBean;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class Cp04AcceptanceIntegrationTest {
    private static final String API_PRODUCT_OWNER_ROLE_ID = "00000000-0000-0000-0000-000000000003";
    private static final String API_PROVIDER_ROLE_ID = "00000000-0000-0000-0000-000000000004";
    private static final String DEVELOPER_ROLE_ID = "00000000-0000-0000-0000-000000000006";
    private static final String P_READ = "11000000-0000-0000-0000-000000000001";
    private static final String P_CREATE = "11000000-0000-0000-0000-000000000002";
    private static final String P_UPDATE = "11000000-0000-0000-0000-000000000003";
    private static final String P_PUBLISH = "11000000-0000-0000-0000-000000000004";
    private static final String P_DEPRECATE = "11000000-0000-0000-0000-000000000005";
    private static final Instant NOW = Instant.parse("2026-09-20T00:00:00Z");

    @Autowired MockMvc mvc;
    @Autowired ObjectMapper objectMapper;
    @Autowired JdbcTemplate jdbc;
    @Autowired EntityManager entityManager;
    @Autowired CustomerRepository customerRepository;
    @Autowired TenantRepository tenantRepository;
    @Autowired TenantConfigurationRepository configurationRepository;
    @Autowired MembershipRepository membershipRepository;
    @Autowired OrganizationRepository organizationRepository;
    @Autowired RoleRepository roleRepository;
    @Autowired RoleAssignmentRepository assignmentRepository;
    @Autowired ProviderRepository providerRepository;
    @Autowired ApiProductRepository productRepository;
    @Autowired LocalizedContentRepository localizedContentRepository;
    @Autowired ApiRepository apiRepository;
    @Autowired ApiVersionRepository apiVersionRepository;
    @Autowired ApiOperationRepository apiOperationRepository;
    @Autowired ApiProductVersionRepository productVersionRepository;
    @Autowired ApiProductComponentRepository componentRepository;
    @Autowired CatalogPublicationRepository publicationRepository;
    @Autowired AudienceScopeRepository audienceRepository;
    @Autowired StateTransitionHistoryRepository historyRepository;
    @Autowired AuditRecordRepository auditRepository;
    @Autowired OutboxEventRepository outboxRepository;
    @Autowired LocalizationResolutionService resolutionService;
    @Autowired CatalogVisibilityService visibilityService;
    @MockitoSpyBean OutboxService outboxService;

    @BeforeEach
    void setUp() {
        cleanupData();
        resetCp04TestRoleMappings();
    }

    @AfterEach
    void tearDown() {
        reset(outboxService);
        cleanupData();
        removeCp04TestRoleMappings();
    }

    private void cleanupData() {
        localizedContentRepository.deleteAllInBatch();
        audienceRepository.deleteAllInBatch();
        publicationRepository.deleteAllInBatch();
        historyRepository.deleteAllInBatch();
        componentRepository.deleteAllInBatch();
        productVersionRepository.deleteAllInBatch();
        apiOperationRepository.deleteAllInBatch();
        apiVersionRepository.deleteAllInBatch();
        apiRepository.deleteAllInBatch();
        productRepository.deleteAllInBatch();
        providerRepository.deleteAllInBatch();
        assignmentRepository.deleteAllInBatch();
        membershipRepository.deleteAllInBatch();
        organizationRepository.deleteAllInBatch();
        configurationRepository.deleteAllInBatch();
        outboxRepository.deleteAllInBatch();
        auditRepository.deleteAllInBatch();
        tenantRepository.deleteAllInBatch();
        customerRepository.deleteAllInBatch();
    }

    @Test
    void cp04T01_productMayStoreIndependentKoAndEnLocalizedContent() throws Exception {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        ApiProductEntity product = product(a, "P1", "Canonical");
        putDraft(a, product, "ko-KR", "한국어", "설명", null, 201);
        putDraft(a, product, "en-US", "English", "Description", null, 201);
        List<LocalizedContentEntity> rows = localizedContentRepository
                .findAllByTenantIdAndApiProductIdOrderByLocaleAsc(a.tenant().getId(), product.getId());
        assertEquals(2, rows.size());
        assertEquals(List.of("en-US", "ko-KR"), rows.stream().map(LocalizedContentEntity::getLocale).toList());
    }

    @Test
    void cp04T02_localizationDoesNotCloneCanonicalApiProduct() throws Exception {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        ApiProductEntity product = product(a, "P1", "Canonical");
        putDraft(a, product, "ko-KR", "한국어", null, null, 201);
        putDraft(a, product, "en-US", "English", null, null, 201);
        assertEquals(1, productRepository.findAllByTenantIdOrderByProductCodeNormalizedAsc(a.tenant().getId()).size());
    }

    @Test
    void cp04T03_duplicateProductLocaleRejectedByDbConstraint() {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        ApiProductEntity product = product(a, "P1", "Canonical");
        localizedContentRepository.saveAndFlush(localized(a, product, "ko-KR", "A"));
        assertThrows(DataIntegrityViolationException.class, () -> localizedContentRepository.saveAndFlush(
                localized(a, product, "ko-KR", "B")));
    }

    @Test
    void cp04T04_crossTenantProductLocalizationIsNotAccessible() throws Exception {
        fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        Fixture b = fixture("B", "user-b", API_PROVIDER_ROLE_ID);
        ApiProductEntity productB = product(b, "PB", "B Product");
        mvc.perform(get("/api/v1/api-products/{id}/localized-contents", productB.getId())
                        .header("X-Test-Principal-Id", "user-a"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.code").value("API_PRODUCT_NOT_FOUND"));
    }

    @Test
    void cp04T05_missingUpdatePermissionDeniedByBackend() throws Exception {
        Fixture a = fixture("A", "user-a", DEVELOPER_ROLE_ID);
        ApiProductEntity product = product(a, "P1", "Canonical");
        mvc.perform(put("/api/v1/api-products/{id}/localized-contents/{locale}", product.getId(), "ko-KR")
                        .header("X-Test-Principal-Id", "user-a")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of("name", "한국어"))))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.code").value("ACCESS_DENIED"));
    }

    @Test
    void cp04T06_controllerUsesSemanticGetPutAndHasNoGenericStatusPatch() {
        assertFalse(Arrays.stream(ApiProductLocalizationController.class.getDeclaredMethods())
                .flatMap(m -> Arrays.stream(m.getAnnotations()))
                .anyMatch(a -> a.annotationType().getSimpleName().equals("PatchMapping")));
    }

    @Test
    void cp04T07_missingLocaleIsDerivedWithoutPersistingMissingRow() {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        ApiProductEntity product = product(a, "P1", "Canonical");
        assertEquals(LocalizationStatus.MISSING, resolutionService.status(a.tenant().getId(), product.getId(), "en-US"));
        assertEquals(0, localizedContentRepository.count());
    }

    @Test
    void cp04T08_putCreatesDraftWithSourceRevision() throws Exception {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        ApiProductEntity product = product(a, "P1", "Canonical");
        mvc.perform(put("/api/v1/api-products/{id}/localized-contents/{locale}", product.getId(), "ko-KR")
                        .header("X-Test-Principal-Id", "user-a")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of("name", "한국어", "description", "설명"))))
                .andExpect(status().isCreated())
                .andExpect(header().string("ETag", "\"0\""))
                .andExpect(jsonPath("$.status").value("DRAFT"))
                .andExpect(jsonPath("$.revision").value(1))
                .andExpect(jsonPath("$.sourceLocalizationRevision").value(1));
    }

    @Test
    void cp04T09_publishCommandRemainsClosedUntilReviewPolicyIsApproved() throws Exception {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        ApiProductEntity product = product(a, "P1", "Canonical");
        putDraft(a, product, "ko-KR", "한국어", null, null, 201);
        mvc.perform(post("/api/v1/api-products/{id}/localized-contents/{locale}/publish", product.getId(), "ko-KR")
                        .header("X-Test-Principal-Id", "user-a"))
                .andExpect(status().isNotFound());
    }

    @Test
    void cp04T10_translatableCanonicalChangeMarksPublishedLocalizationStale() throws Exception {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        ApiProductEntity product = product(a, "P1", "Canonical");
        LocalizedContentEntity localized = published(a, product, "ko-KR", "한국어");
        patchProduct(a, product, "Canonical Changed", null, null, null, 0, 200);
        entityManager.clear();
        ApiProductEntity changed = productRepository.findById(product.getId()).orElseThrow();
        LocalizedContentEntity stale = localizedContentRepository.findById(localized.getId()).orElseThrow();
        assertEquals(2, changed.getLocalizationRevision());
        assertEquals(LocalizationStatus.STALE, stale.getStatus());
        assertEquals(1, stale.getSourceLocalizationRevision());
    }

    @Test
    void cp04T11_nonTranslatableCanonicalChangeDoesNotMarkPublishedLocalizationStale() throws Exception {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        ApiProductEntity product = product(a, "P1", "Canonical");
        ProviderEntity provider = provider(a, "PROV", "Provider");
        LocalizedContentEntity localized = published(a, product, "ko-KR", "한국어");
        patchProduct(a, product, "Canonical", null, provider.getId(), null, 0, 200);
        entityManager.clear();
        assertEquals(1, productRepository.findById(product.getId()).orElseThrow().getLocalizationRevision());
        assertEquals(LocalizationStatus.PUBLISHED,
                localizedContentRepository.findById(localized.getId()).orElseThrow().getStatus());
    }

    @Test
    void cp04T12_requestedPublishedLocaleWinsFallback() {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        ApiProductEntity product = product(a, "P1", "Canonical");
        published(a, product, "ko-KR", "한국어");
        published(a, product, "en-US", "English");
        var resolved = resolutionService.resolve(a.tenant().getId(), product.getId(), "en-US");
        assertEquals("English", resolved.name());
        assertEquals(ResolutionSource.REQUESTED_LOCALE, resolved.source());
    }

    @Test
    void cp04T13_missingRequestedLocaleFallsBackToTenantDefaultPublishedLocale() {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        ApiProductEntity product = product(a, "P1", "Canonical");
        published(a, product, "ko-KR", "한국어");
        var resolved = resolutionService.resolve(a.tenant().getId(), product.getId(), "ja-JP");
        assertEquals("한국어", resolved.name());
        assertEquals(ResolutionSource.TENANT_DEFAULT, resolved.source());
    }

    @Test
    void cp04T14_whenNoPublishedFallbackExistsCanonicalTextIsReturned() {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        ApiProductEntity product = product(a, "P1", "Canonical");
        var resolved = resolutionService.resolve(a.tenant().getId(), product.getId(), "ja-JP");
        assertEquals("Canonical", resolved.name());
        assertEquals(ResolutionSource.CANONICAL, resolved.source());
    }

    @Test
    void cp04T15_draftReviewAndStaleAreNeverSelectedForConsumerFallback() {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        ApiProductEntity product = product(a, "P1", "Canonical");
        localizedContentRepository.saveAndFlush(localized(a, product, "ko-KR", "Draft"));
        LocalizedContentEntity review = localizedContentRepository.saveAndFlush(localized(a, product, "en-US", "Review"));
        LocalizedContentEntity stale = localizedContentRepository.saveAndFlush(localized(a, product, "ja-JP", "Stale"));
        jdbc.update("UPDATE api_product_localized_content SET status='REVIEW' WHERE localized_content_id=?", review.getId());
        jdbc.update("UPDATE api_product_localized_content SET status='STALE' WHERE localized_content_id=?", stale.getId());
        entityManager.clear();
        var resolved = resolutionService.resolve(a.tenant().getId(), product.getId(), "en-US");
        assertEquals("Canonical", resolved.name());
        assertEquals(ResolutionSource.CANONICAL, resolved.source());
    }

    @Test
    void cp04T16_staleLocalizationIfMatchIsRejected() throws Exception {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        ApiProductEntity product = product(a, "P1", "Canonical");
        putDraft(a, product, "ko-KR", "v1", null, null, 201);
        putDraft(a, product, "ko-KR", "v2", null, 0L, 200);
        mvc.perform(put("/api/v1/api-products/{id}/localized-contents/{locale}", product.getId(), "ko-KR")
                        .header("X-Test-Principal-Id", "user-a")
                        .header("If-Match", "\"0\"")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of("name", "v3"))))
                .andExpect(status().isConflict())
                .andExpect(jsonPath("$.code").value("CONCURRENT_MODIFICATION"));
    }

    @Test
    void cp04T17_crossTenantLocalizedContentReferenceRejectedByDb() {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        Fixture b = fixture("B", "user-b", API_PROVIDER_ROLE_ID);
        ApiProductEntity productB = product(b, "PB", "B");
        LocalizedContentEntity invalid = new LocalizedContentEntity(UUID.randomUUID().toString(),
                a.tenant().getId(), productB.getId(), "ko-KR", 1, "invalid", null, NOW, "fixture");
        assertThrows(DataIntegrityViolationException.class, () -> localizedContentRepository.saveAndFlush(invalid));
    }

    @Test
    void cp04T19_staleTransitionCreatesOneLocalizationUpdatedOutboxEvent() throws Exception {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        ApiProductEntity product = product(a, "P1", "Canonical");
        published(a, product, "ko-KR", "한국어");
        patchProduct(a, product, "Changed", null, null, null, 0, 200);
        assertEquals(1, outboxRepository.findAll().stream()
                .filter(e -> e.getEventType().equals("LocalizationUpdated"))
                .filter(e -> e.getAggregateType().equals("API_PRODUCT_LOCALIZATION"))
                .count());
    }

    @Test
    void cp04T20_outboxFailureRollsBackCanonicalChangeAndStaleTransitionTogether() throws Exception {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        ApiProductEntity product = product(a, "P1", "Canonical");
        LocalizedContentEntity localized = published(a, product, "ko-KR", "한국어");
        doThrow(new IllegalStateException("force rollback")).when(outboxService).enqueue(
                eq("LocalizationUpdated"), eq("API_PRODUCT_LOCALIZATION"), eq(localized.getId()),
                eq(a.tenant().getId()), anyMap());
        patchProduct(a, product, "Changed", null, null, null, 0, 500);
        entityManager.clear();
        ApiProductEntity after = productRepository.findById(product.getId()).orElseThrow();
        LocalizedContentEntity localizedAfter = localizedContentRepository.findById(localized.getId()).orElseThrow();
        assertEquals("Canonical", after.getName());
        assertEquals(1, after.getLocalizationRevision());
        assertEquals(LocalizationStatus.PUBLISHED, localizedAfter.getStatus());
        assertFalse(outboxRepository.findAll().stream().anyMatch(e -> e.getAggregateId().equals(localized.getId())));
    }

    @Test
    void cp04T21_localizationServicesDoNotDependOnSearchImplementation() {
        for (Class<?> type : List.of(ApiProductLocalizationService.class, LocalizationResolutionService.class)) {
            assertFalse(Arrays.stream(type.getDeclaredFields())
                    .map(Field::getType)
                    .map(Class::getName)
                    .anyMatch(name -> name.toLowerCase().contains("search")));
        }
    }

    @Test
    void cp04T22_statusProjectionProvidesMissingAndPublishedEvidenceForFutureReadinessPolicy() {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        ApiProductEntity product = product(a, "P1", "Canonical");
        assertEquals(LocalizationStatus.MISSING, resolutionService.status(a.tenant().getId(), product.getId(), "en-US"));
        published(a, product, "ko-KR", "한국어");
        assertEquals(LocalizationStatus.PUBLISHED, resolutionService.status(a.tenant().getId(), product.getId(), "ko-KR"));
    }

    @Test
    void cp04T23_requiredLocaleBusinessPolicyIsNotEmbeddedInLocalizedContentEntity() {
        assertFalse(Arrays.stream(LocalizedContentEntity.class.getDeclaredFields())
                .map(Field::getName)
                .anyMatch(name -> name.toLowerCase().contains("required") || name.toLowerCase().contains("mandatory")));
    }

    @Test
    void cp04T24_cp01SpoofedTenantHeaderStillCannotChangeResolvedTenant() throws Exception {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        Fixture b = fixture("B", "user-b", API_PROVIDER_ROLE_ID);
        ApiProductEntity productA = product(a, "PA", "A");
        putDraft(a, productA, "ko-KR", "A-ko", null, null, 201);
        mvc.perform(get("/api/v1/api-products/{id}/localized-contents", productA.getId())
                        .header("X-Test-Principal-Id", "user-a")
                        .header("X-Tenant-Id", b.tenant().getId()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].name").value("A-ko"));
    }

    @Test
    void cp04T25_cp02ApiProductOptimisticLockStillRejectsStaleRevision() throws Exception {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        ApiProductEntity product = product(a, "P1", "Canonical");
        patchProduct(a, product, "Changed Once", null, null, null, 0, 200);
        mvc.perform(patch("/api/v1/api-products/{id}", product.getId())
                        .header("X-Test-Principal-Id", "user-a")
                        .header("If-Match", "\"0\"")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of("name", "Changed Twice"))))
                .andExpect(status().isConflict())
                .andExpect(jsonPath("$.code").value("CONCURRENT_MODIFICATION"));
    }

    @Test
    void cp04T26_cp03PublicationActivationStillWorksForReleasedVersion() throws Exception {
        Fixture a = fixture("A", "user-a", API_PROVIDER_ROLE_ID);
        ApiProductEntity product = product(a, "P1", "Canonical");
        ApiProductVersionEntity version = productVersion(a, product, "v1", ApiProductVersionState.RELEASED);
        CatalogPublicationEntity publication = publicationRepository.saveAndFlush(new CatalogPublicationEntity(
                UUID.randomUUID().toString(), a.tenant().getId(), version.getId(), NOW, "fixture"));
        audienceRepository.saveAndFlush(new AudienceScopeEntity(UUID.randomUUID().toString(), a.tenant().getId(),
                publication.getId(), AudienceScopeType.TENANT, null, NOW, "fixture"));
        mvc.perform(post("/api/v1/catalog-publications/{id}/activate", publication.getId())
                        .header("X-Test-Principal-Id", "user-a")
                        .header("If-Match", "\"0\""))
                .andExpect(status().isOk());
        assertTrue(visibilityService.isDiscoverable(a.tenant().getId(), null, publication.getId()));
    }

    private void resetCp04TestRoleMappings() {
        removeCp04TestRoleMappings();
        for (String permission : List.of(P_READ, P_CREATE, P_UPDATE, P_PUBLISH)) {
            jdbc.update("INSERT INTO role_permission(role_id, permission_id) VALUES (?, ?)", API_PROVIDER_ROLE_ID, permission);
        }
        jdbc.update("INSERT INTO role_permission(role_id, permission_id) VALUES (?, ?)", API_PRODUCT_OWNER_ROLE_ID, P_READ);
    }

    private void removeCp04TestRoleMappings() {
        for (String role : List.of(API_PROVIDER_ROLE_ID, API_PRODUCT_OWNER_ROLE_ID, DEVELOPER_ROLE_ID)) {
            for (String permission : List.of(P_READ, P_CREATE, P_UPDATE, P_PUBLISH, P_DEPRECATE)) {
                jdbc.update("DELETE FROM role_permission WHERE role_id = ? AND permission_id = ?", role, permission);
            }
        }
    }

    private Fixture fixture(String suffix, String principal, String roleId) {
        CustomerEntity customer = customerRepository.saveAndFlush(new CustomerEntity(UUID.randomUUID().toString(),
                "C-" + suffix, "Customer " + suffix, CustomerStatus.ACTIVE, NOW));
        TenantEntity tenant = new TenantEntity(UUID.randomUUID().toString(), customer.getId(), "T-" + suffix,
                "Tenant " + suffix, "ko-KR", "Asia/Seoul", NOW);
        tenant.activate(NOW);
        tenant = tenantRepository.saveAndFlush(tenant);
        configurationRepository.saveAndFlush(new TenantConfigurationEntity(UUID.randomUUID().toString(),
                tenant.getId(), "ko-KR", "Asia/Seoul", NOW));
        MembershipEntity membership = membershipRepository.saveAndFlush(new MembershipEntity(UUID.randomUUID().toString(),
                tenant.getId(), null, principal, "local-test", NOW.minus(Duration.ofDays(1)), null, NOW));
        RoleEntity role = roleRepository.findById(roleId).orElseThrow();
        assignmentRepository.saveAndFlush(new RoleAssignmentEntity(UUID.randomUUID().toString(), tenant.getId(),
                membership.getId(), role.getId(), null, NOW.minusSeconds(60), null, "fixture", NOW));
        return new Fixture(customer, tenant, membership);
    }

    private ApiProductEntity product(Fixture f, String code, String name) {
        return productRepository.saveAndFlush(new ApiProductEntity(UUID.randomUUID().toString(), f.tenant().getId(),
                code, code, name, null, null, null, NOW, "fixture"));
    }

    private ProviderEntity provider(Fixture f, String code, String displayName) {
        return providerRepository.saveAndFlush(new ProviderEntity(UUID.randomUUID().toString(), f.tenant().getId(),
                code, displayName, null, NOW, "fixture"));
    }

    private LocalizedContentEntity localized(Fixture f, ApiProductEntity product, String locale, String name) {
        return new LocalizedContentEntity(UUID.randomUUID().toString(), f.tenant().getId(), product.getId(), locale,
                product.getLocalizationRevision(), name, null, NOW, "fixture");
    }

    private LocalizedContentEntity published(Fixture f, ApiProductEntity product, String locale, String name) {
        LocalizedContentEntity content = localizedContentRepository.saveAndFlush(localized(f, product, locale, name));
        jdbc.update("UPDATE api_product_localized_content SET status='PUBLISHED', published_at=?, published_by=? "
                        + "WHERE localized_content_id=?", NOW, "fixture", content.getId());
        entityManager.clear();
        return localizedContentRepository.findById(content.getId()).orElseThrow();
    }

    private ApiProductVersionEntity productVersion(Fixture f, ApiProductEntity product, String value,
                                                    ApiProductVersionState state) {
        ApiProductVersionEntity entity = productVersionRepository.saveAndFlush(new ApiProductVersionEntity(
                UUID.randomUUID().toString(), f.tenant().getId(), product.getId(), value, NOW, "fixture"));
        if (state != ApiProductVersionState.DRAFT) {
            jdbc.update("UPDATE api_product_version SET lifecycle_state = ? WHERE api_product_version_id = ?",
                    state.name(), entity.getId());
            entityManager.clear();
            entity = productVersionRepository.findById(entity.getId()).orElseThrow();
        }
        return entity;
    }

    private void putDraft(Fixture f, ApiProductEntity product, String locale, String name, String description,
                          Long revision, int expectedStatus) throws Exception {
        var request = put("/api/v1/api-products/{id}/localized-contents/{locale}", product.getId(), locale)
                .header("X-Test-Principal-Id", principal(f))
                .contentType(MediaType.APPLICATION_JSON)
                .content(json(description == null ? Map.of("name", name) : Map.of("name", name, "description", description)));
        if (revision != null) {
            request.header("If-Match", "\"" + revision + "\"");
        }
        mvc.perform(request).andExpect(status().is(expectedStatus));
    }

    private void patchProduct(Fixture f, ApiProductEntity product, String name, String description,
                              String providerId, String ownerMembershipId, long revision, int expectedStatus) throws Exception {
        java.util.HashMap<String, Object> body = new java.util.HashMap<>();
        body.put("name", name);
        if (description != null) body.put("description", description);
        if (providerId != null) body.put("providerId", providerId);
        if (ownerMembershipId != null) body.put("ownerMembershipId", ownerMembershipId);
        mvc.perform(patch("/api/v1/api-products/{id}", product.getId())
                        .header("X-Test-Principal-Id", principal(f))
                        .header("If-Match", "\"" + revision + "\"")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(body)))
                .andExpect(status().is(expectedStatus));
    }

    private String principal(Fixture f) {
        return f.membership().getPrincipalId();
    }

    private String json(Object value) throws Exception {
        return objectMapper.writeValueAsString(value);
    }

    private record Fixture(CustomerEntity customer, TenantEntity tenant, MembershipEntity membership) {}
}

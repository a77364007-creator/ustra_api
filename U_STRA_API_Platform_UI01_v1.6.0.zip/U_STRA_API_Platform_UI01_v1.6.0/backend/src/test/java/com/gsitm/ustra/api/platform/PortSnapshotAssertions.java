package com.gsitm.ustra.api.platform;

import com.gsitm.ustra.api.platform.subscription.approval.application.ApprovalPort;
import com.gsitm.ustra.api.platform.subscription.gateway.application.GatewayPort;
import com.gsitm.ustra.api.platform.subscription.entitlement.application.ApprovedSubscriptionDecision;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/** Same typed assertions used by JUnit and the isolated JDK runner; no framework replacements. */
public final class PortSnapshotAssertions {
    private static final Instant FROM = Instant.parse("2026-09-22T00:00:00Z");
    private static final Instant TO = FROM.plusSeconds(60);
    private PortSnapshotAssertions() { }
    private static GatewayPort.Quota gatewayQuota() {
        return new GatewayPort.Quota("requests", BigDecimal.TEN, 60, "count");
    }
    private static ApprovalPort.QuotaDecision approvalQuota() {
        return new ApprovalPort.QuotaDecision("requests", BigDecimal.TEN, 60, "count");
    }
    private static GatewayPort.Command gateway(List<String> scope, List<GatewayPort.Quota> quotas) {
        return new GatewayPort.Command("tenant", "fulfillment", "entitlement", "environment",
                "pinned-version", scope, quotas, "Exact:Key", "fixed-fingerprint");
    }
    private static ApprovalPort.CaseCommand request(List<String> scope) {
        return new ApprovalPort.CaseCommand("tenant", "request", 3, "fixed-hash", scope);
    }
    private static ApprovalPort.Decision decision(List<String> scope, List<ApprovalPort.QuotaDecision> quotas) {
        return new ApprovalPort.Decision("case", ApprovalPort.DecisionStatus.APPROVED, 3, "fixed-hash",
                scope, quotas, FROM, TO, "evidence-ref", "reviewer-ref", FROM);
    }
    private static void equal(Object expected, Object actual) {
        if (!Objects.equals(expected, actual)) throw new AssertionError("SNAPSHOT_VALUE_MISMATCH");
    }
    private static void immutable(Runnable mutation) {
        try { mutation.run(); } catch (UnsupportedOperationException expected) { return; }
        throw new AssertionError("SNAPSHOT_ACCESSOR_IS_MUTABLE");
    }
    private static Map<String, Runnable> cases() {
        Map<String, Runnable> cases = new LinkedHashMap<>();
        cases.put("G01_scopeInputMutation", () -> {
            var source = new ArrayList<>(List.of("operation-1")); var value = gateway(source, List.of());
            source.add("operation-2"); equal(List.of("operation-1"), value.apiOperationIds());
        });
        cases.put("G02_quotaInputMutation", () -> {
            var source = new ArrayList<>(List.of(gatewayQuota())); var value = gateway(List.of("op"), source);
            source.clear(); equal(List.of(gatewayQuota()), value.quotas());
        });
        cases.put("G03_scopeAccessor", () -> {
            var value = gateway(new ArrayList<>(List.of("op")), List.of());
            immutable(() -> value.apiOperationIds().add("other"));
        });
        cases.put("G04_quotaAccessor", () -> {
            var value = gateway(List.of("op"), new ArrayList<>(List.of(gatewayQuota())));
            immutable(() -> value.quotas().clear());
        });
        cases.put("G05_nullListsPreserved", () -> {
            var value = gateway(null, null); equal(null, value.apiOperationIds()); equal(null, value.quotas());
        });
        cases.put("G06_invalidElementsNotReinterpreted", () -> {
            var value = gateway(Arrays.asList("op", null), Arrays.asList(gatewayQuota(), null));
            equal(Arrays.asList("op", null), value.apiOperationIds());
            equal(Arrays.asList(gatewayQuota(), null), value.quotas());
        });
        cases.put("G07_orderDuplicatesAndExactFields", () -> {
            var value = gateway(Arrays.asList("b", "A", "b", " op "), List.of());
            equal(Arrays.asList("b", "A", "b", " op "), value.apiOperationIds());
            equal("tenant", value.tenantId()); equal("fulfillment", value.fulfillmentId());
            equal("entitlement", value.entitlementId()); equal("environment", value.consumerAppEnvironmentId());
            equal("pinned-version", value.apiProductVersionId());
            equal("Exact:Key", value.idempotencyKey()); equal("fixed-fingerprint", value.requestFingerprint());
        });
        cases.put("G08_recordIdentityStable", () -> {
            var source = new ArrayList<>(List.of("op")); var value = gateway(source, List.of());
            var expected = gateway(List.of("op"), List.of()); int hash = value.hashCode();
            source.set(0, "other"); equal(expected, value); equal(hash, value.hashCode());
        });
        cases.put("A01_requestInputMutation", () -> {
            var source = new ArrayList<>(List.of("op")); var value = request(source);
            source.clear(); equal(List.of("op"), value.requestedApiOperationIds());
        });
        cases.put("A02_requestAccessor", () -> {
            var value = request(new ArrayList<>(List.of("op")));
            immutable(() -> value.requestedApiOperationIds().clear());
        });
        cases.put("A03_requestNullPreserved", () -> equal(null, request(null).requestedApiOperationIds()));
        cases.put("A04_requestExactPayload", () -> {
            var scope = Arrays.asList("b", null, "A", "b"); var value = request(scope);
            equal(scope, value.requestedApiOperationIds()); equal("tenant", value.tenantId());
            equal("request", value.subscriptionRequestId()); equal(3, value.requestRevisionNo());
            equal("fixed-hash", value.snapshotHash());
        });
        cases.put("D01_decisionScopeInputMutation", () -> {
            var source = new ArrayList<>(List.of("op")); var value = decision(source, List.of());
            source.add("other"); equal(List.of("op"), value.approvedApiOperationIds());
        });
        cases.put("D02_decisionQuotaInputMutation", () -> {
            var source = new ArrayList<>(List.of(approvalQuota())); var value = decision(List.of("op"), source);
            source.set(0, new ApprovalPort.QuotaDecision("requests", new BigDecimal("100"), 60, "count"));
            equal(List.of(approvalQuota()), value.quotaLimits());
        });
        cases.put("D03_decisionScopeAccessor", () -> {
            var value = decision(new ArrayList<>(List.of("op")), List.of());
            immutable(() -> value.approvedApiOperationIds().set(0, "other"));
        });
        cases.put("D04_decisionQuotaAccessor", () -> {
            var value = decision(List.of("op"), new ArrayList<>(List.of(approvalQuota())));
            immutable(() -> value.quotaLimits().remove(0));
        });
        cases.put("D05_pendingNullContractUnchanged", () -> {
            var value = new ApprovalPort.Decision("case", ApprovalPort.DecisionStatus.PENDING,
                    3, "fixed-hash", null, null, null, null, null, null, null);
            equal(null, value.approvedApiOperationIds()); equal(null, value.quotaLimits());
            equal(null, value.effectiveFrom()); equal(null, value.effectiveTo());
            equal(ApprovalPort.DecisionStatus.PENDING, value.status());
        });
        cases.put("D06_decisionInvalidElementsPreserved", () -> {
            var value = decision(Arrays.asList("b", null, "A", "b"), Arrays.asList(approvalQuota(), null));
            equal(Arrays.asList("b", null, "A", "b"), value.approvedApiOperationIds());
            equal(Arrays.asList(approvalQuota(), null), value.quotaLimits());
        });
        cases.put("D07_decisionScalarsUnchanged", () -> {
            var value = decision(List.of("op"), List.of(approvalQuota()));
            equal("case", value.externalCaseRef()); equal(ApprovalPort.DecisionStatus.APPROVED, value.status());
            equal(3, value.requestRevisionNo()); equal("fixed-hash", value.snapshotHash());
            equal(FROM, value.effectiveFrom()); equal(TO, value.effectiveTo());
            equal("evidence-ref", value.evidenceReference()); equal("reviewer-ref", value.reviewerReference());
            equal(FROM, value.decidedAt());
        });
        cases.put("D08_decisionHashStable", () -> {
            var scope = new ArrayList<>(List.of("op")); var quotas = new ArrayList<>(List.of(approvalQuota()));
            var value = decision(scope, quotas); int hash = value.hashCode();
            scope.clear(); quotas.clear(); equal(decision(List.of("op"), List.of(approvalQuota())), value);
            equal(hash, value.hashCode()); equal("fixed-hash", value.snapshotHash());
        });
        cases.put("R01_approvedDecisionExistingSnapshot", () -> {
            var scope = new ArrayList<>(List.of("op"));
            var quota = new ApprovedSubscriptionDecision.QuotaLimitDecision("requests", BigDecimal.TEN, 60, "count");
            var quotas = new ArrayList<>(List.of(quota));
            var value = new ApprovedSubscriptionDecision("tenant", "approval", "request", 3, "hash",
                    "environment", "pinned-version", scope, quotas, FROM, TO);
            scope.clear(); quotas.clear(); equal(List.of("op"), value.apiOperationIds());
            equal(List.of(quota), value.quotaLimits()); immutable(() -> value.apiOperationIds().clear());
        });
        cases.put("R02_approvedDecisionExistingNullPolicy", () -> {
            var value = new ApprovedSubscriptionDecision("tenant", "approval", "request", 3, "hash",
                    "environment", "pinned-version", null, null, FROM, TO);
            equal(List.of(), value.apiOperationIds()); equal(List.of(), value.quotaLimits());
        });
        return cases;
    }
    public static void runCase(String id) {
        Runnable test = cases().get(id);
        if (test == null) throw new IllegalArgumentException("Unknown test case");
        test.run();
    }
    public static void main(String[] args) {
        int passed = 0; int failed = 0;
        for (var entry : cases().entrySet()) {
            try { entry.getValue().run(); System.out.println("PASS " + entry.getKey()); passed++; }
            catch (AssertionError | RuntimeException e) {
                System.out.println("FAIL " + entry.getKey() + " " + e.getClass().getSimpleName()); failed++;
            }
        }
        System.out.println("PORT_SNAPSHOT_RESULT total=" + (passed + failed) + " passed=" + passed + " failed=" + failed);
        if (failed != 0) System.exit(1);
    }
}

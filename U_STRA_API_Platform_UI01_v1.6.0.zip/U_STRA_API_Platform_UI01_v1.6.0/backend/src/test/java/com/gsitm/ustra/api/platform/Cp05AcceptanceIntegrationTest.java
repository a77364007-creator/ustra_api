package com.gsitm.ustra.api.platform;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gsitm.ustra.api.platform.audit.AuditRecordRepository;
import com.gsitm.ustra.api.platform.catalog.localization.persistence.LocalizedContentRepository;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiOperationRepository;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiProductRepository;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiRepository;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiVersionRepository;
import com.gsitm.ustra.api.platform.catalog.persistence.ProviderRepository;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.ApiProductComponentRepository;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.ApiProductVersionRepository;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.AudienceScopeRepository;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.CatalogPublicationRepository;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.StateTransitionHistoryRepository;
import com.gsitm.ustra.api.platform.consumer.domain.ConsumerAppEnvironmentType;
import com.gsitm.ustra.api.platform.consumer.domain.ConsumerAppLifecycleState;
import com.gsitm.ustra.api.platform.consumer.persistence.ConsumerAppEntity;
import com.gsitm.ustra.api.platform.consumer.persistence.ConsumerAppEnvironmentEntity;
import com.gsitm.ustra.api.platform.consumer.persistence.ConsumerAppEnvironmentRepository;
import com.gsitm.ustra.api.platform.consumer.persistence.ConsumerAppRepository;
import com.gsitm.ustra.api.platform.outbox.OutboxEventRepository;
import com.gsitm.ustra.api.platform.tenant.domain.CustomerStatus;
import com.gsitm.ustra.api.platform.tenant.persistence.CustomerEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.CustomerRepository;
import com.gsitm.ustra.api.platform.tenant.persistence.MembershipEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.MembershipRepository;
import com.gsitm.ustra.api.platform.tenant.persistence.OrganizationEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.OrganizationRepository;
import com.gsitm.ustra.api.platform.tenant.persistence.RoleAssignmentEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.RoleAssignmentRepository;
import com.gsitm.ustra.api.platform.tenant.persistence.RoleEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.RoleRepository;
import com.gsitm.ustra.api.platform.tenant.persistence.TenantConfigurationEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.TenantConfigurationRepository;
import com.gsitm.ustra.api.platform.tenant.persistence.TenantEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.TenantRepository;
import jakarta.persistence.EntityManager;
import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class Cp05AcceptanceIntegrationTest {
    private static final String APP_OWNER_ROLE_ID = "00000000-0000-0000-0000-000000000005";
    private static final String DEVELOPER_ROLE_ID = "00000000-0000-0000-0000-000000000006";
    private static final List<String> CP05_PERMISSIONS = List.of(
            "12000000-0000-0000-0000-000000000001",
            "12000000-0000-0000-0000-000000000002",
            "12000000-0000-0000-0000-000000000003",
            "12000000-0000-0000-0000-000000000004",
            "12000000-0000-0000-0000-000000000005");
    private static final Instant NOW = Instant.parse("2026-09-20T00:00:00Z");

    @Autowired MockMvc mvc;
    @Autowired ObjectMapper objectMapper;
    @Autowired JdbcTemplate jdbc;
    @Autowired EntityManager entityManager;
    @Autowired CustomerRepository customerRepository;
    @Autowired TenantRepository tenantRepository;
    @Autowired TenantConfigurationRepository configurationRepository;
    @Autowired MembershipRepository membershipRepository;
    @Autowired OrganizationRepository organizationRepository;
    @Autowired RoleRepository roleRepository;
    @Autowired RoleAssignmentRepository assignmentRepository;
    @Autowired ConsumerAppRepository consumerAppRepository;
    @Autowired ConsumerAppEnvironmentRepository environmentRepository;
    @Autowired ProviderRepository providerRepository;
    @Autowired ApiProductRepository productRepository;
    @Autowired LocalizedContentRepository localizedContentRepository;
    @Autowired ApiRepository apiRepository;
    @Autowired ApiVersionRepository apiVersionRepository;
    @Autowired ApiOperationRepository apiOperationRepository;
    @Autowired ApiProductVersionRepository productVersionRepository;
    @Autowired ApiProductComponentRepository componentRepository;
    @Autowired CatalogPublicationRepository publicationRepository;
    @Autowired AudienceScopeRepository audienceRepository;
    @Autowired StateTransitionHistoryRepository historyRepository;
    @Autowired AuditRecordRepository auditRepository;
    @Autowired OutboxEventRepository outboxRepository;

    @BeforeEach
    void setUp() {
        cleanupData();
        resetPermissionMappings();
    }

    @AfterEach
    void tearDown() {
        cleanupData();
        removePermissionMappings();
    }

    @Test
    void cp05T01_createConsumerAppStartsDraft() throws Exception {
        Fixture a = fixture("A", "user-a", APP_OWNER_ROLE_ID);
        mvc.perform(post("/api/v1/consumer-apps")
                        .header("X-Test-Principal-Id", "user-a")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of("appCode", " app-one ", "name", "App One",
                                "ownerMembershipId", a.membership().getId()))))
                .andExpect(status().isCreated())
                .andExpect(header().string("ETag", "\"0\""))
                .andExpect(jsonPath("$.appCode").value("APP-ONE"))
                .andExpect(jsonPath("$.lifecycleState").value("DRAFT"));
    }

    @Test
    void cp05T02_sameTenantGetSucceeds() throws Exception {
        Fixture a = fixture("A", "user-a", APP_OWNER_ROLE_ID);
        ConsumerAppEntity app = app(a, "APP-A");
        mvc.perform(get("/api/v1/consumer-apps/{id}", app.getId()).header("X-Test-Principal-Id", "user-a"))
                .andExpect(status().isOk()).andExpect(jsonPath("$.consumerAppId").value(app.getId()));
    }

    @Test
    void cp05T03_crossTenantDirectIdDoesNotExposeResource() throws Exception {
        fixture("A", "user-a", APP_OWNER_ROLE_ID);
        Fixture b = fixture("B", "user-b", APP_OWNER_ROLE_ID);
        ConsumerAppEntity appB = app(b, "APP-B");
        mvc.perform(get("/api/v1/consumer-apps/{id}", appB.getId()).header("X-Test-Principal-Id", "user-a"))
                .andExpect(status().isNotFound()).andExpect(jsonPath("$.code").value("CONSUMER_APP_NOT_FOUND"));
    }

    @Test
    void cp05T04_appCodeIsNormalizedAndTenantUnique() throws Exception {
        Fixture a = fixture("A", "user-a", APP_OWNER_ROLE_ID);
        createApp(a, " my-app ", "My App", a.membership().getId(), null, 201);
        createApp(a, "MY-APP", "Duplicate", a.membership().getId(), null, 409);
    }

    @Test
    void cp05T05_appCodeCannotBeMutatedByPatch() throws Exception {
        Fixture a = fixture("A", "user-a", APP_OWNER_ROLE_ID);
        ConsumerAppEntity app = app(a, "APP-A");
        mvc.perform(patch("/api/v1/consumer-apps/{id}", app.getId())
                        .header("X-Test-Principal-Id", "user-a").header("If-Match", "\"0\"")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of("name", "Changed", "ownerMembershipId", a.membership().getId(),
                                "appCode", "OTHER"))))
                .andExpect(status().isBadRequest());
    }

    @Test
    void cp05T06_ownerMustBelongToSameTenant() throws Exception {
        Fixture a = fixture("A", "user-a", APP_OWNER_ROLE_ID);
        Fixture b = fixture("B", "user-b", APP_OWNER_ROLE_ID);
        createApp(a, "APP-A", "A", b.membership().getId(), null, 400);
    }

    @Test
    void cp05N01_ownerMustBeCurrentlyActiveAndEffective() throws Exception {
        Fixture a = fixture("A", "user-a", APP_OWNER_ROLE_ID);
        a.membership().deactivate(NOW);
        membershipRepository.saveAndFlush(a.membership());
        createApp(a, "APP-A", "A", a.membership().getId(), null, 400);
    }

    @Test
    void cp05T07_organizationMustBelongToSameTenant() throws Exception {
        Fixture a = fixture("A", "user-a", APP_OWNER_ROLE_ID);
        Fixture b = fixture("B", "user-b", APP_OWNER_ROLE_ID);
        OrganizationEntity orgB = organization(b, "ORG-B");
        createApp(a, "APP-A", "A", a.membership().getId(), orgB.getId(), 400);
    }

    @Test
    void cp05T08_createDevEnvironment() throws Exception {
        Fixture a = fixture("A", "user-a", APP_OWNER_ROLE_ID);
        ConsumerAppEntity app = app(a, "APP-A");
        createEnvironment(a, app, "DEV", "gw-ref", "iam-ref", "OAuth2", 201)
                .andExpect(jsonPath("$.environmentType").value("DEV"));
    }

    @Test
    void cp05T09_onlyDevTestProdEnvironmentTypesAccepted() throws Exception {
        Fixture a = fixture("A", "user-a", APP_OWNER_ROLE_ID);
        ConsumerAppEntity app = app(a, "APP-A");
        createEnvironment(a, app, "STAGE", null, null, null, 400);
    }

    @Test
    void cp05T10_duplicateEnvironmentTypeRejected() throws Exception {
        Fixture a = fixture("A", "user-a", APP_OWNER_ROLE_ID);
        ConsumerAppEntity app = app(a, "APP-A");
        createEnvironment(a, app, "DEV", null, null, null, 201);
        createEnvironment(a, app, "DEV", null, null, null, 409);
    }

    @Test
    void cp05T11_environmentParentIsTenantQualified() throws Exception {
        Fixture a = fixture("A", "user-a", APP_OWNER_ROLE_ID);
        Fixture b = fixture("B", "user-b", APP_OWNER_ROLE_ID);
        ConsumerAppEntity appB = app(b, "APP-B");
        createEnvironment(a, appB, "DEV", null, null, null, 404);
    }

    @Test
    void cp05T12_rawSecretFieldsAreRejectedAndNotPersisted() throws Exception {
        Fixture a = fixture("A", "user-a", APP_OWNER_ROLE_ID);
        ConsumerAppEntity app = app(a, "APP-A");
        mvc.perform(post("/api/v1/consumer-apps/{id}/environments", app.getId())
                        .header("X-Test-Principal-Id", "user-a")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"environmentType\":\"DEV\",\"clientSecret\":\"must-not-store\"}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("VALIDATION_ERROR"));
        assertEquals(0, environmentRepository.count());
    }

    @Test
    void cp05T13_appUpdateRequiresIfMatch() throws Exception {
        Fixture a = fixture("A", "user-a", APP_OWNER_ROLE_ID);
        ConsumerAppEntity app = app(a, "APP-A");
        mvc.perform(patch("/api/v1/consumer-apps/{id}", app.getId())
                        .header("X-Test-Principal-Id", "user-a")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of("name", "Changed", "ownerMembershipId", a.membership().getId()))))
                .andExpect(status().isBadRequest());
    }

    @Test
    void cp05T14_staleAppIfMatchRejected() throws Exception {
        Fixture a = fixture("A", "user-a", APP_OWNER_ROLE_ID);
        ConsumerAppEntity app = app(a, "APP-A");
        updateApp(a, app, "Changed Once", a.membership().getId(), null, 0, 200);
        updateApp(a, app, "Changed Twice", a.membership().getId(), null, 0, 409);
    }

    @Test
    void cp05T15_environmentUpdateRejectsStaleRevision() throws Exception {
        Fixture a = fixture("A", "user-a", APP_OWNER_ROLE_ID);
        ConsumerAppEntity app = app(a, "APP-A");
        ConsumerAppEnvironmentEntity env = environment(a, app, ConsumerAppEnvironmentType.DEV);
        updateEnvironment(a, app, env, "gw-1", null, null, 0, 200);
        updateEnvironment(a, app, env, "gw-2", null, null, 0, 409);
    }

    @Test
    void cp05T16_draftCanActivate() throws Exception {
        Fixture a = fixture("A", "user-a", APP_OWNER_ROLE_ID);
        ConsumerAppEntity app = app(a, "APP-A");
        lifecycle(a, app, "activate", 0, 200).andExpect(jsonPath("$.lifecycleState").value("ACTIVE"));
    }

    @Test
    void cp05T17_activeCanSuspend() throws Exception {
        Fixture a = fixture("A", "user-a", APP_OWNER_ROLE_ID);
        ConsumerAppEntity app = stateApp(a, "APP-A", ConsumerAppLifecycleState.ACTIVE);
        lifecycle(a, app, "suspend", 0, 200).andExpect(jsonPath("$.lifecycleState").value("SUSPENDED"));
    }

    @Test
    void cp05T18_suspendedCanReactivate() throws Exception {
        Fixture a = fixture("A", "user-a", APP_OWNER_ROLE_ID);
        ConsumerAppEntity app = stateApp(a, "APP-A", ConsumerAppLifecycleState.SUSPENDED);
        lifecycle(a, app, "activate", 0, 200).andExpect(jsonPath("$.lifecycleState").value("ACTIVE"));
    }

    @Test
    void cp05T19_activeOrSuspendedCanRetire() throws Exception {
        Fixture a = fixture("A", "user-a", APP_OWNER_ROLE_ID);
        ConsumerAppEntity active = stateApp(a, "APP-A", ConsumerAppLifecycleState.ACTIVE);
        lifecycle(a, active, "retire", 0, 200).andExpect(jsonPath("$.lifecycleState").value("RETIRED"));
    }

    @Test
    void cp05T20_retiredIsTerminalForLifecycleActions() throws Exception {
        Fixture a = fixture("A", "user-a", APP_OWNER_ROLE_ID);
        ConsumerAppEntity retired = stateApp(a, "APP-A", ConsumerAppLifecycleState.RETIRED);
        lifecycle(a, retired, "activate", 0, 409).andExpect(jsonPath("$.code").value("CONSUMER_APP_STATE_INVALID"));
    }

    @Test
    void cp05T21_lifecycleTransitionHistoryAndAuditAreRecorded() throws Exception {
        Fixture a = fixture("A", "user-a", APP_OWNER_ROLE_ID);
        ConsumerAppEntity app = app(a, "APP-A");
        lifecycle(a, app, "activate", 0, 200);
        assertEquals(1, historyRepository.findAll().stream()
                .filter(h -> h.getAggregateType().equals("CONSUMER_APP") && h.getAggregateId().equals(app.getId()))
                .count());
        assertTrue(auditRepository.findAll().stream().anyMatch(x -> "CONSUMER_APP_ACTIVATE".equals(x.getAction())));
    }

    @Test
    void cp05T22_missingPermissionReturns403AndDenialAudit() throws Exception {
        Fixture a = fixture("A", "user-a", DEVELOPER_ROLE_ID);
        ConsumerAppEntity app = app(a, "APP-A");
        mvc.perform(get("/api/v1/consumer-apps/{id}", app.getId()).header("X-Test-Principal-Id", "user-a"))
                .andExpect(status().isForbidden()).andExpect(jsonPath("$.code").value("ACCESS_DENIED"));
        assertTrue(auditRepository.findAll().stream().anyMatch(x -> "DENIED".equals(x.getOutcome())));
    }

    @Test
    void cp05T23_roleNameAloneDoesNotAuthorizeWithoutPermissionMapping() throws Exception {
        removePermissionMappings();
        Fixture a = fixture("A", "user-a", APP_OWNER_ROLE_ID);
        ConsumerAppEntity app = app(a, "APP-A");
        mvc.perform(get("/api/v1/consumer-apps/{id}", app.getId()).header("X-Test-Principal-Id", "user-a"))
                .andExpect(status().isForbidden());
    }

    @Disabled("Design Feedback: owner/organization object-scope authorization rule is not approved")
    @Test
    void cp05T24_ownerOrganizationObjectScopeAuthorizationRequiresApprovedPolicy() {
        assertTrue(true);
    }

    @Test
    void cp05T25_appRegistryResponseDoesNotCreateSubscriptionEntitlementOrCredential() throws Exception {
        Fixture a = fixture("A", "user-a", APP_OWNER_ROLE_ID);
        mvc.perform(post("/api/v1/consumer-apps")
                        .header("X-Test-Principal-Id", "user-a")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of("appCode", "APP-A", "name", "A",
                                "ownerMembershipId", a.membership().getId()))))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.subscriptionStatus").doesNotExist())
                .andExpect(jsonPath("$.entitlementStatus").doesNotExist())
                .andExpect(jsonPath("$.credential").doesNotExist());
    }

    @Test
    void cp05T26_noRawSecretColumnOrEntityPropertyExists() {
        List<String> fieldNames = List.of(ConsumerAppEnvironmentEntity.class.getDeclaredFields()).stream()
                .map(f -> f.getName().toLowerCase()).toList();
        assertFalse(fieldNames.stream().anyMatch(x -> x.contains("secret") || x.contains("token") || x.equals("apikey")));
    }

    @Test
    void cp05T27_cp01ThroughCp04RegressionSuitesRemainPresent() throws Exception {
        assertNotNull(Class.forName("com.gsitm.ustra.api.platform.Cp01AcceptanceIntegrationTest"));
        assertNotNull(Class.forName("com.gsitm.ustra.api.platform.Cp02AcceptanceIntegrationTest"));
        assertNotNull(Class.forName("com.gsitm.ustra.api.platform.Cp03AcceptanceIntegrationTest"));
        assertNotNull(Class.forName("com.gsitm.ustra.api.platform.Cp04AcceptanceIntegrationTest"));
    }

    @Test
    void cp05T28_migrationResourcesReachV019() {
        assertNotNull(getClass().getResource("/db/migration/V017__consumer_app.sql"));
        assertNotNull(getClass().getResource("/db/migration/V018__consumer_app_environment.sql"));
        assertNotNull(getClass().getResource("/db/migration/V019__consumer_app_permissions.sql"));
    }

    private void cleanupData() {
        environmentRepository.deleteAllInBatch();
        consumerAppRepository.deleteAllInBatch();
        localizedContentRepository.deleteAllInBatch();
        audienceRepository.deleteAllInBatch();
        publicationRepository.deleteAllInBatch();
        historyRepository.deleteAllInBatch();
        componentRepository.deleteAllInBatch();
        productVersionRepository.deleteAllInBatch();
        apiOperationRepository.deleteAllInBatch();
        apiVersionRepository.deleteAllInBatch();
        apiRepository.deleteAllInBatch();
        productRepository.deleteAllInBatch();
        providerRepository.deleteAllInBatch();
        assignmentRepository.deleteAllInBatch();
        membershipRepository.deleteAllInBatch();
        organizationRepository.deleteAllInBatch();
        configurationRepository.deleteAllInBatch();
        outboxRepository.deleteAllInBatch();
        auditRepository.deleteAllInBatch();
        tenantRepository.deleteAllInBatch();
        customerRepository.deleteAllInBatch();
    }

    private void resetPermissionMappings() {
        removePermissionMappings();
        for (String permission : CP05_PERMISSIONS) {
            jdbc.update("INSERT INTO role_permission(role_id, permission_id) VALUES (?, ?)", APP_OWNER_ROLE_ID, permission);
        }
    }

    private void removePermissionMappings() {
        for (String role : List.of(APP_OWNER_ROLE_ID, DEVELOPER_ROLE_ID)) {
            for (String permission : CP05_PERMISSIONS) {
                jdbc.update("DELETE FROM role_permission WHERE role_id = ? AND permission_id = ?", role, permission);
            }
        }
    }

    private Fixture fixture(String suffix, String principal, String roleId) {
        CustomerEntity customer = customerRepository.saveAndFlush(new CustomerEntity(UUID.randomUUID().toString(),
                "C-" + suffix, "Customer " + suffix, CustomerStatus.ACTIVE, NOW));
        TenantEntity tenant = new TenantEntity(UUID.randomUUID().toString(), customer.getId(), "T-" + suffix,
                "Tenant " + suffix, "ko-KR", "Asia/Seoul", NOW);
        tenant.activate(NOW);
        tenant = tenantRepository.saveAndFlush(tenant);
        configurationRepository.saveAndFlush(new TenantConfigurationEntity(UUID.randomUUID().toString(),
                tenant.getId(), "ko-KR", "Asia/Seoul", NOW));
        MembershipEntity membership = membershipRepository.saveAndFlush(new MembershipEntity(UUID.randomUUID().toString(),
                tenant.getId(), null, principal, "local-test", NOW.minus(Duration.ofDays(1)), null, NOW));
        RoleEntity role = roleRepository.findById(roleId).orElseThrow();
        assignmentRepository.saveAndFlush(new RoleAssignmentEntity(UUID.randomUUID().toString(), tenant.getId(),
                membership.getId(), role.getId(), null, NOW.minusSeconds(60), null, "fixture", NOW));
        return new Fixture(customer, tenant, membership);
    }

    private OrganizationEntity organization(Fixture f, String code) {
        return organizationRepository.saveAndFlush(new OrganizationEntity(UUID.randomUUID().toString(),
                f.tenant().getId(), code, code, null, NOW));
    }

    private ConsumerAppEntity app(Fixture f, String code) {
        return consumerAppRepository.saveAndFlush(new ConsumerAppEntity(UUID.randomUUID().toString(), f.tenant().getId(),
                code, code, code, null, f.membership().getId(), null, NOW, "fixture"));
    }

    private ConsumerAppEntity stateApp(Fixture f, String code, ConsumerAppLifecycleState state) {
        ConsumerAppEntity app = app(f, code);
        jdbc.update("UPDATE consumer_app SET lifecycle_state=? WHERE consumer_app_id=?", state.name(), app.getId());
        entityManager.clear();
        return consumerAppRepository.findById(app.getId()).orElseThrow();
    }

    private ConsumerAppEnvironmentEntity environment(Fixture f, ConsumerAppEntity app, ConsumerAppEnvironmentType type) {
        return environmentRepository.saveAndFlush(new ConsumerAppEnvironmentEntity(UUID.randomUUID().toString(),
                f.tenant().getId(), app.getId(), type, null, null, null, NOW, "fixture"));
    }

    private org.springframework.test.web.servlet.ResultActions createApp(Fixture f, String code, String name,
            String ownerMembershipId, String organizationId, int expected) throws Exception {
        java.util.HashMap<String, Object> body = new java.util.HashMap<>();
        body.put("appCode", code); body.put("name", name); body.put("ownerMembershipId", ownerMembershipId);
        if (organizationId != null) body.put("organizationId", organizationId);
        return mvc.perform(post("/api/v1/consumer-apps").header("X-Test-Principal-Id", f.membership().getPrincipalId())
                        .contentType(MediaType.APPLICATION_JSON).content(json(body)))
                .andExpect(status().is(expected));
    }

    private org.springframework.test.web.servlet.ResultActions updateApp(Fixture f, ConsumerAppEntity app, String name,
            String ownerMembershipId, String organizationId, long revision, int expected) throws Exception {
        java.util.HashMap<String, Object> body = new java.util.HashMap<>();
        body.put("name", name); body.put("ownerMembershipId", ownerMembershipId);
        if (organizationId != null) body.put("organizationId", organizationId);
        return mvc.perform(patch("/api/v1/consumer-apps/{id}", app.getId())
                        .header("X-Test-Principal-Id", f.membership().getPrincipalId())
                        .header("If-Match", "\"" + revision + "\"")
                        .contentType(MediaType.APPLICATION_JSON).content(json(body)))
                .andExpect(status().is(expected));
    }

    private org.springframework.test.web.servlet.ResultActions createEnvironment(Fixture f, ConsumerAppEntity app,
            String type, String gateway, String iam, String auth, int expected) throws Exception {
        java.util.HashMap<String, Object> body = new java.util.HashMap<>();
        body.put("environmentType", type);
        if (gateway != null) body.put("gatewayClientReference", gateway);
        if (iam != null) body.put("iamApplicationReference", iam);
        if (auth != null) body.put("authenticationMethod", auth);
        return mvc.perform(post("/api/v1/consumer-apps/{id}/environments", app.getId())
                        .header("X-Test-Principal-Id", f.membership().getPrincipalId())
                        .contentType(MediaType.APPLICATION_JSON).content(json(body)))
                .andExpect(status().is(expected));
    }

    private org.springframework.test.web.servlet.ResultActions updateEnvironment(Fixture f, ConsumerAppEntity app,
            ConsumerAppEnvironmentEntity env, String gateway, String iam, String auth, long revision, int expected) throws Exception {
        java.util.HashMap<String, Object> body = new java.util.HashMap<>();
        if (gateway != null) body.put("gatewayClientReference", gateway);
        if (iam != null) body.put("iamApplicationReference", iam);
        if (auth != null) body.put("authenticationMethod", auth);
        return mvc.perform(patch("/api/v1/consumer-apps/{appId}/environments/{envId}", app.getId(), env.getId())
                        .header("X-Test-Principal-Id", f.membership().getPrincipalId())
                        .header("If-Match", "\"" + revision + "\"")
                        .contentType(MediaType.APPLICATION_JSON).content(json(body)))
                .andExpect(status().is(expected));
    }

    private org.springframework.test.web.servlet.ResultActions lifecycle(Fixture f, ConsumerAppEntity app,
            String action, long revision, int expected) throws Exception {
        return mvc.perform(post("/api/v1/consumer-apps/{id}/{action}", app.getId(), action)
                        .header("X-Test-Principal-Id", f.membership().getPrincipalId())
                        .header("If-Match", "\"" + revision + "\""))
                .andExpect(status().is(expected));
    }

    private String json(Object value) throws Exception { return objectMapper.writeValueAsString(value); }
    private record Fixture(CustomerEntity customer, TenantEntity tenant, MembershipEntity membership) {}
}

package com.gsitm.ustra.api.platform;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gsitm.ustra.api.platform.provider.importing.application.Sha256Service;
import com.gsitm.ustra.api.platform.provider.importing.parser.OpenApiParserPort.ParsedOpenApi;
import com.gsitm.ustra.api.platform.provider.importing.parser.OpenApiReferenceGuard;
import com.gsitm.ustra.api.platform.provider.importing.parser.SanitizedContractFingerprintService;
import com.gsitm.ustra.api.platform.provider.importing.parser.SwaggerOpenApiParserAdapter;
import org.junit.jupiter.api.Test;

class Cp11OpenApiParserUnitTest {
    private final SwaggerOpenApiParserAdapter parser = new SwaggerOpenApiParserAdapter(
            new OpenApiReferenceGuard(),
            new SanitizedContractFingerprintService(new ObjectMapper(), new Sha256Service()));

    @Test
    void parserExtractsSanitizedContractFactsForSnapshot() {
        String source = """
                openapi: 3.0.3
                info:
                  title: Contract API
                  version: '2.0'
                components:
                  schemas:
                    Thing:
                      type: object
                      required: [id]
                      properties:
                        id: { type: string }
                  securitySchemes:
                    bearer:
                      type: http
                      scheme: bearer
                paths:
                  /things/{id}:
                    get:
                      parameters:
                        - in: path
                          name: id
                          required: true
                          schema: { type: string }
                      responses:
                        '200':
                          description: ok
                          content:
                            application/json:
                              schema: { $ref: '#/components/schemas/Thing' }
                      security:
                        - bearer: []
                """;
        ParsedOpenApi parsed = parser.parse(source);
        assertEquals("2.0", parsed.version());
        assertEquals(1, parsed.operations().size());
        var operation = parsed.operations().getFirst();
        assertEquals("GET", operation.method());
        assertEquals("/things/{id}", operation.path());
        assertEquals(1, operation.parameters().size());
        assertFalse(operation.responses().isEmpty());
        assertFalse(operation.securityFingerprints().isEmpty());
        assertNotNull(operation.responses().getFirst().responseFingerprint());
    }
}

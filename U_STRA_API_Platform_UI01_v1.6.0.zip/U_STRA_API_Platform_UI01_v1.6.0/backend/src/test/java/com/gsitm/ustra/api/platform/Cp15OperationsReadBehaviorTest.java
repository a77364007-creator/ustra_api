package com.gsitm.ustra.api.platform;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.gsitm.ustra.api.platform.audit.*;
import com.gsitm.ustra.api.platform.audit.application.AuditQueryService;
import com.gsitm.ustra.api.platform.operations.application.*;
import com.gsitm.ustra.api.platform.operations.persistence.*;
import com.gsitm.ustra.api.platform.integration.approval.persistence.*;
import com.gsitm.ustra.api.platform.integration.approval.domain.*;
import com.gsitm.ustra.api.platform.outbox.*;
import com.gsitm.ustra.api.platform.search.persistence.*;
import com.gsitm.ustra.api.platform.tenant.context.*;
import com.gsitm.ustra.api.platform.tenant.application.TenantPermissionGuard;
import java.time.*;
import org.junit.jupiter.api.Test;
import org.springframework.data.domain.*;
import org.springframework.data.jpa.domain.Specification;

class Cp15OperationsReadBehaviorTest {
    @Test void cp15T07_queryBoundAndStableOrdering() {
        var limits=new OperationsQueryLimits(Cp15SafetyBehaviorTest.CLOCK,100,10000,31,7);
        assertEquals(Cp15SafetyBehaviorTest.NOW.minus(Duration.ofDays(7)),limits.window(null,null).from());
        assertThrows(RuntimeException.class,()->limits.page(-1,50,"NEWEST","createdAt"));
        assertThrows(RuntimeException.class,()->limits.page(0,101,"NEWEST","createdAt"));
        assertThrows(RuntimeException.class,()->limits.page(0,50,"createdAt; drop table","createdAt"));
        assertThrows(RuntimeException.class,()->limits.window(Cp15SafetyBehaviorTest.NOW.minus(Duration.ofDays(32)),null));
        assertNotNull(limits.page(0,10,"NEWEST","createdAt").getSort().getOrderFor("id"));
    }
    @Test void cp15T12T13_safeDtoOmitsAuditDiffAndOutboxPayload() throws Exception {
        var mapper=new ObjectMapper().registerModule(new JavaTimeModule());
        var audit=new AuditRecordEntity("id",Cp15SafetyBehaviorTest.TENANT,Cp15SafetyBehaviorTest.NOW,"actor","IDENTITY","READ",
                "RESOURCE","resource","SUCCESS",null,"correlation",true,"PRIVATE_VENDOR_PAYLOAD","PRIVATE_BEFORE","PRIVATE_AFTER");
        String text=mapper.writeValueAsString(AuditQueryService.View.from(audit));
        assertFalse(text.contains("PRIVATE_"));assertFalse(text.contains("safeDiff"));
        var event=new OutboxEventEntity("id","event","Type",1,"RESOURCE","resource",Cp15SafetyBehaviorTest.TENANT,"PRIVATE_VENDOR_PAYLOAD","correlation",Cp15SafetyBehaviorTest.NOW);
        String outbox=mapper.writeValueAsString(OperationsQueryService.OutboxView.from(event));
        assertFalse(outbox.contains("PRIVATE_"));assertFalse(outbox.contains("payload"));
        assertEquals("PRIVATE_VENDOR_PAYLOAD",event.getPayload()); // read projection never mutates canonical event
    }
    @Test void cp15T54_connectorEnabledDoesNotMeanHealthyAndSecretReferenceIsOmitted() throws Exception {
        var entity=new ConnectorInstanceEntity("id","tenant","profile","code","adapter","authority","PRIVATE_SECRET_REFERENCE",true,Cp15SafetyBehaviorTest.NOW,"actor");
        var view=OperationsQueryService.ConnectorView.from(entity);assertTrue(view.enabled());assertEquals("NOT_MEASURED",view.healthStatus());
        assertFalse(new ObjectMapper().writeValueAsString(view).contains("PRIVATE_SECRET_REFERENCE"));
    }
    @Test void cp15T09_auditUsesIndependentPermissionBeforeRepository() {
        var contexts=mock(TenantContextResolver.class);var permissions=mock(TenantPermissionGuard.class);var repo=mock(AuditRecordRepository.class);
        when(contexts.resolve()).thenReturn(Cp15RecoveryBehaviorTest.context());
        doThrow(new RuntimeException("DENIED")).when(permissions).require(any(),eq("AUDIT:READ"),anyString(),anyString());
        var service=new AuditQueryService(contexts,permissions,repo,new OperationsQueryLimits(Cp15SafetyBehaviorTest.CLOCK,100,10000,31,7),Cp15SafetyBehaviorTest.CLOCK);
        assertThrows(RuntimeException.class,()->service.query(null,null,null,null,null,null,null,0,50,"NEWEST"));verifyNoInteractions(repo);
    }
    @Test void cp15T04T05_summaryDoesNotQueryUnauthorizedSourcesAndDoesNotInventTelemetry() {
        var contexts=mock(TenantContextResolver.class);var permissions=mock(TenantPermissionGuard.class);
        when(contexts.resolve()).thenReturn(Cp15RecoveryBehaviorTest.context());
        var ops=mock(IntegrationOperationRepository.class);var issues=mock(ReconciliationIssueRepository.class);
        var connectors=mock(ConnectorInstanceRepository.class);var outbox=mock(OutboxEventRepository.class);
        var failures=mock(SearchProjectionFailureRepository.class);var docs=mock(CatalogSearchDocumentRepository.class);
        var visibility=mock(CatalogSearchVisibilityRepository.class);var recovery=mock(OperationsRecoveryActionRepository.class);
        when(outbox.findAll(any(Specification.class),any(Pageable.class))).thenReturn(Page.empty());
        var service=new OperationsQueryService(contexts,permissions,new OperationsQueryLimits(Cp15SafetyBehaviorTest.CLOCK,100,10000,31,7),
                ops,issues,connectors,outbox,failures,docs,visibility,recovery,Cp15SafetyBehaviorTest.CLOCK);
        var summary=service.summary();assertTrue(summary.integrations().isEmpty());assertNull(summary.search());
        assertEquals("NOT_MEASURED",summary.unavailableMetrics().get("usage"));assertEquals(Cp15SafetyBehaviorTest.NOW,summary.asOf());
        verifyNoInteractions(ops,issues,connectors,failures,docs,visibility,recovery);
    }
    @Test void cp15T04_typeVocabularyIsDisjoint() {
        var approval=OperationsSpecifications.types(IntegrationType.APPROVAL_ITSM);var gateway=OperationsSpecifications.types(IntegrationType.GATEWAY_IAM);
        assertTrue(java.util.Collections.disjoint(approval,gateway));
        assertEquals(2,approval.size());assertEquals(3,gateway.size());
    }
}

package com.gsitm.ustra.api.platform;

import static org.junit.jupiter.api.Assertions.*;
import static com.gsitm.ustra.api.platform.operations.application.OperationsSpecifications.*;
import com.gsitm.ustra.api.platform.operations.application.OperationsSpecifications;
import com.gsitm.ustra.api.platform.operations.application.OperationsQueryLimits;
import com.gsitm.ustra.api.platform.integration.approval.domain.*;
import com.gsitm.ustra.api.platform.integration.approval.persistence.*;
import com.gsitm.ustra.api.platform.audit.*;
import com.gsitm.ustra.api.platform.search.persistence.*;
import jakarta.persistence.EntityManager;
import java.time.*;
import java.util.*;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.data.domain.*;

/** H2 JPA/criteria behavior only. MariaDB constraints/migrations are tested separately. */
@DataJpaTest(properties={"spring.flyway.enabled=false","spring.jpa.hibernate.ddl-auto=create-drop"})
class Cp15PersistenceIntegrationTest {
    @Autowired EntityManager em;
    @Autowired IntegrationOperationRepository operations;
    @Autowired ReconciliationIssueRepository issues;
    @Autowired AuditRecordRepository audit;
    @Autowired SearchProjectionFailureRepository failures;
    static final Instant NOW=Cp15SafetyBehaviorTest.NOW;
    private IntegrationOperationEntity op(String tenant,IntegrationOperationType type) {
        var row=new IntegrationOperationEntity(UUID.randomUUID().toString(),tenant,UUID.randomUUID().toString(),type,
                "RESOURCE",UUID.randomUUID().toString(),null,null,UUID.randomUUID().toString(),null,NOW,"actor");
        return operations.saveAndFlush(row);
    }
    @Test void cp15T06T08_countAndPagingApplyTenantTypeBeforeLimitWithIdTieBreaker() {
        String a=UUID.randomUUID().toString(),b=UUID.randomUUID().toString();
        var a1=op(a,IntegrationOperationType.APPROVAL_STATUS_QUERY);var a2=op(a,IntegrationOperationType.APPROVAL_CASE_CREATE);
        op(a,IntegrationOperationType.GATEWAY_STATUS_QUERY);op(b,IntegrationOperationType.APPROVAL_STATUS_QUERY);
        var spec=OperationsSpecifications.operations(a,IntegrationType.APPROVAL_ITSM);
        var sort=Sort.by(Sort.Direction.DESC,"createdAt","id");
        var first=operations.findAll(spec,PageRequest.of(0,1,sort));var second=operations.findAll(spec,PageRequest.of(1,1,sort));
        assertEquals(2,first.getTotalElements());assertEquals(2,operations.count(spec));
        assertNotEquals(first.getContent().getFirst().getId(),second.getContent().getFirst().getId());
        assertEquals(Set.of(a1.getId(),a2.getId()),Set.of(first.getContent().getFirst().getId(),second.getContent().getFirst().getId()));
    }
    @Test void cp15T05_issueOwnershipUsesParentOperationNotIssueNamePrefix() {
        String a=UUID.randomUUID().toString(),b=UUID.randomUUID().toString();
        var approval=op(a,IntegrationOperationType.APPROVAL_STATUS_QUERY);var gateway=op(a,IntegrationOperationType.GATEWAY_STATUS_QUERY);
        var other=op(b,IntegrationOperationType.GATEWAY_STATUS_QUERY);
        issues.saveAndFlush(new ReconciliationIssueEntity(UUID.randomUUID().toString(),a,approval.getId(),"GATEWAY_MISLEADING_NAME","CODE",NOW,"actor"));
        var expected=issues.saveAndFlush(new ReconciliationIssueEntity(UUID.randomUUID().toString(),a,gateway.getId(),"GENERIC_NAME","CODE",NOW,"actor"));
        issues.saveAndFlush(new ReconciliationIssueEntity(UUID.randomUUID().toString(),b,other.getId(),"GENERIC_NAME","CODE",NOW,"actor"));
        var found=issues.findAll(OperationsSpecifications.issues(a,IntegrationType.GATEWAY_IAM),PageRequest.of(0,10));
        assertEquals(1,found.getTotalElements());assertEquals(expected.getId(),found.getContent().getFirst().getId());
        assertEquals(1,issues.findScoped(a,OperationsSpecifications.types(IntegrationType.GATEWAY_IAM)).size());
    }
    @Test void cp15T10T11_auditNullTenantAndOtherTenantExcludedBySameFilter() {
        String a=UUID.randomUUID().toString(),b=UUID.randomUUID().toString();
        for(String tenant:Arrays.asList(a,b,null))audit.saveAndFlush(new AuditRecordEntity(UUID.randomUUID().toString(),tenant,NOW,"actor","IDENTITY",
                "READ","RESOURCE","id","SUCCESS",null,"correlation",true,"private",null,null));
        var spec=OperationsSpecifications.<AuditRecordEntity>tenant(a).and(eq("action","READ"))
                .and(eq("correlationId","correlation")).and(window("occurredAt",new OperationsQueryLimits.Window(NOW.minusSeconds(1),NOW.plusSeconds(1))));
        assertEquals(1,audit.count(spec));
        assertEquals(a,audit.findAll(spec).getFirst().getTenantId());
    }
    @Test void cp15T47T49_evenSameClockInstantObservationAdvancesVersionAndBlocksOldSuccess() {
        String tenant=UUID.randomUUID().toString(),product=UUID.randomUUID().toString();
        var row=failures.saveAndFlush(new SearchProjectionFailureEntity(UUID.randomUUID().toString(),tenant,product,NOW));
        long old=row.getRowVersion();row.observe(NOW);failures.saveAndFlush(row);
        assertTrue(row.getRowVersion()>old);assertFalse(row.resolveIfVersion(old,NOW));
        assertTrue(row.resolveIfVersion(row.getRowVersion(),NOW));failures.saveAndFlush(row);
        assertEquals("RESOLVED",row.getStatus());
    }
    @Test void cp15T60_legacyListQueryStillReturnsOnlyItsAuthorizedTypes() {
        String tenant=UUID.randomUUID().toString();op(tenant,IntegrationOperationType.GATEWAY_PROVISION);op(tenant,IntegrationOperationType.APPROVAL_CASE_CREATE);
        var list=operations.findScoped(tenant,types(IntegrationType.APPROVAL_ITSM),null);
        assertEquals(1,list.size());assertEquals(IntegrationOperationType.APPROVAL_CASE_CREATE,list.getFirst().getOperationType());
    }
}

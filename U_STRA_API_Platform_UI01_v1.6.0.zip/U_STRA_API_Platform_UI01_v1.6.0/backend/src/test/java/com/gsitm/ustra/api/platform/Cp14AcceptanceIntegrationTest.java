package com.gsitm.ustra.api.platform;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

/**
 * CP-14 source/contract traceability.
 * Maven + Testcontainers + actual Gateway sandbox execution remains required before release.
 */
class Cp14AcceptanceIntegrationTest {
    private static final Path ROOT = Path.of(".").toAbsolutePath().normalize();

    private static String source(String relative) {
        try {
            return Files.readString(ROOT.resolve(relative));
        } catch (IOException ex) {
            throw new AssertionError(ex);
        }
    }

    private static String state() {
        return source("src/main/java/com/gsitm/ustra/api/platform/integration/gateway/application/GatewayIntegrationStateService.java");
    }

    private static String orch() {
        return source("src/main/java/com/gsitm/ustra/api/platform/integration/gateway/application/GatewayIntegrationOrchestrator.java");
    }

    private static String resolver() {
        return source("src/main/java/com/gsitm/ustra/api/platform/integration/gateway/application/TenantGatewayConnectorResolver.java");
    }

    private static String gatewayState() {
        return source("src/main/java/com/gsitm/ustra/api/platform/subscription/gateway/application/GatewayFulfillmentStateService.java");
    }

    private static String migration() {
        return source("src/main/resources/db/migration/V045__gateway_integration_vocabulary.sql");
    }

    @Test void cp14T01_gatewayPortRemainsDomainBoundary(){assertTrue(source("src/main/java/com/gsitm/ustra/api/platform/subscription/gateway/application/GatewayPort.java").contains("interface GatewayPort"));assertTrue(orch().contains("GatewayPort"));}
    @Test void cp14T02_mockGatewayRemainsNonProductionOnly(){assertTrue(source("src/main/java/com/gsitm/ustra/api/platform/subscription/gateway/infrastructure/MockGatewayAdapter.java").contains("mock-integration"));assertTrue(source("src/main/java/com/gsitm/ustra/api/platform/integration/gateway/infrastructure/MockGatewayConnectorRegistration.java").contains("mock-integration"));}
    @Test void cp14T03_noFabricatedActualGatewayAdapter(){assertFalse(Files.exists(ROOT.resolve("src/main/java/com/gsitm/ustra/api/platform/integration/gateway/infrastructure/ActualGatewayAdapter.java")));assertFalse(source("pom.xml").toLowerCase().contains("kong"));assertFalse(source("pom.xml").toLowerCase().contains("apigee"));}
    @Test void cp14T04_crossTenantConnectorLookupIsQualified(){assertTrue(resolver().contains("findByIdAndTenantId"));assertTrue(resolver().contains("IntegrationType.GATEWAY_IAM"));}
    @Test void cp14T05_provisionCommandDerivedServerSide(){assertTrue(state().contains("gatewayState.begin(tenantId, fulfillmentId)"));assertTrue(gatewayState().contains("EntitlementOperationScopeRepository"));}
    @Test void cp14T06_provisionScopeComesFromEntitlement(){assertTrue(gatewayState().contains("findAllByTenantIdAndEntitlementIdOrderByApiOperationIdAsc"));assertFalse(orch().contains("apiOperationIds"));}
    @Test void cp14T07_provisionQuotaComesFromEntitlementSnapshot(){assertTrue(gatewayState().contains("QuotaProfileRepository"));assertTrue(gatewayState().contains("QuotaLimitRepository"));}
    @Test void cp14T08_productVersionIsPinnedEntitlementVersion(){assertTrue(gatewayState().contains("entitlement.getApiProductVersionId()"));}
    @Test void cp14T09_environmentIsEntitlementEnvironment(){assertTrue(gatewayState().contains("entitlement.getConsumerAppEnvironmentId()"));}
    @Test void cp14T10_durableOperationExistsBeforeExternalEffect(){assertTrue(orch().indexOf("state.prepareEffect") < orch().indexOf("port.provision"));assertTrue(state().contains("operations.saveAndFlush(new IntegrationOperationEntity"));}
    @Test void cp14T11_externalGatewayCallOutsideDbTransaction(){assertTrue(orch().contains("Propagation.NOT_SUPPORTED"));assertTrue(orch().contains("port.provision"));assertTrue(orch().contains("port.deprovision"));}
    @Test void cp14T12_sameEffectIdentityReusesOneOperation(){assertTrue(migration().contains("GATEWAY_PROVISION"));assertTrue(state().contains("findByTenantIdAndOperationTypeAndAggregateIdAndAggregateRevision"));assertTrue(state().contains("invokeRequired"));}
    @Test void cp14T13_fingerprintConflictProtectionRemains(){String mock=source("src/main/java/com/gsitm/ustra/api/platform/subscription/gateway/infrastructure/MockGatewayAdapter.java");assertTrue(mock.contains("IDEMPOTENCY_FINGERPRINT_CONFLICT"));assertTrue(state().contains("fulfillment.getRequestFingerprint()"));}
    @Test void cp14T14_confirmedProvisionSuccessProjectsSucceeded(){assertTrue(state().contains("case SUCCEEDED"));assertTrue(gatewayState().contains("AccessFulfillmentStatus.SUCCEEDED"));}
    @Test void cp14T15_successfulProvisionRequiresOpaqueCredentialRef(){assertTrue(gatewayState().contains("GATEWAY_CREDENTIAL_REFERENCE_REQUIRED"));assertTrue(gatewayState().contains("credentialReference()"));}
    @Test void cp14T16_rawCredentialNeverPersisted(){String s=source("src/main/java/com/gsitm/ustra/api/platform/subscription/entitlement/persistence/CredentialReferenceEntity.java")+migration();assertFalse(s.contains("secret_value"));assertFalse(s.contains("access_token"));assertFalse(s.contains("private_key"));}
    @Test void cp14T17_timeoutOrExceptionBecomesUnknown(){assertTrue(orch().contains("markOutboundExceptionUnknown"));assertTrue(state().contains("UNCERTAIN_EXTERNAL_EFFECT"));assertTrue(gatewayState().contains("AccessFulfillmentStatus.UNKNOWN"));}
    @Test void cp14T18_unknownDoesNotBlindlyReprovision(){assertTrue(state().contains("existing.get().getStatus() == IntegrationOperationStatus.REQUESTED"));assertTrue(orch().contains("if (!prepared.invokeRequired())"));}
    @Test void cp14T19_reconciliationQueriesExistingEffectFirst(){assertTrue(orch().contains("port.queryStatus"));assertTrue(state().contains("prepareQuery"));assertFalse(source("src/main/java/com/gsitm/ustra/api/platform/integration/gateway/application/GatewayIntegrationOperatorService.java").contains("process("));}
    @Test void cp14T20_matchingReconcileProjectsWithoutSecondProvision(){String s=orch();assertTrue(s.contains("completeQuery"));assertEquals(1,count(s,"port.provision("));}
    @Test void cp14T21_repeatedUncertainQueryCanRemainUnknown(){assertTrue(state().contains("markQueryExceptionUnknown"));assertTrue(state().contains("GatewayPort.ResultStatus.UNKNOWN"));}
    @Test void cp14T22_definitiveFailureUsesSafeCode(){assertTrue(state().contains("DEFINITIVE_GATEWAY_FAILURE"));assertFalse(state().contains("getMessage()"));}
    @Test void cp14T23_gatewayFailureDoesNotCoupleCatalog(){assertFalse(state().contains("CatalogPublicationService"));assertFalse(state().contains("ApiProductService"));}
    @Test void cp14T24_readyToUseRemainsSeparate(){assertFalse(state().contains("ReadyToUseService"));assertTrue(Files.exists(ROOT.resolve("src/main/java/com/gsitm/ustra/api/platform/subscription/entitlement/application/ReadyToUseService.java")));}
    @Test void cp14T25_readyToUseRequiresActiveCredential(){assertTrue(source("src/main/java/com/gsitm/ustra/api/platform/subscription/entitlement/application/ReadyToUseService.java").contains("CredentialReferenceStatus.ACTIVE"));}
    @Test void cp14T26_entitlementRevokeAuthorityRemains(){assertTrue(source("src/main/java/com/gsitm/ustra/api/platform/subscription/entitlement/application/EntitlementCommandService.java").contains("REVOKED"));assertTrue(source("src/main/java/com/gsitm/ustra/api/platform/subscription/entitlement/application/ReadyToUseService.java").contains("EntitlementStatus.ACTIVE"));}
    @Test void cp14T27_deprovisionIsSeparateExternalEffect(){assertTrue(migration().contains("GATEWAY_DEPROVISION"));assertTrue(orch().contains("port.deprovision"));}
    @Test void cp14T28_deprovisionExceptionRemainsUnknown(){assertTrue(orch().contains("markOutboundExceptionUnknown"));assertTrue(state().contains("fulfillment.getFulfillmentType()"));}
    @Test void cp14T29_deprovisionReplayUsesSameEffectIdentity(){assertTrue(state().contains("operationType(fulfillment.getFulfillmentType())"));assertTrue(state().contains("fulfillment.getFulfillmentRevision()"));}
    @Test void cp14T30_confirmedDeprovisionProjectsCredentialRevoked(){assertTrue(gatewayState().contains("CredentialReferenceStatus.REVOKED"));}
    @Test void cp14T31_secretNotWrittenToAuditOrOutbox(){String s=state()+gatewayState();assertFalse(s.contains("secretReference"));assertFalse(s.contains("credentialReference\", result.credentialReference"));} 
    @Test void cp14T32_productionProviderMetadataUsesConnectorAuthority(){assertTrue(state().contains("connector.getAuthorityCode()"));assertTrue(gatewayState().contains("credentialProviderType"));assertTrue(gatewayState().contains("providerType"));}
    @Test void cp14T33_zeroGatewayConnectorFailsClosed(){assertTrue(resolver().contains("INTEGRATION_CONNECTOR_NOT_FOUND"));}
    @Test void cp14T34_ambiguousGatewayConnectorFailsClosed(){assertTrue(resolver().contains("INTEGRATION_CONNECTOR_AMBIGUOUS"));}
    @Test void cp14T35_disabledGatewayConnectorFailsClosed(){assertTrue(resolver().contains("INTEGRATION_CONNECTOR_DISABLED"));assertTrue(resolver().contains("ownedEnabled"));}
    @Test void cp14T36_operatorReconcileRequiresPermission(){assertTrue(source("src/main/java/com/gsitm/ustra/api/platform/integration/gateway/application/GatewayIntegrationOperatorService.java").contains("GATEWAY_INTEGRATION:RECONCILE"));}
    @Test void cp14T37_operatorQueriesAreTenantQualified(){String s=source("src/main/java/com/gsitm/ustra/api/platform/integration/gateway/application/GatewayIntegrationOperatorService.java");assertTrue(s.contains("context.tenantId()"));assertTrue(s.contains("TenantContextResolver"));}
    @Test void cp14T38_operatorCannotDirectlyMarkSuccess(){String s=source("src/main/java/com/gsitm/ustra/api/platform/integration/gateway/application/GatewayIntegrationOperatorService.java");assertFalse(s.contains(".succeed("));assertTrue(s.contains("orchestrator.reconcile"));}
    @Test void cp14T39_integrationOperationStoresSafeErrorOnly(){String s=source("src/main/java/com/gsitm/ustra/api/platform/integration/approval/persistence/IntegrationOperationEntity.java");assertTrue(s.contains("safe_error_category"));assertTrue(s.contains("safe_error_code"));assertFalse(s.contains("rawPayload"));}
    @Test void cp14T40_externalOperationReferenceIsOpaque(){assertTrue(source("src/main/java/com/gsitm/ustra/api/platform/integration/approval/persistence/IntegrationOperationEntity.java").contains("external_reference"));assertFalse(source("openapi/cp14.yaml").contains("externalPayload"));}
    @Test void cp14T41_runtimePolicyReferenceIsOpaqueOnly(){String p=source("src/main/java/com/gsitm/ustra/api/platform/subscription/gateway/application/GatewayPort.java");assertTrue(p.contains("runtimePolicyReference"));assertFalse(migration().contains("runtime_policy_payload"));}
    @Test void cp14T42_vendorDtoDoesNotLeakIntoDomain(){String s=state()+orch()+source("src/main/java/com/gsitm/ustra/api/platform/subscription/gateway/application/GatewayPort.java");assertFalse(s.contains("Kong"));assertFalse(s.contains("Apigee"));assertFalse(s.contains("AWSApiGateway"));}
    @Test void cp14T43_noArbitraryRequestUrl(){String s=source("src/main/java/com/gsitm/ustra/api/platform/integration/gateway/api/GatewayIntegrationAdminController.java")+orch();assertFalse(s.contains("http://"));assertFalse(s.contains("https://"));assertFalse(s.toLowerCase().contains("url"));}
    @Test void cp14T44_requestTenantHeaderCannotEstablishAuthority(){String s=source("src/main/java/com/gsitm/ustra/api/platform/integration/gateway/api/GatewayIntegrationAdminController.java");assertFalse(s.contains("X-Tenant-Id"));assertTrue(source("src/main/java/com/gsitm/ustra/api/platform/integration/gateway/application/GatewayIntegrationOperatorService.java").contains("contexts.resolve()"));}
    @Test void cp14T45_missingRuntimePolicyDriftRepresented(){assertTrue(drift().contains("MISSING_RUNTIME_POLICY"));}
    @Test void cp14T46_unexpectedRuntimePolicyDriftRepresented(){assertTrue(drift().contains("UNEXPECTED_RUNTIME_POLICY"));}
    @Test void cp14T47_scopeMismatchDriftRepresented(){assertTrue(drift().contains("SCOPE_MISMATCH"));}
    @Test void cp14T48_quotaMismatchDriftRepresented(){assertTrue(drift().contains("QUOTA_MISMATCH"));}
    @Test void cp14T49_versionMismatchDriftRepresented(){assertTrue(drift().contains("VERSION_MISMATCH"));}
    @Test void cp14T50_expiredEntitlementActiveDriftRepresented(){assertTrue(drift().contains("EXPIRED_ENTITLEMENT_ACTIVE"));}
    @Test void cp14T51_credentialMismatchDoesNotReactivate(){assertTrue(drift().contains("CREDENTIAL_STATE_MISMATCH"));assertFalse(state().contains("grant("));}
    @Test void cp14T52_tenantScopeMismatchFailsClosedVocabulary(){assertTrue(drift().contains("TENANT_SCOPE_MISMATCH"));assertTrue(resolver().contains("tenantId"));}
    @Test void cp14T53_cp07EntitlementRegressionPresent(){assertTrue(Files.exists(ROOT.resolve("src/test/java/com/gsitm/ustra/api/platform/Cp07AcceptanceIntegrationTest.java")));}
    @Test void cp14T54_cp08TimeoutReconciliationRegressionPresent(){assertTrue(Files.exists(ROOT.resolve("src/test/java/com/gsitm/ustra/api/platform/Cp08AcceptanceIntegrationTest.java")));assertTrue(source("src/main/java/com/gsitm/ustra/api/platform/subscription/gateway/application/GatewayFulfillmentOrchestrator.java").contains("reconcile"));}
    @Test void cp14T55_cp08RequestedApprovedScopeRegressionPresent(){assertTrue(source("src/main/java/com/gsitm/ustra/api/platform/subscription/approval/application/ApprovalStateService.java").contains("APPROVAL_SCOPE_EXCEEDS_REQUEST"));}
    @Test void cp14T56_cp08ReadyToUseRegressionPresent(){assertTrue(Files.exists(ROOT.resolve("src/main/java/com/gsitm/ustra/api/platform/subscription/entitlement/application/ReadyToUseService.java")));}
    @Test void cp14T57_cp09ImportRegressionPresent(){assertTrue(Files.exists(ROOT.resolve("src/test/java/com/gsitm/ustra/api/platform/Cp09AcceptanceIntegrationTest.java")));}
    @Test void cp14T58_cp10PublishingRegressionPresent(){assertTrue(Files.exists(ROOT.resolve("src/test/java/com/gsitm/ustra/api/platform/Cp10AcceptanceIntegrationTest.java")));}
    @Test void cp14T59_cp11ChangeImpactRegressionPresent(){assertTrue(Files.exists(ROOT.resolve("src/test/java/com/gsitm/ustra/api/platform/Cp11AcceptanceIntegrationTest.java")));}
    @Test void cp14T60_cp12SearchRegressionPresent(){assertTrue(Files.exists(ROOT.resolve("src/test/java/com/gsitm/ustra/api/platform/Cp12AcceptanceIntegrationTest.java")));}
    @Test void cp14T61_cp13ApprovalIntegrationRegressionPresent(){assertTrue(Files.exists(ROOT.resolve("src/test/java/com/gsitm/ustra/api/platform/Cp13AcceptanceIntegrationTest.java")));assertTrue(source("src/main/java/com/gsitm/ustra/api/platform/integration/approval/domain/IntegrationType.java").contains("APPROVAL_ITSM"));}

    @Test @Disabled("DF-CP14-01: real Gateway endpoint/auth handshake contract is not supplied") void cp14T62_realGatewayEndpointAuthHandshake(){fail();}
    @Test @Disabled("DF-CP14-03: actual runtime-policy object mapping is not supplied") void cp14T63_actualRuntimePolicyMapping(){fail();}
    @Test @Disabled("DF-CP14-06: vendor status/asynchronous operation mapping is not supplied") void cp14T64_vendorStatusMapping(){fail();}
    @Test @Disabled("DF-CP14-04: actual quota/unit mapping is not supplied") void cp14T65_actualQuotaUnitMapping(){fail();}
    @Test @Disabled("DF-CP14-05: credential issue/rotation/revoke contract is not supplied") void cp14T66_credentialLifecycleContract(){fail();}
    @Test @Disabled("DF-CP14-02: vendor idempotency/correlation lookup after timeout is not supplied") void cp14T67_vendorIdempotencyLookup(){fail();}
    @Test @Disabled("DF-CP14-10: production Vault/secret provider binding is not supplied") void cp14T68_productionVaultBinding(){fail();}
    @Test @Disabled("DF-CP14-08: live runtime evidence/drift query contract is not supplied") void cp14T69_liveRuntimeDriftEvidence(){fail();}
    @Test @Disabled("DF-CP14-01: real Gateway sandbox is not supplied") void cp14T70_realGatewaySandboxE2E(){fail();}

    private static String drift(){return source("src/main/java/com/gsitm/ustra/api/platform/integration/gateway/domain/GatewayDriftCategory.java");}
    private static int count(String source,String token){int n=0,at=0;while((at=source.indexOf(token,at))>=0){n++;at+=token.length();}return n;}
}

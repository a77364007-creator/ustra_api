package com.gsitm.ustra.api.platform;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gsitm.ustra.api.platform.audit.AuditRecordRepository;
import com.gsitm.ustra.api.platform.catalog.domain.ApiProductLifecycleState;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiProductEntity;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiProductRepository;
import com.gsitm.ustra.api.platform.catalog.publication.domain.ApiProductVersionState;
import com.gsitm.ustra.api.platform.catalog.publication.domain.AudienceScopeType;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.ApiProductComponentRepository;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.ApiProductVersionEntity;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.ApiProductVersionRepository;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.AudienceScopeEntity;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.AudienceScopeRepository;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.CatalogPublicationEntity;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.CatalogPublicationRepository;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.StateTransitionHistoryRepository;
import com.gsitm.ustra.api.platform.consumer.domain.ConsumerAppEnvironmentType;
import com.gsitm.ustra.api.platform.consumer.persistence.ConsumerAppEntity;
import com.gsitm.ustra.api.platform.consumer.persistence.ConsumerAppEnvironmentEntity;
import com.gsitm.ustra.api.platform.consumer.persistence.ConsumerAppEnvironmentRepository;
import com.gsitm.ustra.api.platform.consumer.persistence.ConsumerAppRepository;
import com.gsitm.ustra.api.platform.outbox.OutboxEventEntity;
import com.gsitm.ustra.api.platform.outbox.OutboxEventRepository;
import com.gsitm.ustra.api.platform.subscription.domain.SubscriptionRequestStatus;
import com.gsitm.ustra.api.platform.subscription.persistence.SubscriptionRequestEntity;
import com.gsitm.ustra.api.platform.subscription.persistence.SubscriptionRequestIdempotencyRepository;
import com.gsitm.ustra.api.platform.subscription.persistence.SubscriptionRequestRepository;
import com.gsitm.ustra.api.platform.subscription.persistence.SubscriptionRequestRevisionEntity;
import com.gsitm.ustra.api.platform.subscription.persistence.SubscriptionRequestRevisionRepository;
import com.gsitm.ustra.api.platform.tenant.domain.CustomerStatus;
import com.gsitm.ustra.api.platform.tenant.persistence.CustomerEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.CustomerRepository;
import com.gsitm.ustra.api.platform.tenant.persistence.MembershipEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.MembershipRepository;
import com.gsitm.ustra.api.platform.tenant.persistence.OrganizationEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.OrganizationRepository;
import com.gsitm.ustra.api.platform.tenant.persistence.RoleAssignmentEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.RoleAssignmentRepository;
import com.gsitm.ustra.api.platform.tenant.persistence.RoleEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.RoleRepository;
import com.gsitm.ustra.api.platform.tenant.persistence.TenantConfigurationEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.TenantConfigurationRepository;
import com.gsitm.ustra.api.platform.tenant.persistence.TenantEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.TenantRepository;
import jakarta.persistence.EntityManager;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class Cp06AcceptanceIntegrationTest {
    private static final String APP_OWNER_ROLE_ID = "00000000-0000-0000-0000-000000000005";
    private static final String DEVELOPER_ROLE_ID = "00000000-0000-0000-0000-000000000006";
    private static final String SUBSCRIPTION_REQUEST_PERMISSION_ID = "13000000-0000-0000-0000-000000000001";
    private static final Instant NOW = Instant.parse("2026-09-20T00:00:00Z");

    @Autowired MockMvc mvc;
    @Autowired ObjectMapper objectMapper;
    @Autowired JdbcTemplate jdbc;
    @Autowired EntityManager entityManager;
    @Autowired CustomerRepository customerRepository;
    @Autowired TenantRepository tenantRepository;
    @Autowired TenantConfigurationRepository configurationRepository;
    @Autowired MembershipRepository membershipRepository;
    @Autowired OrganizationRepository organizationRepository;
    @Autowired RoleRepository roleRepository;
    @Autowired RoleAssignmentRepository assignmentRepository;
    @Autowired ConsumerAppRepository appRepository;
    @Autowired ConsumerAppEnvironmentRepository environmentRepository;
    @Autowired ApiProductRepository productRepository;
    @Autowired ApiProductVersionRepository productVersionRepository;
    @Autowired ApiProductComponentRepository componentRepository;
    @Autowired CatalogPublicationRepository publicationRepository;
    @Autowired AudienceScopeRepository audienceRepository;
    @Autowired SubscriptionRequestRepository requestRepository;
    @Autowired SubscriptionRequestRevisionRepository revisionRepository;
    @Autowired SubscriptionRequestIdempotencyRepository idempotencyRepository;
    @Autowired StateTransitionHistoryRepository historyRepository;
    @Autowired AuditRecordRepository auditRepository;
    @Autowired OutboxEventRepository outboxRepository;

    @BeforeEach
    void setUp() {
        cleanupData();
        resetPermissionMappings();
    }

    @AfterEach
    void tearDown() {
        cleanupData();
        removePermissionMappings();
    }

    @Test
    void cp06T01_validCreateStartsSubmitted() throws Exception {
        Fixture f = fixture("A", "user-a", APP_OWNER_ROLE_ID, false);
        RequestTarget target = target(f, AudienceScopeType.TENANT, null, true, true);
        create(f, target, "idem-01", "Production integration", "5000/day", 201)
                .andExpect(jsonPath("$.status").value("SUBMITTED"))
                .andExpect(header().string("ETag", "\"0\""));
    }

    @Test
    void cp06T02_requestPinsExactProductVersionResolvedFromPublication() throws Exception {
        Fixture f = fixture("A", "user-a", APP_OWNER_ROLE_ID, false);
        RequestTarget target = target(f, AudienceScopeType.TENANT, null, true, true);
        String body = create(f, target, "idem-02", "Pin version", null, 201)
                .andReturn().getResponse().getContentAsString();
        assertEquals(target.productVersion().getId(), objectMapper.readTree(body).get("apiProductVersionId").asText());
    }

    @Test
    void cp06T03_revisionOneIsImmutableSnapshotWithHash() throws Exception {
        Fixture f = fixture("A", "user-a", APP_OWNER_ROLE_ID, false);
        RequestTarget target = target(f, AudienceScopeType.TENANT, null, true, true);
        String id = createdId(create(f, target, "idem-03", "Snapshot purpose", "100/min", 201));
        SubscriptionRequestRevisionEntity rev = revisionRepository
                .findByTenantIdAndSubscriptionRequestIdAndRevisionNo(f.tenant().getId(), id, 1).orElseThrow();
        assertEquals(1, rev.getRevisionNo());
        assertEquals("Snapshot purpose", rev.getPurpose());
        assertEquals(64, rev.getSnapshotHash().length());
    }

    @Test
    void cp06T04_requesterIsServerDerivedAndCannotBeOverridden() throws Exception {
        Fixture f = fixture("A", "user-a", APP_OWNER_ROLE_ID, false);
        RequestTarget target = target(f, AudienceScopeType.TENANT, null, true, true);
        Map<String, Object> body = Map.of(
                "consumerAppEnvironmentId", target.environment().getId(),
                "catalogPublicationId", target.publication().getId(),
                "purpose", "x",
                "requesterMembershipId", "client-controlled");
        mvc.perform(post("/api/v1/subscription-requests")
                        .header("X-Test-Principal-Id", "user-a").header("Idempotency-Key", "idem-04")
                        .contentType(MediaType.APPLICATION_JSON).content(json(body)))
                .andExpect(status().isBadRequest()).andExpect(jsonPath("$.code").value("VALIDATION_ERROR"));
    }

    @Test
    void cp06T05_crossTenantConsumerAppEnvironmentIsNotExposed() throws Exception {
        Fixture a = fixture("A", "user-a", APP_OWNER_ROLE_ID, false);
        Fixture b = fixture("B", "user-b", APP_OWNER_ROLE_ID, false);
        RequestTarget foreign = target(b, AudienceScopeType.TENANT, null, true, true);
        RequestTarget local = target(a, AudienceScopeType.TENANT, null, true, true);
        createRaw(a, foreign.environment().getId(), local.publication().getId(), "idem-05", "x", null, 404)
                .andExpect(jsonPath("$.code").value("CONSUMER_APP_ENVIRONMENT_NOT_FOUND"));
    }

    @Test
    void cp06T06_crossTenantCatalogPublicationIsNotExposed() throws Exception {
        Fixture a = fixture("A", "user-a", APP_OWNER_ROLE_ID, false);
        Fixture b = fixture("B", "user-b", APP_OWNER_ROLE_ID, false);
        RequestTarget local = target(a, AudienceScopeType.TENANT, null, true, true);
        RequestTarget foreign = target(b, AudienceScopeType.TENANT, null, true, true);
        createRaw(a, local.environment().getId(), foreign.publication().getId(), "idem-06", "x", null, 404)
                .andExpect(jsonPath("$.code").value("CATALOG_PUBLICATION_NOT_FOUND"));
    }

    @Test
    void cp06T07_clientCannotIntroduceCrossTenantProductVersionReference() throws Exception {
        Fixture a = fixture("A", "user-a", APP_OWNER_ROLE_ID, false);
        Fixture b = fixture("B", "user-b", APP_OWNER_ROLE_ID, false);
        RequestTarget local = target(a, AudienceScopeType.TENANT, null, true, true);
        RequestTarget foreign = target(b, AudienceScopeType.TENANT, null, true, true);
        Map<String, Object> body = Map.of(
                "consumerAppEnvironmentId", local.environment().getId(),
                "catalogPublicationId", local.publication().getId(),
                "purpose", "x",
                "apiProductVersionId", foreign.productVersion().getId());
        mvc.perform(post("/api/v1/subscription-requests")
                        .header("X-Test-Principal-Id", "user-a").header("Idempotency-Key", "idem-07")
                        .contentType(MediaType.APPLICATION_JSON).content(json(body)))
                .andExpect(status().isBadRequest()).andExpect(jsonPath("$.code").value("VALIDATION_ERROR"));
    }

    @Test
    void cp06T08_inactiveConsumerAppIsRejected() throws Exception {
        Fixture f = fixture("A", "user-a", APP_OWNER_ROLE_ID, false);
        RequestTarget target = target(f, AudienceScopeType.TENANT, null, false, true);
        create(f, target, "idem-08", "x", null, 409)
                .andExpect(jsonPath("$.code").value("CONSUMER_APP_STATE_INVALID"));
    }

    @Test
    void cp06T09_nonActivePublicationBlocksNewRequest() throws Exception {
        Fixture f = fixture("A", "user-a", APP_OWNER_ROLE_ID, false);
        RequestTarget target = target(f, AudienceScopeType.TENANT, null, true, false);
        create(f, target, "idem-09", "x", null, 409)
                .andExpect(jsonPath("$.code").value("CATALOG_PUBLICATION_STATE_INVALID"));
    }

    @Test
    void cp06T10_audienceMismatchBlocksRequest() throws Exception {
        Fixture f = fixture("A", "user-a", APP_OWNER_ROLE_ID, true);
        OrganizationEntity other = organization(f.tenant(), "OTHER");
        RequestTarget target = target(f, AudienceScopeType.ORGANIZATION, other.getId(), true, true);
        create(f, target, "idem-10", "x", null, 403)
                .andExpect(jsonPath("$.code").value("SUBSCRIPTION_REQUEST_AUDIENCE_DENIED"));
    }

    @Test
    void cp06T11_missingPermissionReturns403AndDenialAudit() throws Exception {
        Fixture f = fixture("A", "user-a", DEVELOPER_ROLE_ID, false);
        RequestTarget target = target(f, AudienceScopeType.TENANT, null, true, true);
        create(f, target, "idem-11", "x", null, 403).andExpect(jsonPath("$.code").value("ACCESS_DENIED"));
        assertTrue(auditRepository.findAllByTenantIdOrderByOccurredAtAsc(f.tenant().getId()).stream()
                .anyMatch(a -> "DENIED".equals(a.getOutcome())));
    }

    @Test
    void cp06T12_roleNameIsNotHardcoded() throws Exception {
        jdbc.update("INSERT INTO role_permission(role_id, permission_id) VALUES (?, ?)",
                DEVELOPER_ROLE_ID, SUBSCRIPTION_REQUEST_PERMISSION_ID);
        Fixture f = fixture("A", "user-a", DEVELOPER_ROLE_ID, false);
        RequestTarget target = target(f, AudienceScopeType.TENANT, null, true, true);
        create(f, target, "idem-12", "x", null, 201);
    }

    @Disabled("DF-CP06-07 / CP05-T24: ConsumerApp owner/organization object-scope authorization is not approved")
    @Test
    void cp06T13_consumerAppOwnerOrgObjectScopeAuthorization() {
    }

    @Test
    void cp06T14_sameIdempotencyKeySamePayloadDoesNotDuplicateEffect() throws Exception {
        Fixture f = fixture("A", "user-a", APP_OWNER_ROLE_ID, false);
        RequestTarget target = target(f, AudienceScopeType.TENANT, null, true, true);
        String first = createdId(create(f, target, "idem-14", "same", "100/day", 201));
        String second = createdId(create(f, target, "idem-14", "same", "100/day", 201));
        assertEquals(first, second);
        assertEquals(1, requestRepository.count());
        assertEquals(1, revisionRepository.count());
        assertEquals(1, idempotencyRepository.count());
        assertEquals(1, outboxRepository.findAll().stream().filter(x -> "SubscriptionRequested".equals(x.getEventType())).count());
    }

    @Test
    void cp06T15_sameKeyChangedPayloadIsRejected() throws Exception {
        Fixture f = fixture("A", "user-a", APP_OWNER_ROLE_ID, false);
        RequestTarget target = target(f, AudienceScopeType.TENANT, null, true, true);
        create(f, target, "idem-15", "one", null, 201);
        create(f, target, "idem-15", "two", null, 409)
                .andExpect(jsonPath("$.code").value("IDEMPOTENCY_KEY_CONFLICT"));
    }

    @Test
    void cp06T16_sameIdempotencyKeyDoesNotCollideAcrossTenants() throws Exception {
        Fixture a = fixture("A", "user-a", APP_OWNER_ROLE_ID, false);
        Fixture b = fixture("B", "user-b", APP_OWNER_ROLE_ID, false);
        RequestTarget ta = target(a, AudienceScopeType.TENANT, null, true, true);
        RequestTarget tb = target(b, AudienceScopeType.TENANT, null, true, true);
        String ra = createdId(create(a, ta, "shared-key", "x", null, 201));
        String rb = createdId(create(b, tb, "shared-key", "x", null, 201));
        assertNotEquals(ra, rb);
        assertEquals(2, requestRepository.count());
    }

    @Test
    void cp06T17_createDoesNotJumpToApprovedOrCompleted() throws Exception {
        Fixture f = fixture("A", "user-a", APP_OWNER_ROLE_ID, false);
        RequestTarget target = target(f, AudienceScopeType.TENANT, null, true, true);
        create(f, target, "idem-17", "x", null, 201).andExpect(jsonPath("$.status").value("SUBMITTED"));
    }

    @Test
    void cp06T18_cancelUsesSemanticAction() throws Exception {
        Fixture f = fixture("A", "user-a", APP_OWNER_ROLE_ID, false);
        RequestTarget target = target(f, AudienceScopeType.TENANT, null, true, true);
        String id = createdId(create(f, target, "idem-18", "x", null, 201));
        mvc.perform(post("/api/v1/subscription-requests/{id}/cancel", id)
                        .header("X-Test-Principal-Id", "user-a").header("If-Match", "\"0\""))
                .andExpect(status().isOk()).andExpect(jsonPath("$.status").value("CANCELLED"));
    }

    @Test
    void cp06T19_onlySubmittedCanBeCancelledInCp06() throws Exception {
        Fixture f = fixture("A", "user-a", APP_OWNER_ROLE_ID, false);
        RequestTarget target = target(f, AudienceScopeType.TENANT, null, true, true);
        String id = createdId(create(f, target, "idem-19", "x", null, 201));
        mvc.perform(post("/api/v1/subscription-requests/{id}/cancel", id)
                        .header("X-Test-Principal-Id", "user-a").header("If-Match", "\"0\""))
                .andExpect(status().isOk());
        entityManager.clear();
        SubscriptionRequestEntity cancelled = requestRepository.findById(id).orElseThrow();
        mvc.perform(post("/api/v1/subscription-requests/{id}/cancel", id)
                        .header("X-Test-Principal-Id", "user-a")
                        .header("If-Match", "\"" + cancelled.getRowVersion() + "\""))
                .andExpect(status().isConflict()).andExpect(jsonPath("$.code").value("SUBSCRIPTION_REQUEST_STATE_INVALID"));
    }

    @Test
    void cp06T20_cancellationWritesHistoryAndAudit() throws Exception {
        Fixture f = fixture("A", "user-a", APP_OWNER_ROLE_ID, false);
        RequestTarget target = target(f, AudienceScopeType.TENANT, null, true, true);
        String id = createdId(create(f, target, "idem-20", "x", null, 201));
        mvc.perform(post("/api/v1/subscription-requests/{id}/cancel", id)
                        .header("X-Test-Principal-Id", "user-a").header("If-Match", "\"0\""))
                .andExpect(status().isOk());
        assertTrue(historyRepository.findAllByTenantIdAndAggregateTypeAndAggregateIdOrderByOccurredAtAsc(
                f.tenant().getId(), "SUBSCRIPTION_REQUEST", id).stream()
                .anyMatch(h -> "SUBMITTED".equals(h.getFromState()) && "CANCELLED".equals(h.getToState())));
        assertTrue(auditRepository.findAllByTenantIdOrderByOccurredAtAsc(f.tenant().getId()).stream()
                .anyMatch(a -> "SUBSCRIPTION_REQUEST_CANCEL".equals(a.getAction())));
    }

    @Test
    void cp06T21_createCommitsRequestRevisionHistoryAuditOutboxAndIdempotency() throws Exception {
        Fixture f = fixture("A", "user-a", APP_OWNER_ROLE_ID, false);
        RequestTarget target = target(f, AudienceScopeType.TENANT, null, true, true);
        String id = createdId(create(f, target, "idem-21", "atomic", null, 201));
        assertEquals(1, requestRepository.count());
        assertEquals(1, revisionRepository.count());
        assertEquals(1, idempotencyRepository.count());
        assertTrue(historyRepository.findAllByTenantIdAndAggregateTypeAndAggregateIdOrderByOccurredAtAsc(
                f.tenant().getId(), "SUBSCRIPTION_REQUEST", id).stream().anyMatch(h -> "SUBMITTED".equals(h.getToState())));
        assertTrue(auditRepository.findAllByTenantIdOrderByOccurredAtAsc(f.tenant().getId()).stream()
                .anyMatch(a -> "SUBSCRIPTION_REQUEST_CREATE".equals(a.getAction())));
        assertTrue(outboxRepository.findAll().stream().anyMatch(e -> "SubscriptionRequested".equals(e.getEventType())));
    }

    @Test
    void cp06T22_failedDuplicateCommandLeavesNoAdditionalOrphanEffects() throws Exception {
        Fixture f = fixture("A", "user-a", APP_OWNER_ROLE_ID, false);
        RequestTarget target = target(f, AudienceScopeType.TENANT, null, true, true);
        create(f, target, "idem-22", "first", null, 201);
        long requests = requestRepository.count();
        long revisions = revisionRepository.count();
        long outbox = outboxRepository.count();
        create(f, target, "idem-22", "changed", null, 409);
        assertEquals(requests, requestRepository.count());
        assertEquals(revisions, revisionRepository.count());
        assertEquals(outbox, outboxRepository.count());
    }

    @Test
    void cp06T23_subscriptionRequestedEventContainsOnlySafeIdentifiersAndHash() throws Exception {
        Fixture f = fixture("A", "user-a", APP_OWNER_ROLE_ID, false);
        RequestTarget target = target(f, AudienceScopeType.TENANT, null, true, true);
        String sensitivePurpose = "internal-project-purpose-do-not-emit";
        String id = createdId(create(f, target, "idem-23", sensitivePurpose, "5000/day", 201));
        OutboxEventEntity event = outboxRepository.findAll().stream()
                .filter(e -> "SubscriptionRequested".equals(e.getEventType()) && id.equals(e.getAggregateId()))
                .findFirst().orElseThrow();
        JsonNode payload = objectMapper.readTree(event.getPayload());
        assertEquals(id, payload.get("subscriptionRequestId").asText());
        assertEquals(64, payload.get("snapshotHash").asText().length());
        assertFalse(event.getPayload().contains(sensitivePurpose));
        assertFalse(event.getPayload().toLowerCase().contains("secret"));
    }

    @Test
    void cp06T24_createServiceContainsNoDirectItsmOrHttpClientCall() throws Exception {
        String source = Files.readString(Path.of("src/main/java/com/gsitm/ustra/api/platform/subscription/application/SubscriptionRequestService.java"));
        assertFalse(source.contains("RestTemplate"));
        assertFalse(source.contains("WebClient"));
        assertFalse(source.contains("ITSM"));
        assertFalse(source.contains("HttpClient"));
    }

    @Test
    void cp06T25_requestCreationDoesNotCreateSubscriptionAuthority() throws Exception {
        Fixture f = fixture("A", "user-a", APP_OWNER_ROLE_ID, false);
        RequestTarget target = target(f, AudienceScopeType.TENANT, null, true, true);
        create(f, target, "idem-25", "x", null, 201);
        assertEquals(0, countTable("SUBSCRIPTION"));
    }

    @Test
    void cp06T26_requestCreationDoesNotCreateEntitlement() throws Exception {
        Fixture f = fixture("A", "user-a", APP_OWNER_ROLE_ID, false);
        RequestTarget target = target(f, AudienceScopeType.TENANT, null, true, true);
        create(f, target, "idem-26", "x", null, 201);
        assertEquals(0, countTable("ENTITLEMENT"));
    }

    @Test
    void cp06T27_requestCreationDoesNotCreateCredentialOrGatewayPolicy() throws Exception {
        Fixture f = fixture("A", "user-a", APP_OWNER_ROLE_ID, false);
        RequestTarget target = target(f, AudienceScopeType.TENANT, null, true, true);
        create(f, target, "idem-27", "x", null, 201);
        assertEquals(0, countTable("CREDENTIAL_REFERENCE"));
        assertEquals(0, countTable("GATEWAY_POLICY"));
    }

    @Test
    void cp06T28_cp06DoesNotFabricateApprovalCompletion() throws Exception {
        Fixture f = fixture("A", "user-a", APP_OWNER_ROLE_ID, false);
        RequestTarget target = target(f, AudienceScopeType.TENANT, null, true, true);
        String body = create(f, target, "idem-28", "x", null, 201).andReturn().getResponse().getContentAsString();
        assertFalse(body.contains("APPROVED"));
        assertFalse(body.contains("COMPLETED"));
        assertFalse(body.contains("approvalReference"));
    }

    @Test
    void cp06T29_requestRemainsPinnedWhenNewProductVersionAndPublicationAppear() throws Exception {
        Fixture f = fixture("A", "user-a", APP_OWNER_ROLE_ID, false);
        RequestTarget original = target(f, AudienceScopeType.TENANT, null, true, true);
        String id = createdId(create(f, original, "idem-29", "x", null, 201));
        ApiProductVersionEntity newer = productVersion(f, original.product(), "v2", true);
        publication(f, newer, AudienceScopeType.TENANT, null, true);
        entityManager.clear();
        assertEquals(original.productVersion().getId(), requestRepository.findById(id).orElseThrow().getApiProductVersionId());
    }

    @Test
    void cp06T30_cp01ThroughCp05RegressionSuitesRemainPresent() throws Exception {
        assertNotNull(Class.forName("com.gsitm.ustra.api.platform.Cp01AcceptanceIntegrationTest"));
        assertNotNull(Class.forName("com.gsitm.ustra.api.platform.Cp02AcceptanceIntegrationTest"));
        assertNotNull(Class.forName("com.gsitm.ustra.api.platform.Cp03AcceptanceIntegrationTest"));
        assertNotNull(Class.forName("com.gsitm.ustra.api.platform.Cp04AcceptanceIntegrationTest"));
        assertNotNull(Class.forName("com.gsitm.ustra.api.platform.Cp05AcceptanceIntegrationTest"));
    }

    @Test
    void cp06T31_migrationResourcesReachV022() {
        assertNotNull(getClass().getResource("/db/migration/V020__subscription_request.sql"));
        assertNotNull(getClass().getResource("/db/migration/V021__subscription_request_revision.sql"));
        assertNotNull(getClass().getResource("/db/migration/V022__subscription_request_permission_and_idempotency.sql"));
    }

    @Test
    void cp06N01_getIsTenantQualified() throws Exception {
        Fixture a = fixture("A", "user-a", APP_OWNER_ROLE_ID, false);
        Fixture b = fixture("B", "user-b", APP_OWNER_ROLE_ID, false);
        RequestTarget tb = target(b, AudienceScopeType.TENANT, null, true, true);
        String id = createdId(create(b, tb, "idem-n01", "x", null, 201));
        mvc.perform(get("/api/v1/subscription-requests/{id}", id).header("X-Test-Principal-Id", "user-a"))
                .andExpect(status().isNotFound()).andExpect(jsonPath("$.code").value("SUBSCRIPTION_REQUEST_NOT_FOUND"));
    }

    @Test
    void cp06N02_missingIdempotencyKeyFailsClosed() throws Exception {
        Fixture f = fixture("A", "user-a", APP_OWNER_ROLE_ID, false);
        RequestTarget target = target(f, AudienceScopeType.TENANT, null, true, true);
        Map<String, Object> body = requestBody(target, "x", null);
        mvc.perform(post("/api/v1/subscription-requests")
                        .header("X-Test-Principal-Id", "user-a")
                        .contentType(MediaType.APPLICATION_JSON).content(json(body)))
                .andExpect(status().isBadRequest()).andExpect(jsonPath("$.code").value("IDEMPOTENCY_KEY_REQUIRED"));
    }

    private org.springframework.test.web.servlet.ResultActions create(Fixture f, RequestTarget target,
            String key, String purpose, String expected, int statusCode) throws Exception {
        return createRaw(f, target.environment().getId(), target.publication().getId(), key, purpose, expected, statusCode);
    }

    private org.springframework.test.web.servlet.ResultActions createRaw(Fixture f, String environmentId,
            String publicationId, String key, String purpose, String expected, int statusCode) throws Exception {
        return mvc.perform(post("/api/v1/subscription-requests")
                        .header("X-Test-Principal-Id", f.membership().getPrincipalId())
                        .header("Idempotency-Key", key)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(requestBody(environmentId, publicationId, purpose, expected))))
                .andExpect(status().is(statusCode));
    }

    private Map<String, Object> requestBody(RequestTarget target, String purpose, String expected) {
        return requestBody(target.environment().getId(), target.publication().getId(), purpose, expected);
    }

    private Map<String, Object> requestBody(String environmentId, String publicationId, String purpose, String expected) {
        java.util.HashMap<String, Object> body = new java.util.HashMap<>();
        body.put("consumerAppEnvironmentId", environmentId);
        body.put("catalogPublicationId", publicationId);
        body.put("purpose", purpose);
        if (expected != null) body.put("expectedCallVolume", expected);
        return body;
    }

    private String createdId(org.springframework.test.web.servlet.ResultActions result) throws Exception {
        return objectMapper.readTree(result.andReturn().getResponse().getContentAsString())
                .get("subscriptionRequestId").asText();
    }

    private RequestTarget target(Fixture f, AudienceScopeType scopeType, String organizationId,
                                 boolean appActive, boolean publicationActive) {
        ConsumerAppEntity app = app(f, "APP-" + UUID.randomUUID().toString().substring(0, 8), appActive);
        ConsumerAppEnvironmentEntity environment = environment(f, app, ConsumerAppEnvironmentType.PROD);
        ApiProductEntity product = product(f, "PROD-" + UUID.randomUUID().toString().substring(0, 8));
        ApiProductVersionEntity pv = productVersion(f, product, "v1", true);
        CatalogPublicationEntity publication = publication(f, pv, scopeType, organizationId, publicationActive);
        return new RequestTarget(app, environment, product, pv, publication);
    }

    private ConsumerAppEntity app(Fixture f, String code, boolean active) {
        ConsumerAppEntity entity = new ConsumerAppEntity(UUID.randomUUID().toString(), f.tenant().getId(), code, code,
                code, null, f.membership().getId(), f.membership().getOrganizationId(), NOW, "fixture");
        if (active) entity.activate(NOW, "fixture");
        return appRepository.saveAndFlush(entity);
    }

    private ConsumerAppEnvironmentEntity environment(Fixture f, ConsumerAppEntity app, ConsumerAppEnvironmentType type) {
        return environmentRepository.saveAndFlush(new ConsumerAppEnvironmentEntity(UUID.randomUUID().toString(),
                f.tenant().getId(), app.getId(), type, null, null, null, NOW, "fixture"));
    }

    private ApiProductEntity product(Fixture f, String code) {
        ApiProductEntity product = productRepository.saveAndFlush(new ApiProductEntity(UUID.randomUUID().toString(),
                f.tenant().getId(), code, code, code, null, null, null, NOW, "fixture"));
        assertNotEquals(ApiProductLifecycleState.RETIRED, product.getLifecycleState());
        return product;
    }

    private ApiProductVersionEntity productVersion(Fixture f, ApiProductEntity product, String value, boolean released) {
        ApiProductVersionEntity entity = productVersionRepository.saveAndFlush(new ApiProductVersionEntity(
                UUID.randomUUID().toString(), f.tenant().getId(), product.getId(), value, NOW, "fixture"));
        if (released) {
            jdbc.update("UPDATE api_product_version SET lifecycle_state='RELEASED' WHERE api_product_version_id=?", entity.getId());
            entityManager.clear();
            entity = productVersionRepository.findById(entity.getId()).orElseThrow();
            assertEquals(ApiProductVersionState.RELEASED, entity.getLifecycleState());
        }
        return entity;
    }

    private CatalogPublicationEntity publication(Fixture f, ApiProductVersionEntity pv,
                                                  AudienceScopeType type, String organizationId, boolean active) {
        CatalogPublicationEntity pub = new CatalogPublicationEntity(UUID.randomUUID().toString(), f.tenant().getId(),
                pv.getId(), NOW, "fixture");
        if (active) pub.activate(NOW, "fixture");
        pub = publicationRepository.saveAndFlush(pub);
        audienceRepository.saveAndFlush(new AudienceScopeEntity(UUID.randomUUID().toString(), f.tenant().getId(),
                pub.getId(), type, organizationId, NOW, "fixture"));
        return pub;
    }

    private Fixture fixture(String suffix, String principal, String roleId, boolean withOrganization) {
        CustomerEntity customer = customerRepository.saveAndFlush(new CustomerEntity(UUID.randomUUID().toString(),
                "C-" + suffix + "-" + UUID.randomUUID().toString().substring(0, 5), "Customer " + suffix,
                CustomerStatus.ACTIVE, NOW));
        TenantEntity tenant = new TenantEntity(UUID.randomUUID().toString(), customer.getId(),
                "T-" + suffix + "-" + UUID.randomUUID().toString().substring(0, 5), "Tenant " + suffix,
                "ko-KR", "Asia/Seoul", NOW);
        tenant.activate(NOW);
        tenant = tenantRepository.saveAndFlush(tenant);
        configurationRepository.saveAndFlush(new TenantConfigurationEntity(UUID.randomUUID().toString(),
                tenant.getId(), "ko-KR", "Asia/Seoul", NOW));
        OrganizationEntity org = withOrganization ? organization(tenant, "ORG-" + suffix) : null;
        MembershipEntity membership = membershipRepository.saveAndFlush(new MembershipEntity(UUID.randomUUID().toString(),
                tenant.getId(), org == null ? null : org.getId(), principal, "local-test",
                NOW.minus(Duration.ofDays(1)), null, NOW));
        RoleEntity role = roleRepository.findById(roleId).orElseThrow();
        assignmentRepository.saveAndFlush(new RoleAssignmentEntity(UUID.randomUUID().toString(), tenant.getId(),
                membership.getId(), role.getId(), null, NOW.minusSeconds(60), null, "fixture", NOW));
        return new Fixture(customer, tenant, membership);
    }

    private OrganizationEntity organization(TenantEntity tenant, String code) {
        return organizationRepository.saveAndFlush(new OrganizationEntity(UUID.randomUUID().toString(), tenant.getId(),
                code + "-" + UUID.randomUUID().toString().substring(0, 5), code, null, NOW));
    }

    private long countTable(String tableName) {
        Long count = jdbc.queryForObject("SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE UPPER(TABLE_NAME)=?",
                Long.class, tableName.toUpperCase());
        return count == null ? 0 : count;
    }

    private void resetPermissionMappings() {
        removePermissionMappings();
        jdbc.update("INSERT INTO role_permission(role_id, permission_id) VALUES (?, ?)",
                APP_OWNER_ROLE_ID, SUBSCRIPTION_REQUEST_PERMISSION_ID);
    }

    private void removePermissionMappings() {
        for (String role : List.of(APP_OWNER_ROLE_ID, DEVELOPER_ROLE_ID)) {
            jdbc.update("DELETE FROM role_permission WHERE role_id=? AND permission_id=?",
                    role, SUBSCRIPTION_REQUEST_PERMISSION_ID);
        }
    }

    private void cleanupData() {
        idempotencyRepository.deleteAllInBatch();
        revisionRepository.deleteAllInBatch();
        requestRepository.deleteAllInBatch();
        environmentRepository.deleteAllInBatch();
        appRepository.deleteAllInBatch();
        audienceRepository.deleteAllInBatch();
        publicationRepository.deleteAllInBatch();
        historyRepository.deleteAllInBatch();
        componentRepository.deleteAllInBatch();
        productVersionRepository.deleteAllInBatch();
        productRepository.deleteAllInBatch();
        assignmentRepository.deleteAllInBatch();
        membershipRepository.deleteAllInBatch();
        organizationRepository.deleteAllInBatch();
        configurationRepository.deleteAllInBatch();
        outboxRepository.deleteAllInBatch();
        auditRepository.deleteAllInBatch();
        tenantRepository.deleteAllInBatch();
        customerRepository.deleteAllInBatch();
    }

    private String json(Object value) throws Exception {
        return objectMapper.writeValueAsString(value);
    }

    private record Fixture(CustomerEntity customer, TenantEntity tenant, MembershipEntity membership) {}
    private record RequestTarget(ConsumerAppEntity app, ConsumerAppEnvironmentEntity environment,
                                 ApiProductEntity product, ApiProductVersionEntity productVersion,
                                 CatalogPublicationEntity publication) {}
}

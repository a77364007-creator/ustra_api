package com.gsitm.ustra.api.platform;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import com.gsitm.ustra.api.platform.audit.*;
import com.gsitm.ustra.api.platform.integration.approval.application.*;
import com.gsitm.ustra.api.platform.integration.approval.domain.*;
import com.gsitm.ustra.api.platform.integration.approval.persistence.*;
import com.gsitm.ustra.api.platform.subscription.approval.application.*;
import com.gsitm.ustra.api.platform.subscription.approval.persistence.*;
import com.gsitm.ustra.api.platform.search.application.*;
import com.gsitm.ustra.api.platform.search.persistence.*;
import com.gsitm.ustra.api.platform.tenant.persistence.TenantRepository;
import java.time.*;
import java.util.*;
import org.junit.jupiter.api.Test;

/** Behavior tests, not source-token checks. Execution requires the approved Maven dependencies. */
class Cp15SafetyBehaviorTest {
    static final Instant NOW=Instant.parse("2026-09-22T00:00:00Z");
    static final Clock CLOCK=Clock.fixed(NOW,ZoneOffset.UTC);
    static final String TENANT="10000000-0000-0000-0000-000000000001";
    static final String OP="20000000-0000-0000-0000-000000000001";
    static final String PRODUCT="30000000-0000-0000-0000-000000000001";
    static IntegrationOperationEntity operation() {
        return new IntegrationOperationEntity(OP,TENANT,"connector",IntegrationOperationType.APPROVAL_CASE_CREATE,
                "SUBSCRIPTION_REQUEST","request",1,"a".repeat(64),"key",null,NOW,"actor");
    }
    static class ApprovalFixture {
        final ApprovalIntegrationStateService state=mock(ApprovalIntegrationStateService.class);
        final ApprovalConnectorRegistry registry=mock(ApprovalConnectorRegistry.class);
        final ApprovalPort port=mock(ApprovalPort.class);
        final ApprovalIntegrationOrchestrator service=new ApprovalIntegrationOrchestrator(state,registry);
        final IntegrationOperationEntity op=operation();
        final ApprovalPort.CaseCommand command=mock(ApprovalPort.CaseCommand.class);
        ApprovalFixture() {
            var connector=new ConnectorInstanceEntity("connector",TENANT,"profile","code","adapter","AUTH",null,true,NOW,"actor");
            when(state.prepareCreate(TENANT,"request")).thenReturn(new ApprovalIntegrationStateService.PreparedCreate(op,command,connector,true));
            when(registry.resolve("adapter")).thenReturn(port);
            when(state.markUnknown(eq(TENANT),eq(OP),anyString(),anyString(),nullable(String.class))).thenAnswer(inv->{
                op.unknown("UNKNOWN_RESULT",inv.getArgument(3),null,NOW,"actor");return op;});
            when(state.markFailed(eq(TENANT),eq(OP),anyString())).thenAnswer(inv->{op.fail("DEFINITIVE",inv.getArgument(2),NOW,"actor");return op;});
        }
    }
    @Test void cp15T27_missingAdapterNeverBeginsOutbound() {
        var f=new ApprovalFixture();when(f.registry.resolve("adapter")).thenThrow(new IllegalStateException("fixture missing"));
        assertThrows(IllegalStateException.class,()->f.service.startCase(TENANT,"request"));
        verify(f.state,never()).beginOutbound(anyString(),anyString());verifyNoInteractions(f.port);
    }
    @Test void cp15T28_unclassifiedAfterSendFailureIsUnknown() {
        var f=new ApprovalFixture();when(f.port.createCase(f.command)).thenThrow(new RuntimeException("vendor private body"));
        assertEquals(IntegrationOperationStatus.UNKNOWN,f.service.startCase(TENANT,"request").status());
        verify(f.port,times(1)).createCase(f.command);verify(f.state,never()).markFailed(anyString(),anyString(),anyString());
    }
    @Test void cp15T29_onlyExplicitDefinitiveFailureIsFailed() {
        var f=new ApprovalFixture();when(f.port.createCase(f.command)).thenThrow(new ApprovalConnectorFailureException("DENIED"));
        assertEquals(IntegrationOperationStatus.FAILED,f.service.startCase(TENANT,"request").status());
        verify(f.state).markFailed(TENANT,OP,"DENIED");
    }
    @Test void cp15T30_dbFailureAfterExternalSuccessNeverCreatesAgain() {
        var f=new ApprovalFixture();var external=mock(ApprovalPort.CaseReference.class);
        when(f.port.createCase(f.command)).thenReturn(external);
        when(f.state.completeCreate(TENANT,OP,f.command,external)).thenThrow(new IllegalStateException("DB raw response"));
        assertEquals(IntegrationOperationStatus.UNKNOWN,f.service.startCase(TENANT,"request").status());
        verify(f.port,times(1)).createCase(f.command);
        verify(f.state).markUnknown(TENANT,OP,ApprovalIntegrationStateService.createUnknownIssueType(),"CREATE_RESULT_PERSISTENCE_UNKNOWN",null);
    }
    @Test void cp15T32_existingCreateUnknownDoesNotCreateAgain() {
        var f=new ApprovalFixture();f.op.unknown("UNKNOWN_RESULT","TIMEOUT",null,NOW,"actor");
        var old=f.state.prepareCreate(TENANT,"request");
        when(f.state.prepareCreate(TENANT,"request")).thenReturn(new ApprovalIntegrationStateService.PreparedCreate(f.op,old.command(),old.connector(),false));
        var result=f.service.startCase(TENANT,"request");
        assertEquals(IntegrationOperationStatus.UNKNOWN,result.status());assertNull(result.approvalReferenceId());verifyNoInteractions(f.port);
    }
    @Test void cp15T33_resolvedIssueReopensSameIdentityAndAudits() {
        var repo=mock(ReconciliationIssueRepository.class);var ops=mock(IntegrationOperationRepository.class);var audit=mock(AuditService.class);
        var row=new ReconciliationIssueEntity("issue",TENANT,OP,"CREATE_OUTCOME_UNKNOWN","FIRST",NOW,"actor");
        row.resolve(NOW,"actor");when(ops.lockOwned(TENANT,OP)).thenReturn(Optional.of(operation()));
        when(repo.findByTenantIdAndIntegrationOperationIdAndIssueType(TENANT,OP,"CREATE_OUTCOME_UNKNOWN")).thenReturn(Optional.of(row));
        when(repo.saveAndFlush(any())).thenAnswer(inv->inv.getArgument(0));
        var service=new ReconciliationIssueService(repo,ops,audit,CLOCK);
        assertSame(row,service.open(TENANT,OP,"CREATE_OUTCOME_UNKNOWN","RECURRENT","actor"));
        assertEquals(ReconciliationIssueStatus.OPEN,row.getStatus());assertNull(row.getResolvedAt());
        verify(repo).saveAndFlush(row);verify(audit).success(eq(TENANT),eq("RECONCILIATION_ISSUE_REOPENED"),anyString(),eq("issue"),eq(true),anyMap());
    }
    @Test void cp15T34_parentLockPrecedesFirstIssueInsert() {
        var repo=mock(ReconciliationIssueRepository.class);var ops=mock(IntegrationOperationRepository.class);var audit=mock(AuditService.class);
        when(ops.lockOwned(TENANT,OP)).thenReturn(Optional.of(operation()));
        when(repo.findByTenantIdAndIntegrationOperationIdAndIssueType(anyString(),anyString(),anyString())).thenReturn(Optional.empty());
        when(repo.saveAndFlush(any())).thenAnswer(inv->inv.getArgument(0));
        new ReconciliationIssueService(repo,ops,audit,CLOCK).open(TENANT,OP,"CREATE_OUTCOME_UNKNOWN","CODE","actor");
        var order=inOrder(ops,repo);order.verify(ops).lockOwned(TENANT,OP);
        order.verify(repo).findByTenantIdAndIntegrationOperationIdAndIssueType(TENANT,OP,"CREATE_OUTCOME_UNKNOWN");
        order.verify(repo).saveAndFlush(any());
    }
    @Test void cp15T45_projectionFailureIsObservedWithoutFakeIntegrationRecord() {
        var port=mock(CatalogSearchProjectionPort.class);var observations=mock(SearchProjectionFailureService.class);
        when(port.reindexProduct(TENANT,PRODUCT,"actor")).thenThrow(new IllegalStateException("query raw"));
        var service=new SearchProjectionRecoveryService(port,observations);
        assertThrows(IllegalStateException.class,()->service.reindex(TENANT,PRODUCT,"actor"));
        verify(observations).observe(TENANT,PRODUCT);verify(observations,never()).resolve(anyString(),anyString(),any());
    }
    @Test void cp15T48_successResolvesOnlyObservedVersion() {
        var port=mock(CatalogSearchProjectionPort.class);var observations=mock(SearchProjectionFailureService.class);
        when(observations.openVersion(TENANT,PRODUCT)).thenReturn(7L);
        var expected=new CatalogSearchProjectionPort.ReindexResult(TENANT,PRODUCT,1,1);
        when(port.reindexProduct(TENANT,PRODUCT,"actor")).thenReturn(expected);
        assertSame(expected,new SearchProjectionRecoveryService(port,observations).reindex(TENANT,PRODUCT,"actor"));
        verify(observations).resolve(TENANT,PRODUCT,7L);
    }
    @Test void cp15T49_staleSuccessDoesNotCloseNewerFailure() {
        var row=new SearchProjectionFailureEntity("failure",TENANT,PRODUCT,NOW);
        assertFalse(row.resolveIfVersion(7,NOW));assertEquals("OPEN",row.getStatus());
    }
    @Test void cp15T50_observationDbFailureDoesNotEscapeAfterCommitListener() {
        var port=mock(CatalogSearchProjectionPort.class);var observations=mock(SearchProjectionFailureService.class);
        when(port.reindexProduct(TENANT,PRODUCT,"actor")).thenThrow(new RuntimeException("private payload"));
        doThrow(new RuntimeException("DB credential payload")).when(observations).observe(TENANT,PRODUCT);
        var listener=new CatalogSearchReindexListener(new SearchProjectionRecoveryService(port,observations));
        assertDoesNotThrow(()->listener.on(new CatalogSearchReindexEvent(TENANT,PRODUCT,"actor","UPDATE")));
        verify(observations).observe(TENANT,PRODUCT);
    }
    @Test void cp15T51_rebuildDelegatesCurrentTenantAndResolvesCapturedVersionsOnly() {
        var port=mock(CatalogSearchProjectionPort.class);var observations=mock(SearchProjectionFailureService.class);
        when(observations.openVersions(TENANT)).thenReturn(Map.of(PRODUCT,2L));
        var expected=new CatalogSearchProjectionPort.RebuildResult(TENANT,1,1,1);
        when(port.rebuildTenant(TENANT,"actor")).thenReturn(expected);
        assertSame(expected,new SearchProjectionRecoveryService(port,observations).rebuild(TENANT,"actor"));
        verify(port).rebuildTenant(TENANT,"actor");verify(observations).resolve(TENANT,PRODUCT,2L);
    }
    @Test void cp15T47_repeatedObservationReusesRow() {
        var repo=mock(SearchProjectionFailureRepository.class);var tenants=mock(TenantRepository.class);
        var row=new SearchProjectionFailureEntity("failure",TENANT,PRODUCT,NOW);
        when(tenants.lockById(TENANT)).thenReturn(Optional.of(mock(com.gsitm.ustra.api.platform.tenant.persistence.TenantEntity.class)));
        when(repo.findByTenantIdAndApiProductId(TENANT,PRODUCT)).thenReturn(Optional.of(row));
        var service=new SearchProjectionFailureService(repo,tenants,CLOCK);
        service.observe(TENANT,PRODUCT);service.observe(TENANT,PRODUCT);
        verify(repo,times(2)).saveAndFlush(row);
    }
}

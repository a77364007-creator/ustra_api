package com.gsitm.ustra.api.platform;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gsitm.ustra.api.platform.audit.AuditRecordRepository;
import com.gsitm.ustra.api.platform.catalog.domain.ApiProductLifecycleState;
import com.gsitm.ustra.api.platform.catalog.domain.ApiVersionState;
import com.gsitm.ustra.api.platform.catalog.persistence.*;
import com.gsitm.ustra.api.platform.catalog.publication.domain.*;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.*;
import com.gsitm.ustra.api.platform.common.context.RequestContext;
import com.gsitm.ustra.api.platform.common.context.RequestContextHolder;
import com.gsitm.ustra.api.platform.consumer.domain.*;
import com.gsitm.ustra.api.platform.consumer.persistence.*;
import com.gsitm.ustra.api.platform.outbox.OutboxEventRepository;
import com.gsitm.ustra.api.platform.security.UstraPrincipal;
import com.gsitm.ustra.api.platform.subscription.entitlement.application.*;
import com.gsitm.ustra.api.platform.subscription.entitlement.domain.*;
import com.gsitm.ustra.api.platform.subscription.entitlement.persistence.*;
import com.gsitm.ustra.api.platform.subscription.persistence.*;
import com.gsitm.ustra.api.platform.tenant.domain.CustomerStatus;
import com.gsitm.ustra.api.platform.tenant.persistence.*;
import jakarta.persistence.EntityManager;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.time.Instant;
import java.util.*;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class Cp07AcceptanceIntegrationTest {
    private static final String APP_OWNER_ROLE_ID = "00000000-0000-0000-0000-000000000005";
    private static final String SUBSCRIPTION_REQUEST_PERMISSION_ID = "13000000-0000-0000-0000-000000000001";
    private static final String SUBSCRIPTION_READ_PERMISSION_ID = "14000000-0000-0000-0000-000000000001";
    private static final String ENTITLEMENT_READ_PERMISSION_ID = "14000000-0000-0000-0000-000000000002";
    private static final String ENTITLEMENT_REVOKE_PERMISSION_ID = "14000000-0000-0000-0000-000000000003";
    private static final Instant NOW = Instant.parse("2026-09-20T00:00:00Z");

    @Autowired MockMvc mvc;
    @Autowired ObjectMapper objectMapper;
    @Autowired JdbcTemplate jdbc;
    @Autowired EntityManager entityManager;
    @Autowired EntitlementMaterializationService materializationService;
    @Autowired AccessFulfillmentService fulfillmentService;
    @Autowired ReadyToUseService readyToUseService;
    @Autowired CustomerRepository customerRepository;
    @Autowired TenantRepository tenantRepository;
    @Autowired TenantConfigurationRepository configurationRepository;
    @Autowired MembershipRepository membershipRepository;
    @Autowired OrganizationRepository organizationRepository;
    @Autowired RoleRepository roleRepository;
    @Autowired RoleAssignmentRepository assignmentRepository;
    @Autowired ConsumerAppRepository appRepository;
    @Autowired ConsumerAppEnvironmentRepository environmentRepository;
    @Autowired ApiProductRepository productRepository;
    @Autowired ApiProductVersionRepository productVersionRepository;
    @Autowired ApiProductComponentRepository componentRepository;
    @Autowired ApiRepository apiRepository;
    @Autowired ApiVersionRepository apiVersionRepository;
    @Autowired ApiOperationRepository operationRepository;
    @Autowired CatalogPublicationRepository publicationRepository;
    @Autowired AudienceScopeRepository audienceRepository;
    @Autowired SubscriptionRequestRepository requestRepository;
    @Autowired SubscriptionRequestRevisionRepository revisionRepository;
    @Autowired SubscriptionRequestIdempotencyRepository requestIdempotencyRepository;
    @Autowired SubscriptionRepository subscriptionRepository;
    @Autowired EntitlementRepository entitlementRepository;
    @Autowired EntitlementOperationScopeRepository scopeRepository;
    @Autowired QuotaProfileRepository quotaProfileRepository;
    @Autowired QuotaLimitRepository quotaLimitRepository;
    @Autowired AccessFulfillmentRepository fulfillmentRepository;
    @Autowired CredentialReferenceRepository credentialRepository;
    @Autowired StateTransitionHistoryRepository historyRepository;
    @Autowired AuditRecordRepository auditRepository;
    @Autowired OutboxEventRepository outboxRepository;

    @BeforeEach void setUp() { cleanupData(); resetPermissionMappings(); }
    @AfterEach void tearDown() { SecurityContextHolder.clearContext(); RequestContextHolder.clear(); cleanupData(); removePermissionMappings(); }

    @Test void cp07T01_approvedDecisionMaterializesExactlyOneSubscription() {
        GrantFixture g=grantFixture("A","user-a"); materialize(g, decision(g)); assertEquals(1, subscriptionRepository.count());
    }
    @Test void cp07T02_duplicateApprovedDecisionReplayDoesNotDuplicateSubscription() {
        GrantFixture g=grantFixture("A","user-a"); var d=decision(g); var a=materialize(g,d); var b=materialize(g,d); assertEquals(a.subscription().getId(),b.subscription().getId()); assertEquals(1,subscriptionRepository.count()); assertEquals(1,entitlementRepository.count());
    }
    @Test void cp07T03_requestRevisionOrHashMismatchRejected() {
        GrantFixture g=grantFixture("A","user-a"); var d=decision(g); var bad=new ApprovedSubscriptionDecision(d.tenantId(),d.approvalReferenceId(),d.subscriptionRequestId(),2,d.snapshotHash(),d.consumerAppEnvironmentId(),d.apiProductVersionId(),d.apiOperationIds(),d.quotaLimits(),d.effectiveFrom(),d.effectiveTo()); assertThrows(RuntimeException.class,()->materialize(g,bad));
    }
    @Test void cp07T04_productVersionMismatchAgainstPinnedRequestRejected() {
        GrantFixture g=grantFixture("A","user-a"); ApiProductVersionEntity other=productVersion(g.fixture(),g.product(),"v2",true); var d=decision(g); var bad=new ApprovedSubscriptionDecision(d.tenantId(),d.approvalReferenceId(),d.subscriptionRequestId(),d.requestRevisionNo(),d.snapshotHash(),d.consumerAppEnvironmentId(),other.getId(),d.apiOperationIds(),d.quotaLimits(),d.effectiveFrom(),d.effectiveTo()); assertThrows(RuntimeException.class,()->materialize(g,bad));
    }
    @Test void cp07T05_consumerAppEnvironmentMismatchRejected() {
        GrantFixture g=grantFixture("A","user-a"); ConsumerAppEnvironmentEntity other=environment(g.fixture(),g.app(),ConsumerAppEnvironmentType.TEST); var d=decision(g); var bad=new ApprovedSubscriptionDecision(d.tenantId(),d.approvalReferenceId(),d.subscriptionRequestId(),d.requestRevisionNo(),d.snapshotHash(),other.getId(),d.apiProductVersionId(),d.apiOperationIds(),d.quotaLimits(),d.effectiveFrom(),d.effectiveTo()); assertThrows(RuntimeException.class,()->materialize(g,bad));
    }
    @Test void cp07T06_crossTenantRequestEnvironmentVersionRejected() {
        GrantFixture a=grantFixture("A","user-a"); GrantFixture b=grantFixture("B","user-b"); var d=decision(b); var cross=new ApprovedSubscriptionDecision(a.fixture().tenant().getId(),d.approvalReferenceId(),d.subscriptionRequestId(),d.requestRevisionNo(),d.snapshotHash(),d.consumerAppEnvironmentId(),d.apiProductVersionId(),d.apiOperationIds(),d.quotaLimits(),d.effectiveFrom(),d.effectiveTo()); assertThrows(RuntimeException.class,()->materialize(a,cross));
    }
    @Test void cp07T07_entitlementSubjectIsExactApprovedEnvironment() {
        GrantFixture g=grantFixture("A","user-a"); var r=materialize(g,decision(g)); assertEquals(g.environment().getId(),r.entitlement().getConsumerAppEnvironmentId());
    }
    @Test void cp07T08_onlyApprovedOperationsAreGranted() {
        GrantFixture g=grantFixture("A","user-a"); var r=materialize(g,decision(g)); assertEquals(List.of(g.operation().getId()),scopeRepository.findAllByTenantIdAndEntitlementIdOrderByApiOperationIdAsc(g.fixture().tenant().getId(),r.entitlement().getId()).stream().map(EntitlementOperationScopeEntity::getApiOperationId).toList());
    }
    @Test void cp07T09_operationOutsidePinnedProductVersionRejected() {
        GrantFixture g=grantFixture("A","user-a"); ApiOperationEntity outsider=uncomposedOperation(g.fixture()); var d=decision(g); var bad=new ApprovedSubscriptionDecision(d.tenantId(),d.approvalReferenceId(),d.subscriptionRequestId(),d.requestRevisionNo(),d.snapshotHash(),d.consumerAppEnvironmentId(),d.apiProductVersionId(),List.of(outsider.getId()),d.quotaLimits(),d.effectiveFrom(),d.effectiveTo()); assertThrows(RuntimeException.class,()->materialize(g,bad));
    }
    @Test void cp07T10_emptyScopeIsNotInterpretedAsAll() {
        GrantFixture g=grantFixture("A","user-a"); var d=decision(g); var bad=new ApprovedSubscriptionDecision(d.tenantId(),d.approvalReferenceId(),d.subscriptionRequestId(),d.requestRevisionNo(),d.snapshotHash(),d.consumerAppEnvironmentId(),d.apiProductVersionId(),List.of(),d.quotaLimits(),d.effectiveFrom(),d.effectiveTo()); assertThrows(RuntimeException.class,()->materialize(g,bad));
    }
    @Test void cp07T11_prodRemainsPinnedToExactProductVersion() {
        GrantFixture g=grantFixture("A","user-a"); ApiProductVersionEntity newer=productVersion(g.fixture(),g.product(),"v2",true); var r=materialize(g,decision(g)); assertNotEquals(newer.getId(),r.subscription().getApiProductVersionId()); assertEquals(g.productVersion().getId(),r.subscription().getApiProductVersionId());
    }
    @Test void cp07T12_approvedQuotaMaterializedExactly() {
        GrantFixture g=grantFixture("A","user-a"); var d=decisionWithQuota(g,new BigDecimal("5000")); var r=materialize(g,d); var profile=quotaProfileRepository.findByTenantIdAndEntitlementId(g.fixture().tenant().getId(),r.entitlement().getId()).orElseThrow(); var limits=quotaLimitRepository.findAllByTenantIdAndQuotaProfileIdOrderByMetricCodeAsc(g.fixture().tenant().getId(),profile.getId()); assertEquals(1,limits.size()); assertEquals(0,new BigDecimal("5000").compareTo(limits.get(0).getLimitValue()));
    }
    @Test void cp07T13_unapprovedQuotaExpansionReplayRejected() {
        GrantFixture g=grantFixture("A","user-a"); materialize(g,decisionWithQuota(g,new BigDecimal("5000"))); assertThrows(RuntimeException.class,()->materialize(g,decisionWithQuota(g,new BigDecimal("6000"))));
    }
    @Test void cp07T14_effectivePeriodComesFromDecision() {
        GrantFixture g=grantFixture("A","user-a"); var d=decision(g); var r=materialize(g,d); assertEquals(d.effectiveFrom(),r.entitlement().getEffectiveFrom()); assertEquals(d.effectiveTo(),r.entitlement().getEffectiveTo());
    }
    @Test void cp07T15_invalidEffectivePeriodRejected() {
        GrantFixture g=grantFixture("A","user-a"); var d=decision(g); var bad=new ApprovedSubscriptionDecision(d.tenantId(),d.approvalReferenceId(),d.subscriptionRequestId(),d.requestRevisionNo(),d.snapshotHash(),d.consumerAppEnvironmentId(),d.apiProductVersionId(),d.apiOperationIds(),d.quotaLimits(),NOW,NOW); assertThrows(RuntimeException.class,()->materialize(g,bad));
    }
    @Test void cp07T16_materializationDoesNotMakeReadyToUseTrue() {
        GrantFixture g=grantFixture("A","user-a"); var r=materialize(g,decision(g)); assertFalse(readyToUseService.isReady(r.entitlement()));
    }
    @Test void cp07T17_subscriptionAndEntitlementStatesRemainSeparate() {
        GrantFixture g=grantFixture("A","user-a"); var r=materialize(g,decision(g)); assertEquals(SubscriptionStatus.ACTIVE,r.subscription().getStatus()); assertEquals(EntitlementStatus.GRANTED,r.entitlement().getStatus());
    }
    @Test void cp07T18_grantedDoesNotImplyGatewaySucceeded() {
        GrantFixture g=grantFixture("A","user-a"); var r=materialize(g,decision(g)); assertEquals(AccessFulfillmentStatus.PENDING,r.fulfillment().getStatus()); assertEquals(EntitlementStatus.GRANTED,r.entitlement().getStatus());
    }
    @Test void cp07T19_missingCredentialKeepsReadyFalse() {
        GrantFixture g=grantFixture("A","user-a"); var r=materialize(g,decision(g)); assertTrue(credentialRepository.findByTenantIdAndEntitlementId(g.fixture().tenant().getId(),r.entitlement().getId()).isEmpty()); assertFalse(readyToUseService.isReady(r.entitlement()));
    }
    @Test void cp07T20_missingRevokePermissionReturns403AndDenialAudit() throws Exception {
        GrantFixture g=grantFixture("A","user-a"); var r=materialize(g,decision(g)); jdbc.update("DELETE FROM role_permission WHERE role_id=? AND permission_id=?",APP_OWNER_ROLE_ID,ENTITLEMENT_REVOKE_PERMISSION_ID); mvc.perform(post("/api/v1/entitlements/{id}/revoke",r.entitlement().getId()).header("X-Test-Principal-Id","user-a").header(HttpHeaders.IF_MATCH,"\"0\"")).andExpect(status().isForbidden()); assertTrue(auditRepository.findAllByTenantIdOrderByOccurredAtAsc(g.fixture().tenant().getId()).stream().anyMatch(a->"DENIED".equals(a.getOutcome())));
    }
    @Test void cp07T21_revokeUsesSemanticActionNotGenericPatch() throws Exception {
        String source=Files.readString(Path.of("src/main/java/com/gsitm/ustra/api/platform/subscription/entitlement/api/EntitlementController.java")); assertTrue(source.contains("/{entitlementId}/revoke")); assertFalse(source.contains("@PatchMapping"));
    }
    @Test void cp07T22_revokeImmediatelyMakesReadyToUseFalse() throws Exception {
        GrantFixture g=grantFixture("A","user-a"); var r=materialize(g,decision(g)); makeRuntimeReady(g,r); entityManager.clear(); EntitlementEntity current=entitlementRepository.findById(r.entitlement().getId()).orElseThrow(); assertTrue(readyToUseService.isReady(current)); mvc.perform(post("/api/v1/entitlements/{id}/revoke",current.getId()).header("X-Test-Principal-Id","user-a").header(HttpHeaders.IF_MATCH,"\"0\"")).andExpect(status().isOk()); entityManager.clear(); assertFalse(readyToUseService.isReady(entitlementRepository.findById(current.getId()).orElseThrow()));
    }
    @Test void cp07T23_revokeCommitsHistoryAuditOutboxAtomically() throws Exception {
        GrantFixture g=grantFixture("A","user-a"); var r=materialize(g,decision(g)); mvc.perform(post("/api/v1/entitlements/{id}/revoke",r.entitlement().getId()).header("X-Test-Principal-Id","user-a").header(HttpHeaders.IF_MATCH,"\"0\"")).andExpect(status().isOk()); assertTrue(historyRepository.findAllByTenantIdAndAggregateTypeAndAggregateIdOrderByOccurredAtAsc(g.fixture().tenant().getId(),"ENTITLEMENT",r.entitlement().getId()).stream().anyMatch(h->"REVOKED".equals(h.getToState()))); assertTrue(auditRepository.findAllByTenantIdOrderByOccurredAtAsc(g.fixture().tenant().getId()).stream().anyMatch(a->"ENTITLEMENT_REVOKE".equals(a.getAction()))); assertTrue(outboxRepository.findAll().stream().anyMatch(e->"EntitlementRevoked".equals(e.getEventType())));
    }
    @Test void cp07T24_revokeDoesNotCallGatewayInsideTransaction() throws Exception {
        String source=Files.readString(Path.of("src/main/java/com/gsitm/ustra/api/platform/subscription/entitlement/application/EntitlementCommandService.java")); assertFalse(source.contains("RestTemplate")); assertFalse(source.contains("WebClient")); assertFalse(source.contains("GatewayClient")); assertFalse(source.contains("HttpClient"));
    }
    @Test void cp07T25_duplicateRevokeIsStableConflict() throws Exception {
        GrantFixture g=grantFixture("A","user-a"); var r=materialize(g,decision(g)); mvc.perform(post("/api/v1/entitlements/{id}/revoke",r.entitlement().getId()).header("X-Test-Principal-Id","user-a").header(HttpHeaders.IF_MATCH,"\"0\"")).andExpect(status().isOk()); mvc.perform(post("/api/v1/entitlements/{id}/revoke",r.entitlement().getId()).header("X-Test-Principal-Id","user-a").header(HttpHeaders.IF_MATCH,"\"0\"")).andExpect(status().isConflict());
    }
    @Test void cp07T26_pendingProvisionFulfillmentCreatedForGrant() {
        GrantFixture g=grantFixture("A","user-a"); var r=materialize(g,decision(g)); assertEquals(AccessFulfillmentType.PROVISION,r.fulfillment().getFulfillmentType()); assertEquals(AccessFulfillmentStatus.PENDING,r.fulfillment().getStatus());
    }
    @Test void cp07T27_sameFulfillmentRevisionProducesOneEffectCandidate() {
        GrantFixture g=grantFixture("A","user-a"); var r=materialize(g,decision(g)); assertEquals(1,fulfillmentRepository.findAllByTenantIdAndEntitlementIdOrderByFulfillmentRevisionAsc(g.fixture().tenant().getId(),r.entitlement().getId()).size()); assertEquals(1,r.fulfillment().getFulfillmentRevision());
    }
    @Test void cp07T28_timeoutOutcomePreservedAsUnknown() {
        GrantFixture g=grantFixture("A","user-a"); var r=materialize(g,decision(g)); setInternalActor("user-a"); fulfillmentService.recordOutcome(g.fixture().tenant().getId(),r.fulfillment().getId(),AccessFulfillmentStatus.PROCESSING,"op-1",null); AccessFulfillmentEntity unknown=fulfillmentService.recordOutcome(g.fixture().tenant().getId(),r.fulfillment().getId(),AccessFulfillmentStatus.UNKNOWN,"op-1","TIMEOUT"); assertEquals(AccessFulfillmentStatus.UNKNOWN,unknown.getStatus());
    }
    @Test void cp07T29_unknownIsNotTreatedAsFailed() {
        GrantFixture g=grantFixture("A","user-a"); var r=materialize(g,decision(g)); setInternalActor("user-a"); fulfillmentService.recordOutcome(g.fixture().tenant().getId(),r.fulfillment().getId(),AccessFulfillmentStatus.PROCESSING,"op-1",null); var unknown=fulfillmentService.recordOutcome(g.fixture().tenant().getId(),r.fulfillment().getId(),AccessFulfillmentStatus.UNKNOWN,"op-1","TIMEOUT"); assertNotEquals(AccessFulfillmentStatus.FAILED,unknown.getStatus());
    }
    @Test void cp07T30_credentialReferenceSchemaHasNoRawSecretFields() throws Exception {
        String migration=Files.readString(Path.of("src/main/resources/db/migration/V025__access_fulfillment_credential_reference.sql")).toLowerCase(); assertFalse(migration.contains("client_secret")); assertFalse(migration.contains("api_key_value")); assertFalse(migration.contains("token_value")); assertFalse(migration.contains("private_key"));
    }
    @Test void cp07T31_subscriptionListIsTenantIsolated() throws Exception {
        GrantFixture a=grantFixture("A","user-a"); GrantFixture b=grantFixture("B","user-b"); materialize(a,decision(a)); materialize(b,decision(b)); mvc.perform(get("/api/v1/subscriptions").header("X-Test-Principal-Id","user-a")).andExpect(status().isOk()).andExpect(jsonPath("$.length()").value(1));
    }
    @Test void cp07T32_entitlementListIsTenantIsolated() throws Exception {
        GrantFixture a=grantFixture("A","user-a"); GrantFixture b=grantFixture("B","user-b"); materialize(a,decision(a)); materialize(b,decision(b)); mvc.perform(get("/api/v1/entitlements").header("X-Test-Principal-Id","user-a")).andExpect(status().isOk()).andExpect(jsonPath("$.length()").value(1));
    }
    @Test void cp07T33_roleNamesAreNotHardcodedInBusinessAuthorization() throws Exception {
        String source=Files.readString(Path.of("src/main/java/com/gsitm/ustra/api/platform/subscription/entitlement/application/EntitlementQueryService.java"))+Files.readString(Path.of("src/main/java/com/gsitm/ustra/api/platform/subscription/entitlement/application/EntitlementCommandService.java")); assertFalse(source.contains("APP_OWNER")); assertFalse(source.contains("TENANT_ADMIN"));
    }
    @Disabled("DF-CP07-09: ConsumerApp owner/organization object-scope authorization remains unapproved")
    @Test void cp07T34_objectScopeOwnerOrganizationReadVisibilityPolicyDependent() { fail("Enable after object-scope policy approval"); }
    @Test void cp07T35_cp06RequestCreateStillCreatesNoEntitlementBeforeApproval() throws Exception {
        GrantFixture g=grantFixture("A","user-a"); long before=entitlementRepository.count(); Map<String,Object> body=Map.of("consumerAppEnvironmentId",g.environment().getId(),"catalogPublicationId",g.publication().getId(),"purpose","new request"); mvc.perform(post("/api/v1/subscription-requests").header("X-Test-Principal-Id","user-a").header("Idempotency-Key","cp07-t35").contentType(MediaType.APPLICATION_JSON).content(objectMapper.writeValueAsString(body))).andExpect(status().isCreated()); assertEquals(before,entitlementRepository.count());
    }
    @Test void cp07T36_cp01ThroughCp06RegressionSuitesRemainPresent() throws Exception {
        for(String name:List.of("Cp01AcceptanceIntegrationTest","Cp02AcceptanceIntegrationTest","Cp03AcceptanceIntegrationTest","Cp04AcceptanceIntegrationTest","Cp05AcceptanceIntegrationTest","Cp06AcceptanceIntegrationTest")) assertNotNull(Class.forName("com.gsitm.ustra.api.platform."+name));
    }
    @Test void cp07T37_migrationResourcesReachV026() {
        assertNotNull(getClass().getResource("/db/migration/V023__subscription_entitlement.sql")); assertNotNull(getClass().getResource("/db/migration/V024__entitlement_scope_quota.sql")); assertNotNull(getClass().getResource("/db/migration/V025__access_fulfillment_credential_reference.sql")); assertNotNull(getClass().getResource("/db/migration/V026__entitlement_permissions.sql"));
    }
    @Test void cp07T38_noActualGatewayAdapterShipsInCp07() throws Exception {
        Path root=Path.of("src/main/java/com/gsitm/ustra/api/platform/subscription/entitlement"); String all=Files.walk(root).filter(Files::isRegularFile).map(p->{try{return Files.readString(p);}catch(Exception e){throw new RuntimeException(e);}}).reduce("",String::concat); assertFalse(all.contains("RestTemplate")); assertFalse(all.contains("WebClient")); assertFalse(all.contains("GatewayClient"));
    }

    private EntitlementMaterializationService.MaterializationResult materialize(GrantFixture g,ApprovedSubscriptionDecision d){setInternalActor(g.fixture().membership().getPrincipalId());return materializationService.materialize(d);}
    private ApprovedSubscriptionDecision decision(GrantFixture g){return new ApprovedSubscriptionDecision(g.fixture().tenant().getId(),"APR-"+g.request().getId(),g.request().getId(),1,g.revision().getSnapshotHash(),g.environment().getId(),g.productVersion().getId(),List.of(g.operation().getId()),List.of(),NOW.minusSeconds(60),NOW.plus(Duration.ofDays(30)));}
    private ApprovedSubscriptionDecision decisionWithQuota(GrantFixture g,BigDecimal value){var d=decision(g);return new ApprovedSubscriptionDecision(d.tenantId(),d.approvalReferenceId(),d.subscriptionRequestId(),d.requestRevisionNo(),d.snapshotHash(),d.consumerAppEnvironmentId(),d.apiProductVersionId(),d.apiOperationIds(),List.of(new ApprovedSubscriptionDecision.QuotaLimitDecision("REQUEST_COUNT",value,86400,"REQUEST")),d.effectiveFrom(),d.effectiveTo());}
    private void makeRuntimeReady(GrantFixture g,EntitlementMaterializationService.MaterializationResult r){setInternalActor(g.fixture().membership().getPrincipalId()); fulfillmentService.recordOutcome(g.fixture().tenant().getId(),r.fulfillment().getId(),AccessFulfillmentStatus.PROCESSING,"op-ready",null); fulfillmentService.recordOutcome(g.fixture().tenant().getId(),r.fulfillment().getId(),AccessFulfillmentStatus.SUCCEEDED,"op-ready",null); fulfillmentService.synchronizeCredential(g.fixture().tenant().getId(),r.entitlement().getId(),r.fulfillment().getId(),"MOCK","credential-ref-1",CredentialReferenceStatus.ACTIVE,NOW.plus(Duration.ofDays(20)));}
    private void setInternalActor(String principal){SecurityContextHolder.getContext().setAuthentication(new UsernamePasswordAuthenticationToken(new UstraPrincipal(principal,"local-test"),null,List.of(new SimpleGrantedAuthority("ROLE_TEST"))));RequestContextHolder.set(new RequestContext(UUID.randomUUID().toString(),UUID.randomUUID().toString()));}

    private GrantFixture grantFixture(String suffix,String principal){Fixture f=fixture(suffix,principal); ConsumerAppEntity app=app(f,"APP-"+suffix,true); ConsumerAppEnvironmentEntity env=environment(f,app,ConsumerAppEnvironmentType.PROD); ApiProductEntity product=product(f,"PRODUCT-"+suffix); ApiProductVersionEntity pv=productVersion(f,product,"v1",true); ApiEntity api=apiRepository.saveAndFlush(new ApiEntity(UUID.randomUUID().toString(),f.tenant().getId(),"API-"+suffix,"API-"+suffix,"API "+suffix,null,null,NOW,"fixture")); ApiVersionEntity av=apiVersionRepository.saveAndFlush(new ApiVersionEntity(UUID.randomUUID().toString(),f.tenant().getId(),api.getId(),"v1",ApiVersionState.RELEASED,NOW,"fixture")); ApiOperationEntity op=operationRepository.saveAndFlush(new ApiOperationEntity(UUID.randomUUID().toString(),f.tenant().getId(),av.getId(),"GET","/items","/items","getItems","Get items",NOW,"fixture")); componentRepository.saveAndFlush(new ApiProductComponentEntity(UUID.randomUUID().toString(),f.tenant().getId(),pv.getId(),ApiProductComponentTargetType.API_OPERATION,null,op.getId(),NOW,"fixture")); CatalogPublicationEntity pub=publication(f,pv); SubscriptionRequestEntity req=requestRepository.saveAndFlush(new SubscriptionRequestEntity(UUID.randomUUID().toString(),f.tenant().getId(),env.getId(),pub.getId(),pv.getId(),f.membership().getId(),NOW,"fixture")); String hash="a".repeat(64); SubscriptionRequestRevisionEntity rev=revisionRepository.saveAndFlush(new SubscriptionRequestRevisionEntity(UUID.randomUUID().toString(),f.tenant().getId(),req.getId(),1,f.membership().getId(),"purpose",null,hash,NOW,"fixture")); return new GrantFixture(f,app,env,product,pv,pub,api,av,op,req,rev);}
    private ApiOperationEntity uncomposedOperation(Fixture f){ApiEntity api=apiRepository.saveAndFlush(new ApiEntity(UUID.randomUUID().toString(),f.tenant().getId(),"OTHER-"+UUID.randomUUID(),"OTHER-"+UUID.randomUUID(),"Other",null,null,NOW,"fixture"));ApiVersionEntity av=apiVersionRepository.saveAndFlush(new ApiVersionEntity(UUID.randomUUID().toString(),f.tenant().getId(),api.getId(),"v1",ApiVersionState.RELEASED,NOW,"fixture"));return operationRepository.saveAndFlush(new ApiOperationEntity(UUID.randomUUID().toString(),f.tenant().getId(),av.getId(),"GET","/other","/other",null,"Other",NOW,"fixture"));}
    private ConsumerAppEntity app(Fixture f,String code,boolean active){ConsumerAppEntity e=new ConsumerAppEntity(UUID.randomUUID().toString(),f.tenant().getId(),code,code,code,null,f.membership().getId(),f.membership().getOrganizationId(),NOW,"fixture");if(active)e.activate(NOW,"fixture");return appRepository.saveAndFlush(e);}
    private ConsumerAppEnvironmentEntity environment(Fixture f,ConsumerAppEntity app,ConsumerAppEnvironmentType type){return environmentRepository.saveAndFlush(new ConsumerAppEnvironmentEntity(UUID.randomUUID().toString(),f.tenant().getId(),app.getId(),type,null,null,null,NOW,"fixture"));}
    private ApiProductEntity product(Fixture f,String code){ApiProductEntity p=productRepository.saveAndFlush(new ApiProductEntity(UUID.randomUUID().toString(),f.tenant().getId(),code,code,code,null,null,null,NOW,"fixture"));assertNotEquals(ApiProductLifecycleState.RETIRED,p.getLifecycleState());return p;}
    private ApiProductVersionEntity productVersion(Fixture f,ApiProductEntity p,String v,boolean released){ApiProductVersionEntity e=productVersionRepository.saveAndFlush(new ApiProductVersionEntity(UUID.randomUUID().toString(),f.tenant().getId(),p.getId(),v,NOW,"fixture"));if(released){jdbc.update("UPDATE api_product_version SET lifecycle_state='RELEASED' WHERE api_product_version_id=?",e.getId());entityManager.clear();e=productVersionRepository.findById(e.getId()).orElseThrow();}return e;}
    private CatalogPublicationEntity publication(Fixture f,ApiProductVersionEntity pv){CatalogPublicationEntity p=new CatalogPublicationEntity(UUID.randomUUID().toString(),f.tenant().getId(),pv.getId(),NOW,"fixture");p.activate(NOW,"fixture");p=publicationRepository.saveAndFlush(p);audienceRepository.saveAndFlush(new AudienceScopeEntity(UUID.randomUUID().toString(),f.tenant().getId(),p.getId(),AudienceScopeType.TENANT,null,NOW,"fixture"));return p;}
    private Fixture fixture(String suffix,String principal){CustomerEntity c=customerRepository.saveAndFlush(new CustomerEntity(UUID.randomUUID().toString(),"C-"+suffix+"-"+UUID.randomUUID().toString().substring(0,5),"Customer "+suffix,CustomerStatus.ACTIVE,NOW));TenantEntity t=new TenantEntity(UUID.randomUUID().toString(),c.getId(),"T-"+suffix+"-"+UUID.randomUUID().toString().substring(0,5),"Tenant "+suffix,"ko-KR","Asia/Seoul",NOW);t.activate(NOW);t=tenantRepository.saveAndFlush(t);configurationRepository.saveAndFlush(new TenantConfigurationEntity(UUID.randomUUID().toString(),t.getId(),"ko-KR","Asia/Seoul",NOW));MembershipEntity m=membershipRepository.saveAndFlush(new MembershipEntity(UUID.randomUUID().toString(),t.getId(),null,principal,"local-test",NOW.minus(Duration.ofDays(1)),null,NOW));RoleEntity role=roleRepository.findById(APP_OWNER_ROLE_ID).orElseThrow();assignmentRepository.saveAndFlush(new RoleAssignmentEntity(UUID.randomUUID().toString(),t.getId(),m.getId(),role.getId(),null,NOW.minusSeconds(60),null,"fixture",NOW));return new Fixture(c,t,m);}

    private void resetPermissionMappings(){removePermissionMappings();for(String id:List.of(SUBSCRIPTION_REQUEST_PERMISSION_ID,SUBSCRIPTION_READ_PERMISSION_ID,ENTITLEMENT_READ_PERMISSION_ID,ENTITLEMENT_REVOKE_PERMISSION_ID))jdbc.update("INSERT INTO role_permission(role_id, permission_id) VALUES (?, ?)",APP_OWNER_ROLE_ID,id);}
    private void removePermissionMappings(){for(String id:List.of(SUBSCRIPTION_REQUEST_PERMISSION_ID,SUBSCRIPTION_READ_PERMISSION_ID,ENTITLEMENT_READ_PERMISSION_ID,ENTITLEMENT_REVOKE_PERMISSION_ID))jdbc.update("DELETE FROM role_permission WHERE role_id=? AND permission_id=?",APP_OWNER_ROLE_ID,id);}
    private void cleanupData(){credentialRepository.deleteAllInBatch();fulfillmentRepository.deleteAllInBatch();quotaLimitRepository.deleteAllInBatch();quotaProfileRepository.deleteAllInBatch();scopeRepository.deleteAllInBatch();entitlementRepository.deleteAllInBatch();subscriptionRepository.deleteAllInBatch();requestIdempotencyRepository.deleteAllInBatch();revisionRepository.deleteAllInBatch();requestRepository.deleteAllInBatch();audienceRepository.deleteAllInBatch();publicationRepository.deleteAllInBatch();componentRepository.deleteAllInBatch();operationRepository.deleteAllInBatch();apiVersionRepository.deleteAllInBatch();apiRepository.deleteAllInBatch();productVersionRepository.deleteAllInBatch();productRepository.deleteAllInBatch();environmentRepository.deleteAllInBatch();appRepository.deleteAllInBatch();historyRepository.deleteAllInBatch();assignmentRepository.deleteAllInBatch();membershipRepository.deleteAllInBatch();organizationRepository.deleteAllInBatch();configurationRepository.deleteAllInBatch();outboxRepository.deleteAllInBatch();auditRepository.deleteAllInBatch();tenantRepository.deleteAllInBatch();customerRepository.deleteAllInBatch();}

    private record Fixture(CustomerEntity customer,TenantEntity tenant,MembershipEntity membership){}
    private record GrantFixture(Fixture fixture,ConsumerAppEntity app,ConsumerAppEnvironmentEntity environment,ApiProductEntity product,ApiProductVersionEntity productVersion,CatalogPublicationEntity publication,ApiEntity api,ApiVersionEntity apiVersion,ApiOperationEntity operation,SubscriptionRequestEntity request,SubscriptionRequestRevisionEntity revision){}
}

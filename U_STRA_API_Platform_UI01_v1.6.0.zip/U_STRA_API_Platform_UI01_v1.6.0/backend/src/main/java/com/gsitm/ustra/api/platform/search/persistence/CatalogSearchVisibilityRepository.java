package com.gsitm.ustra.api.platform.search.persistence;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CatalogSearchVisibilityRepository extends JpaRepository<CatalogSearchVisibilityEntity, String> {
    List<CatalogSearchVisibilityEntity> findAllByTenantIdAndApiProductIdOrderByVersionValueAscCatalogPublicationIdAsc(
            String tenantId, String apiProductId);
    long deleteByTenantId(String tenantId);
    long deleteByTenantIdAndApiProductId(String tenantId, String apiProductId);
    long countByTenantId(String tenantId);
}

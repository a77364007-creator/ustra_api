package com.gsitm.ustra.api.platform.subscription.entitlement.persistence;
import jakarta.persistence.*; import java.time.Instant;
@Entity @Table(name="quota_profile")
public class QuotaProfileEntity {
 @Id @Column(name="quota_profile_id",length=36,nullable=false,updatable=false) private String id;
 @Column(name="tenant_id",length=36,nullable=false,updatable=false) private String tenantId;
 @Column(name="entitlement_id",length=36,nullable=false,updatable=false) private String entitlementId;
 @Column(name="profile_revision",nullable=false,updatable=false) private int profileRevision;
 @Column(name="status",length=20,nullable=false,updatable=false) private String status;
 @Column(name="created_at",nullable=false,updatable=false) private Instant createdAt;
 @Column(name="created_by",length=200,nullable=false,updatable=false) private String createdBy;
 protected QuotaProfileEntity(){}
 public QuotaProfileEntity(String id,String tenantId,String entitlementId,Instant now,String actor){this.id=id;this.tenantId=tenantId;this.entitlementId=entitlementId;this.profileRevision=1;this.status="ACTIVE";this.createdAt=now;this.createdBy=actor;}
 public String getId(){return id;} public String getTenantId(){return tenantId;} public String getEntitlementId(){return entitlementId;} public int getProfileRevision(){return profileRevision;}
}

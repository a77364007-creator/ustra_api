package com.gsitm.ustra.api.platform.operations.persistence;

import com.gsitm.ustra.api.platform.operations.domain.*;
import jakarta.persistence.*;
import java.time.Instant;

@Entity
@Table(name="operations_recovery_action")
public class OperationsRecoveryActionEntity {
    @Id @Column(name="recovery_action_id",length=36,nullable=false,updatable=false) private String id;
    @Column(name="tenant_id",length=36,nullable=false,updatable=false) private String tenantId;
    @Enumerated(EnumType.STRING) @Column(name="action_type",length=40,nullable=false,updatable=false) private RecoveryActionType actionType;
    @Column(name="target_type",length=40,nullable=false,updatable=false) private String targetType;
    @Column(name="target_id",length=36,nullable=false,updatable=false) private String targetId;
    @Column(name="idempotency_key",length=200,nullable=false,updatable=false) private String idempotencyKey;
    @Column(name="request_fingerprint",length=64,nullable=false,updatable=false) private String requestFingerprint;
    @Column(name="expected_target_version",updatable=false) private Long expectedTargetVersion;
    @Enumerated(EnumType.STRING) @Column(name="action_status",length=30,nullable=false) private RecoveryActionStatus status;
    @Column(name="active_target_key",length=100) private String activeTargetKey;
    @Column(name="integration_operation_id",length=36) private String integrationOperationId;
    @Column(name="safe_result_code",length=120) private String safeResultCode;
    @Column(name="target_status",length=80) private String targetStatus;
    @Column(name="correlation_id",length=100,nullable=false,updatable=false) private String correlationId;
    @Column(name="requested_by",length=200,nullable=false,updatable=false) private String requestedBy;
    @Column(name="requested_at",nullable=false,updatable=false) private Instant requestedAt;
    @Column(name="started_at") private Instant startedAt;
    @Column(name="completed_at") private Instant completedAt;
    @Version @Column(name="row_version",nullable=false) private long rowVersion;
    protected OperationsRecoveryActionEntity() {}
    public OperationsRecoveryActionEntity(String id,String tenantId,String key,RecoveryRequest request,
                                          String actor,String correlationId,Instant now) {
        this.id=id; this.tenantId=tenantId;this.idempotencyKey=key;
        this.actionType=request.actionType();this.targetType=actionType.targetType();this.targetId=request.targetId();
        this.expectedTargetVersion=request.expectedTargetVersion();this.requestFingerprint=request.fingerprint();
        this.activeTargetKey=actionType.activeKey(tenantId,targetId);this.status=RecoveryActionStatus.REQUESTED;
        this.requestedBy=actor;this.correlationId=correlationId;this.requestedAt=now;
    }
    public boolean claim(Instant now) {
        if(status!=RecoveryActionStatus.REQUESTED) return false;
        status=RecoveryActionStatus.IN_PROGRESS;startedAt=now;return true;
    }
    public void complete(RecoveryActionStatus result,String targetStatus,String operationId,String safeCode,Instant now) {
        if(status!=RecoveryActionStatus.IN_PROGRESS || result==RecoveryActionStatus.IN_PROGRESS || result==RecoveryActionStatus.REQUESTED)
            throw new IllegalStateException("RECOVERY_STATE_INVALID");
        status=result;this.targetStatus=targetStatus;this.integrationOperationId=operationId;this.safeResultCode=safeCode;
        if(result==RecoveryActionStatus.SUCCEEDED || result==RecoveryActionStatus.FAILED) {
            activeTargetKey=null;completedAt=now;
        }
        // UNKNOWN retains its claim: no time-based/force-success takeover exists in Stage A.
    }
    public RecoveryRequest request(){return new RecoveryRequest(actionType,targetId,expectedTargetVersion);}
    public String getId(){return id;} public String getTenantId(){return tenantId;}
    public RecoveryActionType getActionType(){return actionType;} public String getTargetType(){return targetType;}
    public String getTargetId(){return targetId;} public String getRequestFingerprint(){return requestFingerprint;}
    public RecoveryActionStatus getStatus(){return status;} public String getActiveTargetKey(){return activeTargetKey;}
    public String getIntegrationOperationId(){return integrationOperationId;} public String getSafeResultCode(){return safeResultCode;}
    public String getTargetStatus(){return targetStatus;} public String getCorrelationId(){return correlationId;}
    public String getRequestedBy(){return requestedBy;} public Instant getRequestedAt(){return requestedAt;}
    public Instant getStartedAt(){return startedAt;} public Instant getCompletedAt(){return completedAt;}
    public long getRowVersion(){return rowVersion;}
}

package com.gsitm.ustra.api.platform.catalog.publication.domain;

public enum AudienceScopeType {
    TENANT,
    ORGANIZATION
}

package com.gsitm.ustra.api.platform.catalog.domain;

public enum ApiVersionState {
    DRAFT,
    VALIDATED,
    RELEASED,
    DEPRECATED,
    RETIRED
}

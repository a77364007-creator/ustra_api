package com.gsitm.ustra.api.platform.tenant.domain;

public enum RoleAssignmentStatus {
    ACTIVE,
    REVOKED,
    EXPIRED
}

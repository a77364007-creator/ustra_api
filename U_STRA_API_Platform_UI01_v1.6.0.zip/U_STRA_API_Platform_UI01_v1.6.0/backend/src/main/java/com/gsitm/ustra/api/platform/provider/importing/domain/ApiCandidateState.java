package com.gsitm.ustra.api.platform.provider.importing.domain;

public enum ApiCandidateState {
    DETECTED,
    ASSESSING,
    ACCEPTED,
    REJECTED,
    PRODUCTIZING,
    COMPLETED
}

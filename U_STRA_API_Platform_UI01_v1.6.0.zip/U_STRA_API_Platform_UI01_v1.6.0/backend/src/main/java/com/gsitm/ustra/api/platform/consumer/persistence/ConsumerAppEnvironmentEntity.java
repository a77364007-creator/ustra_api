package com.gsitm.ustra.api.platform.consumer.persistence;

import com.gsitm.ustra.api.platform.consumer.domain.ConsumerAppEnvironmentType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Version;
import java.time.Instant;

@Entity
@Table(name = "consumer_app_environment")
public class ConsumerAppEnvironmentEntity {
    @Id
    @Column(name = "consumer_app_environment_id", length = 36, nullable = false, updatable = false)
    private String id;
    @Column(name = "tenant_id", length = 36, nullable = false, updatable = false)
    private String tenantId;
    @Column(name = "consumer_app_id", length = 36, nullable = false, updatable = false)
    private String consumerAppId;
    @Enumerated(EnumType.STRING)
    @Column(name = "environment_type", length = 20, nullable = false, updatable = false)
    private ConsumerAppEnvironmentType environmentType;
    @Column(name = "gateway_client_reference", length = 300)
    private String gatewayClientReference;
    @Column(name = "iam_application_reference", length = 300)
    private String iamApplicationReference;
    @Column(name = "authentication_method", length = 100)
    private String authenticationMethod;
    @Version
    @Column(name = "row_version", nullable = false)
    private long rowVersion;
    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;
    @Column(name = "created_by", length = 200, nullable = false, updatable = false)
    private String createdBy;
    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;
    @Column(name = "updated_by", length = 200, nullable = false)
    private String updatedBy;

    protected ConsumerAppEnvironmentEntity() {}

    public ConsumerAppEnvironmentEntity(String id, String tenantId, String consumerAppId,
                                        ConsumerAppEnvironmentType environmentType, String gatewayClientReference,
                                        String iamApplicationReference, String authenticationMethod,
                                        Instant now, String actor) {
        this.id = id;
        this.tenantId = tenantId;
        this.consumerAppId = consumerAppId;
        this.environmentType = environmentType;
        this.gatewayClientReference = gatewayClientReference;
        this.iamApplicationReference = iamApplicationReference;
        this.authenticationMethod = authenticationMethod;
        this.createdAt = now;
        this.createdBy = actor;
        this.updatedAt = now;
        this.updatedBy = actor;
    }

    public void update(String gatewayClientReference, String iamApplicationReference, String authenticationMethod,
                       Instant now, String actor) {
        this.gatewayClientReference = gatewayClientReference;
        this.iamApplicationReference = iamApplicationReference;
        this.authenticationMethod = authenticationMethod;
        this.updatedAt = now;
        this.updatedBy = actor;
    }

    public String getId() { return id; }
    public String getTenantId() { return tenantId; }
    public String getConsumerAppId() { return consumerAppId; }
    public ConsumerAppEnvironmentType getEnvironmentType() { return environmentType; }
    public String getGatewayClientReference() { return gatewayClientReference; }
    public String getIamApplicationReference() { return iamApplicationReference; }
    public String getAuthenticationMethod() { return authenticationMethod; }
    public long getRowVersion() { return rowVersion; }
    public Instant getCreatedAt() { return createdAt; }
    public String getCreatedBy() { return createdBy; }
    public Instant getUpdatedAt() { return updatedAt; }
    public String getUpdatedBy() { return updatedBy; }
}

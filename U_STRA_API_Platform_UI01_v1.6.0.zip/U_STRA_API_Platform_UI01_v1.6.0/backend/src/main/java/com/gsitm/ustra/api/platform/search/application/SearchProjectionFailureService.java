package com.gsitm.ustra.api.platform.search.application;

import com.gsitm.ustra.api.platform.common.error.*;
import com.gsitm.ustra.api.platform.search.persistence.*;
import com.gsitm.ustra.api.platform.tenant.persistence.TenantRepository;
import java.time.*;
import java.util.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.*;

@Service
public class SearchProjectionFailureService {
    private final SearchProjectionFailureRepository failures;
    private final TenantRepository tenants;
    private final Clock clock;
    public SearchProjectionFailureService(SearchProjectionFailureRepository failures,TenantRepository tenants,Clock clock) {
        this.failures=failures;this.tenants=tenants;this.clock=clock;
    }
    private void lock(String tenantId) {
        tenants.lockById(tenantId).orElseThrow(()->new BusinessException(ErrorCode.TENANT_NOT_FOUND,HttpStatus.NOT_FOUND,"Tenant를 찾을 수 없습니다."));
    }
    @Transactional(propagation=Propagation.REQUIRES_NEW)
    public void observe(String tenantId,String productId) {
        // A separate transaction; lock serializes upsert even on a previously unobserved Product.
        lock(tenantId);Instant now=Instant.now(clock);
        var current=failures.findByTenantIdAndApiProductId(tenantId,productId);
        var row=current.orElseGet(()->new SearchProjectionFailureEntity(UUID.randomUUID().toString(),tenantId,productId,now));
        if(current.isPresent()) row.observe(now);
        failures.saveAndFlush(row);
    }
    @Transactional(readOnly=true,propagation=Propagation.REQUIRES_NEW)
    public Long openVersion(String tenantId,String productId) {
        return failures.findByTenantIdAndApiProductId(tenantId,productId).filter(i->"OPEN".equals(i.getStatus()))
                .map(SearchProjectionFailureEntity::getRowVersion).orElse(null);
    }
    @Transactional(readOnly=true,propagation=Propagation.REQUIRES_NEW)
    public Map<String,Long> openVersions(String tenantId) {
        Map<String,Long> versions=new HashMap<>();
        failures.findAllByTenantIdAndStatus(tenantId,"OPEN").forEach(f->versions.put(f.getApiProductId(),f.getRowVersion()));
        return Map.copyOf(versions);
    }
    @Transactional(propagation=Propagation.REQUIRES_NEW)
    public boolean resolve(String tenantId,String productId,Long expectedVersion) {
        if(expectedVersion==null) return false;
        lock(tenantId);
        var row=failures.findByTenantIdAndApiProductId(tenantId,productId);
        if(row.isEmpty()||!row.get().resolveIfVersion(expectedVersion,Instant.now(clock))) return false;
        failures.saveAndFlush(row.get());return true;
    }
}

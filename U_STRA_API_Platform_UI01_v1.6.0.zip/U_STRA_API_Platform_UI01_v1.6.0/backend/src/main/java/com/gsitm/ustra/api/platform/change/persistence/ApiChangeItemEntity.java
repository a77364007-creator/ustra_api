package com.gsitm.ustra.api.platform.change.persistence;
import com.gsitm.ustra.api.platform.change.domain.ApiChangeItemEffect;
import com.gsitm.ustra.api.platform.change.domain.ApiChangeKind;
import jakarta.persistence.*;
import java.time.Instant;
@Entity @Table(name="api_change_item")
public class ApiChangeItemEntity {
 @Id @Column(name="api_change_item_id",length=36,nullable=false,updatable=false) private String id;
 @Column(name="tenant_id",length=36,nullable=false,updatable=false) private String tenantId;
 @Column(name="api_change_id",length=36,nullable=false,updatable=false) private String apiChangeId;
 @Enumerated(EnumType.STRING) @Column(name="change_kind",length=50,nullable=false,updatable=false) private ApiChangeKind changeKind;
 @Column(name="method",length=20,updatable=false) private String method;
 @Column(name="normalized_path",length=1000,updatable=false) private String normalizedPath;
 @Column(name="contract_location",length=100,updatable=false) private String contractLocation;
 @Column(name="baseline_fingerprint",length=80,updatable=false) private String baselineFingerprint;
 @Column(name="target_fingerprint",length=80,updatable=false) private String targetFingerprint;
 @Enumerated(EnumType.STRING) @Column(name="compatibility_effect",length=30,nullable=false,updatable=false) private ApiChangeItemEffect compatibilityEffect;
 @Column(name="evidence_code",length=100,nullable=false,updatable=false) private String evidenceCode;
 @Column(name="created_at",nullable=false,updatable=false) private Instant createdAt;
 @Column(name="created_by",length=200,nullable=false,updatable=false) private String createdBy;
 protected ApiChangeItemEntity(){}
 public ApiChangeItemEntity(String id,String tenantId,String apiChangeId,ApiChangeKind changeKind,String method,String normalizedPath,String contractLocation,String baselineFingerprint,String targetFingerprint,ApiChangeItemEffect compatibilityEffect,String evidenceCode,Instant now,String actor){this.id=id;this.tenantId=tenantId;this.apiChangeId=apiChangeId;this.changeKind=changeKind;this.method=method;this.normalizedPath=normalizedPath;this.contractLocation=contractLocation;this.baselineFingerprint=baselineFingerprint;this.targetFingerprint=targetFingerprint;this.compatibilityEffect=compatibilityEffect;this.evidenceCode=evidenceCode;this.createdAt=now;this.createdBy=actor;}
 public String getId(){return id;} public String getTenantId(){return tenantId;} public String getApiChangeId(){return apiChangeId;} public ApiChangeKind getChangeKind(){return changeKind;} public String getMethod(){return method;} public String getNormalizedPath(){return normalizedPath;} public String getContractLocation(){return contractLocation;} public String getBaselineFingerprint(){return baselineFingerprint;} public String getTargetFingerprint(){return targetFingerprint;} public ApiChangeItemEffect getCompatibilityEffect(){return compatibilityEffect;} public String getEvidenceCode(){return evidenceCode;} public Instant getCreatedAt(){return createdAt;} public String getCreatedBy(){return createdBy;}
}

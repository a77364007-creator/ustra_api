package com.gsitm.ustra.api.platform.tenant.context;

import com.gsitm.ustra.api.platform.common.context.RequestContext;
import com.gsitm.ustra.api.platform.common.context.RequestContextHolder;
import com.gsitm.ustra.api.platform.common.error.BusinessException;
import com.gsitm.ustra.api.platform.common.error.ErrorCode;
import com.gsitm.ustra.api.platform.security.AuthenticatedIdentity;
import com.gsitm.ustra.api.platform.security.AuthenticatedIdentityProvider;
import com.gsitm.ustra.api.platform.tenant.domain.RoleAssignmentStatus;
import com.gsitm.ustra.api.platform.tenant.domain.TenantStatus;
import com.gsitm.ustra.api.platform.tenant.persistence.MembershipEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.MembershipRepository;
import com.gsitm.ustra.api.platform.tenant.persistence.RoleAssignmentEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.RoleAssignmentRepository;
import com.gsitm.ustra.api.platform.tenant.persistence.RoleEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.RoleRepository;
import com.gsitm.ustra.api.platform.tenant.persistence.TenantEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.TenantRepository;
import java.time.Clock;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
public class TenantContextResolver {
    private final AuthenticatedIdentityProvider identityProvider;
    private final MembershipRepository membershipRepository;
    private final TenantRepository tenantRepository;
    private final RoleAssignmentRepository roleAssignmentRepository;
    private final RoleRepository roleRepository;
    private final Clock clock;

    public TenantContextResolver(AuthenticatedIdentityProvider identityProvider,
                                 MembershipRepository membershipRepository,
                                 TenantRepository tenantRepository,
                                 RoleAssignmentRepository roleAssignmentRepository,
                                 RoleRepository roleRepository,
                                 Clock clock) {
        this.identityProvider = identityProvider;
        this.membershipRepository = membershipRepository;
        this.tenantRepository = tenantRepository;
        this.roleAssignmentRepository = roleAssignmentRepository;
        this.roleRepository = roleRepository;
        this.clock = clock;
    }

    @Transactional(readOnly = true)
    public TenantContext resolve() {
        Instant now = Instant.now(clock);
        AuthenticatedIdentity identity = identityProvider.current();
        List<MembershipEntity> allMemberships = membershipRepository.findAllByPrincipalIdAndIssuer(
                identity.principalId(), identity.issuer());
        if (allMemberships.isEmpty()) {
            throw new BusinessException(ErrorCode.MEMBERSHIP_NOT_FOUND, HttpStatus.FORBIDDEN,
                    "현재 사용자에게 Tenant Membership이 없습니다.");
        }

        List<MembershipEntity> memberships = allMemberships.stream()
                .filter(membership -> membership.isEffectiveAt(now))
                .toList();
        if (memberships.isEmpty()) {
            throw new BusinessException(ErrorCode.MEMBERSHIP_NOT_ACTIVE, HttpStatus.FORBIDDEN,
                    "현재 사용자에게 유효한 Tenant Membership이 없습니다.");
        }
        if (memberships.size() != 1) {
            throw new BusinessException(ErrorCode.TENANT_CONTEXT_REQUIRED, HttpStatus.FORBIDDEN,
                    "현재 사용자의 Tenant Context를 하나로 결정할 수 없습니다.");
        }

        MembershipEntity membership = memberships.getFirst();

        TenantEntity tenant = tenantRepository.findById(membership.getTenantId())
                .orElseThrow(() -> new BusinessException(ErrorCode.TENANT_NOT_FOUND, HttpStatus.FORBIDDEN,
                        "Tenant Context를 확인할 수 없습니다."));
        if (tenant.getStatus() != TenantStatus.ACTIVE) {
            throw new BusinessException(ErrorCode.TENANT_NOT_ACTIVE, HttpStatus.FORBIDDEN,
                    "Tenant가 활성 상태가 아닙니다.");
        }

        List<RoleAssignmentEntity> assignments = roleAssignmentRepository.findEffectiveAssignments(
                tenant.getId(), membership.getId(), RoleAssignmentStatus.ACTIVE, now);
        Set<String> roleIds = assignments.stream().map(RoleAssignmentEntity::getRoleId).collect(Collectors.toSet());
        Map<String, RoleEntity> rolesById = roleRepository.findByIdIn(roleIds).stream()
                .collect(Collectors.toMap(RoleEntity::getId, Function.identity()));
        Set<String> roleCodes = roleIds.stream()
                .map(rolesById::get)
                .filter(role -> role != null)
                .map(RoleEntity::getCode)
                .collect(Collectors.toUnmodifiableSet());

        RequestContext request = RequestContextHolder.required();
        return new TenantContext(
                tenant.getId(), tenant.getCode(), tenant.getCustomerId(), membership.getOrganizationId(),
                identity.principalId(), membership.getId(), roleCodes, tenant.getDefaultLocale(),
                request.requestId(), request.correlationId());
    }
}

package com.gsitm.ustra.api.platform.change.application;

import com.gsitm.ustra.api.platform.audit.AuditService;
import com.gsitm.ustra.api.platform.catalog.domain.ApiVersionState;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiVersionEntity;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiVersionRepository;
import com.gsitm.ustra.api.platform.catalog.publication.application.StateTransitionHistoryService;
import com.gsitm.ustra.api.platform.common.error.BusinessException;
import com.gsitm.ustra.api.platform.common.error.ErrorCode;
import com.gsitm.ustra.api.platform.outbox.OutboxService;
import com.gsitm.ustra.api.platform.tenant.application.TenantPermissionGuard;
import com.gsitm.ustra.api.platform.tenant.context.TenantContext;
import com.gsitm.ustra.api.platform.tenant.context.TenantContextResolver;
import java.time.Clock;
import java.time.Instant;
import java.util.Map;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ApiVersionLifecycleService {
    private final TenantContextResolver contextResolver;
    private final TenantPermissionGuard permissionGuard;
    private final ApiVersionRepository versionRepository;
    private final StateTransitionHistoryService historyService;
    private final AuditService auditService;
    private final OutboxService outboxService;
    private final Clock clock;

    public ApiVersionLifecycleService(
            TenantContextResolver contextResolver,
            TenantPermissionGuard permissionGuard,
            ApiVersionRepository versionRepository,
            StateTransitionHistoryService historyService,
            AuditService auditService,
            OutboxService outboxService,
            Clock clock) {
        this.contextResolver=contextResolver;this.permissionGuard=permissionGuard;this.versionRepository=versionRepository;
        this.historyService=historyService;this.auditService=auditService;this.outboxService=outboxService;this.clock=clock;
    }

    @Transactional
    public ApiVersionEntity deprecate(String id,long expectedVersion){
        TenantContext context=contextResolver.resolve();
        permissionGuard.require(context,"API_VERSION:DEPRECATE","API_VERSION",id);
        ApiVersionEntity entity=versionRepository.findByIdAndTenantId(id,context.tenantId())
                .orElseThrow(()->new BusinessException(ErrorCode.API_VERSION_NOT_FOUND,HttpStatus.NOT_FOUND,"API Version을 찾을 수 없습니다."));
        if(entity.getState()==ApiVersionState.DEPRECATED)return entity;
        if(entity.getRowVersion()!=expectedVersion){throw new BusinessException(ErrorCode.CONCURRENT_MODIFICATION,HttpStatus.CONFLICT,"API Version이 다른 요청에 의해 변경되었습니다.");}
        if(entity.getState()!=ApiVersionState.RELEASED){throw new BusinessException(ErrorCode.API_VERSION_STATE_INVALID,HttpStatus.CONFLICT,"RELEASED API Version만 명시적으로 Deprecated 처리할 수 있습니다.");}
        String from=entity.getState().name(); Instant now=Instant.now(clock);
        entity.deprecate(now,context.principalId()); entity=versionRepository.saveAndFlush(entity);
        historyService.record(context.tenantId(),"API_VERSION",entity.getId(),from,entity.getState().name());
        auditService.success(context.tenantId(),"API_VERSION_DEPRECATED","API_VERSION",entity.getId(),true,Map.of("fromState",from,"toState",entity.getState().name()));
        outboxService.enqueue("APIVersionDeprecated","API_VERSION",entity.getId(),context.tenantId(),Map.of("apiVersionId",entity.getId(),"apiId",entity.getApiId(),"version",entity.getVersionValue()));
        return entity;
    }
}

package com.gsitm.ustra.api.platform.tenant.persistence;

import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = "role_permission")
public class RolePermissionEntity {
    @EmbeddedId
    private RolePermissionId id;

    protected RolePermissionEntity() {
    }

    public RolePermissionId getId() { return id; }
}

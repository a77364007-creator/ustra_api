package com.gsitm.ustra.api.platform.search.persistence;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.Instant;

@Entity
@Table(name = "catalog_search_visibility")
public class CatalogSearchVisibilityEntity {
    @Id @Column(name = "search_visibility_id", length = 36, nullable = false, updatable = false)
    private String id;
    @Column(name = "tenant_id", length = 36, nullable = false, updatable = false)
    private String tenantId;
    @Column(name = "api_product_id", length = 36, nullable = false, updatable = false)
    private String apiProductId;
    @Column(name = "catalog_publication_id", length = 36, nullable = false, updatable = false)
    private String catalogPublicationId;
    @Column(name = "api_product_version_id", length = 36, nullable = false, updatable = false)
    private String apiProductVersionId;
    @Column(name = "version_value", length = 100, nullable = false)
    private String versionValue;
    @Column(name = "publication_state", length = 30, nullable = false)
    private String publicationState;
    @Column(name = "product_version_state", length = 30, nullable = false)
    private String productVersionState;
    @Column(name = "audience_scope_type", length = 30, nullable = false)
    private String audienceScopeType;
    @Column(name = "organization_id", length = 36)
    private String organizationId;
    @Column(name = "source_publication_row_version", nullable = false)
    private long sourcePublicationRowVersion;
    @Column(name = "source_product_version_row_version", nullable = false)
    private long sourceProductVersionRowVersion;
    @Column(name = "projection_hash", length = 64, nullable = false)
    private String projectionHash;
    @Column(name = "projected_at", nullable = false)
    private Instant projectedAt;

    protected CatalogSearchVisibilityEntity() {}

    public CatalogSearchVisibilityEntity(String id, String tenantId, String apiProductId,
                                         String catalogPublicationId, String apiProductVersionId, String versionValue,
                                         String publicationState, String productVersionState, String audienceScopeType,
                                         String organizationId, long sourcePublicationRowVersion,
                                         long sourceProductVersionRowVersion, String projectionHash, Instant projectedAt) {
        this.id=id; this.tenantId=tenantId; this.apiProductId=apiProductId;
        this.catalogPublicationId=catalogPublicationId; this.apiProductVersionId=apiProductVersionId;
        this.versionValue=versionValue; this.publicationState=publicationState;
        this.productVersionState=productVersionState; this.audienceScopeType=audienceScopeType;
        this.organizationId=organizationId; this.sourcePublicationRowVersion=sourcePublicationRowVersion;
        this.sourceProductVersionRowVersion=sourceProductVersionRowVersion;
        this.projectionHash=projectionHash; this.projectedAt=projectedAt;
    }

    public String getId(){return id;} public String getTenantId(){return tenantId;}
    public String getApiProductId(){return apiProductId;} public String getCatalogPublicationId(){return catalogPublicationId;}
    public String getApiProductVersionId(){return apiProductVersionId;} public String getVersionValue(){return versionValue;}
    public String getPublicationState(){return publicationState;} public String getProductVersionState(){return productVersionState;}
    public String getAudienceScopeType(){return audienceScopeType;} public String getOrganizationId(){return organizationId;}
    public long getSourcePublicationRowVersion(){return sourcePublicationRowVersion;}
    public long getSourceProductVersionRowVersion(){return sourceProductVersionRowVersion;}
    public String getProjectionHash(){return projectionHash;} public Instant getProjectedAt(){return projectedAt;}
}

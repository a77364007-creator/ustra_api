package com.gsitm.ustra.api.platform.integration.approval.application;
import com.gsitm.ustra.api.platform.common.error.*; import com.gsitm.ustra.api.platform.subscription.approval.application.ApprovalPort; import java.util.*; import org.springframework.http.HttpStatus; import org.springframework.stereotype.Component;
@Component public class ApprovalConnectorRegistry {
 private final Map<String,ApprovalPort> ports;
 public ApprovalConnectorRegistry(List<ApprovalConnectorRegistration> registrations){Map<String,ApprovalPort> m=new HashMap<>();for(var r:registrations){String code=normalize(r.adapterCode());if(m.putIfAbsent(code,r.port())!=null)throw new IllegalStateException("Duplicate approval connector adapter code: "+code);}this.ports=Map.copyOf(m);}
 public ApprovalPort resolve(String adapterCode){ApprovalPort port=ports.get(normalize(adapterCode));if(port==null)throw new BusinessException(ErrorCode.INTEGRATION_CONNECTOR_UNAVAILABLE,HttpStatus.CONFLICT,"활성화된 Approval connector adapter를 사용할 수 없습니다.");return port;}
 private String normalize(String v){return v==null?"":v.trim().toUpperCase(Locale.ROOT);}
}

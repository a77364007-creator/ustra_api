package com.gsitm.ustra.api.platform.catalog.api;

import com.gsitm.ustra.api.platform.catalog.application.ApiProductService;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiProductEntity;
import com.gsitm.ustra.api.platform.tenant.api.VersionHeaderParser;
import jakarta.validation.Valid;
import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import java.time.Instant;
import java.util.List;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/api-products")
public class ApiProductController {
    private final ApiProductService service;

    public ApiProductController(ApiProductService service) {
        this.service = service;
    }

    @GetMapping
    public List<ApiProductResponse> list() {
        return service.list().stream().map(ApiProductResponse::from).toList();
    }

    @GetMapping("/{apiProductId}")
    public ResponseEntity<ApiProductResponse> get(@PathVariable String apiProductId) {
        ApiProductEntity entity = service.get(apiProductId);
        return ResponseEntity.ok().eTag(VersionHeaderParser.etag(entity.getRowVersion()))
                .body(ApiProductResponse.from(entity));
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<ApiProductResponse> create(@Valid @RequestBody CreateApiProductRequest request) {
        ApiProductEntity entity = service.create(request.productCode(), request.name(), request.description(),
                request.providerId(), request.ownerMembershipId());
        return ResponseEntity.status(HttpStatus.CREATED).eTag(VersionHeaderParser.etag(entity.getRowVersion()))
                .body(ApiProductResponse.from(entity));
    }

    @PatchMapping("/{apiProductId}")
    public ResponseEntity<ApiProductResponse> update(
            @PathVariable String apiProductId,
            @RequestHeader(value = HttpHeaders.IF_MATCH, required = false) String ifMatch,
            @Valid @RequestBody UpdateApiProductRequest request) {
        ApiProductEntity entity = service.update(apiProductId, VersionHeaderParser.parse(ifMatch),
                request.name(), request.description(), request.providerId(), request.ownerMembershipId());
        return ResponseEntity.ok().eTag(VersionHeaderParser.etag(entity.getRowVersion()))
                .body(ApiProductResponse.from(entity));
    }

    public record CreateApiProductRequest(
            @NotBlank @Size(max = 100) String productCode,
            @NotBlank @Size(max = 200) String name,
            @Size(max = 4000) String description,
            String providerId,
            String ownerMembershipId) {
    }

    public record UpdateApiProductRequest(
            @NotBlank @Size(max = 200) String name,
            @Size(max = 4000) String description,
            String providerId,
            String ownerMembershipId,
            String productCode,
            String tenantId,
            String lifecycleState,
            Long revision) {

        @AssertTrue(message = "productCode, tenantId, lifecycleState, revision은 PATCH로 변경할 수 없습니다.")
        public boolean isImmutableFieldMutationAbsent() {
            return productCode == null && tenantId == null && lifecycleState == null && revision == null;
        }
    }

    public record ApiProductResponse(
            String apiProductId,
            String productCode,
            String name,
            String description,
            String providerId,
            String ownerMembershipId,
            String lifecycleState,
            long revision,
            Instant createdAt,
            String createdBy,
            Instant updatedAt,
            String updatedBy) {

        static ApiProductResponse from(ApiProductEntity entity) {
            return new ApiProductResponse(entity.getId(), entity.getProductCode(), entity.getName(),
                    entity.getDescription(), entity.getProviderId(), entity.getOwnerMembershipId(),
                    entity.getLifecycleState().name(), entity.getRowVersion(), entity.getCreatedAt(),
                    entity.getCreatedBy(), entity.getUpdatedAt(), entity.getUpdatedBy());
        }
    }
}

package com.gsitm.ustra.api.platform.catalog.persistence;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ApiVersionRepository extends JpaRepository<ApiVersionEntity, String> {
    Optional<ApiVersionEntity> findByIdAndTenantId(String id, String tenantId);
    Optional<ApiVersionEntity> findByTenantIdAndApiIdAndVersionValue(String tenantId, String apiId, String versionValue);
}

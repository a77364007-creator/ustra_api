package com.gsitm.ustra.api.platform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class UstraApiPlatformApplication {
    public static void main(String[] args) {
        SpringApplication.run(UstraApiPlatformApplication.class, args);
    }
}

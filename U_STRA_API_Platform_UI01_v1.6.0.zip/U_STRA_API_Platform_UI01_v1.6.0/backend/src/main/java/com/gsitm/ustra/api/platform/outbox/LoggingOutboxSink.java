package com.gsitm.ustra.api.platform.outbox;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@org.springframework.context.annotation.Profile("!prod & (local | test | mock-integration)")
@Component
public class LoggingOutboxSink implements OutboxSink {
    private static final Logger log = LoggerFactory.getLogger(LoggingOutboxSink.class);

    @Override
    public void publish(OutboxMessage event) {
        log.info("Outbox event dispatched eventId={} eventType={} aggregateType={} aggregateId={}",
                event.eventId(), event.eventType(), event.aggregateType(), event.aggregateId());
    }
}

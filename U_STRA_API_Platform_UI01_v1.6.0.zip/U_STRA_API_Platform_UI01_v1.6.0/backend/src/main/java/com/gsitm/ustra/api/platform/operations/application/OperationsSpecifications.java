package com.gsitm.ustra.api.platform.operations.application;

import com.gsitm.ustra.api.platform.integration.approval.domain.*;
import com.gsitm.ustra.api.platform.integration.approval.persistence.*;
import java.time.Instant;
import java.util.*;
import org.springframework.data.jpa.domain.Specification;

/** All count and row predicates use the same server-resolved Tenant and authorized source type. */
public final class OperationsSpecifications {
    private OperationsSpecifications() {}
    public static <T> Specification<T> tenant(String tenantId) {
        return (root,query,cb)->cb.equal(root.get("tenantId"),tenantId);
    }
    public static <T> Specification<T> window(String field,OperationsQueryLimits.Window window) {
        return (root,query,cb)->cb.and(cb.greaterThanOrEqualTo(root.<Instant>get(field),window.from()),
                cb.lessThan(root.<Instant>get(field),window.to()));
    }
    public static <T> Specification<T> eq(String field,Object value) {
        return (root,query,cb)->value==null?cb.conjunction():cb.equal(root.get(field),value);
    }
    public static Set<IntegrationOperationType> types(IntegrationType type) {
        return type==IntegrationType.APPROVAL_ITSM?EnumSet.of(IntegrationOperationType.APPROVAL_CASE_CREATE,IntegrationOperationType.APPROVAL_STATUS_QUERY)
                :EnumSet.of(IntegrationOperationType.GATEWAY_PROVISION,IntegrationOperationType.GATEWAY_DEPROVISION,IntegrationOperationType.GATEWAY_STATUS_QUERY);
    }
    public static Specification<IntegrationOperationEntity> operations(String tenantId,IntegrationType type) {
        return OperationsSpecifications.<IntegrationOperationEntity>tenant(tenantId)
                .and((root,query,cb)->root.get("operationType").in(types(type)));
    }
    public static Specification<ReconciliationIssueEntity> issues(String tenantId,IntegrationType type) {
        return OperationsSpecifications.<ReconciliationIssueEntity>tenant(tenantId).and((root,query,cb)->{
            var sub=query.subquery(String.class);var op=sub.from(IntegrationOperationEntity.class);
            sub.select(op.get("id")).where(cb.equal(op.get("tenantId"),tenantId),
                    cb.equal(op.get("id"),root.get("integrationOperationId")),op.get("operationType").in(types(type)));
            return cb.exists(sub);
        });
    }
    public static Specification<ConnectorInstanceEntity> connectors(String tenantId,IntegrationType type) {
        return OperationsSpecifications.<ConnectorInstanceEntity>tenant(tenantId).and((root,query,cb)->{
            var sub=query.subquery(String.class);var profile=sub.from(IntegrationProfileEntity.class);
            sub.select(profile.get("id")).where(cb.equal(profile.get("tenantId"),tenantId),
                    cb.equal(profile.get("id"),root.get("integrationProfileId")),cb.equal(profile.get("integrationType"),type));
            return cb.exists(sub);
        });
    }
}

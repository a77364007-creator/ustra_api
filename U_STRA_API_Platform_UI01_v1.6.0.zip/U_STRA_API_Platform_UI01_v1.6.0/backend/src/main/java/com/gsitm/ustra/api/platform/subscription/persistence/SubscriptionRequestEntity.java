package com.gsitm.ustra.api.platform.subscription.persistence;

import com.gsitm.ustra.api.platform.subscription.domain.SubscriptionRequestStatus;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Version;
import java.time.Instant;

@Entity
@Table(name = "subscription_request")
public class SubscriptionRequestEntity {
    @Id
    @Column(name = "subscription_request_id", length = 36, nullable = false, updatable = false)
    private String id;
    @Column(name = "tenant_id", length = 36, nullable = false, updatable = false)
    private String tenantId;
    @Column(name = "consumer_app_environment_id", length = 36, nullable = false, updatable = false)
    private String consumerAppEnvironmentId;
    @Column(name = "catalog_publication_id", length = 36, nullable = false, updatable = false)
    private String catalogPublicationId;
    @Column(name = "api_product_version_id", length = 36, nullable = false, updatable = false)
    private String apiProductVersionId;
    @Column(name = "requester_membership_id", length = 36, nullable = false, updatable = false)
    private String requesterMembershipId;
    @Enumerated(EnumType.STRING)
    @Column(name = "status", length = 30, nullable = false)
    private SubscriptionRequestStatus status;
    @Column(name = "current_revision_no", nullable = false)
    private int currentRevisionNo;
    @Version
    @Column(name = "row_version", nullable = false)
    private long rowVersion;
    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;
    @Column(name = "created_by", length = 200, nullable = false, updatable = false)
    private String createdBy;
    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;
    @Column(name = "updated_by", length = 200, nullable = false)
    private String updatedBy;

    protected SubscriptionRequestEntity() {}

    public SubscriptionRequestEntity(String id, String tenantId, String consumerAppEnvironmentId,
                                     String catalogPublicationId, String apiProductVersionId,
                                     String requesterMembershipId, Instant now, String actor) {
        this.id = id;
        this.tenantId = tenantId;
        this.consumerAppEnvironmentId = consumerAppEnvironmentId;
        this.catalogPublicationId = catalogPublicationId;
        this.apiProductVersionId = apiProductVersionId;
        this.requesterMembershipId = requesterMembershipId;
        this.status = SubscriptionRequestStatus.SUBMITTED;
        this.currentRevisionNo = 1;
        this.createdAt = now;
        this.createdBy = actor;
        this.updatedAt = now;
        this.updatedBy = actor;
    }

    public void cancel(Instant now, String actor) { transition(SubscriptionRequestStatus.CANCELLED, now, actor); }
    public void beginValidation(Instant now,String actor){transition(SubscriptionRequestStatus.VALIDATING,now,actor);}
    public void pendingApproval(Instant now,String actor){transition(SubscriptionRequestStatus.PENDING_APPROVAL,now,actor);}
    public void approve(Instant now,String actor){transition(SubscriptionRequestStatus.APPROVED,now,actor);}
    public void reject(Instant now,String actor){transition(SubscriptionRequestStatus.REJECTED,now,actor);}
    public void complete(Instant now,String actor){transition(SubscriptionRequestStatus.COMPLETED,now,actor);}
    private void transition(SubscriptionRequestStatus next,Instant now,String actor){this.status=next;this.updatedAt=now;this.updatedBy=actor;}

    public String getId() { return id; }
    public String getTenantId() { return tenantId; }
    public String getConsumerAppEnvironmentId() { return consumerAppEnvironmentId; }
    public String getCatalogPublicationId() { return catalogPublicationId; }
    public String getApiProductVersionId() { return apiProductVersionId; }
    public String getRequesterMembershipId() { return requesterMembershipId; }
    public SubscriptionRequestStatus getStatus() { return status; }
    public int getCurrentRevisionNo() { return currentRevisionNo; }
    public long getRowVersion() { return rowVersion; }
    public Instant getCreatedAt() { return createdAt; }
    public String getCreatedBy() { return createdBy; }
    public Instant getUpdatedAt() { return updatedAt; }
    public String getUpdatedBy() { return updatedBy; }
}

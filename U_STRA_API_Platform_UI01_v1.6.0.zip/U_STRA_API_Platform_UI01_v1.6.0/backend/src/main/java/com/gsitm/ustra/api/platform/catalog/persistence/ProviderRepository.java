package com.gsitm.ustra.api.platform.catalog.persistence;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProviderRepository extends JpaRepository<ProviderEntity, String> {
    Optional<ProviderEntity> findByIdAndTenantId(String id, String tenantId);
}

package com.gsitm.ustra.api.platform.catalog.domain;

public enum ApiProductLifecycleState {
    DRAFT,
    REVIEWING,
    ACTIVE,
    DEPRECATED,
    RETIRED
}

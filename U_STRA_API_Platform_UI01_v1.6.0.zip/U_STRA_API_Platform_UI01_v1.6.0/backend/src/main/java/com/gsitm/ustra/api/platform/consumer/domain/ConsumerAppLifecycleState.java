package com.gsitm.ustra.api.platform.consumer.domain;

public enum ConsumerAppLifecycleState {
    DRAFT, ACTIVE, SUSPENDED, RETIRED
}

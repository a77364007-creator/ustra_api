package com.gsitm.ustra.api.platform.provider.importing.application;
import java.nio.charset.StandardCharsets; import java.security.MessageDigest; import java.security.NoSuchAlgorithmException; import java.util.HexFormat; import org.springframework.stereotype.Component;
@Component public class Sha256Service { public String hash(byte[] bytes){ try{return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes));}catch(NoSuchAlgorithmException e){throw new IllegalStateException(e);} } public String hashText(String text){return hash(text.getBytes(StandardCharsets.UTF_8));} }

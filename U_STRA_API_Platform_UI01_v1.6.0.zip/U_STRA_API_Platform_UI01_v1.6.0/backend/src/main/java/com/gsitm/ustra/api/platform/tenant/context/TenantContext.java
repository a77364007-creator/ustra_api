package com.gsitm.ustra.api.platform.tenant.context;

import java.util.Set;

public record TenantContext(
        String tenantId,
        String tenantCode,
        String customerId,
        String organizationId,
        String principalId,
        String membershipId,
        Set<String> roles,
        String locale,
        String requestId,
        String correlationId) {
}

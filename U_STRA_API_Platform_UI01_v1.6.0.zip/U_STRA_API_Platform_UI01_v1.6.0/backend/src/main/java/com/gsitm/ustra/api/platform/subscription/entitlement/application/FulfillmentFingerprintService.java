package com.gsitm.ustra.api.platform.subscription.entitlement.application;
import java.nio.charset.StandardCharsets; import java.security.MessageDigest; import java.security.NoSuchAlgorithmException; import org.springframework.stereotype.Component;
@Component public class FulfillmentFingerprintService {
 public String fingerprint(String tenantId,String entitlementId,String type,int revision){return sha256(String.join("|",tenantId,entitlementId,type,Integer.toString(revision)));}
 private String sha256(String value){try{byte[] d=MessageDigest.getInstance("SHA-256").digest(value.getBytes(StandardCharsets.UTF_8));StringBuilder b=new StringBuilder();for(byte x:d)b.append(String.format("%02x",x));return b.toString();}catch(NoSuchAlgorithmException e){throw new IllegalStateException(e);}}
}

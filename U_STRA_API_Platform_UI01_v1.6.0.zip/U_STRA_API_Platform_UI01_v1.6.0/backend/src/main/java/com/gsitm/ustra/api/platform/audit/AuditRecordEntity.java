package com.gsitm.ustra.api.platform.audit;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.Instant;

@Entity
@Table(name = "audit_record")
public class AuditRecordEntity {
    @Id
    @Column(name = "audit_id", length = 36, nullable = false, updatable = false)
    private String id;

    @Column(name = "tenant_id", length = 36)
    private String tenantId;

    @Column(name = "occurred_at", nullable = false, updatable = false)
    private Instant occurredAt;

    @Column(name = "actor_principal_id", length = 200, nullable = false, updatable = false)
    private String actorPrincipalId;

    @Column(name = "actor_type", length = 40, nullable = false, updatable = false)
    private String actorType;

    @Column(name = "action", length = 120, nullable = false, updatable = false)
    private String action;

    @Column(name = "resource_type", length = 80, nullable = false, updatable = false)
    private String resourceType;

    @Column(name = "resource_id", length = 200, nullable = false, updatable = false)
    private String resourceId;

    @Column(name = "outcome", length = 40, nullable = false, updatable = false)
    private String outcome;

    @Column(name = "reason_code", length = 120, updatable = false)
    private String reasonCode;

    @Column(name = "correlation_id", length = 100, nullable = false, updatable = false)
    private String correlationId;

    @Column(name = "privileged_flag", nullable = false, updatable = false)
    private boolean privileged;

    @Column(name = "safe_diff", columnDefinition = "LONGTEXT", updatable = false)
    private String safeDiff;

    @Column(name = "before_hash", length = 128, updatable = false)
    private String beforeHash;

    @Column(name = "after_hash", length = 128, updatable = false)
    private String afterHash;

    protected AuditRecordEntity() {
    }

    public AuditRecordEntity(String id, String tenantId, Instant occurredAt, String actorPrincipalId,
                             String actorType, String action, String resourceType, String resourceId,
                             String outcome, String reasonCode, String correlationId, boolean privileged,
                             String safeDiff, String beforeHash, String afterHash) {
        this.id = id;
        this.tenantId = tenantId;
        this.occurredAt = occurredAt;
        this.actorPrincipalId = actorPrincipalId;
        this.actorType = actorType;
        this.action = action;
        this.resourceType = resourceType;
        this.resourceId = resourceId;
        this.outcome = outcome;
        this.reasonCode = reasonCode;
        this.correlationId = correlationId;
        this.privileged = privileged;
        this.safeDiff = safeDiff;
        this.beforeHash = beforeHash;
        this.afterHash = afterHash;
    }

    public String getId() { return id; }
    public String getTenantId() { return tenantId; }
    public Instant getOccurredAt() { return occurredAt; }
    public String getActorPrincipalId() { return actorPrincipalId; }
    public String getAction() { return action; }
    public String getResourceType() { return resourceType; }
    public String getResourceId() { return resourceId; }
    public String getOutcome() { return outcome; }
    public String getReasonCode() { return reasonCode; }
    public String getCorrelationId() { return correlationId; }
}

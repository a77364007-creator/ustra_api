package com.gsitm.ustra.api.platform.tenant.domain;

public enum TenantStatus {
    DRAFT,
    ACTIVE,
    SUSPENDED,
    RETIRED
}

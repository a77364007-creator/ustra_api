package com.gsitm.ustra.api.platform.provider.publishing.persistence;

import com.gsitm.ustra.api.platform.provider.publishing.domain.PublicationReviewState;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PublicationReviewRepository extends JpaRepository<PublicationReviewEntity, String> {
    Optional<PublicationReviewEntity> findByIdAndTenantId(String id, String tenantId);

    List<PublicationReviewEntity> findAllByTenantIdAndApiProductVersionIdOrderByCreatedAtDesc(
            String tenantId, String apiProductVersionId);

    boolean existsByTenantIdAndApiProductVersionIdAndStateIn(
            String tenantId, String apiProductVersionId, Collection<PublicationReviewState> states);
}

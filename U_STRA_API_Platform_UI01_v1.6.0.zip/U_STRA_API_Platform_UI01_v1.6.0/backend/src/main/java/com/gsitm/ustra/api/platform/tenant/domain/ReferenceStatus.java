package com.gsitm.ustra.api.platform.tenant.domain;

public enum ReferenceStatus {
    ACTIVE,
    INACTIVE
}

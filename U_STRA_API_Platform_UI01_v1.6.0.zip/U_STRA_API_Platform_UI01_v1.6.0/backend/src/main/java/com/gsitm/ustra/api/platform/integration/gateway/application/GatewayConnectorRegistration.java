package com.gsitm.ustra.api.platform.integration.gateway.application;

import com.gsitm.ustra.api.platform.subscription.gateway.application.GatewayPort;

public interface GatewayConnectorRegistration {
    String adapterCode();
    GatewayPort port();
}

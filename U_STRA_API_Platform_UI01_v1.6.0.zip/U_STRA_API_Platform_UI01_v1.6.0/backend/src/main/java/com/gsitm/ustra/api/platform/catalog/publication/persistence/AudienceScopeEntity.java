package com.gsitm.ustra.api.platform.catalog.publication.persistence;

import com.gsitm.ustra.api.platform.catalog.publication.domain.AudienceScopeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.Instant;

@Entity
@Table(name = "audience_scope")
public class AudienceScopeEntity {
    @Id
    @Column(name = "audience_scope_id", length = 36, nullable = false, updatable = false)
    private String id;
    @Column(name = "tenant_id", length = 36, nullable = false, updatable = false)
    private String tenantId;
    @Column(name = "catalog_publication_id", length = 36, nullable = false, updatable = false)
    private String catalogPublicationId;
    @Enumerated(EnumType.STRING)
    @Column(name = "scope_type", length = 30, nullable = false, updatable = false)
    private AudienceScopeType scopeType;
    @Column(name = "organization_id", length = 36, updatable = false)
    private String organizationId;
    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;
    @Column(name = "created_by", length = 200, nullable = false, updatable = false)
    private String createdBy;

    protected AudienceScopeEntity() {}

    public AudienceScopeEntity(String id, String tenantId, String catalogPublicationId,
                               AudienceScopeType scopeType, String organizationId, Instant now, String actor) {
        this.id = id;
        this.tenantId = tenantId;
        this.catalogPublicationId = catalogPublicationId;
        this.scopeType = scopeType;
        this.organizationId = organizationId;
        this.createdAt = now;
        this.createdBy = actor;
    }

    public String getId() { return id; }
    public String getTenantId() { return tenantId; }
    public String getCatalogPublicationId() { return catalogPublicationId; }
    public AudienceScopeType getScopeType() { return scopeType; }
    public String getOrganizationId() { return organizationId; }
}

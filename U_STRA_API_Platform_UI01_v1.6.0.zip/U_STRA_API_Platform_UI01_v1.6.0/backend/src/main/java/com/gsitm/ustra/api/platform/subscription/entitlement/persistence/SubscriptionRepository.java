package com.gsitm.ustra.api.platform.subscription.entitlement.persistence;
import java.util.*; import org.springframework.data.jpa.repository.JpaRepository;
public interface SubscriptionRepository extends JpaRepository<SubscriptionEntity,String>{
 Optional<SubscriptionEntity> findByIdAndTenantId(String id,String tenantId);
 Optional<SubscriptionEntity> findByTenantIdAndSourceSubscriptionRequestId(String tenantId,String requestId);
 List<SubscriptionEntity> findAllByTenantIdOrderByCreatedAtDesc(String tenantId);
 List<SubscriptionEntity> findAllByTenantIdAndApiProductVersionIdOrderByCreatedAtAsc(String tenantId,String apiProductVersionId);
}

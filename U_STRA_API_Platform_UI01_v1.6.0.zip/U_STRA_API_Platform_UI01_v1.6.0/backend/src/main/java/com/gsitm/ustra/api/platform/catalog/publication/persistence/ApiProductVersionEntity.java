package com.gsitm.ustra.api.platform.catalog.publication.persistence;

import com.gsitm.ustra.api.platform.catalog.publication.domain.ApiProductVersionState;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Version;
import java.time.Instant;

@Entity
@Table(name = "api_product_version")
public class ApiProductVersionEntity {
    @Id @Column(name = "api_product_version_id", length = 36, nullable = false, updatable = false)
    private String id;
    @Column(name = "tenant_id", length = 36, nullable = false, updatable = false)
    private String tenantId;
    @Column(name = "api_product_id", length = 36, nullable = false, updatable = false)
    private String apiProductId;
    @Column(name = "version_value", length = 100, nullable = false, updatable = false)
    private String versionValue;
    @Enumerated(EnumType.STRING)
    @Column(name = "lifecycle_state", length = 30, nullable = false)
    private ApiProductVersionState lifecycleState;
    @Column(name = "approved_review_id", length = 36)
    private String approvedReviewId;
    @Version @Column(name = "row_version", nullable = false)
    private long rowVersion;
    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;
    @Column(name = "created_by", length = 200, nullable = false, updatable = false)
    private String createdBy;
    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;
    @Column(name = "updated_by", length = 200, nullable = false)
    private String updatedBy;

    protected ApiProductVersionEntity() {}

    public ApiProductVersionEntity(String id, String tenantId, String apiProductId, String versionValue,
                                   Instant now, String actor) {
        this.id=id; this.tenantId=tenantId; this.apiProductId=apiProductId; this.versionValue=versionValue;
        this.lifecycleState=ApiProductVersionState.DRAFT; this.createdAt=now; this.createdBy=actor;
        this.updatedAt=now; this.updatedBy=actor;
    }

    public void touch(Instant now, String actor) { this.updatedAt=now; this.updatedBy=actor; }
    public void beginValidation(Instant now, String actor) {
        this.lifecycleState=ApiProductVersionState.VALIDATING; this.approvedReviewId=null; touch(now,actor);
    }
    public void approve(String reviewId, Instant now, String actor) {
        this.lifecycleState=ApiProductVersionState.APPROVED; this.approvedReviewId=reviewId; touch(now,actor);
    }
    public void returnToDraft(Instant now, String actor) {
        this.lifecycleState=ApiProductVersionState.DRAFT; this.approvedReviewId=null; touch(now,actor);
    }
    public void release(Instant now, String actor) { this.lifecycleState=ApiProductVersionState.RELEASED; touch(now,actor); }

    public String getId(){return id;} public String getTenantId(){return tenantId;}
    public String getApiProductId(){return apiProductId;} public String getVersionValue(){return versionValue;}
    public ApiProductVersionState getLifecycleState(){return lifecycleState;}
    public String getApprovedReviewId(){return approvedReviewId;} public long getRowVersion(){return rowVersion;}
    public Instant getCreatedAt(){return createdAt;} public String getCreatedBy(){return createdBy;}
    public Instant getUpdatedAt(){return updatedAt;} public String getUpdatedBy(){return updatedBy;}
}

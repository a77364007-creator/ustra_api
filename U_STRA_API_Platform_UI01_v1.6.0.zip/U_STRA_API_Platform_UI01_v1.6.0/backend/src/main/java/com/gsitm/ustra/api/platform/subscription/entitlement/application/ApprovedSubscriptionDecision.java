package com.gsitm.ustra.api.platform.subscription.entitlement.application;
import java.math.BigDecimal; import java.time.Instant; import java.util.List;
public record ApprovedSubscriptionDecision(String tenantId,String approvalReferenceId,String subscriptionRequestId,int requestRevisionNo,String snapshotHash,String consumerAppEnvironmentId,String apiProductVersionId,List<String> apiOperationIds,List<QuotaLimitDecision> quotaLimits,Instant effectiveFrom,Instant effectiveTo){
 public ApprovedSubscriptionDecision { apiOperationIds=apiOperationIds==null?List.of():List.copyOf(apiOperationIds); quotaLimits=quotaLimits==null?List.of():List.copyOf(quotaLimits); }
 public record QuotaLimitDecision(String metricCode,BigDecimal limitValue,long windowSeconds,String unitCode){}
}

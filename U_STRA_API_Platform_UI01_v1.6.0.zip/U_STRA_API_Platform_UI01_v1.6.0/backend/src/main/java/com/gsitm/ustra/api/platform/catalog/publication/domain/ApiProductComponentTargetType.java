package com.gsitm.ustra.api.platform.catalog.publication.domain;

public enum ApiProductComponentTargetType {
    API_VERSION,
    API_OPERATION
}

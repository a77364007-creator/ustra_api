package com.gsitm.ustra.api.platform.search.application;

import com.gsitm.ustra.api.platform.audit.AuditService;
import com.gsitm.ustra.api.platform.tenant.application.TenantPermissionGuard;
import com.gsitm.ustra.api.platform.tenant.context.TenantContext;
import com.gsitm.ustra.api.platform.tenant.context.TenantContextResolver;
import java.util.Map;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class CatalogSearchAdminService {
    private final TenantContextResolver contextResolver;
    private final TenantPermissionGuard permissionGuard;
    private final SearchProjectionRecoveryService projectionPort;
    private final AuditService auditService;

    public CatalogSearchAdminService(TenantContextResolver contextResolver, TenantPermissionGuard permissionGuard,
                                     SearchProjectionRecoveryService projectionPort, AuditService auditService) {
        this.contextResolver=contextResolver; this.permissionGuard=permissionGuard;
        this.projectionPort=projectionPort; this.auditService=auditService;
    }

    @Transactional(propagation = org.springframework.transaction.annotation.Propagation.NOT_SUPPORTED)
    public CatalogSearchProjectionPort.RebuildResult rebuild() {
        TenantContext context=contextResolver.resolve();
        permissionGuard.require(context,"CATALOG_SEARCH:REBUILD","CATALOG_SEARCH","rebuild");
        var result=projectionPort.rebuild(context.tenantId(),context.principalId());
        auditService.success(context.tenantId(),"CATALOG_SEARCH_REBUILD","CATALOG_SEARCH",context.tenantId(),true,
                Map.of("productCount",result.productCount(),"documentCount",result.documentCount(),
                        "visibilityCount",result.visibilityCount()));
        return result;
    }
}

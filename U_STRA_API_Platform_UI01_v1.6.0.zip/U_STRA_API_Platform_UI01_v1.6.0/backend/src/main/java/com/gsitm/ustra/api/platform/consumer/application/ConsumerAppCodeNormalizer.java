package com.gsitm.ustra.api.platform.consumer.application;

import com.gsitm.ustra.api.platform.common.error.BusinessException;
import com.gsitm.ustra.api.platform.common.error.ErrorCode;
import java.util.Locale;
import org.springframework.http.HttpStatus;

final class ConsumerAppCodeNormalizer {
    private ConsumerAppCodeNormalizer() {}

    static String appCode(String value) {
        if (value == null || value.isBlank()) {
            throw new BusinessException(ErrorCode.VALIDATION_ERROR, HttpStatus.BAD_REQUEST, "appCode는 필수입니다.");
        }
        String normalized = value.trim().toUpperCase(Locale.ROOT);
        if (normalized.length() > 100) {
            throw new BusinessException(ErrorCode.VALIDATION_ERROR, HttpStatus.BAD_REQUEST, "appCode는 100자를 초과할 수 없습니다.");
        }
        return normalized;
    }
}

package com.gsitm.ustra.api.platform.integration.approval.application;

import com.gsitm.ustra.api.platform.audit.AuditService;
import com.gsitm.ustra.api.platform.common.error.*;
import com.gsitm.ustra.api.platform.integration.approval.domain.*;
import com.gsitm.ustra.api.platform.integration.approval.persistence.*;
import java.time.*;
import java.util.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ReconciliationIssueService {
    private final ReconciliationIssueRepository issues;
    private final IntegrationOperationRepository operations;
    private final AuditService audit;
    private final Clock clock;
    public ReconciliationIssueService(ReconciliationIssueRepository issues, IntegrationOperationRepository operations,
                                      AuditService audit, Clock clock) {
        this.issues=issues; this.operations=operations; this.audit=audit; this.clock=clock;
    }
    private void lock(String tenantId, String operationId) {
        operations.lockOwned(tenantId, operationId).orElseThrow(() -> new BusinessException(
                ErrorCode.INTEGRATION_OPERATION_NOT_FOUND, HttpStatus.NOT_FOUND, "IntegrationOperation을 찾을 수 없습니다."));
    }
    @Transactional
    public ReconciliationIssueEntity open(String tenantId, String operationId, String type, String detail, String actor) {
        // Lock the existing parent even when no issue exists, serializing first insert as well as reopen.
        lock(tenantId, operationId);
        Instant now=Instant.now(clock);
        var current=issues.findByTenantIdAndIntegrationOperationIdAndIssueType(tenantId, operationId, type);
        ReconciliationIssueEntity issue;
        String action;
        if (current.isPresent()) {
            issue=current.get();
            if (issue.getStatus()==ReconciliationIssueStatus.RESOLVED) {
                issue.reopen(detail,now,actor); action="RECONCILIATION_ISSUE_REOPENED";
            } else {
                issue.checked(detail,now,actor); action="RECONCILIATION_ISSUE_OBSERVED";
            }
        } else {
            issue=new ReconciliationIssueEntity(UUID.randomUUID().toString(),tenantId,operationId,type,detail,now,actor);
            action="RECONCILIATION_ISSUE_OPENED";
        }
        issue=issues.saveAndFlush(issue);
        audit.success(tenantId,action,"RECONCILIATION_ISSUE",issue.getId(),true,
                Map.of("integrationOperationId",operationId,"issueType",type));
        return issue;
    }
    @Transactional
    public void resolve(String tenantId,String operationId,String type,String actor) {
        lock(tenantId,operationId);
        issues.findByTenantIdAndIntegrationOperationIdAndIssueType(tenantId,operationId,type)
            .filter(i->i.getStatus()==ReconciliationIssueStatus.OPEN).ifPresent(i->{
                i.resolve(Instant.now(clock),actor); issues.saveAndFlush(i);
                audit.success(tenantId,"RECONCILIATION_ISSUE_RESOLVED","RECONCILIATION_ISSUE",i.getId(),true,
                        Map.of("integrationOperationId",operationId,"issueType",type));
            });
    }
    @Transactional(readOnly=true)
    public List<ReconciliationIssueEntity> list(String tenantId) {return issues.findAllByTenantIdOrderByOpenedAtDesc(tenantId);}
    @Transactional(readOnly=true)
    public List<ReconciliationIssueEntity> listByTypes(String tenantId,Collection<IntegrationOperationType> types) {
        return types.isEmpty()?List.of():issues.findScoped(tenantId,types);
    }
}

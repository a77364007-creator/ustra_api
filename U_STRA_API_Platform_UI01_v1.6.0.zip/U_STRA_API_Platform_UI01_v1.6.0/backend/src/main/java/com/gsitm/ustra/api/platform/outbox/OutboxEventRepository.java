package com.gsitm.ustra.api.platform.outbox;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OutboxEventRepository extends JpaRepository<OutboxEventEntity, String>, org.springframework.data.jpa.repository.JpaSpecificationExecutor<OutboxEventEntity> {
    List<OutboxEventEntity> findTop100ByStatusOrderByCreatedAtAsc(OutboxStatus status);
    long countByEventId(String eventId);
}

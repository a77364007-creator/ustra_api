package com.gsitm.ustra.api.platform.subscription.entitlement.persistence;
import jakarta.persistence.*; import java.math.BigDecimal; import java.time.Instant;
@Entity @Table(name="quota_limit")
public class QuotaLimitEntity {
 @Id @Column(name="quota_limit_id",length=36,nullable=false,updatable=false) private String id;
 @Column(name="tenant_id",length=36,nullable=false,updatable=false) private String tenantId;
 @Column(name="quota_profile_id",length=36,nullable=false,updatable=false) private String quotaProfileId;
 @Column(name="metric_code",length=100,nullable=false,updatable=false) private String metricCode;
 @Column(name="limit_value",precision=20,scale=4,nullable=false,updatable=false) private BigDecimal limitValue;
 @Column(name="window_seconds",nullable=false,updatable=false) private long windowSeconds;
 @Column(name="unit_code",length=50,nullable=false,updatable=false) private String unitCode;
 @Column(name="created_at",nullable=false,updatable=false) private Instant createdAt;
 @Column(name="created_by",length=200,nullable=false,updatable=false) private String createdBy;
 protected QuotaLimitEntity(){}
 public QuotaLimitEntity(String id,String tenantId,String profileId,String metricCode,BigDecimal value,long windowSeconds,String unitCode,Instant now,String actor){this.id=id;this.tenantId=tenantId;this.quotaProfileId=profileId;this.metricCode=metricCode;this.limitValue=value;this.windowSeconds=windowSeconds;this.unitCode=unitCode;this.createdAt=now;this.createdBy=actor;}
 public String getId(){return id;} public String getMetricCode(){return metricCode;} public BigDecimal getLimitValue(){return limitValue;} public long getWindowSeconds(){return windowSeconds;} public String getUnitCode(){return unitCode;}
}

package com.gsitm.ustra.api.platform.subscription.persistence;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SubscriptionRequestRevisionRepository extends JpaRepository<SubscriptionRequestRevisionEntity, String> {
    Optional<SubscriptionRequestRevisionEntity> findByTenantIdAndSubscriptionRequestIdAndRevisionNo(
            String tenantId, String subscriptionRequestId, int revisionNo);
}

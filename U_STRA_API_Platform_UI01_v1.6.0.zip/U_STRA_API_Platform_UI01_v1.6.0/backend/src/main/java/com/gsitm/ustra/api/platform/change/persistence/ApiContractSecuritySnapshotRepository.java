package com.gsitm.ustra.api.platform.change.persistence;
import org.springframework.data.jpa.repository.JpaRepository;
public interface ApiContractSecuritySnapshotRepository extends JpaRepository<ApiContractSecuritySnapshotEntity,String>{}

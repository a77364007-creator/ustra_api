package com.gsitm.ustra.api.platform.operations.domain;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;
import java.util.UUID;

/** Request data only. Tenant/actor/connector/URL/forced status are deliberately absent. */
public record RecoveryRequest(RecoveryActionType actionType, String targetId, Long expectedTargetVersion) {
    public RecoveryRequest validated() {
        if (actionType == null || targetId == null || !isUuid(targetId)
                || (expectedTargetVersion != null && expectedTargetVersion < 0)
                || (actionType == RecoveryActionType.SEARCH_TENANT_REBUILD && expectedTargetVersion != null)) {
            throw new IllegalArgumentException("RECOVERY_REQUEST_INVALID");
        }
        return new RecoveryRequest(actionType, UUID.fromString(targetId).toString(), expectedTargetVersion);
    }
    public static String validateKey(String key) {
        if (key == null || !key.matches("[A-Za-z0-9._:-]{1,200}")) {
            throw new IllegalArgumentException("RECOVERY_IDEMPOTENCY_KEY_INVALID");
        }
        return key; // case-sensitive exact replay identity, never silently trimmed or lower-cased.
    }
    private static boolean isUuid(String value) {
        try { return UUID.fromString(value).toString().equalsIgnoreCase(value); }
        catch (IllegalArgumentException ex) { return false; }
    }
    public String fingerprint() {
        RecoveryRequest r=validated();
        String canonical="CP15-RECOVERY-V1\n"+r.actionType().name()+"\n"+r.targetId()+"\n"
                +(r.expectedTargetVersion()==null?"NONE":r.expectedTargetVersion().toString());
        try {return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(canonical.getBytes(StandardCharsets.UTF_8)));}
        catch(NoSuchAlgorithmException ex){throw new IllegalStateException("SHA-256 unavailable",ex);}
    }
}

package com.gsitm.ustra.api.platform.operations.application;

import com.gsitm.ustra.api.platform.common.error.*;
import java.time.*;
import java.util.Set;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

@Component
public class OperationsQueryLimits {
    private final Clock clock;
    private final int maxPageSize;
    private final int maxPageNumber;
    private final int maxRangeDays;
    private final int defaultRangeDays;
    public OperationsQueryLimits(Clock clock,@Value("${app.operations.max-page-size:100}") int maxPageSize,
            @Value("${app.operations.max-page-number:10000}") int maxPageNumber,
            @Value("${app.operations.max-range-days:31}") int maxRangeDays,
            @Value("${app.operations.default-range-days:7}") int defaultRangeDays) {
        if(maxPageSize<1||maxPageNumber<0||defaultRangeDays<1||maxRangeDays<defaultRangeDays)
            throw new IllegalArgumentException("OPERATIONS_QUERY_CONFIGURATION_INVALID");
        this.clock=clock;this.maxPageSize=maxPageSize;this.maxPageNumber=maxPageNumber;
        this.maxRangeDays=maxRangeDays;this.defaultRangeDays=defaultRangeDays;
    }
    public Window window(Instant from,Instant to) {
        Instant end=to==null?Instant.now(clock):to;
        Instant start=from==null?end.minus(Duration.ofDays(defaultRangeDays)):from;
        if(!start.isBefore(end)||Duration.between(start,end).compareTo(Duration.ofDays(maxRangeDays))>0) throw invalid();
        return new Window(start,end);
    }
    public Pageable page(int page,int size,String order,String timeField) {
        if(page<0||page>maxPageNumber||size<1||size>maxPageSize||!Set.of("NEWEST","OLDEST").contains(order)) throw invalid();
        Sort.Direction direction="NEWEST".equals(order)?Sort.Direction.DESC:Sort.Direction.ASC;
        return PageRequest.of(page,size,Sort.by(direction,timeField,"id"));
    }
    public String filter(String value) {
        if(value==null)return null;
        if(value.isBlank()||value.length()>200||value.chars().anyMatch(Character::isISOControl))throw invalid();
        return value; // exact-match bound value, not SQL/JPQL or LIKE text
    }
    private BusinessException invalid(){return new BusinessException(ErrorCode.VALIDATION_ERROR,HttpStatus.BAD_REQUEST,"운영 조회 조건이 올바르지 않습니다.");}
    public record Window(Instant from,Instant to) {}
}

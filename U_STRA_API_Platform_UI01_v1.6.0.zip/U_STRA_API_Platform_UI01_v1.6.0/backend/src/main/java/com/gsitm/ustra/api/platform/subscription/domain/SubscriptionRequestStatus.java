package com.gsitm.ustra.api.platform.subscription.domain;

public enum SubscriptionRequestStatus {
    SUBMITTED,
    VALIDATING,
    PENDING_APPROVAL,
    APPROVED,
    COMPLETED,
    NEEDS_INFORMATION,
    REJECTED,
    CANCELLED,
    EXPIRED
}

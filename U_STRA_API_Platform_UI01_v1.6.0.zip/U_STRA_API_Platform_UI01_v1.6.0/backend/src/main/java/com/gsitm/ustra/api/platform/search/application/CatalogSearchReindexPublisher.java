package com.gsitm.ustra.api.platform.search.application;

import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Component;

@Component
public class CatalogSearchReindexPublisher {
    private final ApplicationEventPublisher publisher;
    public CatalogSearchReindexPublisher(ApplicationEventPublisher publisher){this.publisher=publisher;}
    public void request(String tenantId,String apiProductId,String actor,String reason){
        publisher.publishEvent(new CatalogSearchReindexEvent(tenantId,apiProductId,actor,reason));
    }
}

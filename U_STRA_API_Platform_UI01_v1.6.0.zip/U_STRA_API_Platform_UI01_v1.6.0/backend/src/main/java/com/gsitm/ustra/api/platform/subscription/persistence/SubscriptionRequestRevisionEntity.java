package com.gsitm.ustra.api.platform.subscription.persistence;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.Instant;

@Entity
@Table(name = "subscription_request_revision")
public class SubscriptionRequestRevisionEntity {
    @Id
    @Column(name = "subscription_request_revision_id", length = 36, nullable = false, updatable = false)
    private String id;
    @Column(name = "tenant_id", length = 36, nullable = false, updatable = false)
    private String tenantId;
    @Column(name = "subscription_request_id", length = 36, nullable = false, updatable = false)
    private String subscriptionRequestId;
    @Column(name = "revision_no", nullable = false, updatable = false)
    private int revisionNo;
    @Column(name = "author_membership_id", length = 36, nullable = false, updatable = false)
    private String authorMembershipId;
    @Column(name = "purpose", columnDefinition = "TEXT", nullable = false, updatable = false)
    private String purpose;
    @Column(name = "expected_call_volume", length = 500, updatable = false)
    private String expectedCallVolume;
    @Column(name = "snapshot_hash", length = 64, nullable = false, updatable = false)
    private String snapshotHash;
    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;
    @Column(name = "created_by", length = 200, nullable = false, updatable = false)
    private String createdBy;

    protected SubscriptionRequestRevisionEntity() {}

    public SubscriptionRequestRevisionEntity(String id, String tenantId, String subscriptionRequestId,
                                             int revisionNo, String authorMembershipId, String purpose,
                                             String expectedCallVolume, String snapshotHash,
                                             Instant createdAt, String createdBy) {
        this.id = id;
        this.tenantId = tenantId;
        this.subscriptionRequestId = subscriptionRequestId;
        this.revisionNo = revisionNo;
        this.authorMembershipId = authorMembershipId;
        this.purpose = purpose;
        this.expectedCallVolume = expectedCallVolume;
        this.snapshotHash = snapshotHash;
        this.createdAt = createdAt;
        this.createdBy = createdBy;
    }

    public String getId() { return id; }
    public String getTenantId() { return tenantId; }
    public String getSubscriptionRequestId() { return subscriptionRequestId; }
    public int getRevisionNo() { return revisionNo; }
    public String getAuthorMembershipId() { return authorMembershipId; }
    public String getPurpose() { return purpose; }
    public String getExpectedCallVolume() { return expectedCallVolume; }
    public String getSnapshotHash() { return snapshotHash; }
    public Instant getCreatedAt() { return createdAt; }
    public String getCreatedBy() { return createdBy; }
}

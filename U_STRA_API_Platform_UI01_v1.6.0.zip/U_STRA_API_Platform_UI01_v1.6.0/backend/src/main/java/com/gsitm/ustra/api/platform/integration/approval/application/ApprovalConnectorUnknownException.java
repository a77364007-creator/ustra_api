package com.gsitm.ustra.api.platform.integration.approval.application;
public class ApprovalConnectorUnknownException extends RuntimeException {
 private final String safeCode; private final String externalReference;
 public ApprovalConnectorUnknownException(String safeCode,String externalReference){super("Approval connector outcome is unknown");this.safeCode=safeCode;this.externalReference=externalReference;}
 public String safeCode(){return safeCode;} public String externalReference(){return externalReference;}
}

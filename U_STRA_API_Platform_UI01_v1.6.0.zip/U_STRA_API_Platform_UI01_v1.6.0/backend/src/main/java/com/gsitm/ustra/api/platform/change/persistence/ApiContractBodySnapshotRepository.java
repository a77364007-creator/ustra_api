package com.gsitm.ustra.api.platform.change.persistence;
import org.springframework.data.jpa.repository.JpaRepository;
public interface ApiContractBodySnapshotRepository extends JpaRepository<ApiContractBodySnapshotEntity,String>{}

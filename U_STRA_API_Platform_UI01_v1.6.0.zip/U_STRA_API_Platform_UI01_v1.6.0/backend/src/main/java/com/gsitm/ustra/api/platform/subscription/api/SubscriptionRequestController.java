package com.gsitm.ustra.api.platform.subscription.api;

import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.gsitm.ustra.api.platform.subscription.application.SubscriptionRequestService;
import com.gsitm.ustra.api.platform.subscription.application.SubscriptionRequestService.SubscriptionRequestView;
import com.gsitm.ustra.api.platform.subscription.persistence.SubscriptionRequestEntity;
import com.gsitm.ustra.api.platform.subscription.persistence.SubscriptionRequestRevisionEntity;
import com.gsitm.ustra.api.platform.tenant.api.VersionHeaderParser;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import java.time.Instant;
import java.util.List;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/subscription-requests")
public class SubscriptionRequestController {
    private final SubscriptionRequestService service;

    public SubscriptionRequestController(SubscriptionRequestService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<SubscriptionRequestResponse> create(
            @RequestHeader(value = "Idempotency-Key", required = false) String idempotencyKey,
            @Valid @RequestBody CreateSubscriptionRequest request) {
        SubscriptionRequestView view = service.create(idempotencyKey, request.consumerAppEnvironmentId,
                request.catalogPublicationId, request.purpose, request.expectedCallVolume, request.requestedApiOperationIds);
        return ResponseEntity.status(HttpStatus.CREATED)
                .eTag(VersionHeaderParser.etag(view.request().getRowVersion()))
                .body(SubscriptionRequestResponse.from(view));
    }

    @GetMapping("/{subscriptionRequestId}")
    public ResponseEntity<SubscriptionRequestResponse> get(@PathVariable String subscriptionRequestId) {
        SubscriptionRequestView view = service.get(subscriptionRequestId);
        return ResponseEntity.ok()
                .eTag(VersionHeaderParser.etag(view.request().getRowVersion()))
                .body(SubscriptionRequestResponse.from(view));
    }

    @PostMapping("/{subscriptionRequestId}/cancel")
    public ResponseEntity<SubscriptionRequestResponse> cancel(
            @PathVariable String subscriptionRequestId,
            @RequestHeader(value = HttpHeaders.IF_MATCH, required = false) String ifMatch) {
        SubscriptionRequestView view = service.cancel(subscriptionRequestId, VersionHeaderParser.parse(ifMatch));
        return ResponseEntity.ok()
                .eTag(VersionHeaderParser.etag(view.request().getRowVersion()))
                .body(SubscriptionRequestResponse.from(view));
    }

    public static final class CreateSubscriptionRequest {
        @NotBlank
        public String consumerAppEnvironmentId;
        @NotBlank
        public String catalogPublicationId;
        @NotBlank
        @Size(max = 4000)
        public String purpose;
        @Size(max = 500)
        public String expectedCallVolume;
        public List<String> requestedApiOperationIds;

        @JsonAnySetter
        public void rejectUnknown(String name, Object ignored) {
            throw new IllegalArgumentException("지원하지 않는 Subscription Request 요청 필드입니다: " + name);
        }
    }

    public record SubscriptionRequestResponse(
            String subscriptionRequestId,
            String consumerAppEnvironmentId,
            String catalogPublicationId,
            String apiProductVersionId,
            String requesterMembershipId,
            String status,
            int currentRevisionNo,
            String purpose,
            String expectedCallVolume,
            String snapshotHash,
            List<String> requestedApiOperationIds,
            long revision,
            Instant createdAt,
            String createdBy,
            Instant updatedAt,
            String updatedBy) {
        static SubscriptionRequestResponse from(SubscriptionRequestView view) {
            SubscriptionRequestEntity request = view.request();
            SubscriptionRequestRevisionEntity snapshot = view.revision();
            return new SubscriptionRequestResponse(
                    request.getId(), request.getConsumerAppEnvironmentId(), request.getCatalogPublicationId(),
                    request.getApiProductVersionId(), request.getRequesterMembershipId(), request.getStatus().name(),
                    request.getCurrentRevisionNo(), snapshot.getPurpose(), snapshot.getExpectedCallVolume(),
                    snapshot.getSnapshotHash(), view.requestedApiOperationIds(), request.getRowVersion(), request.getCreatedAt(), request.getCreatedBy(),
                    request.getUpdatedAt(), request.getUpdatedBy());
        }
    }
}

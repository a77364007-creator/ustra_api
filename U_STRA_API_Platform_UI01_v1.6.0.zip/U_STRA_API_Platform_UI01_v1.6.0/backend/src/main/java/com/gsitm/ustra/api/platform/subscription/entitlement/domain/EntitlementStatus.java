package com.gsitm.ustra.api.platform.subscription.entitlement.domain;
public enum EntitlementStatus { GRANTED, SUSPENDED, REVOKED, EXPIRED }

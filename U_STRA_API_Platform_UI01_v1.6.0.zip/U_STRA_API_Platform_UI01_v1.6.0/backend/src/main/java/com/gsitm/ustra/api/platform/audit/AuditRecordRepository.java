package com.gsitm.ustra.api.platform.audit;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AuditRecordRepository extends JpaRepository<AuditRecordEntity, String>, org.springframework.data.jpa.repository.JpaSpecificationExecutor<AuditRecordEntity> {
    List<AuditRecordEntity> findAllByTenantIdOrderByOccurredAtAsc(String tenantId);
}

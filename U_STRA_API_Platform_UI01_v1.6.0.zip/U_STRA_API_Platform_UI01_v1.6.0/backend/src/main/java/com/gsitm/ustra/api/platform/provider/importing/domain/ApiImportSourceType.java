package com.gsitm.ustra.api.platform.provider.importing.domain;
public enum ApiImportSourceType { OPENAPI_UPLOAD }

package com.gsitm.ustra.api.platform.tenant.domain;

public enum MembershipStatus {
    ACTIVE,
    INACTIVE,
    EXPIRED
}

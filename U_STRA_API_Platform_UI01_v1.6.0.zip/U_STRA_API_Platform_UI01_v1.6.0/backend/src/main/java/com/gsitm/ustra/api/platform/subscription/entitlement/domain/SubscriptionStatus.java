package com.gsitm.ustra.api.platform.subscription.entitlement.domain;
public enum SubscriptionStatus { PENDING_ACTIVATION, ACTIVE, SUSPENDED, EXPIRED, TERMINATED }

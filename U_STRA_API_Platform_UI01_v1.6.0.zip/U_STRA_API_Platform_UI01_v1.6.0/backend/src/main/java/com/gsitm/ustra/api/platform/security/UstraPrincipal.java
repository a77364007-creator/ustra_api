package com.gsitm.ustra.api.platform.security;

import java.security.Principal;

public record UstraPrincipal(String principalId, String issuer) implements Principal {
    @Override
    public String getName() {
        return principalId;
    }
}

package com.gsitm.ustra.api.platform.audit.api;
import com.gsitm.ustra.api.platform.audit.application.AuditQueryService;
import com.gsitm.ustra.api.platform.operations.api.OperationsPage;
import java.time.Instant;
import org.springframework.web.bind.annotation.*;

@RestController @RequestMapping("/api/v1/admin/audit-records")
public class AuditQueryController {
    private final AuditQueryService service;
    public AuditQueryController(AuditQueryService service){this.service=service;}
    @GetMapping
    public OperationsPage<AuditQueryService.View> query(@RequestParam(required=false) Instant from,@RequestParam(required=false) Instant to,
            @RequestParam(required=false) String action,@RequestParam(required=false) String resourceType,
            @RequestParam(required=false) String resourceId,@RequestParam(required=false) String outcome,
            @RequestParam(required=false) String correlationId,@RequestParam(defaultValue="0") int page,
            @RequestParam(defaultValue="50") int size,@RequestParam(defaultValue="NEWEST") String order) {
        return service.query(from,to,action,resourceType,resourceId,outcome,correlationId,page,size,order);
    }
}

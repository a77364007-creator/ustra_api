package com.gsitm.ustra.api.platform.search.application;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;

@Component
public class CatalogSearchReindexListener {
    private static final Logger log=LoggerFactory.getLogger(CatalogSearchReindexListener.class);
    private final SearchProjectionRecoveryService recovery;
    public CatalogSearchReindexListener(SearchProjectionRecoveryService recovery){this.recovery=recovery;}

    @TransactionalEventListener(phase=TransactionPhase.AFTER_COMMIT, fallbackExecution=true)
    public void on(CatalogSearchReindexEvent event) {
        try { recovery.reindex(event.tenantId(),event.apiProductId(),event.actor()); }
        catch(RuntimeException ex) {
            // No exception object, dynamic reason text, SQL or raw payload in operational log.
            log.warn("SEARCH_PROJECTION_REFRESH_FAILED tenantId={} apiProductId={}",event.tenantId(),event.apiProductId());
        }
    }
}

package com.gsitm.ustra.api.platform.outbox;

import java.util.Optional;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.core.env.Profiles;
import org.springframework.stereotype.Service;

/** Stage A: production transport/ACK/claim contracts are not approved. No fallback sink. */
@Service
public class OutboxDispatchService {
    private final OutboxStateService stateService;
    private final OutboxSink sink;
    private final boolean production;

    @Autowired
    public OutboxDispatchService(OutboxStateService stateService, ObjectProvider<OutboxSink> sinks,
                                 Environment environment) {
        this.stateService = stateService;
        this.production = environment.acceptsProfiles(Profiles.of("prod"));
        // getIfUnique also honors an explicit @Primary test transport, preserving existing fixtures.
        this.sink = production ? null : sinks.getIfUnique();
    }

    // Retain the existing explicit, non-Spring unit-fixture construction path.
    public OutboxDispatchService(OutboxStateService stateService, OutboxSink sink) {
        this.stateService = stateService;
        this.sink = sink;
        this.production = false;
    }

    public void requireWorkerConfiguration(boolean enabled) {
        if (enabled && (production || sink == null)) {
            throw new IllegalStateException("OUTBOX_DELIVERY_GATE_BLOCKED");
        }
    }

    public boolean dispatchOne(String outboxId) {
        if (production || sink == null) return false;
        Optional<OutboxMessage> pending = stateService.loadPending(outboxId);
        if (pending.isEmpty()) return false;
        try {
            sink.publish(pending.get());
            stateService.markPublished(outboxId);
            return true;
        } catch (RuntimeException ex) {
            stateService.markAttemptFailed(outboxId);
            return false;
        }
    }
}

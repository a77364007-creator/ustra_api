package com.gsitm.ustra.api.platform.consumer.persistence;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ConsumerAppRepository extends JpaRepository<ConsumerAppEntity, String> {
    Optional<ConsumerAppEntity> findByIdAndTenantId(String id, String tenantId);
    List<ConsumerAppEntity> findAllByTenantIdOrderByAppCodeNormalizedAsc(String tenantId);
    boolean existsByTenantIdAndAppCodeNormalized(String tenantId, String appCodeNormalized);
}

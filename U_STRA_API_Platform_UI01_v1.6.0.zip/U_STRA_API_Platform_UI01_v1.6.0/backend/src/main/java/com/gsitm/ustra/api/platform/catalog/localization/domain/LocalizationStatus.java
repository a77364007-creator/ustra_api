package com.gsitm.ustra.api.platform.catalog.localization.domain;

public enum LocalizationStatus {
    MISSING,
    DRAFT,
    REVIEW,
    PUBLISHED,
    STALE
}

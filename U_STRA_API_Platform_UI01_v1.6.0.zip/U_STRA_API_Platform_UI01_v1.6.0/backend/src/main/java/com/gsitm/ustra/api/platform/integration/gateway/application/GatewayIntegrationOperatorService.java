package com.gsitm.ustra.api.platform.integration.gateway.application;

import com.gsitm.ustra.api.platform.audit.AuditService;
import com.gsitm.ustra.api.platform.integration.approval.application.ReconciliationIssueService;
import com.gsitm.ustra.api.platform.integration.approval.domain.IntegrationOperationStatus;
import com.gsitm.ustra.api.platform.integration.approval.domain.IntegrationOperationType;
import com.gsitm.ustra.api.platform.integration.approval.persistence.IntegrationOperationEntity;
import com.gsitm.ustra.api.platform.integration.approval.persistence.IntegrationOperationRepository;
import com.gsitm.ustra.api.platform.integration.approval.persistence.ReconciliationIssueEntity;
import com.gsitm.ustra.api.platform.tenant.application.TenantPermissionGuard;
import com.gsitm.ustra.api.platform.tenant.context.TenantContext;
import com.gsitm.ustra.api.platform.tenant.context.TenantContextResolver;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class GatewayIntegrationOperatorService {
    private static final EnumSet<IntegrationOperationType> GATEWAY_TYPES = EnumSet.of(
            IntegrationOperationType.GATEWAY_PROVISION,
            IntegrationOperationType.GATEWAY_DEPROVISION,
            IntegrationOperationType.GATEWAY_STATUS_QUERY);

    private final TenantContextResolver contexts;
    private final TenantPermissionGuard permissions;
    private final IntegrationOperationRepository operations;
    private final ReconciliationIssueService issues;
    private final GatewayIntegrationOrchestrator orchestrator;
    private final AuditService audit;

    public GatewayIntegrationOperatorService(
            TenantContextResolver contexts,
            TenantPermissionGuard permissions,
            IntegrationOperationRepository operations,
            ReconciliationIssueService issues,
            GatewayIntegrationOrchestrator orchestrator,
            AuditService audit) {
        this.contexts = contexts;
        this.permissions = permissions;
        this.operations = operations;
        this.issues = issues;
        this.orchestrator = orchestrator;
        this.audit = audit;
    }

    @Transactional(readOnly = true)
    public List<OperationView> operations(IntegrationOperationStatus status) {
        TenantContext context = contexts.resolve();
        permissions.require(
                context,
                "GATEWAY_INTEGRATION:READ",
                "GATEWAY_INTEGRATION",
                "operations");
        List<IntegrationOperationEntity> rows = operations.findScoped(context.tenantId(), GATEWAY_TYPES, status);
        return rows.stream()
                .map(OperationView::from)
                .toList();
    }

    @Transactional(readOnly = true)
    public List<IssueView> issues() {
        TenantContext context = contexts.resolve();
        permissions.require(
                context,
                "GATEWAY_INTEGRATION:READ",
                "GATEWAY_INTEGRATION",
                "issues");
        return issues.listByTypes(context.tenantId(), GATEWAY_TYPES).stream()
                .map(IssueView::from)
                .toList();
    }

    public ReconcileView reconcileFulfillment(String fulfillmentId) {
        TenantContext context = contexts.resolve();
        permissions.require(
                context,
                "GATEWAY_INTEGRATION:RECONCILE",
                "ACCESS_FULFILLMENT",
                fulfillmentId);
        audit.success(
                context.tenantId(),
                "GATEWAY_INTEGRATION_RECONCILE_REQUEST",
                "ACCESS_FULFILLMENT",
                fulfillmentId,
                true,
                Map.of());
        var result = orchestrator.reconcile(context.tenantId(), fulfillmentId);
        return new ReconcileView(
                result.integrationOperationId(),
                result.operationStatus().name(),
                result.fulfillmentStatus());
    }

    public record OperationView(
            String integrationOperationId,
            String operationType,
            String aggregateType,
            String aggregateId,
            Integer aggregateRevision,
            String connectorInstanceId,
            String status,
            int attemptCount,
            String safeErrorCategory,
            String safeErrorCode,
            String externalReference) {
        static OperationView from(IntegrationOperationEntity entity) {
            return new OperationView(
                    entity.getId(),
                    entity.getOperationType().name(),
                    entity.getAggregateType(),
                    entity.getAggregateId(),
                    entity.getAggregateRevision(),
                    entity.getConnectorInstanceId(),
                    entity.getStatus().name(),
                    entity.getAttemptCount(),
                    entity.getSafeErrorCategory(),
                    entity.getSafeErrorCode(),
                    entity.getExternalReference());
        }
    }

    public record IssueView(
            String reconciliationIssueId,
            String integrationOperationId,
            String issueType,
            String status,
            String safeDetailCode) {
        static IssueView from(ReconciliationIssueEntity entity) {
            return new IssueView(
                    entity.getId(),
                    entity.getIntegrationOperationId(),
                    entity.getIssueType(),
                    entity.getStatus().name(),
                    entity.getSafeDetailCode());
        }
    }

    public record ReconcileView(
            String integrationOperationId,
            String operationStatus,
            String fulfillmentStatus) {}
}

package com.gsitm.ustra.api.platform.tenant.application;

import com.gsitm.ustra.api.platform.audit.AuditService;
import com.gsitm.ustra.api.platform.common.error.BusinessException;
import com.gsitm.ustra.api.platform.common.error.ErrorCode;
import com.gsitm.ustra.api.platform.outbox.OutboxService;
import com.gsitm.ustra.api.platform.tenant.context.TenantContext;
import com.gsitm.ustra.api.platform.tenant.context.TenantContextResolver;
import com.gsitm.ustra.api.platform.tenant.persistence.MembershipEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.MembershipRepository;
import com.gsitm.ustra.api.platform.tenant.persistence.OrganizationRepository;
import java.time.Clock;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class MembershipService {
    private final TenantContextResolver contextResolver;
    private final TenantPermissionGuard permissionGuard;
    private final MembershipRepository membershipRepository;
    private final OrganizationRepository organizationRepository;
    private final IdentityAuthority identityAuthority;
    private final AuditService auditService;
    private final OutboxService outboxService;
    private final Clock clock;

    public MembershipService(TenantContextResolver contextResolver, TenantPermissionGuard permissionGuard,
                             MembershipRepository membershipRepository, OrganizationRepository organizationRepository,
                             IdentityAuthority identityAuthority, AuditService auditService,
                             OutboxService outboxService, Clock clock) {
        this.contextResolver = contextResolver;
        this.permissionGuard = permissionGuard;
        this.membershipRepository = membershipRepository;
        this.organizationRepository = organizationRepository;
        this.identityAuthority = identityAuthority;
        this.auditService = auditService;
        this.outboxService = outboxService;
        this.clock = clock;
    }

    @Transactional(readOnly = true)
    public List<MembershipEntity> list() {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "MEMBERSHIP:MANAGE", "MEMBERSHIP", "list");
        return membershipRepository.findAllByTenantIdOrderByCreatedAtAsc(context.tenantId());
    }

    @Transactional
    public MembershipEntity add(String principalId, String issuer, String organizationId,
                                Instant effectiveFrom, Instant effectiveTo) {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "MEMBERSHIP:MANAGE", "MEMBERSHIP", "new");
        Cp01Validation.effectivePeriod(effectiveFrom, effectiveTo);
        if (organizationId != null && organizationRepository.findByIdAndTenantId(organizationId, context.tenantId()).isEmpty()) {
            throw new BusinessException(ErrorCode.ORGANIZATION_TENANT_MISMATCH, HttpStatus.BAD_REQUEST,
                    "Membership Organization은 현재 Tenant에 속해야 합니다.");
        }
        if (!identityAuthority.exists(principalId, issuer)) {
            throw new BusinessException(ErrorCode.IDENTITY_NOT_VERIFIED, HttpStatus.BAD_REQUEST,
                    "Identity authority에서 Principal을 확인할 수 없습니다.");
        }
        Instant now = Instant.now(clock);
        MembershipEntity entity = new MembershipEntity(UUID.randomUUID().toString(), context.tenantId(),
                organizationId, principalId, issuer, effectiveFrom, effectiveTo, now);
        membershipRepository.save(entity);
        auditService.success(context.tenantId(), "MEMBERSHIP_ADD", "MEMBERSHIP", entity.getId(), true,
                Map.of("principalId", principalId, "issuer", issuer));
        outboxService.enqueue("MembershipAdded", "MEMBERSHIP", entity.getId(), context.tenantId(),
                Map.of("membershipId", entity.getId()));
        return entity;
    }

    @Transactional
    public MembershipEntity deactivate(String membershipId) {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "MEMBERSHIP:MANAGE", "MEMBERSHIP", membershipId);
        MembershipEntity entity = membershipRepository.findByIdAndTenantId(membershipId, context.tenantId())
                .orElseThrow(() -> new BusinessException(ErrorCode.MEMBERSHIP_NOT_FOUND, HttpStatus.NOT_FOUND,
                        "Membership을 찾을 수 없습니다."));
        entity.deactivate(Instant.now(clock));
        auditService.success(context.tenantId(), "MEMBERSHIP_DEACTIVATE", "MEMBERSHIP", membershipId, true, Map.of());
        outboxService.enqueue("MembershipDeactivated", "MEMBERSHIP", membershipId, context.tenantId(),
                Map.of("membershipId", membershipId));
        return entity;
    }
}

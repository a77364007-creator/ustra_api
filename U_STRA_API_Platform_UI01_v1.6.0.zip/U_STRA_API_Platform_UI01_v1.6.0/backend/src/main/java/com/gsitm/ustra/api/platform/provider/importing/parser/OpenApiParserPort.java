package com.gsitm.ustra.api.platform.provider.importing.parser;

import java.util.List;

public interface OpenApiParserPort {
    ParsedOpenApi parse(String source);

    record ParsedOpenApi(
            String title,
            String description,
            String version,
            List<ParsedOperation> operations) {
    }

    record ParsedOperation(
            String method,
            String path,
            String operationId,
            String summary,
            List<ParsedParameter> parameters,
            List<ParsedBody> requestBodies,
            List<ParsedResponse> responses,
            List<String> securityFingerprints) {
    }

    record ParsedParameter(
            String location,
            String name,
            boolean required,
            String schemaFingerprint,
            String parameterFingerprint) {
    }

    record ParsedBody(
            boolean required,
            String mediaType,
            String schemaFingerprint,
            String bodyFingerprint) {
    }

    record ParsedResponse(
            String responseCode,
            String mediaType,
            String schemaFingerprint,
            String responseFingerprint) {
    }
}

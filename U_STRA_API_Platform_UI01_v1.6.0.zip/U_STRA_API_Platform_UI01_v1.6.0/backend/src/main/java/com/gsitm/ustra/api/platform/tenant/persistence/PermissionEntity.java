package com.gsitm.ustra.api.platform.tenant.persistence;

import com.gsitm.ustra.api.platform.tenant.domain.ReferenceStatus;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "permission")
public class PermissionEntity {
    @Id
    @Column(name = "permission_id", length = 36, nullable = false)
    private String id;

    @Column(name = "permission_code", length = 120, nullable = false, unique = true)
    private String code;

    @Column(name = "resource_type", length = 80, nullable = false)
    private String resourceType;

    @Column(name = "action", length = 80, nullable = false)
    private String action;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", length = 30, nullable = false)
    private ReferenceStatus status;

    protected PermissionEntity() {
    }

    public String getId() { return id; }
    public String getCode() { return code; }
}

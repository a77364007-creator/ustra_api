package com.gsitm.ustra.api.platform.search.application;

import java.util.List;

public interface CatalogSearchPort {
    SearchPage search(SearchRequest request);

    record SearchRequest(String query, String locale, String providerId, int page, int size) {}
    record SearchPage(List<SearchResult> items, int page, int size, long totalElements, boolean hasNext) {}
    record SearchResult(String apiProductId, String productCode, String displayName, String description,
                        String resolvedLocale, String resolutionSource, ProviderSummary provider,
                        List<VisibleVersion> visibleVersions, List<String> matchedLocaleKeys) {}
    record ProviderSummary(String providerId, String providerCode, String displayName) {}
    record VisibleVersion(String apiProductVersionId, String versionValue, String catalogPublicationId) {}
}

package com.gsitm.ustra.api.platform.subscription.approval.domain; public enum ApprovalCanonicalStatus { PENDING, APPROVED, REJECTED, CANCELLED, UNKNOWN }

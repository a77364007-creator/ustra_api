package com.gsitm.ustra.api.platform.change.persistence;
import java.util.Optional; import org.springframework.data.jpa.repository.JpaRepository;
public interface ApiContractSnapshotRepository extends JpaRepository<ApiContractSnapshotEntity,String>{Optional<ApiContractSnapshotEntity> findByTenantIdAndApiVersionId(String tenantId,String apiVersionId);}

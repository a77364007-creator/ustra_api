package com.gsitm.ustra.api.platform.subscription.persistence;
import jakarta.persistence.*; import java.time.Instant;
@Entity @Table(name="subscription_request_revision_operation_scope")
public class SubscriptionRequestRevisionOperationScopeEntity {
 @Id @Column(name="subscription_request_revision_operation_scope_id",length=36,nullable=false,updatable=false) private String id;
 @Column(name="tenant_id",length=36,nullable=false,updatable=false) private String tenantId;
 @Column(name="subscription_request_revision_id",length=36,nullable=false,updatable=false) private String subscriptionRequestRevisionId;
 @Column(name="api_operation_id",length=36,nullable=false,updatable=false) private String apiOperationId;
 @Column(name="created_at",nullable=false,updatable=false) private Instant createdAt;
 @Column(name="created_by",length=200,nullable=false,updatable=false) private String createdBy;
 protected SubscriptionRequestRevisionOperationScopeEntity(){}
 public SubscriptionRequestRevisionOperationScopeEntity(String id,String tenantId,String revisionId,String operationId,Instant now,String actor){this.id=id;this.tenantId=tenantId;this.subscriptionRequestRevisionId=revisionId;this.apiOperationId=operationId;this.createdAt=now;this.createdBy=actor;}
 public String getId(){return id;} public String getTenantId(){return tenantId;} public String getSubscriptionRequestRevisionId(){return subscriptionRequestRevisionId;} public String getApiOperationId(){return apiOperationId;}
}

package com.gsitm.ustra.api.platform.change.persistence;
import jakarta.persistence.*;
@Entity @Table(name="api_contract_response_snapshot")
public class ApiContractResponseSnapshotEntity {
 @Id @Column(name="api_contract_response_snapshot_id",length=36,nullable=false,updatable=false) private String id;
 @Column(name="tenant_id",length=36,nullable=false,updatable=false) private String tenantId;
 @Column(name="api_contract_operation_snapshot_id",length=36,nullable=false,updatable=false) private String operationSnapshotId;
 @Column(name="response_code",length=20,nullable=false,updatable=false) private String responseCode;
 @Column(name="media_type",length=200,nullable=false,updatable=false) private String mediaType;
 @Column(name="schema_fingerprint",length=64,nullable=false,updatable=false) private String schemaFingerprint;
 @Column(name="response_fingerprint",length=64,nullable=false,updatable=false) private String responseFingerprint;
 protected ApiContractResponseSnapshotEntity(){}
 public ApiContractResponseSnapshotEntity(String id,String tenantId,String operationSnapshotId,String responseCode,String mediaType,String schemaFingerprint,String responseFingerprint){this.id=id;this.tenantId=tenantId;this.operationSnapshotId=operationSnapshotId;this.responseCode=responseCode;this.mediaType=mediaType;this.schemaFingerprint=schemaFingerprint;this.responseFingerprint=responseFingerprint;}
 public String getId(){return id;} public String getTenantId(){return tenantId;} public String getOperationSnapshotId(){return operationSnapshotId;} public String getResponseCode(){return responseCode;} public String getMediaType(){return mediaType;} public String getSchemaFingerprint(){return schemaFingerprint;} public String getResponseFingerprint(){return responseFingerprint;}
}

package com.gsitm.ustra.api.platform.integration.approval.persistence;
import java.util.Optional; import org.springframework.data.jpa.repository.JpaRepository;
public interface ProcessedExternalEventRepository extends JpaRepository<ProcessedExternalEventEntity,String>{Optional<ProcessedExternalEventEntity> findByTenantIdAndConnectorInstanceIdAndExternalEventId(String tenantId,String connectorInstanceId,String externalEventId);}

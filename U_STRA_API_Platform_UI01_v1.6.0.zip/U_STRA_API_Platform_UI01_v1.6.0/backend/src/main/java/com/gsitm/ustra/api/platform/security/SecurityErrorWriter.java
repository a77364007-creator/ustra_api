package com.gsitm.ustra.api.platform.security;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gsitm.ustra.api.platform.common.context.RequestContextHolder;
import com.gsitm.ustra.api.platform.common.error.ApiErrorResponse;
import com.gsitm.ustra.api.platform.common.error.ErrorCode;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

@Component
public class SecurityErrorWriter {
    private final ObjectMapper objectMapper;

    public SecurityErrorWriter(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    public void write(HttpServletResponse response, int status, ErrorCode code, String message) throws IOException {
        response.setStatus(status);
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding("UTF-8");
        String correlationId = RequestContextHolder.get().map(c -> c.correlationId()).orElse("unknown");
        objectMapper.writeValue(response.getWriter(), new ApiErrorResponse(code.name(), message, correlationId));
    }
}

package com.gsitm.ustra.api.platform.catalog.publication.application;

import com.gsitm.ustra.api.platform.catalog.domain.ApiProductLifecycleState;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiProductRepository;
import com.gsitm.ustra.api.platform.catalog.publication.domain.ApiProductVersionState;
import com.gsitm.ustra.api.platform.catalog.publication.domain.AudienceScopeType;
import com.gsitm.ustra.api.platform.catalog.publication.domain.CatalogPublicationState;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.ApiProductVersionRepository;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.AudienceScopeRepository;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.CatalogPublicationRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class CatalogVisibilityService {
    private final CatalogPublicationRepository publicationRepository;
    private final AudienceScopeRepository audienceRepository;
    private final ApiProductVersionRepository versionRepository;
    private final ApiProductRepository productRepository;

    public CatalogVisibilityService(CatalogPublicationRepository publicationRepository,
                                    AudienceScopeRepository audienceRepository,
                                    ApiProductVersionRepository versionRepository,
                                    ApiProductRepository productRepository) {
        this.publicationRepository = publicationRepository;
        this.audienceRepository = audienceRepository;
        this.versionRepository = versionRepository;
        this.productRepository = productRepository;
    }

    @Transactional(readOnly = true)
    public boolean isDiscoverable(String tenantId, String organizationId, String publicationId) {
        return publicationRepository.findByIdAndTenantId(publicationId, tenantId)
                .filter(p -> p.getLifecycleState() == CatalogPublicationState.ACTIVE)
                .flatMap(p -> versionRepository.findByIdAndTenantId(p.getApiProductVersionId(), tenantId)
                        .filter(v -> v.getLifecycleState() == ApiProductVersionState.RELEASED)
                        .flatMap(v -> productRepository.findByIdAndTenantId(v.getApiProductId(), tenantId)
                                .filter(product -> product.getLifecycleState() != ApiProductLifecycleState.RETIRED)
                                .map(product -> audienceRepository
                                        .findAllByTenantIdAndCatalogPublicationIdOrderByCreatedAtAsc(tenantId, publicationId)
                                        .stream().anyMatch(scope -> scope.getScopeType() == AudienceScopeType.TENANT
                                                || (scope.getScopeType() == AudienceScopeType.ORGANIZATION
                                                && scope.getOrganizationId().equals(organizationId))))))
                .orElse(false);
    }
}

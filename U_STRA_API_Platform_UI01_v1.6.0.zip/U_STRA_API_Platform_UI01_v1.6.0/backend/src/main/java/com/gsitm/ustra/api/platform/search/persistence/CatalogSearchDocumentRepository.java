package com.gsitm.ustra.api.platform.search.persistence;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CatalogSearchDocumentRepository extends JpaRepository<CatalogSearchDocumentEntity, String> {
    List<CatalogSearchDocumentEntity> findAllByTenantIdOrderByApiProductIdAscLocaleKeyAsc(String tenantId);
    List<CatalogSearchDocumentEntity> findAllByTenantIdAndApiProductIdOrderByLocaleKeyAsc(String tenantId, String apiProductId);
    long deleteByTenantId(String tenantId);
    long deleteByTenantIdAndApiProductId(String tenantId, String apiProductId);
    long countByTenantId(String tenantId);
}

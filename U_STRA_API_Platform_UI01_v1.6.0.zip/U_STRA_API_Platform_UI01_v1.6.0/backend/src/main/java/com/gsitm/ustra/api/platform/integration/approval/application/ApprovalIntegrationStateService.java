package com.gsitm.ustra.api.platform.integration.approval.application;

import com.gsitm.ustra.api.platform.audit.AuditService;
import com.gsitm.ustra.api.platform.common.error.*;
import com.gsitm.ustra.api.platform.integration.approval.domain.*;
import com.gsitm.ustra.api.platform.integration.approval.persistence.*;
import com.gsitm.ustra.api.platform.outbox.OutboxService;
import com.gsitm.ustra.api.platform.security.AuthenticatedIdentityProvider;
import com.gsitm.ustra.api.platform.subscription.approval.application.*;
import com.gsitm.ustra.api.platform.subscription.approval.persistence.*;
import com.gsitm.ustra.api.platform.subscription.entitlement.application.ApprovedSubscriptionDecisionPort;
import java.time.*; import java.util.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ApprovalIntegrationStateService {
    private static final String AGGREGATE_REQUEST="SUBSCRIPTION_REQUEST";
    private static final String AGGREGATE_APPROVAL="APPROVAL_REFERENCE";
    private static final String ISSUE_CREATE_UNKNOWN="CREATE_OUTCOME_UNKNOWN";
    private static final String ISSUE_QUERY_UNKNOWN="STATUS_QUERY_UNKNOWN";

    private final ApprovalStateService approvalState;
    private final ApprovalReferenceRepository approvalReferences;
    private final TenantApprovalConnectorResolver connectorResolver;
    private final IntegrationOperationRepository operations;
    private final ReconciliationIssueService issues;
    private final ApprovedSubscriptionDecisionPort materializer;
    private final AuditService audit;
    private final OutboxService outbox;
    private final AuthenticatedIdentityProvider identity;
    private final Clock clock;

    public ApprovalIntegrationStateService(ApprovalStateService approvalState, ApprovalReferenceRepository approvalReferences,
            TenantApprovalConnectorResolver connectorResolver, IntegrationOperationRepository operations,
            ReconciliationIssueService issues, ApprovedSubscriptionDecisionPort materializer,
            AuditService audit, OutboxService outbox, AuthenticatedIdentityProvider identity, Clock clock) {
        this.approvalState=approvalState; this.approvalReferences=approvalReferences; this.connectorResolver=connectorResolver;
        this.operations=operations; this.issues=issues; this.materializer=materializer; this.audit=audit;
        this.outbox=outbox; this.identity=identity; this.clock=clock;
    }

    @Transactional
    public PreparedCreate prepareCreate(String tenantId,String requestId) {
        ApprovalPort.CaseCommand command=approvalState.caseCommand(tenantId,requestId);
        var existing=operations.findByTenantIdAndOperationTypeAndAggregateIdAndAggregateRevision(
                tenantId,IntegrationOperationType.APPROVAL_CASE_CREATE,requestId,command.requestRevisionNo());
        if(existing.isPresent()){ConnectorInstanceEntity connector=connectorResolver.ownedEnabled(tenantId,existing.get().getConnectorInstanceId());return new PreparedCreate(existing.get(),command,connector,existing.get().getStatus()==IntegrationOperationStatus.REQUESTED);}
        ConnectorInstanceEntity connector=connectorResolver.resolve(tenantId);
        Instant now=Instant.now(clock); String actor=identity.current().principalId();
        IntegrationOperationEntity op=operations.saveAndFlush(new IntegrationOperationEntity(
                UUID.randomUUID().toString(),tenantId,connector.getId(),IntegrationOperationType.APPROVAL_CASE_CREATE,
                AGGREGATE_REQUEST,requestId,command.requestRevisionNo(),command.snapshotHash(),UUID.randomUUID().toString(),null,now,actor));
        audit.success(tenantId,"APPROVAL_INTEGRATION_CREATE_REQUESTED","INTEGRATION_OPERATION",op.getId(),true,
                Map.of("subscriptionRequestId",requestId,"requestRevisionNo",command.requestRevisionNo(),"connectorInstanceId",connector.getId()));
        return new PreparedCreate(op,command,connector,true);
    }

    @Transactional
    public IntegrationOperationEntity beginOutbound(String tenantId,String operationId) {
        IntegrationOperationEntity op=owned(tenantId,operationId);
        if(op.getStatus()!=IntegrationOperationStatus.REQUESTED) throw state("REQUESTED IntegrationOperation만 외부 호출을 시작할 수 있습니다.");
        Instant now=Instant.now(clock); String actor=identity.current().principalId(); op.begin(now,actor); op=operations.saveAndFlush(op);
        audit.success(tenantId,"APPROVAL_INTEGRATION_OUTBOUND_BEGIN","INTEGRATION_OPERATION",op.getId(),true,
                Map.of("operationType",op.getOperationType().name(),"attemptCount",op.getAttemptCount()));
        return op;
    }

    @Transactional
    public ApprovalReferenceEntity completeCreate(String tenantId,String operationId,ApprovalPort.CaseCommand command,ApprovalPort.CaseReference external) {
        IntegrationOperationEntity op=owned(tenantId,operationId); requireInProgress(op);
        ConnectorInstanceEntity connector=connectorResolver.owned(tenantId,op.getConnectorInstanceId());
        if(external==null||external.externalCaseRef()==null||external.externalCaseRef().isBlank()) throw state("성공한 Approval case 생성에는 external case reference가 필요합니다.");
        if(!connector.getAuthorityCode().equals(external.authorityCode())) throw new BusinessException(ErrorCode.APPROVAL_REFERENCE_CONFLICT,HttpStatus.CONFLICT,"Connector authority와 외부 Case authority가 일치하지 않습니다.");
        ApprovalReferenceEntity ref=approvalState.recordCase(command,external);
        Instant now=Instant.now(clock);String actor=identity.current().principalId();op.succeed(external.externalCaseRef(),external.workflowVersion(),now,actor);operations.saveAndFlush(op);
        issues.resolve(tenantId,op.getId(),ISSUE_CREATE_UNKNOWN,actor);
        outbox.enqueue("ApprovalIntegrationCaseCreated","INTEGRATION_OPERATION",op.getId(),tenantId,
                Map.of("integrationOperationId",op.getId(),"approvalReferenceId",ref.getId(),"subscriptionRequestId",command.subscriptionRequestId(),"authorityCode",external.authorityCode()));
        return ref;
    }

    @Transactional
    public IntegrationOperationEntity markUnknown(String tenantId,String operationId,String issueType,String safeCode,String externalReference) {
        IntegrationOperationEntity op=owned(tenantId,operationId); requireInProgress(op);Instant now=Instant.now(clock);String actor=identity.current().principalId();
        op.unknown("UNCERTAIN_EXTERNAL_EFFECT",safe(safeCode),externalReference,now,actor);op=operations.saveAndFlush(op);
        issues.open(tenantId,op.getId(),issueType,safe(safeCode),actor);
        audit.success(tenantId,"APPROVAL_INTEGRATION_UNKNOWN","INTEGRATION_OPERATION",op.getId(),true,
                Map.of("operationType",op.getOperationType().name(),"safeErrorCode",safeValue(safeCode)));
        return op;
    }

    @Transactional
    public IntegrationOperationEntity markFailed(String tenantId,String operationId,String safeCode) {
        IntegrationOperationEntity op=owned(tenantId,operationId); requireInProgress(op);Instant now=Instant.now(clock);String actor=identity.current().principalId();
        op.fail("DEFINITIVE_CONNECTOR_FAILURE",safe(safeCode),now,actor);op=operations.saveAndFlush(op);
        audit.success(tenantId,"APPROVAL_INTEGRATION_FAILED","INTEGRATION_OPERATION",op.getId(),true,
                Map.of("operationType",op.getOperationType().name(),"safeErrorCode",safeValue(safeCode)));
        return op;
    }

    @Transactional
    public PreparedQuery prepareQuery(String tenantId,String approvalReferenceId) {
        ApprovalReferenceEntity ref=approvalReferences.findByIdAndTenantId(approvalReferenceId,tenantId)
                .orElseThrow(()->new BusinessException(ErrorCode.APPROVAL_REFERENCE_NOT_FOUND,HttpStatus.NOT_FOUND,"ApprovalReference를 찾을 수 없습니다."));
        IntegrationOperationEntity create=operations.findByTenantIdAndOperationTypeAndAggregateIdAndAggregateRevision(
                tenantId,IntegrationOperationType.APPROVAL_CASE_CREATE,ref.getSubscriptionRequestId(),ref.getRequestRevisionNo())
                .orElseThrow(()->new BusinessException(ErrorCode.INTEGRATION_OPERATION_NOT_FOUND,HttpStatus.CONFLICT,"Approval case 생성 IntegrationOperation을 찾을 수 없습니다."));
        if(create.getStatus()!=IntegrationOperationStatus.SUCCEEDED) throw state("성공적으로 생성된 Approval case만 상태를 조회할 수 있습니다.");
        ConnectorInstanceEntity connector=connectorResolver.ownedEnabled(tenantId,create.getConnectorInstanceId());
        Instant now=Instant.now(clock);String actor=identity.current().principalId();
        IntegrationOperationEntity query=operations.saveAndFlush(new IntegrationOperationEntity(
                UUID.randomUUID().toString(),tenantId,connector.getId(),IntegrationOperationType.APPROVAL_STATUS_QUERY,
                AGGREGATE_APPROVAL,ref.getId(),null,ref.getSnapshotHash(),UUID.randomUUID().toString(),create.getId(),now,actor));
        return new PreparedQuery(query,ref,connector);
    }

    @Transactional
    public DecisionResult completeQuery(String tenantId,String operationId,String approvalReferenceId,ApprovalPort.Decision decision) {
        IntegrationOperationEntity op=owned(tenantId,operationId); requireInProgress(op);
        ApprovalReferenceEntity ref=approvalReferences.findByIdAndTenantId(approvalReferenceId,tenantId)
                .orElseThrow(()->new BusinessException(ErrorCode.APPROVAL_REFERENCE_NOT_FOUND,HttpStatus.NOT_FOUND,"ApprovalReference를 찾을 수 없습니다."));
        if(!ref.getExternalCaseRef().equals(decision.externalCaseRef())) throw new BusinessException(ErrorCode.APPROVAL_DECISION_MISMATCH,HttpStatus.CONFLICT,"조회된 승인결정의 external case reference가 다릅니다.");
        ApprovalStateService.DecisionProjection projection=null;
        if(decision.status()!=ApprovalPort.DecisionStatus.PENDING){
            projection=approvalState.synchronizeDecision(tenantId,approvalReferenceId,decision);
            if(decision.status()==ApprovalPort.DecisionStatus.APPROVED){materializer.materialize(projection.toApprovedDecision());approvalState.complete(tenantId,approvalReferenceId);}
        }
        Instant now=Instant.now(clock);String actor=identity.current().principalId();op.succeed(ref.getExternalCaseRef(),ref.getWorkflowVersion(),now,actor);operations.saveAndFlush(op);for(var previous:operations.findAllByTenantIdAndAggregateTypeAndAggregateIdOrderByCreatedAtDesc(tenantId,AGGREGATE_APPROVAL,approvalReferenceId)){issues.resolve(tenantId,previous.getId(),ISSUE_QUERY_UNKNOWN,actor);}
        audit.success(tenantId,"APPROVAL_INTEGRATION_STATUS_SYNCHRONIZED","APPROVAL_REFERENCE",approvalReferenceId,true,
                Map.of("integrationOperationId",op.getId(),"canonicalDecision",decision.status().name()));
        return new DecisionResult(op,decision.status(),projection);
    }

    @Transactional(readOnly=true)
    public boolean hasUnresolvedCaseCreation(String tenantId,String requestId,int revisionNo) {
        return operations.findByTenantIdAndOperationTypeAndAggregateIdAndAggregateRevision(tenantId,IntegrationOperationType.APPROVAL_CASE_CREATE,requestId,revisionNo)
                .map(op->op.getStatus()!=IntegrationOperationStatus.FAILED&&op.getStatus()!=IntegrationOperationStatus.CANCELLED).orElse(false);
    }

    @Transactional(readOnly=true) public IntegrationOperationEntity owned(String tenantId,String operationId){return operations.findByIdAndTenantId(operationId,tenantId).orElseThrow(()->new BusinessException(ErrorCode.INTEGRATION_OPERATION_NOT_FOUND,HttpStatus.NOT_FOUND,"IntegrationOperation을 찾을 수 없습니다."));}
    private void requireInProgress(IntegrationOperationEntity op){if(op.getStatus()!=IntegrationOperationStatus.IN_PROGRESS)throw state("IN_PROGRESS IntegrationOperation만 결과를 반영할 수 있습니다.");}
    private BusinessException state(String message){return new BusinessException(ErrorCode.INTEGRATION_OPERATION_STATE_INVALID,HttpStatus.CONFLICT,message);} private String safe(String v){return v==null||v.isBlank()?"UNSPECIFIED":v.trim();} private String safeValue(String v){return v==null?"":v;}
    public static String createUnknownIssueType(){return ISSUE_CREATE_UNKNOWN;} public static String queryUnknownIssueType(){return ISSUE_QUERY_UNKNOWN;}
    public record PreparedCreate(IntegrationOperationEntity operation,ApprovalPort.CaseCommand command,ConnectorInstanceEntity connector,boolean invokeRequired){}
    public record PreparedQuery(IntegrationOperationEntity operation,ApprovalReferenceEntity approvalReference,ConnectorInstanceEntity connector){}
    public record DecisionResult(IntegrationOperationEntity operation,ApprovalPort.DecisionStatus decisionStatus,ApprovalStateService.DecisionProjection projection){}
}

package com.gsitm.ustra.api.platform.provider.publishing.application;

/**
 * Boundary for publication authorities that are confirmed by design but not yet physically defined in CP-10.
 * Implementations must resolve authoritative state; callers fail closed when an authority is unresolved.
 */
public interface PublishAuthorityPort {
    AuthorityStatus resolve(String tenantId, String apiProductId, String apiProductVersionId);

    record AuthorityStatus(
            boolean classificationResolved,
            boolean accessPolicyResolved,
            boolean requiredLocalePolicyResolved,
            boolean termsVersionResolved,
            boolean criticalFindingAuthorityResolved) {
    }
}

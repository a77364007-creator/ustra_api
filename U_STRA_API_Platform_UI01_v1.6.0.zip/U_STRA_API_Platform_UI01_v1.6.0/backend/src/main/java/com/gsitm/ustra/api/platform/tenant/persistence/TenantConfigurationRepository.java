package com.gsitm.ustra.api.platform.tenant.persistence;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TenantConfigurationRepository extends JpaRepository<TenantConfigurationEntity, String> {
    Optional<TenantConfigurationEntity> findByTenantId(String tenantId);
}

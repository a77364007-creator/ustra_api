package com.gsitm.ustra.api.platform.change.api;

import com.gsitm.ustra.api.platform.change.application.ApiChangeAssessmentService;
import com.gsitm.ustra.api.platform.change.persistence.ApiChangeEntity;
import com.gsitm.ustra.api.platform.change.persistence.ApiChangeItemEntity;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import java.time.Instant;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/api-changes")
public class ApiChangeController {
    private final ApiChangeAssessmentService service;
    public ApiChangeController(ApiChangeAssessmentService service){this.service=service;}

    @PostMapping("/assessments")
    public ResponseEntity<ApiChangeResponse> assess(
            @RequestHeader(value="Idempotency-Key",required=false) String idempotencyKey,
            @Valid @RequestBody AssessmentRequest request){
        ApiChangeEntity entity=service.assess(request.baselineApiVersionId(),request.targetApiVersionId(),idempotencyKey);
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiChangeResponse.from(entity));
    }

    @GetMapping("/{apiChangeId}")
    public ApiChangeResponse get(@PathVariable String apiChangeId){return ApiChangeResponse.from(service.get(apiChangeId));}

    @GetMapping("/{apiChangeId}/items")
    public List<ApiChangeItemResponse> items(@PathVariable String apiChangeId){return service.items(apiChangeId).stream().map(ApiChangeItemResponse::from).toList();}

    public record AssessmentRequest(@NotBlank String baselineApiVersionId,@NotBlank String targetApiVersionId){}
    public record ApiChangeResponse(String apiChangeId,String apiId,String baselineApiVersionId,String targetApiVersionId,String assessmentStatus,String compatibilityResult,String baselineStructuralHash,String targetStructuralHash,String ruleSetVersion,String changeSummaryHash,Instant assessedAt,long revision){
        static ApiChangeResponse from(ApiChangeEntity e){return new ApiChangeResponse(e.getId(),e.getApiId(),e.getBaselineApiVersionId(),e.getTargetApiVersionId(),e.getAssessmentStatus().name(),e.getCompatibilityResult()==null?null:e.getCompatibilityResult().name(),e.getBaselineStructuralHash(),e.getTargetStructuralHash(),e.getRuleSetVersion(),e.getChangeSummaryHash(),e.getAssessedAt(),e.getRowVersion());}
    }
    public record ApiChangeItemResponse(String apiChangeItemId,String changeKind,String method,String normalizedPath,String contractLocation,String compatibilityEffect,String evidenceCode){
        static ApiChangeItemResponse from(ApiChangeItemEntity e){return new ApiChangeItemResponse(e.getId(),e.getChangeKind().name(),e.getMethod(),e.getNormalizedPath(),e.getContractLocation(),e.getCompatibilityEffect().name(),e.getEvidenceCode());}
    }
}

package com.gsitm.ustra.api.platform.tenant.api;

import com.gsitm.ustra.api.platform.tenant.application.OrganizationService;
import com.gsitm.ustra.api.platform.tenant.persistence.OrganizationEntity;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import java.util.List;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/organizations")
public class OrganizationController {
    private final OrganizationService service;

    public OrganizationController(OrganizationService service) {
        this.service = service;
    }

    @GetMapping
    public List<OrganizationResponse> list() {
        return service.list().stream().map(OrganizationResponse::from).toList();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public OrganizationResponse create(@Valid @RequestBody CreateOrganizationRequest request) {
        return OrganizationResponse.from(service.create(request.organizationCode(), request.displayName(),
                request.parentOrganizationId()));
    }

    @PatchMapping("/{organizationId}")
    public ResponseEntity<OrganizationResponse> update(
            @PathVariable String organizationId,
            @RequestHeader(value = HttpHeaders.IF_MATCH, required = false) String ifMatch,
            @Valid @RequestBody UpdateOrganizationRequest request) {
        OrganizationEntity entity = service.update(organizationId, VersionHeaderParser.parse(ifMatch),
                request.displayName(), request.parentOrganizationId());
        return ResponseEntity.ok().eTag(VersionHeaderParser.etag(entity.getRowVersion()))
                .body(OrganizationResponse.from(entity));
    }

    @PostMapping("/{organizationId}/deactivate")
    public OrganizationResponse deactivate(@PathVariable String organizationId) {
        return OrganizationResponse.from(service.deactivate(organizationId));
    }

    public record CreateOrganizationRequest(
            @NotBlank @Size(max = 80) String organizationCode,
            @NotBlank @Size(max = 200) String displayName,
            String parentOrganizationId) {
    }

    public record UpdateOrganizationRequest(@NotBlank @Size(max = 200) String displayName,
                                            String parentOrganizationId) {
    }

    public record OrganizationResponse(String organizationId, String organizationCode, String displayName,
                                       String parentOrganizationId, String status, long version) {
        static OrganizationResponse from(OrganizationEntity entity) {
            return new OrganizationResponse(entity.getId(), entity.getCode(), entity.getDisplayName(),
                    entity.getParentOrganizationId(), entity.getStatus().name(), entity.getRowVersion());
        }
    }
}

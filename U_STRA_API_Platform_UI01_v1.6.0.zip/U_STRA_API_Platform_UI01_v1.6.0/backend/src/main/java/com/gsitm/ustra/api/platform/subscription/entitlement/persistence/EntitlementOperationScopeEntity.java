package com.gsitm.ustra.api.platform.subscription.entitlement.persistence;
import jakarta.persistence.*; import java.time.Instant;
@Entity @Table(name="entitlement_operation_scope")
public class EntitlementOperationScopeEntity {
 @Id @Column(name="entitlement_operation_scope_id",length=36,nullable=false,updatable=false) private String id;
 @Column(name="tenant_id",length=36,nullable=false,updatable=false) private String tenantId;
 @Column(name="entitlement_id",length=36,nullable=false,updatable=false) private String entitlementId;
 @Column(name="api_operation_id",length=36,nullable=false,updatable=false) private String apiOperationId;
 @Column(name="created_at",nullable=false,updatable=false) private Instant createdAt;
 @Column(name="created_by",length=200,nullable=false,updatable=false) private String createdBy;
 protected EntitlementOperationScopeEntity(){}
 public EntitlementOperationScopeEntity(String id,String tenantId,String entitlementId,String operationId,Instant now,String actor){this.id=id;this.tenantId=tenantId;this.entitlementId=entitlementId;this.apiOperationId=operationId;this.createdAt=now;this.createdBy=actor;}
 public String getId(){return id;} public String getTenantId(){return tenantId;} public String getEntitlementId(){return entitlementId;} public String getApiOperationId(){return apiOperationId;}
}

package com.gsitm.ustra.api.platform.provider.publishing.infrastructure;

import com.gsitm.ustra.api.platform.provider.publishing.application.PublishAuthorityPort;
import org.springframework.stereotype.Component;

/**
 * Fail-closed CP-10 adapter. It deliberately invents no classification, access-policy, locale,
 * terms, or finding vocabulary. A later authoritative package must replace this boundary.
 */
@Component
public class UnresolvedPublishAuthorityAdapter implements PublishAuthorityPort {
    @Override
    public AuthorityStatus resolve(String tenantId, String apiProductId, String apiProductVersionId) {
        return new AuthorityStatus(false, false, false, false, false);
    }
}

package com.gsitm.ustra.api.platform.catalog.localization.application;

import com.gsitm.ustra.api.platform.catalog.localization.domain.LocalizationStatus;
import com.gsitm.ustra.api.platform.catalog.localization.persistence.LocalizedContentEntity;
import com.gsitm.ustra.api.platform.catalog.localization.persistence.LocalizedContentRepository;
import com.gsitm.ustra.api.platform.outbox.OutboxService;
import java.time.Clock;
import java.time.Instant;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class LocalizationStalenessService {
    private final LocalizedContentRepository repository;
    private final OutboxService outboxService;
    private final Clock clock;

    public LocalizationStalenessService(LocalizedContentRepository repository, OutboxService outboxService, Clock clock) {
        this.repository = repository;
        this.outboxService = outboxService;
        this.clock = clock;
    }

    public int markPublishedStale(String tenantId, String apiProductId, long currentSourceRevision, String actor) {
        Instant now = Instant.now(clock);
        int changed = 0;
        for (LocalizedContentEntity content : repository.findAllByTenantIdAndApiProductIdAndStatus(
                tenantId, apiProductId, LocalizationStatus.PUBLISHED)) {
            if (!content.markStale(now, actor)) {
                continue;
            }
            changed++;
            outboxService.enqueue("LocalizationUpdated", "API_PRODUCT_LOCALIZATION", content.getId(), tenantId,
                    Map.of(
                            "apiProductId", apiProductId,
                            "locale", content.getLocale(),
                            "status", LocalizationStatus.STALE.name(),
                            "sourceLocalizationRevision", content.getSourceLocalizationRevision(),
                            "currentLocalizationRevision", currentSourceRevision));
        }
        return changed;
    }
}

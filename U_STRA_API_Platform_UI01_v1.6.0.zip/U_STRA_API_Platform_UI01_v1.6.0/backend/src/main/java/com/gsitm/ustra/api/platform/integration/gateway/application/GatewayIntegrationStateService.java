package com.gsitm.ustra.api.platform.integration.gateway.application;

import com.gsitm.ustra.api.platform.audit.AuditService;
import com.gsitm.ustra.api.platform.common.error.BusinessException;
import com.gsitm.ustra.api.platform.common.error.ErrorCode;
import com.gsitm.ustra.api.platform.integration.approval.application.ReconciliationIssueService;
import com.gsitm.ustra.api.platform.integration.approval.domain.IntegrationOperationStatus;
import com.gsitm.ustra.api.platform.integration.approval.domain.IntegrationOperationType;
import com.gsitm.ustra.api.platform.integration.approval.persistence.ConnectorInstanceEntity;
import com.gsitm.ustra.api.platform.integration.approval.persistence.IntegrationOperationEntity;
import com.gsitm.ustra.api.platform.integration.approval.persistence.IntegrationOperationRepository;
import com.gsitm.ustra.api.platform.security.AuthenticatedIdentityProvider;
import com.gsitm.ustra.api.platform.subscription.entitlement.domain.AccessFulfillmentStatus;
import com.gsitm.ustra.api.platform.subscription.entitlement.domain.AccessFulfillmentType;
import com.gsitm.ustra.api.platform.subscription.entitlement.persistence.AccessFulfillmentEntity;
import com.gsitm.ustra.api.platform.subscription.entitlement.persistence.AccessFulfillmentRepository;
import com.gsitm.ustra.api.platform.subscription.gateway.application.GatewayFulfillmentStateService;
import com.gsitm.ustra.api.platform.subscription.gateway.application.GatewayPort;
import java.time.Clock;
import java.time.Instant;
import java.util.Map;
import java.util.UUID;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class GatewayIntegrationStateService {
    private static final String AGGREGATE_FULFILLMENT = "ACCESS_FULFILLMENT";
    private static final String ISSUE_GATEWAY_UNKNOWN = "GATEWAY_EFFECT_UNKNOWN";

    private final AccessFulfillmentRepository fulfillments;
    private final IntegrationOperationRepository operations;
    private final TenantGatewayConnectorResolver connectorResolver;
    private final GatewayFulfillmentStateService gatewayState;
    private final ReconciliationIssueService issues;
    private final AuditService audit;
    private final AuthenticatedIdentityProvider identity;
    private final Clock clock;

    public GatewayIntegrationStateService(
            AccessFulfillmentRepository fulfillments,
            IntegrationOperationRepository operations,
            TenantGatewayConnectorResolver connectorResolver,
            GatewayFulfillmentStateService gatewayState,
            ReconciliationIssueService issues,
            AuditService audit,
            AuthenticatedIdentityProvider identity,
            Clock clock) {
        this.fulfillments = fulfillments;
        this.operations = operations;
        this.connectorResolver = connectorResolver;
        this.gatewayState = gatewayState;
        this.issues = issues;
        this.audit = audit;
        this.identity = identity;
        this.clock = clock;
    }

    @Transactional
    public PreparedEffect prepareEffect(String tenantId, String fulfillmentId) {
        AccessFulfillmentEntity fulfillment = ownedFulfillment(tenantId, fulfillmentId);
        IntegrationOperationType type = operationType(fulfillment.getFulfillmentType());
        var existing = operations.findByTenantIdAndOperationTypeAndAggregateIdAndAggregateRevision(
                tenantId, type, fulfillmentId, fulfillment.getFulfillmentRevision());
        if (existing.isPresent()) {
            ConnectorInstanceEntity connector =
                    connectorResolver.ownedEnabled(tenantId, existing.get().getConnectorInstanceId());
            boolean invokeRequired = existing.get().getStatus() == IntegrationOperationStatus.REQUESTED;
            return new PreparedEffect(existing.get(), fulfillment.getFulfillmentType(), connector, invokeRequired);
        }
        if (fulfillment.getStatus() != AccessFulfillmentStatus.PENDING) {
            throw state("신규 Gateway 외부효과는 PENDING Fulfillment에서만 준비할 수 있습니다.");
        }

        ConnectorInstanceEntity connector = connectorResolver.resolve(tenantId);
        Instant now = Instant.now(clock);
        String actor = identity.current().principalId();
        IntegrationOperationEntity operation = operations.saveAndFlush(new IntegrationOperationEntity(
                UUID.randomUUID().toString(),
                tenantId,
                connector.getId(),
                type,
                AGGREGATE_FULFILLMENT,
                fulfillmentId,
                fulfillment.getFulfillmentRevision(),
                fulfillment.getRequestFingerprint(),
                "gateway-effect:" + fulfillmentId + ":" + fulfillment.getFulfillmentRevision(),
                null,
                now,
                actor));
        audit.success(
                tenantId,
                "GATEWAY_INTEGRATION_EFFECT_REQUESTED",
                "INTEGRATION_OPERATION",
                operation.getId(),
                true,
                Map.of(
                        "accessFulfillmentId", fulfillmentId,
                        "operationType", type.name(),
                        "connectorInstanceId", connector.getId()));
        return new PreparedEffect(operation, fulfillment.getFulfillmentType(), connector, true);
    }

    @Transactional
    public OutboundEffect beginOutbound(
            String tenantId,
            String operationId,
            String fulfillmentId) {
        IntegrationOperationEntity operation = ownedOperation(tenantId, operationId);
        if (operation.getStatus() != IntegrationOperationStatus.REQUESTED) {
            throw state("REQUESTED Gateway IntegrationOperation만 외부 호출을 시작할 수 있습니다.");
        }
        ConnectorInstanceEntity connector =
                connectorResolver.ownedEnabled(tenantId, operation.getConnectorInstanceId());
        AccessFulfillmentEntity fulfillment = ownedFulfillment(tenantId, fulfillmentId);
        GatewayPort.Command command = gatewayState.begin(tenantId, fulfillmentId);

        Instant now = Instant.now(clock);
        String actor = identity.current().principalId();
        operation.begin(now, actor);
        operation = operations.saveAndFlush(operation);
        audit.success(
                tenantId,
                "GATEWAY_INTEGRATION_OUTBOUND_BEGIN",
                "INTEGRATION_OPERATION",
                operation.getId(),
                true,
                Map.of(
                        "accessFulfillmentId", fulfillmentId,
                        "operationType", operation.getOperationType().name(),
                        "attemptCount", operation.getAttemptCount()));
        return new OutboundEffect(operation, fulfillment.getFulfillmentType(), connector, command);
    }

    @Transactional
    public EffectResult completeEffect(
            String tenantId,
            String operationId,
            String fulfillmentId,
            GatewayPort.Result result) {
        IntegrationOperationEntity operation = ownedOperation(tenantId, operationId);
        requireInProgress(operation);
        ConnectorInstanceEntity connector =
                connectorResolver.owned(tenantId, operation.getConnectorInstanceId());

        AccessFulfillmentEntity fulfillment =
                gatewayState.apply(tenantId, fulfillmentId, result, connector.getAuthorityCode());

        Instant now = Instant.now(clock);
        String actor = identity.current().principalId();
        switch (result.status()) {
            case SUCCEEDED -> {
                operation.succeed(result.externalOperationRef(), null, now, actor);
                issues.resolve(tenantId, operation.getId(), ISSUE_GATEWAY_UNKNOWN, actor);
            }
            case FAILED -> {
                operation.fail("DEFINITIVE_GATEWAY_FAILURE", safe(result.safeErrorCode()), now, actor);
                issues.resolve(tenantId, operation.getId(), ISSUE_GATEWAY_UNKNOWN, actor);
            }
            case UNKNOWN -> {
                operation.unknown(
                        "UNCERTAIN_EXTERNAL_EFFECT",
                        safe(result.safeErrorCode()),
                        result.externalOperationRef(),
                        now,
                        actor);
                issues.open(
                        tenantId,
                        operation.getId(),
                        ISSUE_GATEWAY_UNKNOWN,
                        safe(result.safeErrorCode()),
                        actor);
            }
        }
        operation = operations.saveAndFlush(operation);
        audit.success(
                tenantId,
                "GATEWAY_INTEGRATION_EFFECT_RESULT",
                "INTEGRATION_OPERATION",
                operation.getId(),
                true,
                Map.of(
                        "operationType", operation.getOperationType().name(),
                        "operationStatus", operation.getStatus().name(),
                        "fulfillmentStatus", fulfillment.getStatus().name(),
                        "safeErrorCode", safeValue(result.safeErrorCode())));
        return new EffectResult(operation, fulfillment);
    }

    @Transactional
    public EffectResult markOutboundExceptionUnknown(
            String tenantId,
            String operationId,
            String fulfillmentId,
            String safeCode) {
        IntegrationOperationEntity operation = ownedOperation(tenantId, operationId);
        requireInProgress(operation);
        AccessFulfillmentEntity fulfillment = ownedFulfillment(tenantId, fulfillmentId);
        GatewayPort.Result unknown = new GatewayPort.Result(
                GatewayPort.ResultStatus.UNKNOWN,
                fulfillment.getExternalOperationRef(),
                null,
                null,
                null,
                safe(safeCode));
        return completeEffect(tenantId, operationId, fulfillmentId, unknown);
    }

    @Transactional
    public PreparedQuery prepareQuery(String tenantId, String fulfillmentId) {
        AccessFulfillmentEntity fulfillment = ownedFulfillment(tenantId, fulfillmentId);
        if (fulfillment.getStatus() != AccessFulfillmentStatus.UNKNOWN
                && fulfillment.getStatus() != AccessFulfillmentStatus.FAILED) {
            throw state("UNKNOWN/FAILED Fulfillment만 Gateway reconciliation을 시작할 수 있습니다.");
        }
        IntegrationOperationType effectType = operationType(fulfillment.getFulfillmentType());
        IntegrationOperationEntity effect = operations
                .findByTenantIdAndOperationTypeAndAggregateIdAndAggregateRevision(
                        tenantId, effectType, fulfillmentId, fulfillment.getFulfillmentRevision())
                .orElseThrow(() -> new BusinessException(
                        ErrorCode.INTEGRATION_OPERATION_NOT_FOUND,
                        HttpStatus.CONFLICT,
                        "원본 Gateway IntegrationOperation을 찾을 수 없습니다."));
        ConnectorInstanceEntity connector =
                connectorResolver.ownedEnabled(tenantId, effect.getConnectorInstanceId());

        Instant now = Instant.now(clock);
        String actor = identity.current().principalId();
        IntegrationOperationEntity query = operations.saveAndFlush(new IntegrationOperationEntity(
                UUID.randomUUID().toString(),
                tenantId,
                connector.getId(),
                IntegrationOperationType.GATEWAY_STATUS_QUERY,
                AGGREGATE_FULFILLMENT,
                fulfillmentId,
                null,
                fulfillment.getRequestFingerprint(),
                "gateway-query:" + UUID.randomUUID(),
                effect.getId(),
                now,
                actor));
        return new PreparedQuery(query, effect, connector);
    }

    @Transactional
    public OutboundQuery beginQuery(
            String tenantId,
            String queryOperationId,
            String fulfillmentId) {
        IntegrationOperationEntity query = ownedOperation(tenantId, queryOperationId);
        if (query.getOperationType() != IntegrationOperationType.GATEWAY_STATUS_QUERY
                || query.getStatus() != IntegrationOperationStatus.REQUESTED) {
            throw state("REQUESTED GATEWAY_STATUS_QUERY만 외부 조회를 시작할 수 있습니다.");
        }
        ConnectorInstanceEntity connector =
                connectorResolver.ownedEnabled(tenantId, query.getConnectorInstanceId());
        GatewayPort.StatusQuery statusQuery = gatewayState.beginReconcile(tenantId, fulfillmentId);
        Instant now = Instant.now(clock);
        String actor = identity.current().principalId();
        query.begin(now, actor);
        query = operations.saveAndFlush(query);
        return new OutboundQuery(query, connector, statusQuery);
    }

    @Transactional
    public EffectResult completeQuery(
            String tenantId,
            String queryOperationId,
            String fulfillmentId,
            GatewayPort.Result result) {
        IntegrationOperationEntity query = ownedOperation(tenantId, queryOperationId);
        requireInProgress(query);
        ConnectorInstanceEntity connector =
                connectorResolver.owned(tenantId, query.getConnectorInstanceId());
        AccessFulfillmentEntity fulfillment =
                gatewayState.apply(tenantId, fulfillmentId, result, connector.getAuthorityCode());

        Instant now = Instant.now(clock);
        String actor = identity.current().principalId();
        if (result.status() == GatewayPort.ResultStatus.SUCCEEDED) {
            query.succeed(result.externalOperationRef(), null, now, actor);
            resolveOriginalUnknown(tenantId, query, actor);
        } else if (result.status() == GatewayPort.ResultStatus.FAILED) {
            query.fail("DEFINITIVE_GATEWAY_FAILURE", safe(result.safeErrorCode()), now, actor);
            resolveOriginalUnknown(tenantId, query, actor);
        } else {
            query.unknown(
                    "UNCERTAIN_EXTERNAL_EFFECT",
                    safe(result.safeErrorCode()),
                    result.externalOperationRef(),
                    now,
                    actor);
            openOriginalUnknown(tenantId, query, safe(result.safeErrorCode()), actor);
        }
        query = operations.saveAndFlush(query);
        audit.success(
                tenantId,
                "GATEWAY_INTEGRATION_RECONCILED",
                "INTEGRATION_OPERATION",
                query.getId(),
                true,
                Map.of(
                        "accessFulfillmentId", fulfillmentId,
                        "operationStatus", query.getStatus().name(),
                        "fulfillmentStatus", fulfillment.getStatus().name()));
        return new EffectResult(query, fulfillment);
    }

    @Transactional
    public EffectResult markQueryExceptionUnknown(
            String tenantId,
            String queryOperationId,
            String fulfillmentId,
            String safeCode) {
        IntegrationOperationEntity query = ownedOperation(tenantId, queryOperationId);
        requireInProgress(query);
        AccessFulfillmentEntity fulfillment = ownedFulfillment(tenantId, fulfillmentId);
        GatewayPort.Result unknown = new GatewayPort.Result(
                GatewayPort.ResultStatus.UNKNOWN,
                fulfillment.getExternalOperationRef(),
                null,
                null,
                null,
                safe(safeCode));
        return completeQuery(tenantId, queryOperationId, fulfillmentId, unknown);
    }

    @Transactional(readOnly = true)
    public IntegrationOperationEntity ownedOperation(String tenantId, String operationId) {
        return operations.findByIdAndTenantId(operationId, tenantId)
                .orElseThrow(() -> new BusinessException(
                        ErrorCode.INTEGRATION_OPERATION_NOT_FOUND,
                        HttpStatus.NOT_FOUND,
                        "IntegrationOperation을 찾을 수 없습니다."));
    }

    private void resolveOriginalUnknown(String tenantId, IntegrationOperationEntity query, String actor) {
        if (query.getCausationId() != null) {
            issues.resolve(tenantId, query.getCausationId(), ISSUE_GATEWAY_UNKNOWN, actor);
        }
    }

    private void openOriginalUnknown(
            String tenantId,
            IntegrationOperationEntity query,
            String safeCode,
            String actor) {
        String operationId = query.getCausationId() == null ? query.getId() : query.getCausationId();
        issues.open(tenantId, operationId, ISSUE_GATEWAY_UNKNOWN, safeCode, actor);
    }

    private AccessFulfillmentEntity ownedFulfillment(String tenantId, String fulfillmentId) {
        return fulfillments.findByIdAndTenantId(fulfillmentId, tenantId)
                .orElseThrow(() -> new BusinessException(
                        ErrorCode.ACCESS_FULFILLMENT_NOT_FOUND,
                        HttpStatus.NOT_FOUND,
                        "AccessFulfillment를 찾을 수 없습니다."));
    }

    private IntegrationOperationType operationType(AccessFulfillmentType type) {
        return type == AccessFulfillmentType.PROVISION
                ? IntegrationOperationType.GATEWAY_PROVISION
                : IntegrationOperationType.GATEWAY_DEPROVISION;
    }

    private void requireInProgress(IntegrationOperationEntity operation) {
        if (operation.getStatus() != IntegrationOperationStatus.IN_PROGRESS) {
            throw state("IN_PROGRESS Gateway IntegrationOperation만 결과를 반영할 수 있습니다.");
        }
    }

    private BusinessException state(String message) {
        return new BusinessException(
                ErrorCode.INTEGRATION_OPERATION_STATE_INVALID,
                HttpStatus.CONFLICT,
                message);
    }

    private String safe(String value) {
        return value == null || value.isBlank() ? "UNSPECIFIED" : value.trim();
    }

    private String safeValue(String value) {
        return value == null ? "" : value;
    }

    public static String unknownIssueType() {
        return ISSUE_GATEWAY_UNKNOWN;
    }

    public record PreparedEffect(
            IntegrationOperationEntity operation,
            AccessFulfillmentType fulfillmentType,
            ConnectorInstanceEntity connector,
            boolean invokeRequired) {}

    public record OutboundEffect(
            IntegrationOperationEntity operation,
            AccessFulfillmentType fulfillmentType,
            ConnectorInstanceEntity connector,
            GatewayPort.Command command) {}

    public record PreparedQuery(
            IntegrationOperationEntity queryOperation,
            IntegrationOperationEntity effectOperation,
            ConnectorInstanceEntity connector) {}

    public record OutboundQuery(
            IntegrationOperationEntity queryOperation,
            ConnectorInstanceEntity connector,
            GatewayPort.StatusQuery query) {}

    public record EffectResult(
            IntegrationOperationEntity operation,
            AccessFulfillmentEntity fulfillment) {}
}

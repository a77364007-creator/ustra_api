package com.gsitm.ustra.api.platform.change.application;

import com.gsitm.ustra.api.platform.audit.AuditService;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiVersionEntity;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiVersionRepository;
import com.gsitm.ustra.api.platform.change.domain.ApiChangeAssessmentStatus;
import com.gsitm.ustra.api.platform.change.domain.ApiChangeItemEffect;
import com.gsitm.ustra.api.platform.change.domain.ApiChangeKind;
import com.gsitm.ustra.api.platform.change.domain.CompatibilityResult;
import com.gsitm.ustra.api.platform.change.persistence.ApiChangeEntity;
import com.gsitm.ustra.api.platform.change.persistence.ApiChangeItemEntity;
import com.gsitm.ustra.api.platform.change.persistence.ApiChangeItemRepository;
import com.gsitm.ustra.api.platform.change.persistence.ApiChangeRepository;
import com.gsitm.ustra.api.platform.change.persistence.ApiContractOperationSnapshotEntity;
import com.gsitm.ustra.api.platform.change.persistence.ApiContractOperationSnapshotRepository;
import com.gsitm.ustra.api.platform.change.persistence.ApiContractSnapshotEntity;
import com.gsitm.ustra.api.platform.change.persistence.ApiContractSnapshotRepository;
import com.gsitm.ustra.api.platform.common.error.BusinessException;
import com.gsitm.ustra.api.platform.common.error.ErrorCode;
import com.gsitm.ustra.api.platform.outbox.OutboxService;
import com.gsitm.ustra.api.platform.provider.importing.application.Sha256Service;
import com.gsitm.ustra.api.platform.tenant.application.TenantPermissionGuard;
import com.gsitm.ustra.api.platform.tenant.context.TenantContext;
import com.gsitm.ustra.api.platform.tenant.context.TenantContextResolver;
import java.time.Clock;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ApiChangeAssessmentService {
    public static final String RULE_SET_VERSION = "CP11-OPERATION-V1";
    private static final String MISSING = "MISSING";

    private final TenantContextResolver contextResolver;
    private final TenantPermissionGuard permissionGuard;
    private final ApiVersionRepository apiVersionRepository;
    private final ApiContractSnapshotRepository snapshotRepository;
    private final ApiContractOperationSnapshotRepository operationSnapshotRepository;
    private final ApiChangeRepository changeRepository;
    private final ApiChangeItemRepository itemRepository;
    private final Sha256Service sha256Service;
    private final AuditService auditService;
    private final OutboxService outboxService;
    private final Clock clock;

    public ApiChangeAssessmentService(
            TenantContextResolver contextResolver,
            TenantPermissionGuard permissionGuard,
            ApiVersionRepository apiVersionRepository,
            ApiContractSnapshotRepository snapshotRepository,
            ApiContractOperationSnapshotRepository operationSnapshotRepository,
            ApiChangeRepository changeRepository,
            ApiChangeItemRepository itemRepository,
            Sha256Service sha256Service,
            AuditService auditService,
            OutboxService outboxService,
            Clock clock) {
        this.contextResolver = contextResolver;
        this.permissionGuard = permissionGuard;
        this.apiVersionRepository = apiVersionRepository;
        this.snapshotRepository = snapshotRepository;
        this.operationSnapshotRepository = operationSnapshotRepository;
        this.changeRepository = changeRepository;
        this.itemRepository = itemRepository;
        this.sha256Service = sha256Service;
        this.auditService = auditService;
        this.outboxService = outboxService;
        this.clock = clock;
    }

    @Transactional
    public ApiChangeEntity assess(String baselineApiVersionId, String targetApiVersionId, String idempotencyKey) {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "API_CHANGE:ASSESS", "API_CHANGE", null);
        String key = requireIdempotencyKey(idempotencyKey);
        String requestFingerprint = sha256Service.hashText(
                baselineApiVersionId + "|" + targetApiVersionId + "|" + RULE_SET_VERSION);

        ApiChangeEntity priorByKey = changeRepository
                .findByTenantIdAndIdempotencyKey(context.tenantId(), key).orElse(null);
        if (priorByKey != null) {
            if (!Objects.equals(priorByKey.getRequestFingerprint(), requestFingerprint)) {
                throw new BusinessException(ErrorCode.API_CHANGE_IDEMPOTENCY_CONFLICT, HttpStatus.CONFLICT,
                        "동일 Idempotency-Key에 다른 변경평가 요청이 사용되었습니다.");
            }
            return priorByKey;
        }

        ApiVersionEntity baseline = ownedVersion(context, baselineApiVersionId);
        ApiVersionEntity target = ownedVersion(context, targetApiVersionId);
        if (Objects.equals(baseline.getId(), target.getId()) || !Objects.equals(baseline.getApiId(), target.getApiId())) {
            throw new BusinessException(ErrorCode.API_CHANGE_PAIR_INVALID, HttpStatus.BAD_REQUEST,
                    "변경평가는 같은 API의 서로 다른 APIVersion 사이에서만 수행할 수 있습니다.");
        }

        ApiContractSnapshotEntity baselineSnapshot = snapshotRepository
                .findByTenantIdAndApiVersionId(context.tenantId(), baseline.getId()).orElse(null);
        ApiContractSnapshotEntity targetSnapshot = snapshotRepository
                .findByTenantIdAndApiVersionId(context.tenantId(), target.getId()).orElse(null);
        String baselineHash = baselineSnapshot == null ? MISSING : baselineSnapshot.getStructuralHash();
        String targetHash = targetSnapshot == null ? MISSING : targetSnapshot.getStructuralHash();

        ApiChangeEntity exact = changeRepository
                .findByTenantIdAndBaselineApiVersionIdAndTargetApiVersionIdAndBaselineStructuralHashAndTargetStructuralHashAndRuleSetVersion(
                        context.tenantId(), baseline.getId(), target.getId(), baselineHash, targetHash, RULE_SET_VERSION)
                .orElse(null);
        if (exact != null) return exact;

        Instant now = Instant.now(clock);
        ApiChangeEntity change = new ApiChangeEntity(
                UUID.randomUUID().toString(), context.tenantId(), baseline.getApiId(), baseline.getId(), target.getId(),
                baselineHash, targetHash, RULE_SET_VERSION, key, requestFingerprint, now, context.principalId());
        change.begin(now, context.principalId());
        change = changeRepository.saveAndFlush(change);

        Assessment assessment = compare(context, change, baselineSnapshot, targetSnapshot, now);
        for (ApiChangeItemEntity item : assessment.items()) itemRepository.save(item);
        String summaryHash = summaryHash(assessment.result(), assessment.items());
        change.complete(assessment.result(), summaryHash, now, context.principalId());
        change = changeRepository.saveAndFlush(change);

        auditService.success(context.tenantId(), "API_CHANGE_ASSESSED", "API_CHANGE", change.getId(), true,
                Map.of("baselineApiVersionId", baseline.getId(), "targetApiVersionId", target.getId(),
                        "compatibilityResult", change.getCompatibilityResult().name(),
                        "ruleSetVersion", RULE_SET_VERSION, "changeSummaryHash", summaryHash));
        outboxService.enqueue("APIChangeAssessed", "API_CHANGE", change.getId(), context.tenantId(),
                Map.of("apiChangeId", change.getId(), "apiId", change.getApiId(),
                        "baselineApiVersionId", baseline.getId(), "targetApiVersionId", target.getId(),
                        "compatibilityResult", change.getCompatibilityResult().name(),
                        "ruleSetVersion", RULE_SET_VERSION));
        return change;
    }

    @Transactional(readOnly = true)
    public ApiChangeEntity get(String id) {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "API_CHANGE:READ", "API_CHANGE", id);
        return ownedChange(context, id);
    }

    @Transactional(readOnly = true)
    public List<ApiChangeItemEntity> items(String id) {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "API_CHANGE:READ", "API_CHANGE", id);
        ownedChange(context, id);
        return itemRepository.findAllByTenantIdAndApiChangeIdOrderByCreatedAtAsc(context.tenantId(), id);
    }

    private Assessment compare(
            TenantContext context,
            ApiChangeEntity change,
            ApiContractSnapshotEntity baselineSnapshot,
            ApiContractSnapshotEntity targetSnapshot,
            Instant now) {
        List<ApiChangeItemEntity> items = new ArrayList<>();
        if (baselineSnapshot == null) {
            items.add(item(context, change, ApiChangeKind.BASELINE_SNAPSHOT_MISSING, null, null,
                    null, MISSING, change.getTargetStructuralHash(), ApiChangeItemEffect.REVIEW_REQUIRED,
                    "BASELINE_CONTRACT_SNAPSHOT_MISSING", now));
        }
        if (targetSnapshot == null) {
            items.add(item(context, change, ApiChangeKind.TARGET_SNAPSHOT_MISSING, null, null,
                    null, change.getBaselineStructuralHash(), MISSING, ApiChangeItemEffect.REVIEW_REQUIRED,
                    "TARGET_CONTRACT_SNAPSHOT_MISSING", now));
        }
        if (baselineSnapshot == null || targetSnapshot == null) {
            return new Assessment(CompatibilityResult.REVIEW_REQUIRED, List.copyOf(items));
        }
        if (Objects.equals(baselineSnapshot.getStructuralHash(), targetSnapshot.getStructuralHash())) {
            return new Assessment(CompatibilityResult.NO_CONTRACT_CHANGE, List.of());
        }

        Map<String, ApiContractOperationSnapshotEntity> baselineOps = byIdentity(
                operationSnapshotRepository.findAllByTenantIdAndSnapshotIdOrderByMethodAscNormalizedPathAsc(
                        context.tenantId(), baselineSnapshot.getId()));
        Map<String, ApiContractOperationSnapshotEntity> targetOps = byIdentity(
                operationSnapshotRepository.findAllByTenantIdAndSnapshotIdOrderByMethodAscNormalizedPathAsc(
                        context.tenantId(), targetSnapshot.getId()));

        for (Map.Entry<String, ApiContractOperationSnapshotEntity> entry : baselineOps.entrySet()) {
            ApiContractOperationSnapshotEntity oldOp = entry.getValue();
            ApiContractOperationSnapshotEntity newOp = targetOps.get(entry.getKey());
            if (newOp == null) {
                items.add(item(context, change, ApiChangeKind.OPERATION_REMOVED, oldOp.getMethod(),
                        oldOp.getNormalizedPath(), "OPERATION", oldOp.getOperationFingerprint(), null,
                        ApiChangeItemEffect.BREAKING, "OPERATION_REMOVED", now));
            } else if (!Objects.equals(oldOp.getOperationFingerprint(), newOp.getOperationFingerprint())) {
                items.add(item(context, change, ApiChangeKind.OPERATION_STRUCTURE_CHANGED, oldOp.getMethod(),
                        oldOp.getNormalizedPath(), "OPERATION_STRUCTURE", oldOp.getOperationFingerprint(),
                        newOp.getOperationFingerprint(), ApiChangeItemEffect.REVIEW_REQUIRED,
                        "STRUCTURAL_CHANGE_RULE_COVERAGE_INCOMPLETE", now));
            }
        }
        for (Map.Entry<String, ApiContractOperationSnapshotEntity> entry : targetOps.entrySet()) {
            if (!baselineOps.containsKey(entry.getKey())) {
                ApiContractOperationSnapshotEntity newOp = entry.getValue();
                items.add(item(context, change, ApiChangeKind.OPERATION_ADDED, newOp.getMethod(),
                        newOp.getNormalizedPath(), "OPERATION", null, newOp.getOperationFingerprint(),
                        ApiChangeItemEffect.INFORMATIONAL, "OPERATION_ADDED_REQUIRES_REVIEW", now));
            }
        }
        boolean breaking = items.stream().anyMatch(i -> i.getCompatibilityEffect() == ApiChangeItemEffect.BREAKING);
        return new Assessment(breaking ? CompatibilityResult.BREAKING : CompatibilityResult.REVIEW_REQUIRED,
                List.copyOf(items));
    }

    private Map<String, ApiContractOperationSnapshotEntity> byIdentity(List<ApiContractOperationSnapshotEntity> values) {
        Map<String, ApiContractOperationSnapshotEntity> result = new LinkedHashMap<>();
        for (ApiContractOperationSnapshotEntity value : values) {
            result.put(value.getMethod() + " " + value.getNormalizedPath(), value);
        }
        return result;
    }

    private ApiChangeItemEntity item(
            TenantContext context,
            ApiChangeEntity change,
            ApiChangeKind kind,
            String method,
            String path,
            String location,
            String baselineFingerprint,
            String targetFingerprint,
            ApiChangeItemEffect effect,
            String evidenceCode,
            Instant now) {
        return new ApiChangeItemEntity(
                UUID.randomUUID().toString(), context.tenantId(), change.getId(), kind, method, path, location,
                baselineFingerprint, targetFingerprint, effect, evidenceCode, now, context.principalId());
    }

    private String summaryHash(CompatibilityResult result, List<ApiChangeItemEntity> items) {
        String canonical = items.stream()
                .sorted(Comparator.comparing(ApiChangeItemEntity::getEvidenceCode)
                        .thenComparing(i -> Objects.toString(i.getMethod(), ""))
                        .thenComparing(i -> Objects.toString(i.getNormalizedPath(), "")))
                .map(i -> i.getEvidenceCode() + "|" + i.getCompatibilityEffect() + "|"
                        + Objects.toString(i.getMethod(), "") + "|" + Objects.toString(i.getNormalizedPath(), "")
                        + "|" + Objects.toString(i.getBaselineFingerprint(), "") + "|"
                        + Objects.toString(i.getTargetFingerprint(), ""))
                .reduce(result.name(), (a, b) -> a + "\n" + b);
        return sha256Service.hashText(canonical);
    }

    private ApiVersionEntity ownedVersion(TenantContext context, String id) {
        return apiVersionRepository.findByIdAndTenantId(id, context.tenantId())
                .orElseThrow(() -> new BusinessException(ErrorCode.API_VERSION_NOT_FOUND, HttpStatus.NOT_FOUND,
                        "API Version을 찾을 수 없습니다."));
    }

    private ApiChangeEntity ownedChange(TenantContext context, String id) {
        return changeRepository.findByIdAndTenantId(id, context.tenantId())
                .orElseThrow(() -> new BusinessException(ErrorCode.API_CHANGE_NOT_FOUND, HttpStatus.NOT_FOUND,
                        "API Change를 찾을 수 없습니다."));
    }

    private String requireIdempotencyKey(String value) {
        if (value == null || value.isBlank()) {
            throw new BusinessException(ErrorCode.IDEMPOTENCY_KEY_REQUIRED, HttpStatus.BAD_REQUEST,
                    "Idempotency-Key가 필요합니다.");
        }
        String key = value.trim();
        if (key.length() > 200) {
            throw new BusinessException(ErrorCode.VALIDATION_ERROR, HttpStatus.BAD_REQUEST,
                    "Idempotency-Key는 200자를 초과할 수 없습니다.");
        }
        return key;
    }

    private record Assessment(CompatibilityResult result, List<ApiChangeItemEntity> items) {}
}

package com.gsitm.ustra.api.platform.catalog.localization.application;

import com.gsitm.ustra.api.platform.catalog.localization.domain.LocalizationStatus;
import com.gsitm.ustra.api.platform.catalog.localization.persistence.LocalizedContentEntity;
import com.gsitm.ustra.api.platform.catalog.localization.persistence.LocalizedContentRepository;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiProductEntity;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiProductRepository;
import com.gsitm.ustra.api.platform.common.error.BusinessException;
import com.gsitm.ustra.api.platform.common.error.ErrorCode;
import com.gsitm.ustra.api.platform.tenant.application.TenantPermissionGuard;
import com.gsitm.ustra.api.platform.tenant.context.TenantContext;
import com.gsitm.ustra.api.platform.tenant.context.TenantContextResolver;
import java.time.Clock;
import java.time.Instant;
import java.util.List;
import java.util.UUID;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ApiProductLocalizationService {
    private final TenantContextResolver contextResolver;
    private final TenantPermissionGuard permissionGuard;
    private final ApiProductRepository productRepository;
    private final LocalizedContentRepository repository;
    private final Clock clock;

    public ApiProductLocalizationService(TenantContextResolver contextResolver,
                                         TenantPermissionGuard permissionGuard,
                                         ApiProductRepository productRepository,
                                         LocalizedContentRepository repository,
                                         Clock clock) {
        this.contextResolver = contextResolver;
        this.permissionGuard = permissionGuard;
        this.productRepository = productRepository;
        this.repository = repository;
        this.clock = clock;
    }

    @Transactional(readOnly = true)
    public List<LocalizedContentEntity> list(String apiProductId) {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "API_PRODUCT:READ", "API_PRODUCT", apiProductId);
        ownedProduct(context, apiProductId);
        return repository.findAllByTenantIdAndApiProductIdOrderByLocaleAsc(context.tenantId(), apiProductId);
    }

    @Transactional(readOnly = true)
    public LocalizationStatus status(String apiProductId, String locale) {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "API_PRODUCT:READ", "API_PRODUCT", apiProductId);
        ownedProduct(context, apiProductId);
        return repository.findByTenantIdAndApiProductIdAndLocale(context.tenantId(), apiProductId, normalizeLocale(locale))
                .map(LocalizedContentEntity::getStatus)
                .orElse(LocalizationStatus.MISSING);
    }

    @Transactional
    public SaveResult saveDraft(String apiProductId, String locale, Long expectedVersion,
                                String name, String description) {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "API_PRODUCT:UPDATE", "API_PRODUCT", apiProductId);
        ApiProductEntity product = ownedProduct(context, apiProductId);
        String normalizedLocale = normalizeLocale(locale);
        Instant now = Instant.now(clock);
        var existing = repository.findByTenantIdAndApiProductIdAndLocale(context.tenantId(), apiProductId, normalizedLocale);
        if (existing.isEmpty()) {
            if (expectedVersion != null) {
                throw new BusinessException(ErrorCode.CONCURRENT_MODIFICATION, HttpStatus.CONFLICT,
                        "아직 생성되지 않은 Localization에는 If-Match를 사용할 수 없습니다.");
            }
            LocalizedContentEntity created = repository.saveAndFlush(new LocalizedContentEntity(
                    UUID.randomUUID().toString(), context.tenantId(), apiProductId, normalizedLocale,
                    product.getLocalizationRevision(), name, description, now, context.principalId()));
            return new SaveResult(created, true);
        }
        LocalizedContentEntity content = existing.get();
        if (expectedVersion == null) {
            throw new BusinessException(ErrorCode.VALIDATION_ERROR, HttpStatus.BAD_REQUEST,
                    "기존 Localization 수정에는 If-Match header가 필요합니다.");
        }
        if (content.getRowVersion() != expectedVersion) {
            throw new BusinessException(ErrorCode.CONCURRENT_MODIFICATION, HttpStatus.CONFLICT,
                    "Localization이 다른 요청에 의해 변경되었습니다.");
        }
        content.saveDraft(product.getLocalizationRevision(), name, description, now, context.principalId());
        return new SaveResult(content, false);
    }

    private ApiProductEntity ownedProduct(TenantContext context, String apiProductId) {
        return productRepository.findByIdAndTenantId(apiProductId, context.tenantId())
                .orElseThrow(() -> new BusinessException(ErrorCode.API_PRODUCT_NOT_FOUND, HttpStatus.NOT_FOUND,
                        "API Product를 찾을 수 없습니다."));
    }

    private String normalizeLocale(String locale) {
        if (locale == null || locale.isBlank()) {
            throw new BusinessException(ErrorCode.VALIDATION_ERROR, HttpStatus.BAD_REQUEST,
                    "locale은 필수입니다.");
        }
        String value = locale.trim();
        if (value.length() > 35) {
            throw new BusinessException(ErrorCode.VALIDATION_ERROR, HttpStatus.BAD_REQUEST,
                    "locale 길이는 35자를 초과할 수 없습니다.");
        }
        return value;
    }

    public record SaveResult(LocalizedContentEntity content, boolean created) {
    }
}

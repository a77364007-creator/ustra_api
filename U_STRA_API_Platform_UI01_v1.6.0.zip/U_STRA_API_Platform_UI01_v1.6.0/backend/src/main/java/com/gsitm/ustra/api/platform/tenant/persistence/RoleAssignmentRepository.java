package com.gsitm.ustra.api.platform.tenant.persistence;

import com.gsitm.ustra.api.platform.tenant.domain.RoleAssignmentStatus;
import java.time.Instant;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface RoleAssignmentRepository extends JpaRepository<RoleAssignmentEntity, String> {
    Optional<RoleAssignmentEntity> findByIdAndTenantId(String id, String tenantId);
    List<RoleAssignmentEntity> findAllByTenantIdOrderByAssignedAtAsc(String tenantId);

    @Query("""
            select ra from RoleAssignmentEntity ra
            where ra.tenantId = :tenantId
              and ra.membershipId = :membershipId
              and ra.status = :status
              and ra.effectiveFrom <= :now
              and (ra.effectiveTo is null or ra.effectiveTo > :now)
            """)
    List<RoleAssignmentEntity> findEffectiveAssignments(
            @Param("tenantId") String tenantId,
            @Param("membershipId") String membershipId,
            @Param("status") RoleAssignmentStatus status,
            @Param("now") Instant now);

    List<RoleAssignmentEntity> findAllByTenantIdAndMembershipIdAndRoleIdAndStatus(
            String tenantId, String membershipId, String roleId, RoleAssignmentStatus status);
}

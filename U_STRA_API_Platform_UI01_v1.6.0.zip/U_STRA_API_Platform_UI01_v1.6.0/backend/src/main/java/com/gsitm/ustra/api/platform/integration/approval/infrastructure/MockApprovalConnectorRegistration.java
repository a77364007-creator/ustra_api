package com.gsitm.ustra.api.platform.integration.approval.infrastructure;
import com.gsitm.ustra.api.platform.integration.approval.application.ApprovalConnectorRegistration; import com.gsitm.ustra.api.platform.subscription.approval.application.ApprovalPort; import com.gsitm.ustra.api.platform.subscription.approval.infrastructure.MockApprovalAdapter; import org.springframework.context.annotation.Profile; import org.springframework.stereotype.Component;
@Component @Profile({"local","test","mock-integration"}) public class MockApprovalConnectorRegistration implements ApprovalConnectorRegistration {
 private final MockApprovalAdapter adapter; public MockApprovalConnectorRegistration(MockApprovalAdapter a){adapter=a;} public String adapterCode(){return "MOCK_APPROVAL";} public ApprovalPort port(){return adapter;}
}

package com.gsitm.ustra.api.platform.tenant.application;

import com.gsitm.ustra.api.platform.audit.AuditService;
import com.gsitm.ustra.api.platform.common.error.BusinessException;
import com.gsitm.ustra.api.platform.common.error.ErrorCode;
import com.gsitm.ustra.api.platform.outbox.OutboxService;
import com.gsitm.ustra.api.platform.tenant.context.TenantContext;
import com.gsitm.ustra.api.platform.tenant.context.TenantContextResolver;
import com.gsitm.ustra.api.platform.tenant.persistence.TenantConfigurationEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.TenantConfigurationRepository;
import java.time.Clock;
import java.time.Instant;
import java.util.Map;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class TenantConfigurationService {
    private final TenantContextResolver contextResolver;
    private final TenantPermissionGuard permissionGuard;
    private final TenantConfigurationRepository repository;
    private final AuditService auditService;
    private final OutboxService outboxService;
    private final Clock clock;

    public TenantConfigurationService(TenantContextResolver contextResolver, TenantPermissionGuard permissionGuard,
                                      TenantConfigurationRepository repository, AuditService auditService,
                                      OutboxService outboxService, Clock clock) {
        this.contextResolver = contextResolver;
        this.permissionGuard = permissionGuard;
        this.repository = repository;
        this.auditService = auditService;
        this.outboxService = outboxService;
        this.clock = clock;
    }

    @Transactional(readOnly = true)
    public TenantConfigurationEntity get() {
        TenantContext context = contextResolver.resolve();
        return repository.findByTenantId(context.tenantId())
                .orElseThrow(() -> new BusinessException(ErrorCode.TENANT_NOT_FOUND, HttpStatus.NOT_FOUND,
                        "Tenant configuration을 찾을 수 없습니다."));
    }

    @Transactional
    public TenantConfigurationEntity update(long expectedRevision, String defaultLocale, String timezone) {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "TENANT_CONFIGURATION:MANAGE", "TENANT_CONFIGURATION", context.tenantId());
        Cp01Validation.locale(defaultLocale);
        Cp01Validation.timezone(timezone);
        TenantConfigurationEntity entity = repository.findByTenantId(context.tenantId())
                .orElseThrow(() -> new BusinessException(ErrorCode.TENANT_NOT_FOUND, HttpStatus.NOT_FOUND,
                        "Tenant configuration을 찾을 수 없습니다."));
        if (entity.getConfigRevision() != expectedRevision) {
            throw new BusinessException(ErrorCode.CONCURRENT_MODIFICATION, HttpStatus.CONFLICT,
                    "Tenant configuration revision이 최신 값이 아닙니다.");
        }
        entity.update(defaultLocale, timezone, Instant.now(clock));
        auditService.success(context.tenantId(), "TENANT_CONFIGURATION_CHANGE", "TENANT_CONFIGURATION",
                entity.getId(), true, Map.of("revision", entity.getConfigRevision()));
        outboxService.enqueue("TenantConfigurationChanged", "TENANT_CONFIGURATION", entity.getId(),
                context.tenantId(), Map.of("revision", entity.getConfigRevision()));
        return entity;
    }
}

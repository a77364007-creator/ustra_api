package com.gsitm.ustra.api.platform.catalog.localization.api;

import com.gsitm.ustra.api.platform.catalog.localization.application.ApiProductLocalizationService;
import com.gsitm.ustra.api.platform.catalog.localization.persistence.LocalizedContentEntity;
import com.gsitm.ustra.api.platform.tenant.api.VersionHeaderParser;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import java.time.Instant;
import java.util.List;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/api-products/{apiProductId}/localized-contents")
public class ApiProductLocalizationController {
    private final ApiProductLocalizationService service;

    public ApiProductLocalizationController(ApiProductLocalizationService service) {
        this.service = service;
    }

    @GetMapping
    public List<LocalizedContentResponse> list(@PathVariable String apiProductId) {
        return service.list(apiProductId).stream().map(LocalizedContentResponse::from).toList();
    }

    @PutMapping("/{locale}")
    public ResponseEntity<LocalizedContentResponse> saveDraft(
            @PathVariable String apiProductId,
            @PathVariable String locale,
            @RequestHeader(value = HttpHeaders.IF_MATCH, required = false) String ifMatch,
            @Valid @RequestBody SaveLocalizedContentRequest request) {
        Long expectedVersion = ifMatch == null || ifMatch.isBlank() ? null : VersionHeaderParser.parse(ifMatch);
        ApiProductLocalizationService.SaveResult result = service.saveDraft(apiProductId, locale, expectedVersion,
                request.name(), request.description());
        LocalizedContentEntity content = result.content();
        HttpStatus status = result.created() ? HttpStatus.CREATED : HttpStatus.OK;
        return ResponseEntity.status(status).eTag(VersionHeaderParser.etag(content.getRowVersion()))
                .body(LocalizedContentResponse.from(content));
    }

    public record SaveLocalizedContentRequest(
            @NotBlank @Size(max = 200) String name,
            @Size(max = 4000) String description) {
    }

    public record LocalizedContentResponse(
            String localizedContentId,
            String locale,
            String status,
            long revision,
            long sourceLocalizationRevision,
            String name,
            String description,
            boolean stale,
            String etag,
            Instant updatedAt,
            String updatedBy) {

        static LocalizedContentResponse from(LocalizedContentEntity entity) {
            return new LocalizedContentResponse(entity.getId(), entity.getLocale(), entity.getStatus().name(),
                    entity.getContentRevision(), entity.getSourceLocalizationRevision(), entity.getLocalizedName(),
                    entity.getLocalizedDescription(), entity.getStatus().name().equals("STALE"),
                    VersionHeaderParser.etag(entity.getRowVersion()), entity.getUpdatedAt(), entity.getUpdatedBy());
        }
    }
}

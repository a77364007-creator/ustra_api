package com.gsitm.ustra.api.platform.tenant.application;

import com.gsitm.ustra.api.platform.common.error.BusinessException;
import com.gsitm.ustra.api.platform.common.error.ErrorCode;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

@Component
@Profile("prod")
public class ProductionIdentityAuthority implements IdentityAuthority {
    @Override
    public boolean exists(String principalId, String issuer) {
        throw new BusinessException(ErrorCode.IDENTITY_AUTHORITY_UNAVAILABLE, HttpStatus.SERVICE_UNAVAILABLE,
                "Identity authority 연계가 구성되지 않았습니다.");
    }
}

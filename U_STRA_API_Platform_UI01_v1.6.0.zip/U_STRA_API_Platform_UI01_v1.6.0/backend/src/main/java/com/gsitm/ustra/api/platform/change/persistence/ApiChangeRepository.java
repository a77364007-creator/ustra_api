package com.gsitm.ustra.api.platform.change.persistence;
import java.util.Optional; import org.springframework.data.jpa.repository.JpaRepository;
public interface ApiChangeRepository extends JpaRepository<ApiChangeEntity,String>{
 Optional<ApiChangeEntity> findByIdAndTenantId(String id,String tenantId);
 Optional<ApiChangeEntity> findByTenantIdAndIdempotencyKey(String tenantId,String idempotencyKey);
 Optional<ApiChangeEntity> findByTenantIdAndBaselineApiVersionIdAndTargetApiVersionIdAndBaselineStructuralHashAndTargetStructuralHashAndRuleSetVersion(String tenantId,String baselineApiVersionId,String targetApiVersionId,String baselineStructuralHash,String targetStructuralHash,String ruleSetVersion);
}

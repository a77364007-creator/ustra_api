package com.gsitm.ustra.api.platform.integration.approval.persistence;
import java.util.List; import java.util.Optional; import org.springframework.data.jpa.repository.JpaRepository;
public interface ConnectorInstanceRepository extends JpaRepository<ConnectorInstanceEntity, String>, org.springframework.data.jpa.repository.JpaSpecificationExecutor<ConnectorInstanceEntity>{Optional<ConnectorInstanceEntity> findByIdAndTenantId(String id,String tenantId);List<ConnectorInstanceEntity> findAllByTenantIdAndIntegrationProfileIdAndEnabledTrueOrderByConnectorCodeAsc(String tenantId,String profileId);}

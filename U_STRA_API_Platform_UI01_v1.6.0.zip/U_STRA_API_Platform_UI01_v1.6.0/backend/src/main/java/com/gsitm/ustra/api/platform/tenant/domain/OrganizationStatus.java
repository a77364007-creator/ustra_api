package com.gsitm.ustra.api.platform.tenant.domain;

public enum OrganizationStatus {
    ACTIVE,
    INACTIVE
}

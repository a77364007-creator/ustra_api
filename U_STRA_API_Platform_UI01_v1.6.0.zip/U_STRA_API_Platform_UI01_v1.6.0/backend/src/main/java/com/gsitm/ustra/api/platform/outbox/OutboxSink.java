package com.gsitm.ustra.api.platform.outbox;

public interface OutboxSink {
    void publish(OutboxMessage event);
}

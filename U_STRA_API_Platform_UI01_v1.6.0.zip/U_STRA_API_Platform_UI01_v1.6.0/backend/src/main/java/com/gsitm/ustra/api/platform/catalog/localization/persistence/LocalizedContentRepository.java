package com.gsitm.ustra.api.platform.catalog.localization.persistence;

import com.gsitm.ustra.api.platform.catalog.localization.domain.LocalizationStatus;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LocalizedContentRepository extends JpaRepository<LocalizedContentEntity, String> {
    List<LocalizedContentEntity> findAllByTenantIdAndApiProductIdOrderByLocaleAsc(String tenantId, String apiProductId);
    List<LocalizedContentEntity> findAllByTenantIdAndApiProductIdAndStatus(String tenantId, String apiProductId,
                                                                          LocalizationStatus status);
    Optional<LocalizedContentEntity> findByTenantIdAndApiProductIdAndLocale(String tenantId, String apiProductId,
                                                                            String locale);
    Optional<LocalizedContentEntity> findByTenantIdAndApiProductIdAndLocaleAndStatus(
            String tenantId, String apiProductId, String locale, LocalizationStatus status);
}

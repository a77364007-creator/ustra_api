package com.gsitm.ustra.api.platform.change.persistence;
import jakarta.persistence.*;
@Entity @Table(name="api_contract_body_snapshot")
public class ApiContractBodySnapshotEntity {
 @Id @Column(name="api_contract_body_snapshot_id",length=36,nullable=false,updatable=false) private String id;
 @Column(name="tenant_id",length=36,nullable=false,updatable=false) private String tenantId;
 @Column(name="api_contract_operation_snapshot_id",length=36,nullable=false,updatable=false) private String operationSnapshotId;
 @Column(name="required_flag",nullable=false,updatable=false) private boolean required;
 @Column(name="media_type",length=200,nullable=false,updatable=false) private String mediaType;
 @Column(name="schema_fingerprint",length=64,nullable=false,updatable=false) private String schemaFingerprint;
 @Column(name="body_fingerprint",length=64,nullable=false,updatable=false) private String bodyFingerprint;
 protected ApiContractBodySnapshotEntity(){}
 public ApiContractBodySnapshotEntity(String id,String tenantId,String operationSnapshotId,boolean required,String mediaType,String schemaFingerprint,String bodyFingerprint){this.id=id;this.tenantId=tenantId;this.operationSnapshotId=operationSnapshotId;this.required=required;this.mediaType=mediaType;this.schemaFingerprint=schemaFingerprint;this.bodyFingerprint=bodyFingerprint;}
 public String getId(){return id;} public String getTenantId(){return tenantId;} public String getOperationSnapshotId(){return operationSnapshotId;} public boolean isRequired(){return required;} public String getMediaType(){return mediaType;} public String getSchemaFingerprint(){return schemaFingerprint;} public String getBodyFingerprint(){return bodyFingerprint;}
}

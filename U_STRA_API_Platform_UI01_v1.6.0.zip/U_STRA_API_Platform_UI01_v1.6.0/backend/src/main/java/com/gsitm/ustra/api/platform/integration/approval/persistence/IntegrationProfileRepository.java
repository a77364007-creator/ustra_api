package com.gsitm.ustra.api.platform.integration.approval.persistence;
import com.gsitm.ustra.api.platform.integration.approval.domain.IntegrationType; import java.util.List; import java.util.Optional; import org.springframework.data.jpa.repository.JpaRepository;
public interface IntegrationProfileRepository extends JpaRepository<IntegrationProfileEntity,String>{Optional<IntegrationProfileEntity> findByIdAndTenantId(String id,String tenantId);List<IntegrationProfileEntity> findAllByTenantIdAndIntegrationTypeAndEnabledTrueOrderByProfileCodeAsc(String tenantId,IntegrationType type);}

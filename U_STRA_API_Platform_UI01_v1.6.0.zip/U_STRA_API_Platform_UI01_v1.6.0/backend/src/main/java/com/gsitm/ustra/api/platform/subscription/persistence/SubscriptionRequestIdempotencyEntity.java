package com.gsitm.ustra.api.platform.subscription.persistence;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.Instant;

@Entity
@Table(name = "subscription_request_idempotency")
public class SubscriptionRequestIdempotencyEntity {
    @Id
    @Column(name = "subscription_request_idempotency_id", length = 36, nullable = false, updatable = false)
    private String id;
    @Column(name = "tenant_id", length = 36, nullable = false, updatable = false)
    private String tenantId;
    @Column(name = "operation_code", length = 80, nullable = false, updatable = false)
    private String operationCode;
    @Column(name = "idempotency_key", length = 200, nullable = false, updatable = false)
    private String idempotencyKey;
    @Column(name = "request_fingerprint", length = 64, nullable = false, updatable = false)
    private String requestFingerprint;
    @Column(name = "subscription_request_id", length = 36, nullable = false, updatable = false)
    private String subscriptionRequestId;
    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    protected SubscriptionRequestIdempotencyEntity() {}

    public SubscriptionRequestIdempotencyEntity(String id, String tenantId, String operationCode,
                                                String idempotencyKey, String requestFingerprint,
                                                String subscriptionRequestId, Instant createdAt) {
        this.id = id;
        this.tenantId = tenantId;
        this.operationCode = operationCode;
        this.idempotencyKey = idempotencyKey;
        this.requestFingerprint = requestFingerprint;
        this.subscriptionRequestId = subscriptionRequestId;
        this.createdAt = createdAt;
    }

    public String getId() { return id; }
    public String getTenantId() { return tenantId; }
    public String getOperationCode() { return operationCode; }
    public String getIdempotencyKey() { return idempotencyKey; }
    public String getRequestFingerprint() { return requestFingerprint; }
    public String getSubscriptionRequestId() { return subscriptionRequestId; }
    public Instant getCreatedAt() { return createdAt; }
}

package com.gsitm.ustra.api.platform.change.persistence;
import jakarta.persistence.*;
@Entity @Table(name="api_contract_security_snapshot")
public class ApiContractSecuritySnapshotEntity {
 @Id @Column(name="api_contract_security_snapshot_id",length=36,nullable=false,updatable=false) private String id;
 @Column(name="tenant_id",length=36,nullable=false,updatable=false) private String tenantId;
 @Column(name="api_contract_operation_snapshot_id",length=36,nullable=false,updatable=false) private String operationSnapshotId;
 @Column(name="requirement_index",nullable=false,updatable=false) private int requirementIndex;
 @Column(name="requirement_fingerprint",length=64,nullable=false,updatable=false) private String requirementFingerprint;
 protected ApiContractSecuritySnapshotEntity(){}
 public ApiContractSecuritySnapshotEntity(String id,String tenantId,String operationSnapshotId,int requirementIndex,String requirementFingerprint){this.id=id;this.tenantId=tenantId;this.operationSnapshotId=operationSnapshotId;this.requirementIndex=requirementIndex;this.requirementFingerprint=requirementFingerprint;}
 public String getId(){return id;} public String getTenantId(){return tenantId;} public String getOperationSnapshotId(){return operationSnapshotId;} public int getRequirementIndex(){return requirementIndex;} public String getRequirementFingerprint(){return requirementFingerprint;}
}

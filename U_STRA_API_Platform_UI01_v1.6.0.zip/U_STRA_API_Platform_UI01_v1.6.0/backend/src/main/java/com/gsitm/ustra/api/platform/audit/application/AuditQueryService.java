package com.gsitm.ustra.api.platform.audit.application;

import com.gsitm.ustra.api.platform.audit.*;
import com.gsitm.ustra.api.platform.operations.api.OperationsPage;
import com.gsitm.ustra.api.platform.operations.application.*;
import com.gsitm.ustra.api.platform.tenant.application.TenantPermissionGuard;
import com.gsitm.ustra.api.platform.tenant.context.TenantContextResolver;
import java.time.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import static com.gsitm.ustra.api.platform.operations.application.OperationsSpecifications.*;

@Service
public class AuditQueryService {
    private final TenantContextResolver contexts;
    private final TenantPermissionGuard permissions;
    private final AuditRecordRepository repository;
    private final OperationsQueryLimits limits;
    private final Clock clock;
    public AuditQueryService(TenantContextResolver contexts,TenantPermissionGuard permissions,AuditRecordRepository repository,
                             OperationsQueryLimits limits,Clock clock) {
        this.contexts=contexts;this.permissions=permissions;this.repository=repository;this.limits=limits;this.clock=clock;
    }
    @Transactional(readOnly=true)
    public OperationsPage<View> query(Instant from,Instant to,String action,String resourceType,String resourceId,
                                      String outcome,String correlationId,int page,int size,String order) {
        var c=contexts.resolve();permissions.require(c,"AUDIT:READ","AUDIT_RECORD","query");
        var w=limits.window(from,to);
        var spec=OperationsSpecifications.<AuditRecordEntity>tenant(c.tenantId()).and(window("occurredAt",w))
                .and(eq("action",limits.filter(action))).and(eq("resourceType",limits.filter(resourceType)))
                .and(eq("resourceId",limits.filter(resourceId))).and(eq("outcome",limits.filter(outcome)))
                .and(eq("correlationId",limits.filter(correlationId)));
        return OperationsPage.from(repository.findAll(spec,limits.page(page,size,order,"occurredAt")).map(View::from),Instant.now(clock),w.from(),w.to());
    }
    public record View(String id,Instant occurredAt,String actorPrincipalId,String action,String resourceType,
                       String resourceId,String outcome,String reasonCode,String correlationId) {
        public static View from(AuditRecordEntity e){return new View(e.getId(),e.getOccurredAt(),e.getActorPrincipalId(),e.getAction(),e.getResourceType(),e.getResourceId(),e.getOutcome(),e.getReasonCode(),e.getCorrelationId());}
    }
}

package com.gsitm.ustra.api.platform.integration.gateway.api;

import com.gsitm.ustra.api.platform.common.error.BusinessException;
import com.gsitm.ustra.api.platform.common.error.ErrorCode;
import com.gsitm.ustra.api.platform.integration.approval.domain.IntegrationOperationStatus;
import com.gsitm.ustra.api.platform.integration.gateway.application.GatewayIntegrationOperatorService;
import java.util.List;
import java.util.Locale;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/admin/gateway-integrations")
public class GatewayIntegrationAdminController {
    private final GatewayIntegrationOperatorService service;

    public GatewayIntegrationAdminController(GatewayIntegrationOperatorService service) {
        this.service = service;
    }

    @GetMapping("/operations")
    public List<GatewayIntegrationOperatorService.OperationView> operations(
            @RequestParam(required = false) String status) {
        return service.operations(parseStatus(status));
    }

    @GetMapping("/issues")
    public List<GatewayIntegrationOperatorService.IssueView> issues() {
        return service.issues();
    }

    @PostMapping("/fulfillments/{fulfillmentId}/reconcile")
    public ResponseEntity<GatewayIntegrationOperatorService.ReconcileView> reconcile(
            @PathVariable String fulfillmentId) {
        return ResponseEntity.ok(service.reconcileFulfillment(fulfillmentId));
    }

    private IntegrationOperationStatus parseStatus(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        try {
            return IntegrationOperationStatus.valueOf(value.trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException ex) {
            throw new BusinessException(
                    ErrorCode.VALIDATION_ERROR,
                    HttpStatus.BAD_REQUEST,
                    "지원하지 않는 IntegrationOperation status입니다.");
        }
    }
}

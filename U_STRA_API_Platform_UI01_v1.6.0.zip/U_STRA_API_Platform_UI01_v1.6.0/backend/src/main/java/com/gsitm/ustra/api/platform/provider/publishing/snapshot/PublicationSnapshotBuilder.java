package com.gsitm.ustra.api.platform.provider.publishing.snapshot;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiOperationEntity;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiOperationRepository;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiProductEntity;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiProductRepository;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiVersionEntity;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiVersionRepository;
import com.gsitm.ustra.api.platform.catalog.publication.domain.ApiProductComponentTargetType;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.ApiProductComponentEntity;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.ApiProductComponentRepository;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.ApiProductVersionEntity;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.ApiProductVersionRepository;
import com.gsitm.ustra.api.platform.common.error.BusinessException;
import com.gsitm.ustra.api.platform.common.error.ErrorCode;
import com.gsitm.ustra.api.platform.provider.importing.application.Sha256Service;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class PublicationSnapshotBuilder {
    private final ApiProductRepository productRepository;
    private final ApiProductVersionRepository productVersionRepository;
    private final ApiProductComponentRepository componentRepository;
    private final ApiVersionRepository apiVersionRepository;
    private final ApiOperationRepository operationRepository;
    private final ObjectMapper objectMapper;
    private final Sha256Service sha256Service;

    public PublicationSnapshotBuilder(
            ApiProductRepository productRepository,
            ApiProductVersionRepository productVersionRepository,
            ApiProductComponentRepository componentRepository,
            ApiVersionRepository apiVersionRepository,
            ApiOperationRepository operationRepository,
            ObjectMapper objectMapper,
            Sha256Service sha256Service) {
        this.productRepository = productRepository;
        this.productVersionRepository = productVersionRepository;
        this.componentRepository = componentRepository;
        this.apiVersionRepository = apiVersionRepository;
        this.operationRepository = operationRepository;
        this.objectMapper = objectMapper;
        this.sha256Service = sha256Service;
    }

    @Transactional(readOnly = true)
    public Snapshot build(String tenantId, String apiProductVersionId) {
        ApiProductVersionEntity version = productVersionRepository.findByIdAndTenantId(apiProductVersionId, tenantId)
                .orElseThrow(() -> new BusinessException(ErrorCode.API_PRODUCT_VERSION_NOT_FOUND, HttpStatus.NOT_FOUND,
                        "API Product Version을 찾을 수 없습니다."));
        ApiProductEntity product = productRepository.findByIdAndTenantId(version.getApiProductId(), tenantId)
                .orElseThrow(() -> new BusinessException(ErrorCode.API_PRODUCT_NOT_FOUND, HttpStatus.NOT_FOUND,
                        "API Product를 찾을 수 없습니다."));

        List<ApiProductComponentEntity> components =
                componentRepository.findAllByTenantIdAndApiProductVersionIdOrderByCreatedAtAsc(
                        tenantId, apiProductVersionId);

        List<ComponentMember> componentMembers = new ArrayList<>();
        Set<String> apiVersionIds = new LinkedHashSet<>();

        for (ApiProductComponentEntity component : components) {
            String targetId;
            String referencedApiVersionId;
            if (component.getTargetType() == ApiProductComponentTargetType.API_VERSION) {
                targetId = component.getApiVersionId();
                referencedApiVersionId = component.getApiVersionId();
                apiVersionRepository.findByIdAndTenantId(referencedApiVersionId, tenantId)
                        .orElseThrow(() -> invalidComponent("API Version component target이 존재하지 않습니다."));
            } else {
                targetId = component.getApiOperationId();
                ApiOperationEntity operation = operationRepository.findByIdAndTenantId(targetId, tenantId)
                        .orElseThrow(() -> invalidComponent("API Operation component target이 존재하지 않습니다."));
                referencedApiVersionId = operation.getApiVersionId();
            }
            apiVersionIds.add(referencedApiVersionId);
            componentMembers.add(new ComponentMember(
                    component.getId(), component.getTargetType().name(), targetId, referencedApiVersionId));
        }

        componentMembers.sort(Comparator
                .comparing(ComponentMember::targetType)
                .thenComparing(ComponentMember::targetId)
                .thenComparing(ComponentMember::componentId));

        List<ApiVersionEvidence> apiVersions = apiVersionIds.stream()
                .map(id -> apiVersionRepository.findByIdAndTenantId(id, tenantId)
                        .orElseThrow(() -> invalidComponent("참조 API Version이 존재하지 않습니다.")))
                .map(v -> new ApiVersionEvidence(
                        v.getId(), v.getState().name(), v.getRowVersion(), v.getSourceType(),
                        v.getSourceRepository(), v.getSourcePath(), v.getSourceRevision(),
                        v.getSourceContentHash(), v.getSourceImportId()))
                .sorted(Comparator.comparing(ApiVersionEvidence::apiVersionId))
                .toList();

        Map<String, Object> canonical = new LinkedHashMap<>();
        canonical.put("tenantId", tenantId);
        canonical.put("apiProductId", product.getId());
        canonical.put("productRowVersion", product.getRowVersion());
        canonical.put("productLocalizationRevision", product.getLocalizationRevision());
        canonical.put("apiProductVersionId", version.getId());
        canonical.put("productVersionRowVersion", version.getRowVersion());
        canonical.put("productVersionState", version.getLifecycleState().name());
        canonical.put("approvedReviewId", version.getApprovedReviewId());
        canonical.put("components", componentMembers);
        canonical.put("apiVersions", apiVersions);

        String canonicalJson = toJson(canonical);
        return new Snapshot(
                sha256Service.hashText(canonicalJson),
                canonicalJson,
                product.getRowVersion(),
                product.getLocalizationRevision(),
                version.getRowVersion(),
                componentMembers,
                apiVersions);
    }

    private BusinessException invalidComponent(String message) {
        return new BusinessException(ErrorCode.API_PRODUCT_COMPONENT_TARGET_INVALID, HttpStatus.CONFLICT, message);
    }

    private String toJson(Map<String, Object> canonical) {
        try {
            return objectMapper.writeValueAsString(canonical);
        } catch (JsonProcessingException ex) {
            throw new IllegalStateException("Publication review snapshot serialization failed", ex);
        }
    }

    public record ComponentMember(
            String componentId,
            String targetType,
            String targetId,
            String referencedApiVersionId) {
    }

    public record ApiVersionEvidence(
            String apiVersionId,
            String state,
            long rowVersion,
            String sourceType,
            String sourceRepository,
            String sourcePath,
            String sourceRevision,
            String sourceContentHash,
            String sourceImportId) {
        public boolean hasImportEvidence() {
            return sourceContentHash != null && !sourceContentHash.isBlank()
                    && sourceImportId != null && !sourceImportId.isBlank();
        }

        public boolean hasReconstructableSourceReference() {
            return sourceRepository != null && !sourceRepository.isBlank()
                    && sourcePath != null && !sourcePath.isBlank()
                    && sourceRevision != null && !sourceRevision.isBlank();
        }
    }

    public record Snapshot(
            String hash,
            String canonicalJson,
            long productRowVersion,
            long productLocalizationRevision,
            long productVersionRowVersion,
            List<ComponentMember> components,
            List<ApiVersionEvidence> apiVersions) {
        public List<String> referencedApiVersionIds() {
            return apiVersions.stream().map(ApiVersionEvidence::apiVersionId).toList();
        }
    }
}

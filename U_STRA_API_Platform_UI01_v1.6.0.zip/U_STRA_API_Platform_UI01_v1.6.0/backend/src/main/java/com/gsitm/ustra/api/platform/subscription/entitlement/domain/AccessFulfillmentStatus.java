package com.gsitm.ustra.api.platform.subscription.entitlement.domain;
public enum AccessFulfillmentStatus { PENDING, PROCESSING, SUCCEEDED, FAILED, UNKNOWN, RECONCILING }

package com.gsitm.ustra.api.platform.integration.approval.api;
import com.gsitm.ustra.api.platform.common.error.*; import com.gsitm.ustra.api.platform.integration.approval.application.ApprovalIntegrationOperatorService; import com.gsitm.ustra.api.platform.integration.approval.domain.IntegrationOperationStatus; import java.util.*; import org.springframework.http.*; import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/api/v1/admin/approval-integrations") public class ApprovalIntegrationAdminController {
 private final ApprovalIntegrationOperatorService service; public ApprovalIntegrationAdminController(ApprovalIntegrationOperatorService s){service=s;}
 @GetMapping("/operations") public List<ApprovalIntegrationOperatorService.OperationView> operations(@RequestParam(required=false) String status){return service.operations(parseStatus(status));}
 @GetMapping("/issues") public List<ApprovalIntegrationOperatorService.IssueView> issues(){return service.issues();}
 @PostMapping("/approval-references/{approvalReferenceId}/reconcile") public ResponseEntity<ApprovalIntegrationOperatorService.ReconcileView> reconcile(@PathVariable String approvalReferenceId){return ResponseEntity.ok(service.reconcileApprovalReference(approvalReferenceId));}
 private IntegrationOperationStatus parseStatus(String value){if(value==null||value.isBlank())return null;try{return IntegrationOperationStatus.valueOf(value.trim().toUpperCase(Locale.ROOT));}catch(IllegalArgumentException ex){throw new BusinessException(ErrorCode.VALIDATION_ERROR,HttpStatus.BAD_REQUEST,"지원하지 않는 IntegrationOperation status입니다.");}}
}

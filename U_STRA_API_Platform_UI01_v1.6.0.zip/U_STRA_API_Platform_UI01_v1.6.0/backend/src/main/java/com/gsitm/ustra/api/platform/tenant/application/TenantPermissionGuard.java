package com.gsitm.ustra.api.platform.tenant.application;

import com.gsitm.ustra.api.platform.audit.AuditService;
import com.gsitm.ustra.api.platform.common.error.BusinessException;
import com.gsitm.ustra.api.platform.common.error.ErrorCode;
import com.gsitm.ustra.api.platform.tenant.context.TenantContext;
import com.gsitm.ustra.api.platform.tenant.persistence.RolePermissionRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

@Component
public class TenantPermissionGuard {
    private final RolePermissionRepository rolePermissionRepository;
    private final AuditService auditService;

    public TenantPermissionGuard(RolePermissionRepository rolePermissionRepository, AuditService auditService) {
        this.rolePermissionRepository = rolePermissionRepository;
        this.auditService = auditService;
    }

    /** Read-model capability check; not a replacement for require() on actions. */
    public boolean has(TenantContext context, String permissionCode) {
        return !context.roles().isEmpty()
                && rolePermissionRepository.countPermissionForRoles(context.roles(), permissionCode) > 0;
    }

    public void require(TenantContext context, String permissionCode, String resourceType, String resourceId) {
        if (context.roles().isEmpty()
                || rolePermissionRepository.countPermissionForRoles(context.roles(), permissionCode) == 0) {
            auditService.denied(context.tenantId(), "AUTHORIZE:" + permissionCode, resourceType,
                    resourceId == null ? "unknown" : resourceId, ErrorCode.ACCESS_DENIED.name());
            throw new BusinessException(ErrorCode.ACCESS_DENIED, HttpStatus.FORBIDDEN, "요청 권한이 없습니다.");
        }
    }
}

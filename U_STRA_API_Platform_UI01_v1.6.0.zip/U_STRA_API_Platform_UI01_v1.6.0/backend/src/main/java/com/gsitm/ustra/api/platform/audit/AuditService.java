package com.gsitm.ustra.api.platform.audit;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gsitm.ustra.api.platform.common.context.RequestContextHolder;
import com.gsitm.ustra.api.platform.security.AuthenticatedIdentityProvider;
import java.time.Clock;
import java.time.Instant;
import java.util.Map;
import java.util.UUID;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AuditService {
    private final AuditRecordRepository repository;
    private final AuthenticatedIdentityProvider identityProvider;
    private final ObjectMapper objectMapper;
    private final Clock clock;

    public AuditService(AuditRecordRepository repository,
                        AuthenticatedIdentityProvider identityProvider,
                        ObjectMapper objectMapper,
                        Clock clock) {
        this.repository = repository;
        this.identityProvider = identityProvider;
        this.objectMapper = objectMapper;
        this.clock = clock;
    }

    public void success(String tenantId, String action, String resourceType, String resourceId,
                        boolean privileged, Map<String, Object> safeDiff) {
        String actor = identityProvider.current().principalId();
        String correlationId = RequestContextHolder.required().correlationId();
        repository.save(new AuditRecordEntity(
                UUID.randomUUID().toString(), tenantId, Instant.now(clock), actor, "IDENTITY",
                action, resourceType, resourceId, "SUCCESS", null, correlationId, privileged,
                toSafeJson(safeDiff), null, null));
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void denied(String tenantId, String action, String resourceType, String resourceId, String reasonCode) {
        String actor = identityProvider.current().principalId();
        String correlationId = RequestContextHolder.required().correlationId();
        repository.save(new AuditRecordEntity(
                UUID.randomUUID().toString(), tenantId, Instant.now(clock), actor, "IDENTITY",
                action, resourceType, resourceId, "DENIED", reasonCode, correlationId, true,
                null, null, null));
    }

    private String toSafeJson(Map<String, Object> safeDiff) {
        if (safeDiff == null || safeDiff.isEmpty()) {
            return null;
        }
        try {
            return objectMapper.writeValueAsString(safeDiff);
        } catch (JsonProcessingException ex) {
            throw new IllegalStateException("Failed to serialize safe audit diff", ex);
        }
    }
}

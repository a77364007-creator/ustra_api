package com.gsitm.ustra.api.platform.integration.approval.domain;

public enum IntegrationType {
    APPROVAL_ITSM,
    GATEWAY_IAM
}

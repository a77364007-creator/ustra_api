package com.gsitm.ustra.api.platform.search.persistence;
import java.util.*;
import org.springframework.data.jpa.repository.*;
public interface SearchProjectionFailureRepository extends JpaRepository<SearchProjectionFailureEntity,String>,
        JpaSpecificationExecutor<SearchProjectionFailureEntity> {
    Optional<SearchProjectionFailureEntity> findByTenantIdAndApiProductId(String tenantId,String apiProductId);
    List<SearchProjectionFailureEntity> findAllByTenantIdAndStatus(String tenantId,String status);
}

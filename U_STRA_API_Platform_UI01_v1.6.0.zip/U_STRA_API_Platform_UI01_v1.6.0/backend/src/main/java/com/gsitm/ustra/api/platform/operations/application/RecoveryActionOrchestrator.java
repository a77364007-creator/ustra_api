package com.gsitm.ustra.api.platform.operations.application;

import com.gsitm.ustra.api.platform.audit.AuditService;
import com.gsitm.ustra.api.platform.common.error.*;
import com.gsitm.ustra.api.platform.operations.domain.*;
import com.gsitm.ustra.api.platform.integration.approval.application.ApprovalIntegrationOrchestrator;
import com.gsitm.ustra.api.platform.integration.gateway.application.GatewayIntegrationOrchestrator;
import com.gsitm.ustra.api.platform.search.application.SearchProjectionRecoveryService;
import com.gsitm.ustra.api.platform.tenant.application.TenantPermissionGuard;
import com.gsitm.ustra.api.platform.tenant.context.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.*;

@Service
@Transactional(propagation=Propagation.NOT_SUPPORTED)
public class RecoveryActionOrchestrator {
    private final TenantContextResolver contexts;
    private final TenantPermissionGuard permissions;
    private final RecoveryTargetValidator targets;
    private final RecoveryActionService journal;
    private final ApprovalIntegrationOrchestrator approval;
    private final GatewayIntegrationOrchestrator gateway;
    private final SearchProjectionRecoveryService search;
    private final AuditService audit;
    public RecoveryActionOrchestrator(TenantContextResolver contexts,TenantPermissionGuard permissions,
            RecoveryTargetValidator targets,RecoveryActionService journal,ApprovalIntegrationOrchestrator approval,
            GatewayIntegrationOrchestrator gateway,SearchProjectionRecoveryService search,AuditService audit) {
        this.contexts=contexts;this.permissions=permissions;this.targets=targets;this.journal=journal;
        this.approval=approval;this.gateway=gateway;this.search=search;this.audit=audit;
    }
    public RecoveryActionService.View execute(String key,RecoveryRequest body) {
        TenantContext c=contexts.resolve();
        final RecoveryRequest request;
        try {key=RecoveryRequest.validateKey(key);request=body.validated();}
        catch(IllegalArgumentException|NullPointerException ex) {
            audit.denied(c.tenantId(),"OPERATIONS_RECOVERY_REJECTED","OPERATIONS_RECOVERY_ACTION","invalid",ErrorCode.VALIDATION_ERROR.name());
            throw new BusinessException(ErrorCode.VALIDATION_ERROR,HttpStatus.BAD_REQUEST,"복구 요청 형식이 올바르지 않습니다.");
        }
        permissions.require(c,request.actionType().executePermission(),request.actionType().targetType(),request.targetId());
        RecoveryActionService.Prepared prepared;
        try {prepared=journal.prepare(c,key,request);}
        catch(BusinessException ex) {
            audit.denied(c.tenantId(),"OPERATIONS_RECOVERY_REJECTED",request.actionType().targetType(),request.targetId(),ex.code().name());
            throw ex;
        }
        String id=prepared.row().getId();
        if(!prepared.created() || !journal.claim(c.tenantId(),id)) {
            return RecoveryActionService.View.from(journal.owned(c.tenantId(),id));
        }
        // Recheck mutable target before invoking the existing application service.
        try {targets.validate(c.tenantId(),request);}
        catch(BusinessException ex) {
            return journal.complete(c.tenantId(),id,RecoveryActionStatus.FAILED,null,null,"TARGET_PRECONDITION_CHANGED");
        }
        catch(RuntimeException ex) {
            return uncertain(c.tenantId(),id,"TARGET_REVALIDATION_UNCONFIRMED");
        }
        Outcome outcome;
        try {
            outcome=switch(request.actionType()) {
                case APPROVAL_STATUS_RECONCILE -> {
                    var result=approval.synchronize(c.tenantId(),request.targetId());
                    yield new Outcome(result.operation().getStatus()==com.gsitm.ustra.api.platform.integration.approval.domain.IntegrationOperationStatus.UNKNOWN
                            ? "UNKNOWN" : result.decisionStatus().name(),result.operation().getId(),"STATUS_QUERY_COMPLETED");
                }
                case GATEWAY_STATUS_RECONCILE -> {
                    var result=gateway.reconcile(c.tenantId(),request.targetId());
                    yield new Outcome(result.fulfillmentStatus(),result.integrationOperationId(),"STATUS_QUERY_COMPLETED");
                }
                case SEARCH_PRODUCT_REINDEX -> {
                    search.reindex(c.tenantId(),request.targetId(),c.principalId());
                    yield new Outcome("REINDEX_COMPLETED",null,"SEARCH_REINDEX_COMPLETED");
                }
                case SEARCH_TENANT_REBUILD -> {
                    search.rebuild(c.tenantId(),c.principalId());
                    yield new Outcome("REBUILD_COMPLETED",null,"SEARCH_REBUILD_COMPLETED");
                }
            };
        } catch(RuntimeException ex) {
            return uncertain(c.tenantId(),id,"HANDLER_OUTCOME_UNCONFIRMED");
        }
        try {
            // Handler completion is NOT approval / fulfillment success. targetStatus remains separate.
            return journal.complete(c.tenantId(),id,RecoveryActionStatus.SUCCEEDED,outcome.targetStatus(),outcome.operationId(),outcome.code());
        } catch(RuntimeException ex) {
            return uncertain(c.tenantId(),id,"RESULT_RECORD_UNCONFIRMED");
        }
    }
    private RecoveryActionService.View uncertain(String tenantId,String id,String code) {
        try {return journal.complete(tenantId,id,RecoveryActionStatus.UNKNOWN,null,null,code);}
        catch(RuntimeException ex) {
            // Durable IN_PROGRESS may remain if the DB is unavailable. Do not replay or force success.
            throw new BusinessException(ErrorCode.OPERATIONS_RECOVERY_RECORD_UNAVAILABLE,HttpStatus.SERVICE_UNAVAILABLE,
                    "결과 기록을 확인할 수 없습니다. 동일 요청 키로 실행기록을 확인하십시오.");
        }
    }
    public RecoveryActionService.View get(String id) {
        TenantContext c=contexts.resolve();
        permissions.require(c,"OPERATIONS:READ","OPERATIONS_RECOVERY_ACTION",id);
        var allowed=java.util.Arrays.stream(RecoveryActionType.values())
                .filter(type->permissions.has(c,type.readPermission())).toList();
        var row=journal.ownedReadable(c.tenantId(),id,allowed);
        permissions.require(c,row.getActionType().readPermission(),row.getTargetType(),row.getTargetId());
        return RecoveryActionService.View.from(row);
    }
    private record Outcome(String targetStatus,String operationId,String code) {}
}

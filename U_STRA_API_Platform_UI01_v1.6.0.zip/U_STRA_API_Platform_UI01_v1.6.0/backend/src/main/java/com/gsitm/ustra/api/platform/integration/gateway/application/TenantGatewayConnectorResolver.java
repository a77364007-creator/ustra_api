package com.gsitm.ustra.api.platform.integration.gateway.application;

import com.gsitm.ustra.api.platform.common.error.BusinessException;
import com.gsitm.ustra.api.platform.common.error.ErrorCode;
import com.gsitm.ustra.api.platform.integration.approval.domain.IntegrationType;
import com.gsitm.ustra.api.platform.integration.approval.persistence.ConnectorInstanceEntity;
import com.gsitm.ustra.api.platform.integration.approval.persistence.ConnectorInstanceRepository;
import com.gsitm.ustra.api.platform.integration.approval.persistence.IntegrationProfileRepository;
import java.util.ArrayList;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class TenantGatewayConnectorResolver {
    private final IntegrationProfileRepository profiles;
    private final ConnectorInstanceRepository connectors;

    public TenantGatewayConnectorResolver(
            IntegrationProfileRepository profiles,
            ConnectorInstanceRepository connectors) {
        this.profiles = profiles;
        this.connectors = connectors;
    }

    @Transactional(readOnly = true)
    public ConnectorInstanceEntity resolve(String tenantId) {
        List<ConnectorInstanceEntity> active = new ArrayList<>();
        for (var profile : profiles.findAllByTenantIdAndIntegrationTypeAndEnabledTrueOrderByProfileCodeAsc(
                tenantId, IntegrationType.GATEWAY_IAM)) {
            active.addAll(connectors.findAllByTenantIdAndIntegrationProfileIdAndEnabledTrueOrderByConnectorCodeAsc(
                    tenantId, profile.getId()));
        }
        if (active.isEmpty()) {
            throw new BusinessException(
                    ErrorCode.INTEGRATION_CONNECTOR_NOT_FOUND,
                    HttpStatus.CONFLICT,
                    "Tenant에 활성 Gateway/IAM connector가 없습니다.");
        }
        if (active.size() != 1) {
            throw new BusinessException(
                    ErrorCode.INTEGRATION_CONNECTOR_AMBIGUOUS,
                    HttpStatus.CONFLICT,
                    "Tenant의 Gateway/IAM connector를 하나로 결정할 수 없습니다.");
        }
        return active.getFirst();
    }

    @Transactional(readOnly = true)
    public ConnectorInstanceEntity owned(String tenantId, String connectorId) {
        return connectors.findByIdAndTenantId(connectorId, tenantId)
                .orElseThrow(() -> new BusinessException(
                        ErrorCode.INTEGRATION_CONNECTOR_NOT_FOUND,
                        HttpStatus.NOT_FOUND,
                        "ConnectorInstance를 찾을 수 없습니다."));
    }

    @Transactional(readOnly = true)
    public ConnectorInstanceEntity ownedEnabled(String tenantId, String connectorId) {
        ConnectorInstanceEntity connector = owned(tenantId, connectorId);
        if (!connector.isEnabled()) {
            throw new BusinessException(
                    ErrorCode.INTEGRATION_CONNECTOR_DISABLED,
                    HttpStatus.CONFLICT,
                    "Gateway/IAM connector가 비활성 상태입니다.");
        }
        return connector;
    }
}

package com.gsitm.ustra.api.platform.provider.publishing.application;

import com.gsitm.ustra.api.platform.audit.AuditService;
import com.gsitm.ustra.api.platform.catalog.domain.ApiProductLifecycleState;
import com.gsitm.ustra.api.platform.catalog.domain.ApiVersionState;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiProductEntity;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiProductRepository;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiVersionEntity;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiVersionRepository;
import com.gsitm.ustra.api.platform.catalog.publication.application.StateTransitionHistoryService;
import com.gsitm.ustra.api.platform.catalog.publication.domain.ApiProductVersionState;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.ApiProductVersionEntity;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.ApiProductVersionRepository;
import com.gsitm.ustra.api.platform.common.error.BusinessException;
import com.gsitm.ustra.api.platform.common.error.ErrorCode;
import com.gsitm.ustra.api.platform.provider.publishing.domain.PublicationReviewState;
import com.gsitm.ustra.api.platform.provider.publishing.persistence.PublicationReviewEntity;
import com.gsitm.ustra.api.platform.provider.publishing.persistence.PublicationReviewRepository;
import com.gsitm.ustra.api.platform.provider.publishing.snapshot.PublicationSnapshotBuilder;
import com.gsitm.ustra.api.platform.provider.publishing.snapshot.PublicationSnapshotBuilder.Snapshot;
import com.gsitm.ustra.api.platform.tenant.application.TenantPermissionGuard;
import com.gsitm.ustra.api.platform.tenant.context.TenantContext;
import com.gsitm.ustra.api.platform.tenant.context.TenantContextResolver;
import java.time.Clock;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class PublicationReviewService {
    private static final List<PublicationReviewState> ACTIVE_REVIEW_STATES =
            List.of(PublicationReviewState.SUBMITTED, PublicationReviewState.IN_REVIEW);

    private final TenantContextResolver contextResolver;
    private final TenantPermissionGuard permissionGuard;
    private final ApiProductRepository productRepository;
    private final ApiProductVersionRepository productVersionRepository;
    private final ApiVersionRepository apiVersionRepository;
    private final PublicationReviewRepository reviewRepository;
    private final PublicationSnapshotBuilder snapshotBuilder;
    private final PublishReadinessService readinessService;
    private final StateTransitionHistoryService historyService;
    private final AuditService auditService;
    private final Clock clock;

    public PublicationReviewService(
            TenantContextResolver contextResolver,
            TenantPermissionGuard permissionGuard,
            ApiProductRepository productRepository,
            ApiProductVersionRepository productVersionRepository,
            ApiVersionRepository apiVersionRepository,
            PublicationReviewRepository reviewRepository,
            PublicationSnapshotBuilder snapshotBuilder,
            PublishReadinessService readinessService,
            StateTransitionHistoryService historyService,
            AuditService auditService,
            Clock clock) {
        this.contextResolver = contextResolver;
        this.permissionGuard = permissionGuard;
        this.productRepository = productRepository;
        this.productVersionRepository = productVersionRepository;
        this.apiVersionRepository = apiVersionRepository;
        this.reviewRepository = reviewRepository;
        this.snapshotBuilder = snapshotBuilder;
        this.readinessService = readinessService;
        this.historyService = historyService;
        this.auditService = auditService;
        this.clock = clock;
    }

    @Transactional(readOnly = true)
    public PublicationReviewEntity get(String reviewId) {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "PUBLICATION_REVIEW:READ", "PUBLICATION_REVIEW", reviewId);
        return ownedReview(context, reviewId);
    }

    @Transactional
    public PublicationReviewEntity submit(String apiProductId, String apiProductVersionId, long expectedVersion) {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "PUBLICATION_REVIEW:SUBMIT", "API_PRODUCT_VERSION", apiProductVersionId);

        ApiProductVersionEntity version = ownedVersion(context, apiProductVersionId);
        if (!Objects.equals(version.getApiProductId(), apiProductId)) {
            throw new BusinessException(ErrorCode.API_PRODUCT_VERSION_NOT_FOUND, HttpStatus.NOT_FOUND,
                    "API Product Version을 찾을 수 없습니다.");
        }
        requireVersionRevision(version, expectedVersion);
        if (version.getLifecycleState() != ApiProductVersionState.DRAFT) {
            throw versionStateInvalid("DRAFT ProductVersion만 PublicationReview를 제출할 수 있습니다.");
        }
        if (reviewRepository.existsByTenantIdAndApiProductVersionIdAndStateIn(
                context.tenantId(), version.getId(), ACTIVE_REVIEW_STATES)) {
            throw new BusinessException(ErrorCode.PUBLICATION_REVIEW_CONFLICT, HttpStatus.CONFLICT,
                    "진행 중인 PublicationReview가 이미 존재합니다.");
        }

        PublishReadinessService.Readiness preReadiness =
                readinessService.evaluateInternal(context.tenantId(), version.getId());
        readinessService.requireReviewSubmittable(preReadiness);

        ApiProductEntity product = ownedProduct(context, apiProductId);
        Instant now = Instant.now(clock);

        String productFrom = product.getLifecycleState().name();
        boolean productMoved = product.beginReview(now, context.principalId());
        if (productMoved) {
            product = productRepository.saveAndFlush(product);
            historyService.record(context.tenantId(), "API_PRODUCT", product.getId(),
                    productFrom, product.getLifecycleState().name());
        }

        String versionFrom = version.getLifecycleState().name();
        version.beginValidation(now, context.principalId());
        version = productVersionRepository.saveAndFlush(version);
        historyService.record(context.tenantId(), "API_PRODUCT_VERSION", version.getId(),
                versionFrom, version.getLifecycleState().name());

        Snapshot snapshot = snapshotBuilder.build(context.tenantId(), version.getId());
        PublicationReviewEntity review = reviewRepository.saveAndFlush(new PublicationReviewEntity(
                UUID.randomUUID().toString(),
                context.tenantId(),
                product.getId(),
                version.getId(),
                snapshot.hash(),
                snapshot.canonicalJson(),
                snapshot.productRowVersion(),
                snapshot.productLocalizationRevision(),
                snapshot.productVersionRowVersion(),
                now,
                context.principalId()));

        historyService.record(context.tenantId(), "PUBLICATION_REVIEW", review.getId(),
                "DRAFT", review.getState().name());
        auditService.success(context.tenantId(), "PUBLICATION_REVIEW_SUBMITTED",
                "PUBLICATION_REVIEW", review.getId(), true,
                Map.of("apiProductId", product.getId(),
                        "apiProductVersionId", version.getId(),
                        "submittedSnapshotHash", snapshot.hash()));
        return review;
    }

    @Transactional
    public PublicationReviewEntity start(String reviewId, long expectedVersion) {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "PUBLICATION_REVIEW:DECIDE", "PUBLICATION_REVIEW", reviewId);
        PublicationReviewEntity review = ownedReview(context, reviewId);
        requireReviewRevision(review, expectedVersion);
        if (review.getState() != PublicationReviewState.SUBMITTED) {
            throw reviewStateInvalid("SUBMITTED PublicationReview만 검토를 시작할 수 있습니다.");
        }

        String from = review.getState().name();
        review.start(Instant.now(clock), context.principalId());
        review = reviewRepository.saveAndFlush(review);
        historyService.record(context.tenantId(), "PUBLICATION_REVIEW", review.getId(),
                from, review.getState().name());
        return review;
    }

    @Transactional
    public PublicationReviewEntity approve(
            String reviewId, long expectedVersion, String reasonCode, String summary) {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "PUBLICATION_REVIEW:DECIDE", "PUBLICATION_REVIEW", reviewId);
        PublicationReviewEntity review = ownedReview(context, reviewId);
        requireReviewRevision(review, expectedVersion);
        if (review.getState() == PublicationReviewState.APPROVED) {
            return review;
        }
        if (review.getState() != PublicationReviewState.IN_REVIEW) {
            throw reviewStateInvalid("IN_REVIEW PublicationReview만 승인할 수 있습니다.");
        }

        Snapshot submittedCurrent = snapshotBuilder.build(context.tenantId(), review.getApiProductVersionId());
        if (!Objects.equals(review.getSubmittedSnapshotHash(), submittedCurrent.hash())) {
            throw snapshotMismatch();
        }

        PublishReadinessService.Readiness readiness =
                readinessService.evaluateInternal(context.tenantId(), review.getApiProductVersionId());
        readinessService.requireReady(readiness);

        Instant now = Instant.now(clock);
        validateReferencedApiVersions(context, submittedCurrent, now);

        ApiProductVersionEntity version = ownedVersion(context, review.getApiProductVersionId());
        if (version.getLifecycleState() != ApiProductVersionState.VALIDATING) {
            throw versionStateInvalid("VALIDATING ProductVersion만 PublicationReview 승인으로 APPROVED가 될 수 있습니다.");
        }
        String versionFrom = version.getLifecycleState().name();
        version.approve(review.getId(), now, context.principalId());
        version = productVersionRepository.saveAndFlush(version);
        historyService.record(context.tenantId(), "API_PRODUCT_VERSION", version.getId(),
                versionFrom, version.getLifecycleState().name());

        Snapshot approvedSnapshot = snapshotBuilder.build(context.tenantId(), version.getId());
        String reviewFrom = review.getState().name();
        review.approve(approvedSnapshot.hash(), approvedSnapshot.canonicalJson(),
                safeReason(reasonCode), safeSummary(summary), now, context.principalId());
        review = reviewRepository.saveAndFlush(review);
        historyService.record(context.tenantId(), "PUBLICATION_REVIEW", review.getId(),
                reviewFrom, review.getState().name());

        auditService.success(context.tenantId(), "PUBLICATION_REVIEW_APPROVED",
                "PUBLICATION_REVIEW", review.getId(), true,
                Map.of("apiProductVersionId", version.getId(),
                        "submittedSnapshotHash", review.getSubmittedSnapshotHash(),
                        "approvedSnapshotHash", review.getApprovedSnapshotHash()));
        return review;
    }

    @Transactional
    public PublicationReviewEntity requestChanges(
            String reviewId, long expectedVersion, String reasonCode, String summary) {
        return returnToDraft(reviewId, expectedVersion, reasonCode, summary, Decision.CHANGES_REQUESTED);
    }

    @Transactional
    public PublicationReviewEntity reject(
            String reviewId, long expectedVersion, String reasonCode, String summary) {
        return returnToDraft(reviewId, expectedVersion, reasonCode, summary, Decision.REJECTED);
    }

    @Transactional
    public PublicationReviewEntity cancel(
            String reviewId, long expectedVersion, String reasonCode, String summary) {
        return returnToDraft(reviewId, expectedVersion, reasonCode, summary, Decision.CANCELLED);
    }

    private PublicationReviewEntity returnToDraft(
            String reviewId, long expectedVersion, String reasonCode, String summary, Decision decision) {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "PUBLICATION_REVIEW:DECIDE", "PUBLICATION_REVIEW", reviewId);
        PublicationReviewEntity review = ownedReview(context, reviewId);
        requireReviewRevision(review, expectedVersion);
        if (review.getState() != PublicationReviewState.IN_REVIEW) {
            throw reviewStateInvalid("IN_REVIEW PublicationReview만 반려/변경요청/취소할 수 있습니다.");
        }

        ApiProductVersionEntity version = ownedVersion(context, review.getApiProductVersionId());
        if (version.getLifecycleState() != ApiProductVersionState.VALIDATING) {
            throw versionStateInvalid("PublicationReview 실패 복귀 대상 ProductVersion이 VALIDATING이 아닙니다.");
        }

        Instant now = Instant.now(clock);
        String reviewFrom = review.getState().name();
        switch (decision) {
            case CHANGES_REQUESTED ->
                    review.requestChanges(safeReason(reasonCode), safeSummary(summary), now, context.principalId());
            case REJECTED ->
                    review.reject(safeReason(reasonCode), safeSummary(summary), now, context.principalId());
            case CANCELLED ->
                    review.cancel(safeReason(reasonCode), safeSummary(summary), now, context.principalId());
        }
        review = reviewRepository.saveAndFlush(review);
        historyService.record(context.tenantId(), "PUBLICATION_REVIEW", review.getId(),
                reviewFrom, review.getState().name());

        String versionFrom = version.getLifecycleState().name();
        version.returnToDraft(now, context.principalId());
        version = productVersionRepository.saveAndFlush(version);
        historyService.record(context.tenantId(), "API_PRODUCT_VERSION", version.getId(),
                versionFrom, version.getLifecycleState().name());

        auditService.success(context.tenantId(), decision.auditAction,
                "PUBLICATION_REVIEW", review.getId(), true,
                Map.of("apiProductVersionId", version.getId(),
                        "submittedSnapshotHash", review.getSubmittedSnapshotHash()));
        return review;
    }

    private void validateReferencedApiVersions(TenantContext context, Snapshot snapshot, Instant now) {
        for (String apiVersionId : snapshot.referencedApiVersionIds()) {
            ApiVersionEntity apiVersion = apiVersionRepository.findByIdAndTenantId(apiVersionId, context.tenantId())
                    .orElseThrow(() -> new BusinessException(ErrorCode.API_VERSION_NOT_FOUND, HttpStatus.CONFLICT,
                            "Review snapshot의 API Version을 찾을 수 없습니다."));
            ApiVersionState from = apiVersion.getState();
            if (from == ApiVersionState.DRAFT) {
                apiVersion.validateForPublication(now, context.principalId());
                apiVersionRepository.saveAndFlush(apiVersion);
                historyService.record(context.tenantId(), "API_VERSION", apiVersion.getId(),
                        from.name(), apiVersion.getState().name());
            } else if (from != ApiVersionState.VALIDATED && from != ApiVersionState.RELEASED) {
                throw new BusinessException(ErrorCode.API_VERSION_STATE_INVALID, HttpStatus.CONFLICT,
                        "DRAFT/VALIDATED/RELEASED API Version만 PublicationReview 승인에 참여할 수 있습니다.");
            }
        }
    }

    private ApiProductEntity ownedProduct(TenantContext context, String id) {
        return productRepository.findByIdAndTenantId(id, context.tenantId())
                .orElseThrow(() -> new BusinessException(ErrorCode.API_PRODUCT_NOT_FOUND, HttpStatus.NOT_FOUND,
                        "API Product를 찾을 수 없습니다."));
    }

    private ApiProductVersionEntity ownedVersion(TenantContext context, String id) {
        return productVersionRepository.findByIdAndTenantId(id, context.tenantId())
                .orElseThrow(() -> new BusinessException(ErrorCode.API_PRODUCT_VERSION_NOT_FOUND, HttpStatus.NOT_FOUND,
                        "API Product Version을 찾을 수 없습니다."));
    }

    private PublicationReviewEntity ownedReview(TenantContext context, String id) {
        return reviewRepository.findByIdAndTenantId(id, context.tenantId())
                .orElseThrow(() -> new BusinessException(ErrorCode.PUBLICATION_REVIEW_NOT_FOUND, HttpStatus.NOT_FOUND,
                        "PublicationReview를 찾을 수 없습니다."));
    }

    private void requireVersionRevision(ApiProductVersionEntity version, long expectedVersion) {
        if (version.getRowVersion() != expectedVersion) {
            throw new BusinessException(ErrorCode.CONCURRENT_MODIFICATION, HttpStatus.CONFLICT,
                    "API Product Version이 다른 요청에 의해 변경되었습니다.");
        }
    }

    private void requireReviewRevision(PublicationReviewEntity review, long expectedVersion) {
        if (review.getRowVersion() != expectedVersion) {
            throw new BusinessException(ErrorCode.CONCURRENT_MODIFICATION, HttpStatus.CONFLICT,
                    "PublicationReview가 다른 요청에 의해 변경되었습니다.");
        }
    }

    private BusinessException versionStateInvalid(String message) {
        return new BusinessException(ErrorCode.API_PRODUCT_VERSION_STATE_INVALID, HttpStatus.CONFLICT, message);
    }

    private BusinessException reviewStateInvalid(String message) {
        return new BusinessException(ErrorCode.PUBLICATION_REVIEW_STATE_INVALID, HttpStatus.CONFLICT, message);
    }

    private BusinessException snapshotMismatch() {
        return new BusinessException(ErrorCode.PUBLICATION_REVIEW_SNAPSHOT_MISMATCH, HttpStatus.CONFLICT,
                "현재 ProductVersion 상태가 제출된 review snapshot과 일치하지 않습니다.");
    }

    private String safeReason(String reasonCode) {
        if (reasonCode == null) return null;
        String value = reasonCode.trim();
        return value.length() <= 100 ? value : value.substring(0, 100);
    }

    private String safeSummary(String summary) {
        if (summary == null) return null;
        String value = summary.replace("\r", " ").replace("\n", " ").trim();
        return value.length() <= 500 ? value : value.substring(0, 500);
    }

    private enum Decision {
        CHANGES_REQUESTED("PUBLICATION_REVIEW_CHANGES_REQUESTED"),
        REJECTED("PUBLICATION_REVIEW_REJECTED"),
        CANCELLED("PUBLICATION_REVIEW_CANCELLED");

        private final String auditAction;

        Decision(String auditAction) {
            this.auditAction = auditAction;
        }
    }
}

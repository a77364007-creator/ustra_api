package com.gsitm.ustra.api.platform.search.persistence;

import jakarta.persistence.*;
import java.time.Instant;

@Entity @Table(name="search_projection_failure")
public class SearchProjectionFailureEntity {
    @Id @Column(name="failure_id",length=36,nullable=false,updatable=false) private String id;
    @Column(name="tenant_id",length=36,nullable=false,updatable=false) private String tenantId;
    @Column(name="api_product_id",length=36,nullable=false,updatable=false) private String apiProductId;
    @Column(name="observed_at",nullable=false,updatable=false) private Instant observedAt;
    @Column(name="last_checked_at",nullable=false) private Instant lastCheckedAt;
    @Column(name="resolved_at") private Instant resolvedAt;
    @Column(name="safe_error_code",length=120,nullable=false) private String safeErrorCode;
    @Column(name="status",length=30,nullable=false) private String status;
    @Column(name="observation_count",nullable=false) private long observationCount;
    @Version @Column(name="row_version",nullable=false) private long rowVersion;
    protected SearchProjectionFailureEntity() {}
    public SearchProjectionFailureEntity(String id,String tenantId,String productId,Instant now) {
        this.id=id;this.tenantId=tenantId;this.apiProductId=productId;this.observedAt=now;observe(now);
    }
    public void observe(Instant now) {
        observationCount++;status="OPEN";safeErrorCode="SEARCH_PROJECTION_REFRESH_FAILED";lastCheckedAt=now;resolvedAt=null;
    }
    public boolean resolveIfVersion(long expectedVersion,Instant now) {
        if(!"OPEN".equals(status)||rowVersion!=expectedVersion) return false;
        status="RESOLVED";resolvedAt=now;lastCheckedAt=now;return true;
    }
    public String getId(){return id;} public String getTenantId(){return tenantId;} public String getApiProductId(){return apiProductId;}
    public Instant getObservedAt(){return observedAt;} public Instant getLastCheckedAt(){return lastCheckedAt;}
    public Instant getResolvedAt(){return resolvedAt;} public String getSafeErrorCode(){return safeErrorCode;}
    public String getStatus(){return status;} public long getRowVersion(){return rowVersion;}
}

package com.gsitm.ustra.api.platform.security;

import com.gsitm.ustra.api.platform.common.error.BusinessException;
import com.gsitm.ustra.api.platform.common.error.ErrorCode;
import java.net.URI;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Component;

@Component
public class AuthenticatedIdentityProvider {
    public AuthenticatedIdentity current() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !authentication.isAuthenticated()) {
            throw new BusinessException(ErrorCode.AUTHENTICATION_REQUIRED, HttpStatus.UNAUTHORIZED, "인증이 필요합니다.");
        }
        Object principal = authentication.getPrincipal();
        if (principal instanceof UstraPrincipal ustraPrincipal) {
            return new AuthenticatedIdentity(ustraPrincipal.principalId(), ustraPrincipal.issuer());
        }
        if (principal instanceof Jwt jwt) {
            URI issuer = jwt.getIssuer();
            String issuerValue = issuer == null ? "unknown" : issuer.toString();
            return new AuthenticatedIdentity(jwt.getSubject(), issuerValue);
        }
        return new AuthenticatedIdentity(authentication.getName(), "spring-security");
    }
}

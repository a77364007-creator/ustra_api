package com.gsitm.ustra.api.platform.catalog.publication.persistence;

import java.util.Collection;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ApiProductComponentRepository extends JpaRepository<ApiProductComponentEntity, String> {
    List<ApiProductComponentEntity> findAllByTenantIdAndApiProductVersionIdOrderByCreatedAtAsc(String tenantId, String apiProductVersionId);
    Optional<ApiProductComponentEntity> findByIdAndTenantIdAndApiProductVersionId(String id, String tenantId, String apiProductVersionId);
    List<ApiProductComponentEntity> findAllByTenantIdAndApiVersionId(String tenantId, String apiVersionId);
    List<ApiProductComponentEntity> findAllByTenantIdAndApiOperationIdIn(String tenantId, Collection<String> apiOperationIds);
}

package com.gsitm.ustra.api.platform.search.application;

public interface CatalogSearchProjectionPort {
    RebuildResult rebuildTenant(String tenantId, String actor);
    ReindexResult reindexProduct(String tenantId, String apiProductId, String actor);

    record RebuildResult(String tenantId, int productCount, long documentCount, long visibilityCount) {}
    record ReindexResult(String tenantId, String apiProductId, long documentCount, long visibilityCount) {}
}

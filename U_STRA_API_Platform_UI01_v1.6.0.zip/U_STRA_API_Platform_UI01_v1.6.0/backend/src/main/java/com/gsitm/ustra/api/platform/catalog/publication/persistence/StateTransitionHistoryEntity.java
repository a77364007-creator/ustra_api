package com.gsitm.ustra.api.platform.catalog.publication.persistence;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.Instant;

@Entity
@Table(name = "state_transition_history")
public class StateTransitionHistoryEntity {
    @Id
    @Column(name = "state_transition_history_id", length = 36, nullable = false, updatable = false)
    private String id;
    @Column(name = "tenant_id", length = 36, nullable = false, updatable = false)
    private String tenantId;
    @Column(name = "aggregate_type", length = 80, nullable = false, updatable = false)
    private String aggregateType;
    @Column(name = "aggregate_id", length = 200, nullable = false, updatable = false)
    private String aggregateId;
    @Column(name = "from_state", length = 40, nullable = false, updatable = false)
    private String fromState;
    @Column(name = "to_state", length = 40, nullable = false, updatable = false)
    private String toState;
    @Column(name = "occurred_at", nullable = false, updatable = false)
    private Instant occurredAt;
    @Column(name = "actor_principal_id", length = 200, nullable = false, updatable = false)
    private String actorPrincipalId;
    @Column(name = "correlation_id", length = 100, nullable = false, updatable = false)
    private String correlationId;

    protected StateTransitionHistoryEntity() {}

    public StateTransitionHistoryEntity(String id, String tenantId, String aggregateType, String aggregateId,
                                        String fromState, String toState, Instant occurredAt,
                                        String actorPrincipalId, String correlationId) {
        this.id = id;
        this.tenantId = tenantId;
        this.aggregateType = aggregateType;
        this.aggregateId = aggregateId;
        this.fromState = fromState;
        this.toState = toState;
        this.occurredAt = occurredAt;
        this.actorPrincipalId = actorPrincipalId;
        this.correlationId = correlationId;
    }

    public String getId() { return id; }
    public String getTenantId() { return tenantId; }
    public String getAggregateType() { return aggregateType; }
    public String getAggregateId() { return aggregateId; }
    public String getFromState() { return fromState; }
    public String getToState() { return toState; }
    public Instant getOccurredAt() { return occurredAt; }
}

package com.gsitm.ustra.api.platform.change.persistence;
import java.util.*; import org.springframework.data.jpa.repository.JpaRepository;
public interface ConsumerImpactAnalysisRepository extends JpaRepository<ConsumerImpactAnalysisEntity,String>{
 Optional<ConsumerImpactAnalysisEntity> findByIdAndTenantId(String id,String tenantId);
 Optional<ConsumerImpactAnalysisEntity> findByTenantIdAndApiChangeIdAndImpactBasisHash(String tenantId,String apiChangeId,String impactBasisHash);
 List<ConsumerImpactAnalysisEntity> findAllByTenantIdAndApiChangeIdOrderByAnalyzedAtDesc(String tenantId,String apiChangeId);
}

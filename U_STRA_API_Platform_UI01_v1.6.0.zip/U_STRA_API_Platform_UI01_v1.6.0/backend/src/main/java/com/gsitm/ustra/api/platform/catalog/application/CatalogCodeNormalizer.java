package com.gsitm.ustra.api.platform.catalog.application;

import com.gsitm.ustra.api.platform.common.error.BusinessException;
import com.gsitm.ustra.api.platform.common.error.ErrorCode;
import java.util.Locale;
import org.springframework.http.HttpStatus;

final class CatalogCodeNormalizer {
    private CatalogCodeNormalizer() {
    }

    static String productCode(String value) {
        if (value == null || value.isBlank()) {
            throw new BusinessException(ErrorCode.VALIDATION_ERROR, HttpStatus.BAD_REQUEST,
                    "productCode는 필수입니다.");
        }
        return value.trim().toUpperCase(Locale.ROOT);
    }
}

package com.gsitm.ustra.api.platform.operations.api;
import java.time.Instant;
import java.util.List;
import org.springframework.data.domain.Page;
public record OperationsPage<T>(List<T> items,long totalElements,int page,int size,Instant asOf,
                                 Instant fromInclusive,Instant toExclusive) {
    public static <T> OperationsPage<T> from(Page<T> page,Instant asOf,Instant from,Instant to) {
        return new OperationsPage<>(page.getContent(),page.getTotalElements(),page.getNumber(),page.getSize(),asOf,from,to);
    }
}

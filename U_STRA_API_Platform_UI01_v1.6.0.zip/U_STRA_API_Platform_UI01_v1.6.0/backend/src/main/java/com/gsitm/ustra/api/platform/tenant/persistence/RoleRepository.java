package com.gsitm.ustra.api.platform.tenant.persistence;

import java.util.Collection;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository<RoleEntity, String> {
    Optional<RoleEntity> findByCode(String code);
    List<RoleEntity> findByIdIn(Collection<String> ids);
}

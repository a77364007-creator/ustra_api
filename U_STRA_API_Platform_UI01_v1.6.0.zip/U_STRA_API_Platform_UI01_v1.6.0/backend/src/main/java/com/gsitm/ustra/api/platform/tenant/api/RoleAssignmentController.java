package com.gsitm.ustra.api.platform.tenant.api;

import com.gsitm.ustra.api.platform.tenant.application.RoleAssignmentService;
import com.gsitm.ustra.api.platform.tenant.persistence.RoleAssignmentEntity;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.time.Instant;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/role-assignments")
public class RoleAssignmentController {
    private final RoleAssignmentService service;

    public RoleAssignmentController(RoleAssignmentService service) {
        this.service = service;
    }

    @GetMapping
    public List<RoleAssignmentResponse> list() {
        return service.list().stream().map(RoleAssignmentResponse::from).toList();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public RoleAssignmentResponse assign(@Valid @RequestBody AssignRoleRequest request) {
        return RoleAssignmentResponse.from(service.assign(request.membershipId(), request.roleCode(),
                request.organizationScopeId(), request.effectiveFrom(), request.effectiveTo()));
    }

    @PostMapping("/{assignmentId}/revoke")
    public RoleAssignmentResponse revoke(@PathVariable String assignmentId) {
        return RoleAssignmentResponse.from(service.revoke(assignmentId));
    }

    public record AssignRoleRequest(@NotBlank String membershipId,
                                    @NotBlank String roleCode,
                                    String organizationScopeId,
                                    @NotNull Instant effectiveFrom,
                                    Instant effectiveTo) {
    }

    public record RoleAssignmentResponse(String roleAssignmentId, String membershipId, String roleId,
                                         String organizationScopeId, String status,
                                         Instant effectiveFrom, Instant effectiveTo, long version) {
        static RoleAssignmentResponse from(RoleAssignmentEntity entity) {
            return new RoleAssignmentResponse(entity.getId(), entity.getMembershipId(), entity.getRoleId(),
                    entity.getOrganizationScopeId(), entity.getStatus().name(), entity.getEffectiveFrom(),
                    entity.getEffectiveTo(), entity.getRowVersion());
        }
    }
}

package com.gsitm.ustra.api.platform.subscription.application;
import java.nio.charset.StandardCharsets; import java.security.*; import java.util.*; import org.springframework.stereotype.Service;
@Service
public class SubscriptionRequestSnapshotService {
 public String requestFingerprint(String tenantId,String environmentId,String publicationId,String purpose,String expected){return requestFingerprint(tenantId,environmentId,publicationId,purpose,expected,null);}
 public String requestFingerprint(String tenantId,String environmentId,String publicationId,String purpose,String expected,List<String> operationIds){
  if(operationIds==null)return sha256(canonical(tenantId,environmentId,publicationId,purpose,expected));
  return sha256(canonical(tenantId,environmentId,publicationId,purpose,expected,scopeCanonical(operationIds)));
 }
 public String snapshotHash(String tenantId,String requestId,int revisionNo,String environmentId,String publicationId,String productVersionId,String requesterId,String purpose,String expected){return snapshotHash(tenantId,requestId,revisionNo,environmentId,publicationId,productVersionId,requesterId,purpose,expected,null);}
 public String snapshotHash(String tenantId,String requestId,int revisionNo,String environmentId,String publicationId,String productVersionId,String requesterId,String purpose,String expected,List<String> operationIds){
  if(operationIds==null)return sha256(canonical(tenantId,requestId,Integer.toString(revisionNo),environmentId,publicationId,productVersionId,requesterId,purpose,expected));
  return sha256(canonical(tenantId,requestId,Integer.toString(revisionNo),environmentId,publicationId,productVersionId,requesterId,purpose,expected,scopeCanonical(operationIds)));
 }
 private String scopeCanonical(List<String> ids){return ids.stream().filter(Objects::nonNull).map(String::trim).distinct().sorted().reduce((a,b)->a+","+b).orElse("");}
 private String canonical(String... values){StringBuilder b=new StringBuilder();for(String value:values){String n=value==null?"<null>":value;b.append(n.length()).append(':').append(n).append('|');}return b.toString();}
 private String sha256(String value){try{return java.util.HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(value.getBytes(StandardCharsets.UTF_8)));}catch(NoSuchAlgorithmException ex){throw new IllegalStateException("SHA-256 is not available",ex);}}
}

package com.gsitm.ustra.api.platform.tenant.application;

import com.gsitm.ustra.api.platform.audit.AuditService;
import com.gsitm.ustra.api.platform.common.error.BusinessException;
import com.gsitm.ustra.api.platform.common.error.ErrorCode;
import com.gsitm.ustra.api.platform.outbox.OutboxService;
import com.gsitm.ustra.api.platform.tenant.context.TenantContext;
import com.gsitm.ustra.api.platform.tenant.context.TenantContextResolver;
import com.gsitm.ustra.api.platform.tenant.domain.ReferenceStatus;
import com.gsitm.ustra.api.platform.tenant.domain.RoleAssignmentStatus;
import com.gsitm.ustra.api.platform.tenant.domain.RoleScopeType;
import com.gsitm.ustra.api.platform.tenant.persistence.MembershipEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.MembershipRepository;
import com.gsitm.ustra.api.platform.tenant.persistence.OrganizationRepository;
import com.gsitm.ustra.api.platform.tenant.persistence.RoleAssignmentEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.RoleAssignmentRepository;
import com.gsitm.ustra.api.platform.tenant.persistence.RoleEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.RoleRepository;
import java.time.Clock;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class RoleAssignmentService {
    private final TenantContextResolver contextResolver;
    private final TenantPermissionGuard permissionGuard;
    private final MembershipRepository membershipRepository;
    private final RoleRepository roleRepository;
    private final RoleAssignmentRepository assignmentRepository;
    private final OrganizationRepository organizationRepository;
    private final AuditService auditService;
    private final OutboxService outboxService;
    private final Clock clock;

    public RoleAssignmentService(TenantContextResolver contextResolver, TenantPermissionGuard permissionGuard,
                                 MembershipRepository membershipRepository, RoleRepository roleRepository,
                                 RoleAssignmentRepository assignmentRepository, OrganizationRepository organizationRepository,
                                 AuditService auditService, OutboxService outboxService, Clock clock) {
        this.contextResolver = contextResolver;
        this.permissionGuard = permissionGuard;
        this.membershipRepository = membershipRepository;
        this.roleRepository = roleRepository;
        this.assignmentRepository = assignmentRepository;
        this.organizationRepository = organizationRepository;
        this.auditService = auditService;
        this.outboxService = outboxService;
        this.clock = clock;
    }

    @Transactional(readOnly = true)
    public List<RoleAssignmentEntity> list() {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "ROLE_ASSIGNMENT:MANAGE", "ROLE_ASSIGNMENT", "list");
        return assignmentRepository.findAllByTenantIdOrderByAssignedAtAsc(context.tenantId());
    }

    @Transactional
    public RoleAssignmentEntity assign(String membershipId, String roleCode, String organizationScopeId,
                                       Instant effectiveFrom, Instant effectiveTo) {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "ROLE_ASSIGNMENT:MANAGE", "ROLE_ASSIGNMENT", "new");
        Cp01Validation.effectivePeriod(effectiveFrom, effectiveTo);

        MembershipEntity membership = membershipRepository.findByIdAndTenantIdForUpdate(membershipId, context.tenantId())
                .orElseThrow(() -> new BusinessException(ErrorCode.MEMBERSHIP_NOT_FOUND, HttpStatus.NOT_FOUND,
                        "Membership을 찾을 수 없습니다."));
        RoleEntity role = roleRepository.findByCode(roleCode)
                .orElseThrow(() -> new BusinessException(ErrorCode.ROLE_NOT_FOUND, HttpStatus.BAD_REQUEST,
                        "Role을 찾을 수 없습니다."));
        if (role.getStatus() != ReferenceStatus.ACTIVE) {
            throw new BusinessException(ErrorCode.ROLE_NOT_FOUND, HttpStatus.BAD_REQUEST, "활성 Role이 아닙니다.");
        }
        if (role.getScopeType() == RoleScopeType.PLATFORM || "PLATFORM_ADMIN".equals(role.getCode())) {
            auditService.denied(context.tenantId(), "ROLE_ASSIGN", "ROLE", role.getId(),
                    ErrorCode.PLATFORM_ROLE_ASSIGNMENT_FORBIDDEN.name());
            throw new BusinessException(ErrorCode.PLATFORM_ROLE_ASSIGNMENT_FORBIDDEN, HttpStatus.FORBIDDEN,
                    "Tenant 관리자는 Platform Role을 부여할 수 없습니다.");
        }
        if (organizationScopeId != null
                && organizationRepository.findByIdAndTenantId(organizationScopeId, context.tenantId()).isEmpty()) {
            throw new BusinessException(ErrorCode.ORGANIZATION_TENANT_MISMATCH, HttpStatus.BAD_REQUEST,
                    "RoleAssignment Organization Scope는 현재 Tenant에 속해야 합니다.");
        }

        List<RoleAssignmentEntity> existing = assignmentRepository
                .findAllByTenantIdAndMembershipIdAndRoleIdAndStatus(
                        context.tenantId(), membership.getId(), role.getId(), RoleAssignmentStatus.ACTIVE);
        boolean duplicateAuthority = existing.stream()
                .filter(e -> java.util.Objects.equals(e.getOrganizationScopeId(), organizationScopeId))
                .anyMatch(e -> e.overlaps(effectiveFrom, effectiveTo));
        if (duplicateAuthority) {
            throw Cp01Validation.validation("동일 범위에 중복되는 활성 RoleAssignment가 있습니다.");
        }

        Instant now = Instant.now(clock);
        RoleAssignmentEntity assignment = new RoleAssignmentEntity(UUID.randomUUID().toString(), context.tenantId(),
                membership.getId(), role.getId(), organizationScopeId, effectiveFrom, effectiveTo,
                context.principalId(), now);
        assignmentRepository.save(assignment);
        auditService.success(context.tenantId(), "ROLE_ASSIGN", "ROLE_ASSIGNMENT", assignment.getId(), true,
                Map.of("membershipId", membershipId, "roleCode", roleCode));
        outboxService.enqueue("RoleAssigned", "ROLE_ASSIGNMENT", assignment.getId(), context.tenantId(),
                Map.of("roleAssignmentId", assignment.getId(), "roleCode", roleCode));
        return assignment;
    }

    @Transactional
    public RoleAssignmentEntity revoke(String assignmentId) {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "ROLE_ASSIGNMENT:MANAGE", "ROLE_ASSIGNMENT", assignmentId);
        RoleAssignmentEntity assignment = assignmentRepository.findByIdAndTenantId(assignmentId, context.tenantId())
                .orElseThrow(() -> new BusinessException(ErrorCode.ROLE_ASSIGNMENT_FORBIDDEN, HttpStatus.NOT_FOUND,
                        "RoleAssignment를 찾을 수 없습니다."));
        assignment.revoke(context.principalId(), Instant.now(clock));
        auditService.success(context.tenantId(), "ROLE_REVOKE", "ROLE_ASSIGNMENT", assignmentId, true, Map.of());
        outboxService.enqueue("RoleRevoked", "ROLE_ASSIGNMENT", assignmentId, context.tenantId(),
                Map.of("roleAssignmentId", assignmentId));
        return assignment;
    }
}

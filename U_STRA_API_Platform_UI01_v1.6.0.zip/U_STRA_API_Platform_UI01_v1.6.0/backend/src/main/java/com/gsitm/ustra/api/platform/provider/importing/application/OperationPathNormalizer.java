package com.gsitm.ustra.api.platform.provider.importing.application;
import java.util.regex.Pattern;
import org.springframework.stereotype.Component;
@Component public class OperationPathNormalizer { private static final Pattern PARAM=Pattern.compile("\\{[^/{}]+}"); public String normalize(String path){ return PARAM.matcher(path).replaceAll("{}"); } }

package com.gsitm.ustra.api.platform.operations.application;

import com.gsitm.ustra.api.platform.operations.api.OperationsPage;
import com.gsitm.ustra.api.platform.operations.persistence.*;
import com.gsitm.ustra.api.platform.operations.domain.*;
import com.gsitm.ustra.api.platform.integration.approval.domain.*;
import com.gsitm.ustra.api.platform.integration.approval.persistence.*;
import com.gsitm.ustra.api.platform.outbox.*;
import com.gsitm.ustra.api.platform.search.persistence.*;
import com.gsitm.ustra.api.platform.tenant.application.TenantPermissionGuard;
import com.gsitm.ustra.api.platform.tenant.context.*;
import java.time.*;
import java.util.*;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import static com.gsitm.ustra.api.platform.operations.application.OperationsSpecifications.*;

@Service @Transactional(readOnly=true)
public class OperationsQueryService {
    private final TenantContextResolver contexts;
    private final TenantPermissionGuard permissions;
    private final OperationsQueryLimits limits;
    private final IntegrationOperationRepository operations;
    private final ReconciliationIssueRepository issues;
    private final ConnectorInstanceRepository connectors;
    private final OutboxEventRepository outbox;
    private final SearchProjectionFailureRepository failures;
    private final CatalogSearchDocumentRepository documents;
    private final CatalogSearchVisibilityRepository visibility;
    private final OperationsRecoveryActionRepository recovery;
    private final Clock clock;
    public OperationsQueryService(TenantContextResolver contexts,TenantPermissionGuard permissions,OperationsQueryLimits limits,
            IntegrationOperationRepository operations,ReconciliationIssueRepository issues,ConnectorInstanceRepository connectors,
            OutboxEventRepository outbox,SearchProjectionFailureRepository failures,CatalogSearchDocumentRepository documents,
            CatalogSearchVisibilityRepository visibility,OperationsRecoveryActionRepository recovery,Clock clock) {
        this.contexts=contexts;this.permissions=permissions;this.limits=limits;this.operations=operations;this.issues=issues;
        this.connectors=connectors;this.outbox=outbox;this.failures=failures;this.documents=documents;this.visibility=visibility;
        this.recovery=recovery;this.clock=clock;
    }
    private String readPermission(IntegrationType type){return type==IntegrationType.APPROVAL_ITSM?"APPROVAL_INTEGRATION:READ":"GATEWAY_INTEGRATION:READ";}
    private TenantContext source(IntegrationType type) {
        TenantContext c=contexts.resolve();permissions.require(c,readPermission(type),"INTEGRATION",type.name());return c;
    }
    public OperationsPage<OperationView> operations(IntegrationType type,IntegrationOperationStatus status,
            Instant from,Instant to,int page,int size,String order) {
        var c=source(type);var w=limits.window(from,to);
        var spec=OperationsSpecifications.operations(c.tenantId(),type).and(eq("status",status)).and(window("createdAt",w));
        return OperationsPage.from(operations.findAll(spec,limits.page(page,size,order,"createdAt")).map(OperationView::from),Instant.now(clock),w.from(),w.to());
    }
    public OperationsPage<IssueView> issues(IntegrationType type,ReconciliationIssueStatus status,
            Instant from,Instant to,int page,int size,String order) {
        var c=source(type);var w=limits.window(from,to);
        var spec=OperationsSpecifications.issues(c.tenantId(),type).and(eq("status",status)).and(window("openedAt",w));
        return OperationsPage.from(issues.findAll(spec,limits.page(page,size,order,"openedAt")).map(IssueView::from),Instant.now(clock),w.from(),w.to());
    }
    public OperationsPage<OutboxView> outbox(OutboxStatus status,Instant from,Instant to,int page,int size,String order) {
        var c=contexts.resolve();permissions.require(c,"OPERATIONS:READ","OUTBOX","metadata");var w=limits.window(from,to);
        var spec=OperationsSpecifications.<OutboxEventEntity>tenant(c.tenantId()).and(eq("status",status)).and(window("createdAt",w));
        return OperationsPage.from(outbox.findAll(spec,limits.page(page,size,order,"createdAt")).map(OutboxView::from),Instant.now(clock),w.from(),w.to());
    }
    public OperationsPage<ConnectorView> connectors(IntegrationType type,int page,int size,String order) {
        var c=source(type);
        return OperationsPage.from(connectors.findAll(OperationsSpecifications.connectors(c.tenantId(),type),
                limits.page(page,size,order,"createdAt")).map(ConnectorView::from),Instant.now(clock),null,null);
    }
    public OperationsPage<SearchFailureView> searchFailures(Instant from,Instant to,int page,int size,String order) {
        var c=contexts.resolve();permissions.require(c,"OPERATIONS:READ","SEARCH_PROJECTION_FAILURE","metadata");
        permissions.require(c,"API_PRODUCT:READ","CATALOG_SEARCH","metadata");var w=limits.window(from,to);
        var spec=OperationsSpecifications.<SearchProjectionFailureEntity>tenant(c.tenantId()).and(window("lastCheckedAt",w));
        return OperationsPage.from(failures.findAll(spec,limits.page(page,size,order,"lastCheckedAt")).map(SearchFailureView::from),Instant.now(clock),w.from(),w.to());
    }
    public Summary summary() {
        var c=contexts.resolve();permissions.require(c,"OPERATIONS:READ","OPERATIONS","summary");
        Map<String,Long> outboxCounts=new LinkedHashMap<>();
        for(OutboxStatus status:OutboxStatus.values())
            outboxCounts.put(status.name(),outbox.count(OperationsSpecifications.<OutboxEventEntity>tenant(c.tenantId()).and(eq("status",status))));
        var pending=outbox.findAll(OperationsSpecifications.<OutboxEventEntity>tenant(c.tenantId()).and(eq("status",OutboxStatus.PENDING)),
                PageRequest.of(0,1,Sort.by(Sort.Direction.ASC,"createdAt","id")));
        Instant oldest=pending.isEmpty()?null:pending.getContent().getFirst().getCreatedAt();
        Map<String,IntegrationSummary> integration=new LinkedHashMap<>();
        for(IntegrationType type:IntegrationType.values()) {
            if(!permissions.has(c,readPermission(type)))continue; // do not count or expose unauthorized sources
            Map<String,Long> opCounts=new LinkedHashMap<>();
            for(var status:IntegrationOperationStatus.values())opCounts.put(status.name(),operations.count(OperationsSpecifications.operations(c.tenantId(),type).and(eq("status",status))));
            Map<String,Long> issueCounts=new LinkedHashMap<>();
            for(var status:ReconciliationIssueStatus.values())issueCounts.put(status.name(),issues.count(OperationsSpecifications.issues(c.tenantId(),type).and(eq("status",status))));
            integration.put(type.name(),new IntegrationSummary(opCounts,issueCounts,
                    connectors.count(OperationsSpecifications.connectors(c.tenantId(),type).and(eq("enabled",true))),"NOT_MEASURED"));
        }
        SearchSummary search=null;
        if(permissions.has(c,"API_PRODUCT:READ")) {
            var last=recovery.findAll(OperationsSpecifications.<OperationsRecoveryActionEntity>tenant(c.tenantId())
                    .and(eq("actionType",RecoveryActionType.SEARCH_TENANT_REBUILD)).and(eq("status",RecoveryActionStatus.SUCCEEDED)),
                    PageRequest.of(0,1,Sort.by(Sort.Direction.DESC,"completedAt","id")));
            search=new SearchSummary(documents.countByTenantId(c.tenantId()),visibility.countByTenantId(c.tenantId()),
                    failures.count(OperationsSpecifications.<SearchProjectionFailureEntity>tenant(c.tenantId()).and(eq("status","OPEN"))),
                    last.isEmpty()?null:last.getContent().getFirst().getCompletedAt(),"LATEST_RECORDED_JOURNALED_REBUILD_ONLY; GLOBAL_FRESHNESS_NOT_PROVEN");
        }
        return new Summary(c.tenantId(),Instant.now(clock),outboxCounts,oldest,Map.copyOf(integration),search,
                Map.of("usage","NOT_MEASURED","latency","NOT_MEASURED","deliveryRate","NOT_MEASURED","dlq","NOT_IMPLEMENTED","liveHealth","NOT_MEASURED"),
                "STORED_STATE_ONLY; SEQUENTIAL_READS_NOT_EXTERNAL_RUNTIME_EVIDENCE");
    }
    public record OperationView(String id,String operationType,String aggregateType,String aggregateId,String connectorInstanceId,
                                String status,int attemptCount,String safeErrorCode,Instant createdAt,Instant lastAttemptAt) {
        public static OperationView from(IntegrationOperationEntity e){return new OperationView(e.getId(),e.getOperationType().name(),e.getAggregateType(),e.getAggregateId(),e.getConnectorInstanceId(),e.getStatus().name(),e.getAttemptCount(),e.getSafeErrorCode(),e.getCreatedAt(),e.getLastAttemptAt());}
    }
    public record IssueView(String id,String integrationOperationId,String issueType,String status,String safeDetailCode,
                            Instant openedAt,Instant lastCheckedAt,Instant resolvedAt,long rowVersion) {
        public static IssueView from(ReconciliationIssueEntity e){return new IssueView(e.getId(),e.getIntegrationOperationId(),e.getIssueType(),e.getStatus().name(),e.getSafeDetailCode(),e.getOpenedAt(),e.getLastCheckedAt(),e.getResolvedAt(),e.getRowVersion());}
    }
    public record OutboxView(String id,String eventId,String eventType,String aggregateType,String aggregateId,
                             String status,int publishAttempts,String correlationId,Instant createdAt) {
        public static OutboxView from(OutboxEventEntity e){return new OutboxView(e.getId(),e.getEventId(),e.getEventType(),e.getAggregateType(),e.getAggregateId(),e.getStatus().name(),e.getPublishAttempts(),e.getCorrelationId(),e.getCreatedAt());}
    }
    public record ConnectorView(String id,String integrationProfileId,String connectorCode,String adapterCode,String authorityCode,
                                boolean enabled,String healthStatus) {
        public static ConnectorView from(ConnectorInstanceEntity e){return new ConnectorView(e.getId(),e.getIntegrationProfileId(),e.getConnectorCode(),e.getAdapterCode(),e.getAuthorityCode(),e.isEnabled(),"NOT_MEASURED");}
    }
    public record SearchFailureView(String id,String apiProductId,String status,String safeErrorCode,Instant observedAt,
                                    Instant lastCheckedAt,Instant resolvedAt,long rowVersion) {
        public static SearchFailureView from(SearchProjectionFailureEntity e){return new SearchFailureView(e.getId(),e.getApiProductId(),e.getStatus(),e.getSafeErrorCode(),e.getObservedAt(),e.getLastCheckedAt(),e.getResolvedAt(),e.getRowVersion());}
    }
    public record IntegrationSummary(Map<String,Long> operationStatusCounts,Map<String,Long> issueStatusCounts,long enabledConnectorCount,String healthStatus) {}
    public record SearchSummary(long documentCount,long visibilityCount,long observedOpenFailureCount,Instant lastRecordedRebuildAt,String evidenceScope) {}
    public record Summary(String tenantId,Instant asOf,Map<String,Long> outboxStatusCounts,Instant oldestPendingCreatedAt,
                          Map<String,IntegrationSummary> integrations,SearchSummary search,Map<String,String> unavailableMetrics,String evidenceScope) {}
}

package com.gsitm.ustra.api.platform.subscription.entitlement.domain;
public enum CredentialReferenceStatus { NOT_ISSUED, ACTIVE, ROTATION_REQUIRED, EXPIRED, REVOKED, UNKNOWN }

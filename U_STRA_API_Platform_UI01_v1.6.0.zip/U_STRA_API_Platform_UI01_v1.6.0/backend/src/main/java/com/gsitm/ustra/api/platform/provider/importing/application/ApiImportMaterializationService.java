package com.gsitm.ustra.api.platform.provider.importing.application;

import com.gsitm.ustra.api.platform.catalog.domain.ApiVersionState;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiEntity;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiOperationEntity;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiOperationRepository;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiRepository;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiVersionEntity;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiVersionRepository;
import com.gsitm.ustra.api.platform.change.application.ContractSnapshotMaterializationService;
import com.gsitm.ustra.api.platform.common.error.BusinessException;
import com.gsitm.ustra.api.platform.common.error.ErrorCode;
import com.gsitm.ustra.api.platform.provider.importing.parser.OpenApiParserPort.ParsedOpenApi;
import com.gsitm.ustra.api.platform.provider.importing.parser.OpenApiParserPort.ParsedOperation;
import com.gsitm.ustra.api.platform.security.AuthenticatedIdentityProvider;
import java.time.Clock;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ApiImportMaterializationService {
    private final ApiRepository apis;
    private final ApiVersionRepository versions;
    private final ApiOperationRepository operations;
    private final OperationPathNormalizer normalizer;
    private final ContractSnapshotMaterializationService contractSnapshots;
    private final AuthenticatedIdentityProvider identity;
    private final Clock clock;

    public ApiImportMaterializationService(
            ApiRepository apis,
            ApiVersionRepository versions,
            ApiOperationRepository operations,
            OperationPathNormalizer normalizer,
            ContractSnapshotMaterializationService contractSnapshots,
            AuthenticatedIdentityProvider identity,
            Clock clock) {
        this.apis = apis;
        this.versions = versions;
        this.operations = operations;
        this.normalizer = normalizer;
        this.contractSnapshots = contractSnapshots;
        this.identity = identity;
        this.clock = clock;
    }

    @Transactional
    public Result materialize(
            String tenantId,
            String providerId,
            String apiCodeOriginal,
            String apiCodeNormalized,
            String importId,
            String hash,
            ParsedOpenApi parsed) {
        Instant now = Instant.now(clock);
        String actor = identity.current().principalId();
        ApiEntity api = apis.findByTenantIdAndApiCodeNormalized(tenantId, apiCodeNormalized).orElse(null);
        if (api == null) {
            api = apis.save(new ApiEntity(
                    UUID.randomUUID().toString(), tenantId, apiCodeOriginal.trim(), apiCodeNormalized,
                    parsed.title(), parsed.description(), providerId, now, actor));
        } else if (!Objects.equals(api.getProviderId(), providerId)) {
            throw new BusinessException(ErrorCode.API_CODE_CONFLICT, HttpStatus.CONFLICT,
                    "동일 API code가 다른 Provider에 이미 존재합니다.");
        }

        ApiVersionEntity existing = versions
                .findByTenantIdAndApiIdAndVersionValue(tenantId, api.getId(), parsed.version())
                .orElse(null);
        if (existing != null) {
            if (Objects.equals(existing.getSourceContentHash(), hash)) {
                return new Result(api.getId(), existing.getId(), true);
            }
            throw new BusinessException(ErrorCode.API_VERSION_IMPORT_CONFLICT, HttpStatus.CONFLICT,
                    "동일 API/version에 다른 OpenAPI source가 이미 존재합니다.");
        }

        Set<String> identities = new HashSet<>();
        List<Op> normalized = new ArrayList<>();
        for (ParsedOperation op : parsed.operations()) {
            String method = op.method().toUpperCase(Locale.ROOT);
            String normalizedPath = normalizer.normalize(op.path());
            String key = method + " " + normalizedPath;
            if (!identities.add(key)) {
                throw new BusinessException(ErrorCode.OPENAPI_DUPLICATE_OPERATION, HttpStatus.CONFLICT,
                        "동일 method/normalizedPath operation이 중복됩니다.");
            }
            normalized.add(new Op(method, op.path(), normalizedPath, op.operationId(), op.summary()));
        }

        ApiVersionEntity version = new ApiVersionEntity(
                UUID.randomUUID().toString(), tenantId, api.getId(), parsed.version(),
                ApiVersionState.DRAFT, now, actor);
        version.attachImportProvenance("OPENAPI_UPLOAD", hash, importId, now);
        versions.saveAndFlush(version);
        for (Op op : normalized) {
            operations.save(new ApiOperationEntity(
                    UUID.randomUUID().toString(), tenantId, version.getId(), op.method(), op.path(),
                    op.normalizedPath(), op.operationId(), op.summary(), now, actor));
        }
        contractSnapshots.materialize(tenantId, version.getId(), hash, parsed);
        return new Result(api.getId(), version.getId(), false);
    }

    private record Op(String method, String path, String normalizedPath, String operationId, String summary) {}
    public record Result(String apiId, String apiVersionId, boolean replayedVersion) {}
}

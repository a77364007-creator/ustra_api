package com.gsitm.ustra.api.platform.catalog.publication.persistence;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ApiProductVersionRepository extends JpaRepository<ApiProductVersionEntity, String> {
    Optional<ApiProductVersionEntity> findByIdAndTenantId(String id, String tenantId);
    List<ApiProductVersionEntity> findAllByTenantIdAndApiProductIdOrderByCreatedAtAsc(String tenantId, String apiProductId);
    boolean existsByApiProductIdAndVersionValue(String apiProductId, String versionValue);
}

package com.gsitm.ustra.api.platform.catalog.persistence;

import com.gsitm.ustra.api.platform.catalog.domain.ApiProductLifecycleState;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Version;
import java.time.Instant;
import java.util.Objects;

@Entity
@Table(name = "api_product")
public class ApiProductEntity {
    @Id @Column(name = "api_product_id", length = 36, nullable = false, updatable = false)
    private String id;
    @Column(name = "tenant_id", length = 36, nullable = false, updatable = false)
    private String tenantId;
    @Column(name = "product_code", length = 100, nullable = false, updatable = false)
    private String productCode;
    @Column(name = "product_code_normalized", length = 100, nullable = false, updatable = false)
    private String productCodeNormalized;
    @Column(name = "name", length = 200, nullable = false)
    private String name;
    @Column(name = "description", columnDefinition = "TEXT")
    private String description;
    @Column(name = "provider_id", length = 36)
    private String providerId;
    @Column(name = "owner_membership_id", length = 36)
    private String ownerMembershipId;
    @Enumerated(EnumType.STRING)
    @Column(name = "lifecycle_state", length = 30, nullable = false)
    private ApiProductLifecycleState lifecycleState;
    @Column(name = "localization_revision", nullable = false)
    private long localizationRevision;
    @Version @Column(name = "row_version", nullable = false)
    private long rowVersion;
    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;
    @Column(name = "created_by", length = 200, nullable = false, updatable = false)
    private String createdBy;
    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;
    @Column(name = "updated_by", length = 200, nullable = false)
    private String updatedBy;

    protected ApiProductEntity() {}

    public ApiProductEntity(String id, String tenantId, String productCode, String productCodeNormalized,
                            String name, String description, String providerId, String ownerMembershipId,
                            Instant now, String actor) {
        this.id = id; this.tenantId = tenantId; this.productCode = productCode;
        this.productCodeNormalized = productCodeNormalized; this.name = name; this.description = description;
        this.providerId = providerId; this.ownerMembershipId = ownerMembershipId;
        this.lifecycleState = ApiProductLifecycleState.DRAFT; this.localizationRevision = 1;
        this.createdAt = now; this.createdBy = actor; this.updatedAt = now; this.updatedBy = actor;
    }

    public boolean update(String name, String description, String providerId, String ownerMembershipId,
                          Instant now, String actor) {
        boolean translatableChanged = !Objects.equals(this.name, name) || !Objects.equals(this.description, description);
        this.name = name; this.description = description; this.providerId = providerId;
        this.ownerMembershipId = ownerMembershipId;
        if (translatableChanged) this.localizationRevision++;
        this.updatedAt = now; this.updatedBy = actor;
        return translatableChanged;
    }

    public boolean beginReview(Instant now, String actor) {
        if (this.lifecycleState != ApiProductLifecycleState.DRAFT) return false;
        this.lifecycleState = ApiProductLifecycleState.REVIEWING;
        this.updatedAt = now; this.updatedBy = actor;
        return true;
    }

    public boolean activate(Instant now, String actor) {
        if (this.lifecycleState == ApiProductLifecycleState.ACTIVE) return false;
        if (this.lifecycleState != ApiProductLifecycleState.DRAFT
                && this.lifecycleState != ApiProductLifecycleState.REVIEWING) return false;
        this.lifecycleState = ApiProductLifecycleState.ACTIVE;
        this.updatedAt = now; this.updatedBy = actor;
        return true;
    }

    public String getId() { return id; }
    public String getTenantId() { return tenantId; }
    public String getProductCode() { return productCode; }
    public String getProductCodeNormalized() { return productCodeNormalized; }
    public String getName() { return name; }
    public String getDescription() { return description; }
    public String getProviderId() { return providerId; }
    public String getOwnerMembershipId() { return ownerMembershipId; }
    public ApiProductLifecycleState getLifecycleState() { return lifecycleState; }
    public long getLocalizationRevision() { return localizationRevision; }
    public long getRowVersion() { return rowVersion; }
    public Instant getCreatedAt() { return createdAt; }
    public String getCreatedBy() { return createdBy; }
    public Instant getUpdatedAt() { return updatedAt; }
    public String getUpdatedBy() { return updatedBy; }
}

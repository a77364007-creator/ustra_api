package com.gsitm.ustra.api.platform.subscription.entitlement.api;

import com.gsitm.ustra.api.platform.subscription.entitlement.application.EntitlementCommandService;
import com.gsitm.ustra.api.platform.subscription.entitlement.application.EntitlementQueryService;
import com.gsitm.ustra.api.platform.subscription.entitlement.persistence.EntitlementEntity;
import com.gsitm.ustra.api.platform.tenant.api.VersionHeaderParser;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/entitlements")
public class EntitlementController {
    private final EntitlementQueryService query;
    private final EntitlementCommandService command;

    public EntitlementController(EntitlementQueryService query, EntitlementCommandService command) {
        this.query = query;
        this.command = command;
    }

    @GetMapping
    public List<EntitlementResponse> list() {
        return query.listEntitlements().stream().map(EntitlementResponse::from).toList();
    }

    @PostMapping("/{entitlementId}/revoke")
    public ResponseEntity<RevokeEntitlementResponse> revoke(
            @PathVariable String entitlementId,
            @RequestHeader(value = HttpHeaders.IF_MATCH, required = false) String ifMatch) {
        var result = command.revoke(entitlementId, VersionHeaderParser.parse(ifMatch));
        EntitlementEntity entity = result.entitlement();
        return ResponseEntity.ok()
                .eTag(VersionHeaderParser.etag(entity.getRowVersion()))
                .body(new RevokeEntitlementResponse(
                        entity.getId(), entity.getStatus().name(), entity.getRowVersion(),
                        new FulfillmentResponse(result.fulfillment().getId(),
                                result.fulfillment().getFulfillmentType().name(),
                                result.fulfillment().getStatus().name())));
    }

    public record OperationScopeResponse(String apiOperationId) {}
    public record QuotaLimitResponse(String metricCode, BigDecimal limitValue, long windowSeconds, String unitCode) {}
    public record FulfillmentResponse(String accessFulfillmentId, String type, String status) {}

    public record EntitlementResponse(
            String entitlementId,
            String subscriptionId,
            String consumerAppEnvironmentId,
            String apiProductVersionId,
            String status,
            Instant effectiveFrom,
            Instant effectiveTo,
            int policyRevision,
            long revision,
            List<OperationScopeResponse> operationScopes,
            List<QuotaLimitResponse> quotaLimits,
            FulfillmentResponse latestFulfillment,
            String credentialStatus,
            boolean readyToUse) {
        static EntitlementResponse from(EntitlementQueryService.EntitlementView view) {
            EntitlementEntity entity = view.entitlement();
            var scopes = view.operationScopes().stream()
                    .map(x -> new OperationScopeResponse(x.getApiOperationId())).toList();
            var quotas = view.quotaLimits().stream()
                    .map(x -> new QuotaLimitResponse(x.getMetricCode(), x.getLimitValue(),
                            x.getWindowSeconds(), x.getUnitCode())).toList();
            var fulfillment = view.latestFulfillment() == null ? null
                    : new FulfillmentResponse(view.latestFulfillment().getId(),
                            view.latestFulfillment().getFulfillmentType().name(),
                            view.latestFulfillment().getStatus().name());
            return new EntitlementResponse(entity.getId(), entity.getSubscriptionId(),
                    entity.getConsumerAppEnvironmentId(), entity.getApiProductVersionId(),
                    entity.getStatus().name(), entity.getEffectiveFrom(), entity.getEffectiveTo(),
                    entity.getPolicyRevision(), entity.getRowVersion(), scopes, quotas, fulfillment,
                    view.credentialReference() == null ? null : view.credentialReference().getStatus().name(),
                    view.readyToUse());
        }
    }

    public record RevokeEntitlementResponse(
            String entitlementId,
            String status,
            long revision,
            FulfillmentResponse deprovisionFulfillment) {}
}

package com.gsitm.ustra.api.platform.catalog.publication.persistence;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StateTransitionHistoryRepository extends JpaRepository<StateTransitionHistoryEntity, String> {
    List<StateTransitionHistoryEntity> findAllByTenantIdAndAggregateTypeAndAggregateIdOrderByOccurredAtAsc(
            String tenantId, String aggregateType, String aggregateId);
}

package com.gsitm.ustra.api.platform.catalog.persistence;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Version;
import java.time.Instant;

@Entity
@Table(name = "api_operation")
public class ApiOperationEntity {
    @Id
    @Column(name = "api_operation_id", length = 36, nullable = false, updatable = false)
    private String id;
    @Column(name = "tenant_id", length = 36, nullable = false, updatable = false)
    private String tenantId;
    @Column(name = "api_version_id", length = 36, nullable = false, updatable = false)
    private String apiVersionId;
    @Column(name = "method", length = 20, nullable = false, updatable = false)
    private String method;
    @Column(name = "path", length = 1000, nullable = false, updatable = false)
    private String path;
    @Column(name = "normalized_path", length = 1000, nullable = false, updatable = false)
    private String normalizedPath;
    @Column(name = "operation_key", length = 200)
    private String operationKey;
    @Column(name = "summary", length = 500)
    private String summary;
    @Version
    @Column(name = "row_version", nullable = false)
    private long rowVersion;
    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;
    @Column(name = "created_by", length = 200, nullable = false, updatable = false)
    private String createdBy;
    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;
    @Column(name = "updated_by", length = 200, nullable = false)
    private String updatedBy;

    protected ApiOperationEntity() {
    }

    /**
     * Internal persistence constructor only. normalizedPath must come from the approved shared normalizer
     * once that contract exists; CP-02 exposes no public operation-write API.
     */
    public ApiOperationEntity(String id, String tenantId, String apiVersionId, String method, String path,
                              String normalizedPath, String operationKey, String summary, Instant now, String actor) {
        this.id = id;
        this.tenantId = tenantId;
        this.apiVersionId = apiVersionId;
        this.method = method;
        this.path = path;
        this.normalizedPath = normalizedPath;
        this.operationKey = operationKey;
        this.summary = summary;
        this.createdAt = now;
        this.createdBy = actor;
        this.updatedAt = now;
        this.updatedBy = actor;
    }

    public String getId() { return id; }
    public String getTenantId() { return tenantId; }
    public String getApiVersionId() { return apiVersionId; }
    public String getMethod() { return method; }
    public String getPath() { return path; }
    public String getNormalizedPath() { return normalizedPath; }
}

package com.gsitm.ustra.api.platform.catalog.persistence;

import com.gsitm.ustra.api.platform.catalog.domain.ApiVersionState;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Version;
import java.time.Instant;

@Entity
@Table(name = "api_version")
public class ApiVersionEntity {
    @Id @Column(name="api_version_id",length=36,nullable=false,updatable=false) private String id;
    @Column(name="tenant_id",length=36,nullable=false,updatable=false) private String tenantId;
    @Column(name="api_id",length=36,nullable=false,updatable=false) private String apiId;
    @Column(name="version",length=100,nullable=false,updatable=false) private String versionValue;
    @Enumerated(EnumType.STRING) @Column(name="state",length=30,nullable=false) private ApiVersionState state;
    @Column(name="source_type",length=40) private String sourceType;
    @Column(name="source_repository",length=500) private String sourceRepository;
    @Column(name="source_path",length=1000) private String sourcePath;
    @Column(name="source_revision",length=200) private String sourceRevision;
    @Column(name="source_content_hash",length=64) private String sourceContentHash;
    @Column(name="source_import_id",length=36) private String sourceImportId;
    @Column(name="source_imported_at") private Instant sourceImportedAt;
    @Version @Column(name="row_version",nullable=false) private long rowVersion;
    @Column(name="created_at",nullable=false,updatable=false) private Instant createdAt;
    @Column(name="created_by",length=200,nullable=false,updatable=false) private String createdBy;
    @Column(name="updated_at",nullable=false) private Instant updatedAt;
    @Column(name="updated_by",length=200,nullable=false) private String updatedBy;

    protected ApiVersionEntity() {}
    public ApiVersionEntity(String id,String tenantId,String apiId,String versionValue,ApiVersionState state,
                            Instant now,String actor){
        this.id=id;this.tenantId=tenantId;this.apiId=apiId;this.versionValue=versionValue;this.state=state;
        this.createdAt=now;this.createdBy=actor;this.updatedAt=now;this.updatedBy=actor;
    }
    public void attachImportProvenance(String sourceType,String sourceContentHash,String sourceImportId,Instant importedAt){
        this.sourceType=sourceType;this.sourceContentHash=sourceContentHash;this.sourceImportId=sourceImportId;
        this.sourceImportedAt=importedAt;this.updatedAt=importedAt;
    }
    public boolean validateForPublication(Instant now,String actor){
        if(state==ApiVersionState.VALIDATED||state==ApiVersionState.RELEASED)return false;
        if(state!=ApiVersionState.DRAFT)return false;
        state=ApiVersionState.VALIDATED;updatedAt=now;updatedBy=actor;return true;
    }
    public boolean releaseForPublication(Instant now,String actor){
        if(state==ApiVersionState.RELEASED)return false;
        if(state!=ApiVersionState.VALIDATED)return false;
        state=ApiVersionState.RELEASED;updatedAt=now;updatedBy=actor;return true;
    }
    public boolean deprecate(Instant now,String actor){
        if(state==ApiVersionState.DEPRECATED)return false;
        if(state!=ApiVersionState.RELEASED)return false;
        state=ApiVersionState.DEPRECATED;updatedAt=now;updatedBy=actor;return true;
    }
    public String getId(){return id;} public String getTenantId(){return tenantId;} public String getApiId(){return apiId;}
    public String getVersionValue(){return versionValue;} public ApiVersionState getState(){return state;}
    public String getSourceType(){return sourceType;} public String getSourceRepository(){return sourceRepository;}
    public String getSourcePath(){return sourcePath;} public String getSourceRevision(){return sourceRevision;}
    public String getSourceContentHash(){return sourceContentHash;} public String getSourceImportId(){return sourceImportId;}
    public Instant getSourceImportedAt(){return sourceImportedAt;} public long getRowVersion(){return rowVersion;}
}

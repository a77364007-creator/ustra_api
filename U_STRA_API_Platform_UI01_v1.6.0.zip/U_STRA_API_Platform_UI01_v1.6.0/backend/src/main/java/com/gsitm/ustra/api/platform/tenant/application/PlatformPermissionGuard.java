package com.gsitm.ustra.api.platform.tenant.application;

import com.gsitm.ustra.api.platform.common.error.BusinessException;
import com.gsitm.ustra.api.platform.common.error.ErrorCode;
import com.gsitm.ustra.api.platform.tenant.persistence.RolePermissionRepository;
import java.util.Set;
import java.util.stream.Collectors;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
public class PlatformPermissionGuard {
    private final RolePermissionRepository rolePermissionRepository;

    public PlatformPermissionGuard(RolePermissionRepository rolePermissionRepository) {
        this.rolePermissionRepository = rolePermissionRepository;
    }

    @Transactional(readOnly = true)
    public void require(String permissionCode) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !authentication.isAuthenticated()) {
            throw denied(permissionCode);
        }

        Set<String> roleCodes = authentication.getAuthorities().stream()
                .map(authority -> authority.getAuthority())
                .filter(authority -> authority.startsWith("ROLE_"))
                .map(authority -> authority.substring("ROLE_".length()))
                .collect(Collectors.toUnmodifiableSet());

        if (roleCodes.isEmpty()
                || rolePermissionRepository.countPermissionForRoles(roleCodes, permissionCode) == 0) {
            throw denied(permissionCode);
        }
    }

    private BusinessException denied(String permissionCode) {
        return new BusinessException(ErrorCode.ACCESS_DENIED, HttpStatus.FORBIDDEN,
                "Platform 권한이 없습니다: " + permissionCode);
    }
}

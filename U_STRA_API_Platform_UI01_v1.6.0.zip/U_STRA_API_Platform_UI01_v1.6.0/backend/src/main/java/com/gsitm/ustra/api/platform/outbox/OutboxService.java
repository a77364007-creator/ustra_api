package com.gsitm.ustra.api.platform.outbox;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gsitm.ustra.api.platform.common.context.RequestContextHolder;
import java.time.Clock;
import java.time.Instant;
import java.util.Map;
import java.util.UUID;
import org.springframework.stereotype.Service;

@Service
public class OutboxService {
    private final OutboxEventRepository repository;
    private final ObjectMapper objectMapper;
    private final Clock clock;

    public OutboxService(OutboxEventRepository repository, ObjectMapper objectMapper, Clock clock) {
        this.repository = repository;
        this.objectMapper = objectMapper;
        this.clock = clock;
    }

    public String enqueue(String eventType, String aggregateType, String aggregateId,
                          String tenantId, Map<String, Object> safePayload) {
        String eventId = UUID.randomUUID().toString();
        String correlationId = RequestContextHolder.required().correlationId();
        repository.save(new OutboxEventEntity(
                UUID.randomUUID().toString(), eventId, eventType, 1, aggregateType, aggregateId,
                tenantId, serialize(safePayload), correlationId, Instant.now(clock)));
        return eventId;
    }

    private String serialize(Map<String, Object> payload) {
        try {
            return objectMapper.writeValueAsString(payload == null ? Map.of() : payload);
        } catch (JsonProcessingException ex) {
            throw new IllegalStateException("Failed to serialize outbox payload", ex);
        }
    }
}

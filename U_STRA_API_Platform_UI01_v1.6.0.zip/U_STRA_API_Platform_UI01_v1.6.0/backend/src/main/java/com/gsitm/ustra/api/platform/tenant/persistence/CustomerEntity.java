package com.gsitm.ustra.api.platform.tenant.persistence;

import com.gsitm.ustra.api.platform.tenant.domain.CustomerStatus;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.Instant;

@Entity
@Table(name = "customer")
public class CustomerEntity {
    @Id
    @Column(name = "customer_id", length = 36, nullable = false, updatable = false)
    private String id;

    @Column(name = "customer_code", length = 80, nullable = false)
    private String code;

    @Column(name = "display_name", length = 200, nullable = false)
    private String displayName;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", length = 30, nullable = false)
    private CustomerStatus status;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;

    protected CustomerEntity() {
    }

    public CustomerEntity(String id, String code, String displayName, CustomerStatus status, Instant now) {
        this.id = id;
        this.code = code;
        this.displayName = displayName;
        this.status = status;
        this.createdAt = now;
        this.updatedAt = now;
    }

    public String getId() { return id; }
    public String getCode() { return code; }
    public String getDisplayName() { return displayName; }
    public CustomerStatus getStatus() { return status; }
}

package com.gsitm.ustra.api.platform.catalog.publication.api;

import com.gsitm.ustra.api.platform.catalog.publication.application.ApiProductVersionService;
import com.gsitm.ustra.api.platform.catalog.publication.domain.ApiProductComponentTargetType;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.ApiProductComponentEntity;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.ApiProductVersionEntity;
import com.gsitm.ustra.api.platform.tenant.api.VersionHeaderParser;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.time.Instant;
import java.util.List;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1")
public class ApiProductVersionController {
    private final ApiProductVersionService service;

    public ApiProductVersionController(ApiProductVersionService service) {
        this.service = service;
    }

    @PostMapping("/api-products/{apiProductId}/versions")
    public ResponseEntity<ApiProductVersionResponse> create(@PathVariable String apiProductId,
                                                             @Valid @RequestBody CreateVersionRequest request) {
        ApiProductVersionEntity entity = service.create(apiProductId, request.version());
        return ResponseEntity.status(HttpStatus.CREATED).eTag(VersionHeaderParser.etag(entity.getRowVersion()))
                .body(ApiProductVersionResponse.from(entity));
    }

    @GetMapping("/api-products/{apiProductId}/versions")
    public List<ApiProductVersionResponse> list(@PathVariable String apiProductId) {
        return service.list(apiProductId).stream().map(ApiProductVersionResponse::from).toList();
    }

    @GetMapping("/api-product-versions/{id}")
    public ResponseEntity<ApiProductVersionResponse> get(@PathVariable String id) {
        ApiProductVersionEntity entity = service.get(id);
        return ResponseEntity.ok().eTag(VersionHeaderParser.etag(entity.getRowVersion()))
                .body(ApiProductVersionResponse.from(entity));
    }

    @GetMapping("/api-product-versions/{id}/components")
    public List<ApiProductComponentResponse> components(@PathVariable String id) {
        return service.listComponents(id).stream().map(ApiProductComponentResponse::from).toList();
    }

    @PostMapping("/api-product-versions/{id}/components")
    public ResponseEntity<ApiProductComponentResponse> addComponent(
            @PathVariable String id,
            @RequestHeader(value = HttpHeaders.IF_MATCH, required = false) String ifMatch,
            @Valid @RequestBody AddComponentRequest request) {
        ApiProductComponentEntity entity = service.addComponent(id, VersionHeaderParser.parse(ifMatch),
                request.targetType(), request.targetId());
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiProductComponentResponse.from(entity));
    }

    @DeleteMapping("/api-product-versions/{id}/components/{componentId}")
    public ResponseEntity<Void> removeComponent(
            @PathVariable String id, @PathVariable String componentId,
            @RequestHeader(value = HttpHeaders.IF_MATCH, required = false) String ifMatch) {
        ApiProductVersionEntity entity = service.removeComponent(id, componentId, VersionHeaderParser.parse(ifMatch));
        return ResponseEntity.noContent().eTag(VersionHeaderParser.etag(entity.getRowVersion())).build();
    }

    @PostMapping("/api-product-versions/{id}/release")
    public ResponseEntity<ApiProductVersionResponse> release(
            @PathVariable String id,
            @RequestHeader(value = HttpHeaders.IF_MATCH, required = false) String ifMatch) {
        ApiProductVersionEntity entity = service.release(id, VersionHeaderParser.parse(ifMatch));
        return ResponseEntity.ok().eTag(VersionHeaderParser.etag(entity.getRowVersion()))
                .body(ApiProductVersionResponse.from(entity));
    }

    public record CreateVersionRequest(@NotBlank @Size(max = 100) String version) {}
    public record AddComponentRequest(@NotNull ApiProductComponentTargetType targetType,
                                      @NotBlank String targetId) {}

    public record ApiProductVersionResponse(String apiProductVersionId, String apiProductId, String version,
                                            String lifecycleState, long revision, Instant createdAt,
                                            String createdBy, Instant updatedAt, String updatedBy) {
        static ApiProductVersionResponse from(ApiProductVersionEntity entity) {
            return new ApiProductVersionResponse(entity.getId(), entity.getApiProductId(), entity.getVersionValue(),
                    entity.getLifecycleState().name(), entity.getRowVersion(), entity.getCreatedAt(),
                    entity.getCreatedBy(), entity.getUpdatedAt(), entity.getUpdatedBy());
        }
    }

    public record ApiProductComponentResponse(String componentId, String apiProductVersionId, String targetType,
                                              String targetId) {
        static ApiProductComponentResponse from(ApiProductComponentEntity entity) {
            String targetId = entity.getTargetType() == ApiProductComponentTargetType.API_VERSION
                    ? entity.getApiVersionId() : entity.getApiOperationId();
            return new ApiProductComponentResponse(entity.getId(), entity.getApiProductVersionId(),
                    entity.getTargetType().name(), targetId);
        }
    }
}

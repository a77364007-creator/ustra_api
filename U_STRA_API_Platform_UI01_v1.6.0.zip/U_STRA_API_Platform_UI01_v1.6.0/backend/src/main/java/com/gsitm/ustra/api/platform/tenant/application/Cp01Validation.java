package com.gsitm.ustra.api.platform.tenant.application;

import com.gsitm.ustra.api.platform.common.error.BusinessException;
import com.gsitm.ustra.api.platform.common.error.ErrorCode;
import java.time.Instant;
import java.time.ZoneId;
import java.time.zone.ZoneRulesException;
import java.util.Locale;
import org.springframework.http.HttpStatus;

final class Cp01Validation {
    private Cp01Validation() {
    }

    static void effectivePeriod(Instant from, Instant to) {
        if (from == null || (to != null && !to.isAfter(from))) {
            throw validation("유효기간이 올바르지 않습니다.");
        }
    }

    static void locale(String locale) {
        if (locale == null || locale.isBlank() || Locale.forLanguageTag(locale).getLanguage().isBlank()) {
            throw validation("locale 형식이 올바르지 않습니다.");
        }
    }

    static void timezone(String timezone) {
        try {
            ZoneId.of(timezone);
        } catch (ZoneRulesException | NullPointerException ex) {
            throw validation("timezone 형식이 올바르지 않습니다.");
        }
    }

    static BusinessException validation(String message) {
        return new BusinessException(ErrorCode.VALIDATION_ERROR, HttpStatus.BAD_REQUEST, message);
    }
}

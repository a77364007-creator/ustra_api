package com.gsitm.ustra.api.platform.subscription.gateway.application;

import com.gsitm.ustra.api.platform.audit.AuditService;
import com.gsitm.ustra.api.platform.common.error.BusinessException;
import com.gsitm.ustra.api.platform.common.error.ErrorCode;
import com.gsitm.ustra.api.platform.outbox.OutboxService;
import com.gsitm.ustra.api.platform.security.AuthenticatedIdentityProvider;
import com.gsitm.ustra.api.platform.subscription.entitlement.domain.AccessFulfillmentStatus;
import com.gsitm.ustra.api.platform.subscription.entitlement.domain.AccessFulfillmentType;
import com.gsitm.ustra.api.platform.subscription.entitlement.domain.CredentialReferenceStatus;
import com.gsitm.ustra.api.platform.subscription.entitlement.persistence.AccessFulfillmentEntity;
import com.gsitm.ustra.api.platform.subscription.entitlement.persistence.AccessFulfillmentRepository;
import com.gsitm.ustra.api.platform.subscription.entitlement.persistence.CredentialReferenceEntity;
import com.gsitm.ustra.api.platform.subscription.entitlement.persistence.CredentialReferenceRepository;
import com.gsitm.ustra.api.platform.subscription.entitlement.persistence.EntitlementEntity;
import com.gsitm.ustra.api.platform.subscription.entitlement.persistence.EntitlementOperationScopeEntity;
import com.gsitm.ustra.api.platform.subscription.entitlement.persistence.EntitlementOperationScopeRepository;
import com.gsitm.ustra.api.platform.subscription.entitlement.persistence.EntitlementRepository;
import com.gsitm.ustra.api.platform.subscription.entitlement.persistence.QuotaLimitRepository;
import com.gsitm.ustra.api.platform.subscription.entitlement.persistence.QuotaProfileRepository;
import java.time.Clock;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class GatewayFulfillmentStateService {
    private final AccessFulfillmentRepository fulfillments;
    private final EntitlementRepository entitlements;
    private final EntitlementOperationScopeRepository scopes;
    private final QuotaProfileRepository profiles;
    private final QuotaLimitRepository limits;
    private final CredentialReferenceRepository credentials;
    private final AuditService audit;
    private final OutboxService outbox;
    private final AuthenticatedIdentityProvider identity;
    private final Clock clock;

    public GatewayFulfillmentStateService(
            AccessFulfillmentRepository fulfillments,
            EntitlementRepository entitlements,
            EntitlementOperationScopeRepository scopes,
            QuotaProfileRepository profiles,
            QuotaLimitRepository limits,
            CredentialReferenceRepository credentials,
            AuditService audit,
            OutboxService outbox,
            AuthenticatedIdentityProvider identity,
            Clock clock) {
        this.fulfillments = fulfillments;
        this.entitlements = entitlements;
        this.scopes = scopes;
        this.profiles = profiles;
        this.limits = limits;
        this.credentials = credentials;
        this.audit = audit;
        this.outbox = outbox;
        this.identity = identity;
        this.clock = clock;
    }

    @Transactional
    public GatewayPort.Command begin(String tenantId, String fulfillmentId) {
        AccessFulfillmentEntity fulfillment = owned(tenantId, fulfillmentId);
        if (fulfillment.getStatus() != AccessFulfillmentStatus.PENDING) {
            throw state("PENDING Fulfillment만 시작할 수 있습니다.");
        }
        EntitlementEntity entitlement = entitlements.findByIdAndTenantId(fulfillment.getEntitlementId(), tenantId)
                .orElseThrow(() -> new BusinessException(
                        ErrorCode.ENTITLEMENT_NOT_FOUND,
                        HttpStatus.NOT_FOUND,
                        "Entitlement를 찾을 수 없습니다."));
        List<String> operations = scopes.findAllByTenantIdAndEntitlementIdOrderByApiOperationIdAsc(
                        tenantId, entitlement.getId())
                .stream().map(EntitlementOperationScopeEntity::getApiOperationId).toList();
        var quotaProfile = profiles.findByTenantIdAndEntitlementId(tenantId, entitlement.getId());
        List<GatewayPort.Quota> quotas = quotaProfile
                .map(profile -> limits.findAllByTenantIdAndQuotaProfileIdOrderByMetricCodeAsc(
                                tenantId, profile.getId())
                        .stream()
                        .map(q -> new GatewayPort.Quota(
                                q.getMetricCode(), q.getLimitValue(), q.getWindowSeconds(), q.getUnitCode()))
                        .toList())
                .orElse(List.of());

        Instant now = Instant.now(clock);
        String actor = identity.current().principalId();
        fulfillment.transition(
                AccessFulfillmentStatus.PROCESSING,
                fulfillment.getExternalOperationRef(),
                null,
                now,
                actor);
        fulfillments.saveAndFlush(fulfillment);
        audit.success(
                tenantId,
                "GATEWAY_FULFILLMENT_PROCESSING",
                "ACCESS_FULFILLMENT",
                fulfillment.getId(),
                true,
                Map.of("fulfillmentType", fulfillment.getFulfillmentType().name()));

        return new GatewayPort.Command(
                tenantId,
                fulfillment.getId(),
                entitlement.getId(),
                entitlement.getConsumerAppEnvironmentId(),
                entitlement.getApiProductVersionId(),
                operations,
                quotas,
                fulfillment.getIdempotencyKey(),
                fulfillment.getRequestFingerprint());
    }

    @Transactional
    public GatewayPort.StatusQuery beginReconcile(String tenantId, String fulfillmentId) {
        AccessFulfillmentEntity fulfillment = owned(tenantId, fulfillmentId);
        if (fulfillment.getStatus() != AccessFulfillmentStatus.UNKNOWN
                && fulfillment.getStatus() != AccessFulfillmentStatus.FAILED) {
            throw state("UNKNOWN/FAILED Fulfillment만 reconcile할 수 있습니다.");
        }
        Instant now = Instant.now(clock);
        String actor = identity.current().principalId();
        fulfillment.transition(
                AccessFulfillmentStatus.RECONCILING,
                fulfillment.getExternalOperationRef(),
                fulfillment.getLastErrorCode(),
                now,
                actor);
        fulfillments.saveAndFlush(fulfillment);
        audit.success(
                tenantId,
                "GATEWAY_FULFILLMENT_RECONCILING",
                "ACCESS_FULFILLMENT",
                fulfillment.getId(),
                true,
                Map.of("fulfillmentType", fulfillment.getFulfillmentType().name()));
        return new GatewayPort.StatusQuery(
                tenantId,
                fulfillment.getIdempotencyKey(),
                fulfillment.getRequestFingerprint(),
                fulfillment.getExternalOperationRef());
    }

    /** Backward-compatible CP-08 mock path. Production-capable CP-14 path passes resolved authority explicitly. */
    @Transactional
    public AccessFulfillmentEntity apply(String tenantId, String fulfillmentId, GatewayPort.Result result) {
        return apply(tenantId, fulfillmentId, result, "MOCK_GATEWAY");
    }

    @Transactional
    public AccessFulfillmentEntity apply(
            String tenantId,
            String fulfillmentId,
            GatewayPort.Result result,
            String credentialProviderType) {
        AccessFulfillmentEntity fulfillment = owned(tenantId, fulfillmentId);
        AccessFulfillmentStatus target = switch (result.status()) {
            case SUCCEEDED -> AccessFulfillmentStatus.SUCCEEDED;
            case FAILED -> AccessFulfillmentStatus.FAILED;
            case UNKNOWN -> AccessFulfillmentStatus.UNKNOWN;
        };
        if (fulfillment.getStatus() != AccessFulfillmentStatus.PROCESSING
                && fulfillment.getStatus() != AccessFulfillmentStatus.RECONCILING) {
            throw state("PROCESSING/RECONCILING 상태만 Gateway 결과를 반영할 수 있습니다.");
        }

        String providerType = normalizeProvider(credentialProviderType);
        Instant now = Instant.now(clock);
        String actor = identity.current().principalId();
        fulfillment.transition(
                target,
                safe(result.externalOperationRef()),
                safe(result.safeErrorCode()),
                now,
                actor);
        fulfillment = fulfillments.saveAndFlush(fulfillment);

        if (target == AccessFulfillmentStatus.SUCCEEDED) {
            if (fulfillment.getFulfillmentType() == AccessFulfillmentType.PROVISION) {
                if (result.credentialReference() == null || result.credentialReference().isBlank()) {
                    throw new BusinessException(
                            ErrorCode.GATEWAY_CREDENTIAL_REFERENCE_REQUIRED,
                            HttpStatus.CONFLICT,
                            "성공한 Provision에는 opaque credential reference가 필요합니다.");
                }
                synchronizeCredential(
                        tenantId,
                        fulfillment,
                        result,
                        providerType,
                        CredentialReferenceStatus.ACTIVE,
                        now,
                        actor);
                outbox.enqueue(
                        "GatewayProvisioningCompleted",
                        "ACCESS_FULFILLMENT",
                        fulfillment.getId(),
                        tenantId,
                        Map.of(
                                "accessFulfillmentId", fulfillment.getId(),
                                "entitlementId", fulfillment.getEntitlementId(),
                                "externalOperationRef", safeValue(result.externalOperationRef()),
                                "runtimePolicyReference", safeValue(result.runtimePolicyReference())));
            } else {
                credentials.findByTenantIdAndEntitlementId(tenantId, fulfillment.getEntitlementId())
                        .ifPresent(credential -> {
                            credential.synchronize(
                                    fulfillment.getId(),
                                    providerType,
                                    credential.getExternalReference(),
                                    CredentialReferenceStatus.REVOKED,
                                    credential.getExpiresAt(),
                                    now,
                                    actor);
                            credentials.saveAndFlush(credential);
                        });
            }
        }

        audit.success(
                tenantId,
                "GATEWAY_FULFILLMENT_RESULT",
                "ACCESS_FULFILLMENT",
                fulfillment.getId(),
                true,
                Map.of(
                        "fulfillmentType", fulfillment.getFulfillmentType().name(),
                        "status", target.name(),
                        "providerType", providerType,
                        "safeErrorCode", safeValue(result.safeErrorCode())));
        return fulfillment;
    }

    private void synchronizeCredential(
            String tenantId,
            AccessFulfillmentEntity fulfillment,
            GatewayPort.Result result,
            String providerType,
            CredentialReferenceStatus status,
            Instant now,
            String actor) {
        var current = credentials.findByTenantIdAndEntitlementId(tenantId, fulfillment.getEntitlementId());
        if (current.isPresent()) {
            var credential = current.get();
            credential.synchronize(
                    fulfillment.getId(),
                    providerType,
                    result.credentialReference(),
                    status,
                    result.credentialExpiresAt(),
                    now,
                    actor);
            credentials.saveAndFlush(credential);
        } else {
            credentials.saveAndFlush(new CredentialReferenceEntity(
                    UUID.randomUUID().toString(),
                    tenantId,
                    fulfillment.getEntitlementId(),
                    fulfillment.getId(),
                    providerType,
                    result.credentialReference(),
                    status,
                    result.credentialExpiresAt(),
                    now,
                    actor));
        }
    }

    private AccessFulfillmentEntity owned(String tenantId, String fulfillmentId) {
        return fulfillments.findByIdAndTenantId(fulfillmentId, tenantId)
                .orElseThrow(() -> new BusinessException(
                        ErrorCode.ACCESS_FULFILLMENT_NOT_FOUND,
                        HttpStatus.NOT_FOUND,
                        "AccessFulfillment를 찾을 수 없습니다."));
    }

    private String normalizeProvider(String value) {
        if (value == null || value.isBlank()) {
            throw new BusinessException(
                    ErrorCode.VALIDATION_ERROR,
                    HttpStatus.BAD_REQUEST,
                    "Credential provider authority가 필요합니다.");
        }
        return value.trim();
    }

    private BusinessException state(String message) {
        return new BusinessException(
                ErrorCode.ACCESS_FULFILLMENT_STATE_INVALID,
                HttpStatus.CONFLICT,
                message);
    }

    private String safe(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }

    private String safeValue(String value) {
        return value == null ? "" : value;
    }
}

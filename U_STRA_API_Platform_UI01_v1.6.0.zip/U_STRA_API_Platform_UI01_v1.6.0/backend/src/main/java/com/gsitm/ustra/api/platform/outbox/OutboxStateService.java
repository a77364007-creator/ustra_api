package com.gsitm.ustra.api.platform.outbox;

import java.time.Clock;
import java.time.Instant;
import java.util.Optional;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service
public class OutboxStateService {
    private final OutboxEventRepository repository;
    private final Clock clock;

    public OutboxStateService(OutboxEventRepository repository, Clock clock) {
        this.repository = repository;
        this.clock = clock;
    }

    @Transactional(readOnly = true, propagation = Propagation.REQUIRES_NEW)
    public Optional<OutboxMessage> loadPending(String outboxId) {
        return repository.findById(outboxId)
                .filter(event -> event.getStatus() == OutboxStatus.PENDING)
                .map(OutboxMessage::from);
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void markPublished(String outboxId) {
        repository.findById(outboxId)
                .filter(event -> event.getStatus() == OutboxStatus.PENDING)
                .ifPresent(event -> event.markPublished(Instant.now(clock)));
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void markAttemptFailed(String outboxId) {
        repository.findById(outboxId)
                .filter(event -> event.getStatus() == OutboxStatus.PENDING)
                .ifPresent(OutboxEventEntity::markAttemptFailed);
    }
}

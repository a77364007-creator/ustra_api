package com.gsitm.ustra.api.platform.outbox;

public record OutboxMessage(
        String outboxId,
        String eventId,
        String eventType,
        int eventVersion,
        String aggregateType,
        String aggregateId,
        String tenantId,
        String payload,
        String correlationId) {
    static OutboxMessage from(OutboxEventEntity entity) {
        return new OutboxMessage(entity.getId(), entity.getEventId(), entity.getEventType(), entity.getEventVersion(),
                entity.getAggregateType(), entity.getAggregateId(), entity.getTenantId(), entity.getPayload(),
                entity.getCorrelationId());
    }
}

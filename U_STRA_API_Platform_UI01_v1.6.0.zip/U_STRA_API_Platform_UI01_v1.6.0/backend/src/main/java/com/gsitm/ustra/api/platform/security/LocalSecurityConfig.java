package com.gsitm.ustra.api.platform.security;

import com.gsitm.ustra.api.platform.common.error.ErrorCode;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpStatus;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.AnonymousAuthenticationFilter;

@Configuration
@Profile({"local", "test"})
@EnableMethodSecurity
public class LocalSecurityConfig {
    @Bean
    SecurityFilterChain localSecurityFilterChain(
            HttpSecurity http,
            TestHeaderAuthenticationFilter testHeaderAuthenticationFilter,
            SecurityErrorWriter errorWriter) throws Exception {
        return http
                .csrf(csrf -> csrf.disable())
                .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/actuator/health", "/actuator/info").permitAll()
                        .anyRequest().authenticated())
                .exceptionHandling(ex -> ex
                        .authenticationEntryPoint((request, response, e) -> errorWriter.write(
                                response, HttpStatus.UNAUTHORIZED.value(), ErrorCode.AUTHENTICATION_REQUIRED, "인증이 필요합니다."))
                        .accessDeniedHandler((request, response, e) -> errorWriter.write(
                                response, HttpStatus.FORBIDDEN.value(), ErrorCode.ACCESS_DENIED, "요청 권한이 없습니다.")))
                .addFilterBefore(testHeaderAuthenticationFilter, AnonymousAuthenticationFilter.class)
                .build();
    }
}

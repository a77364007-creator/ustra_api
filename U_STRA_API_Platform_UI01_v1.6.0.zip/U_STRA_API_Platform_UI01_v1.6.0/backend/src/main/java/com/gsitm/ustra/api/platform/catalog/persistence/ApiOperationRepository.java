package com.gsitm.ustra.api.platform.catalog.persistence;
import java.util.List; import java.util.Optional; import org.springframework.data.jpa.repository.JpaRepository;
public interface ApiOperationRepository extends JpaRepository<ApiOperationEntity,String>{ Optional<ApiOperationEntity> findByIdAndTenantId(String id,String tenantId); List<ApiOperationEntity> findAllByTenantIdAndApiVersionIdOrderByIdAsc(String tenantId,String apiVersionId);}

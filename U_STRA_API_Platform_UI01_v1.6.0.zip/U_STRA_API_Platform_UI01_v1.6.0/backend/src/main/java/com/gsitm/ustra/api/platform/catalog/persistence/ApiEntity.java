package com.gsitm.ustra.api.platform.catalog.persistence;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Version;
import java.time.Instant;

@Entity
@Table(name = "api")
public class ApiEntity {
    @Id
    @Column(name = "api_id", length = 36, nullable = false, updatable = false)
    private String id;
    @Column(name = "tenant_id", length = 36, nullable = false, updatable = false)
    private String tenantId;
    @Column(name = "api_code", length = 100, nullable = false)
    private String apiCode;
    @Column(name = "api_code_normalized", length = 100, nullable = false)
    private String apiCodeNormalized;
    @Column(name = "name", length = 200, nullable = false)
    private String name;
    @Column(name = "description", columnDefinition = "TEXT")
    private String description;
    @Column(name = "provider_id", length = 36)
    private String providerId;
    @Version
    @Column(name = "row_version", nullable = false)
    private long rowVersion;
    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;
    @Column(name = "created_by", length = 200, nullable = false, updatable = false)
    private String createdBy;
    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;
    @Column(name = "updated_by", length = 200, nullable = false)
    private String updatedBy;

    protected ApiEntity() {
    }

    public ApiEntity(String id, String tenantId, String apiCode, String apiCodeNormalized, String name,
                     String description, String providerId, Instant now, String actor) {
        this.id = id;
        this.tenantId = tenantId;
        this.apiCode = apiCode;
        this.apiCodeNormalized = apiCodeNormalized;
        this.name = name;
        this.description = description;
        this.providerId = providerId;
        this.createdAt = now;
        this.createdBy = actor;
        this.updatedAt = now;
        this.updatedBy = actor;
    }

    public String getId() { return id; }
    public String getTenantId() { return tenantId; }
    public String getApiCode() { return apiCode; }
    public String getApiCodeNormalized() { return apiCodeNormalized; }
    public String getName() { return name; }
    public String getProviderId() { return providerId; }
}

package com.gsitm.ustra.api.platform.integration.approval.domain;
public enum IntegrationOperationStatus { REQUESTED, IN_PROGRESS, SUCCEEDED, FAILED, UNKNOWN, CANCELLED }

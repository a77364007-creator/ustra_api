package com.gsitm.ustra.api.platform.search.api;

import com.gsitm.ustra.api.platform.search.application.CatalogSearchAdminService;
import com.gsitm.ustra.api.platform.search.application.CatalogSearchProjectionPort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/admin/catalog-search")
public class CatalogSearchAdminController {
    private final CatalogSearchAdminService service;
    public CatalogSearchAdminController(CatalogSearchAdminService service){this.service=service;}

    @PostMapping("/rebuild")
    public ResponseEntity<CatalogSearchProjectionPort.RebuildResult> rebuild(){
        return ResponseEntity.status(HttpStatus.OK).body(service.rebuild());
    }
}

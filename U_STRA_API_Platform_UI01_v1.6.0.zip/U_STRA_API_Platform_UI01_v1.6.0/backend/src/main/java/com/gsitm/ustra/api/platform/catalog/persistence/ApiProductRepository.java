package com.gsitm.ustra.api.platform.catalog.persistence;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ApiProductRepository extends JpaRepository<ApiProductEntity, String> {
    Optional<ApiProductEntity> findByIdAndTenantId(String id, String tenantId);
    List<ApiProductEntity> findAllByTenantIdOrderByProductCodeNormalizedAsc(String tenantId);
    boolean existsByTenantIdAndProductCodeNormalized(String tenantId, String productCodeNormalized);
}

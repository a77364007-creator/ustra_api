package com.gsitm.ustra.api.platform.common.error;

import com.gsitm.ustra.api.platform.common.context.RequestContextHolder;
import jakarta.persistence.OptimisticLockException;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.http.HttpStatus;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {
    private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @ExceptionHandler(BusinessException.class)
    ResponseEntity<ApiErrorResponse> handleBusiness(BusinessException ex) {
        log.warn("Request rejected code={} status={}", ex.code().name(), ex.status().value());
        return ResponseEntity.status(ex.status()).body(error(ex.code(), ex.getMessage()));
    }

    @ExceptionHandler({MethodArgumentNotValidException.class, BindException.class})
    ResponseEntity<ApiErrorResponse> handleValidation(Exception ex) {
        String message;
        if (ex instanceof MethodArgumentNotValidException manv) {
            message = manv.getBindingResult().getFieldErrors().stream()
                    .map(e -> e.getField() + ": " + e.getDefaultMessage())
                    .collect(Collectors.joining(", "));
        } else if (ex instanceof BindException bind) {
            message = bind.getBindingResult().getFieldErrors().stream()
                    .map(e -> e.getField() + ": " + e.getDefaultMessage())
                    .collect(Collectors.joining(", "));
        } else {
            message = "요청 값이 올바르지 않습니다.";
        }
        log.warn("Request validation failed code={} status={}", ErrorCode.VALIDATION_ERROR.name(),
                HttpStatus.BAD_REQUEST.value());
        return ResponseEntity.badRequest().body(error(ErrorCode.VALIDATION_ERROR, message));
    }

    @ExceptionHandler({org.springframework.web.method.annotation.MethodArgumentTypeMismatchException.class,
            org.springframework.web.bind.MissingServletRequestParameterException.class,
            org.springframework.web.bind.MissingRequestHeaderException.class})
    ResponseEntity<ApiErrorResponse> handleParameter(Exception ex) {
        log.warn("Request parameter rejected code={} status={}", ErrorCode.VALIDATION_ERROR.name(), 400);
        return ResponseEntity.badRequest().body(error(ErrorCode.VALIDATION_ERROR, "요청 파라미터 형식 또는 필수값이 올바르지 않습니다."));
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    ResponseEntity<ApiErrorResponse> handleUnreadableJson(HttpMessageNotReadableException ex) {
        log.warn("Request JSON rejected code={} status={}", ErrorCode.VALIDATION_ERROR.name(),
                HttpStatus.BAD_REQUEST.value());
        return ResponseEntity.badRequest()
                .body(error(ErrorCode.VALIDATION_ERROR, "요청 JSON 형식 또는 필드가 올바르지 않습니다."));
    }

    @ExceptionHandler({OptimisticLockingFailureException.class, OptimisticLockException.class})
    ResponseEntity<ApiErrorResponse> handleOptimisticLock(Exception ex) {
        log.warn("Concurrent modification rejected code={} status={}",
                ErrorCode.CONCURRENT_MODIFICATION.name(), HttpStatus.CONFLICT.value());
        return ResponseEntity.status(HttpStatus.CONFLICT)
                .body(error(ErrorCode.CONCURRENT_MODIFICATION, "다른 요청에 의해 데이터가 변경되었습니다."));
    }

    @ExceptionHandler(Exception.class)
    ResponseEntity<ApiErrorResponse> handleUnexpected(Exception ex) {
        log.error("Unhandled request failure", ex);
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(error(ErrorCode.VALIDATION_ERROR, "요청 처리 중 오류가 발생했습니다."));
    }

    private ApiErrorResponse error(ErrorCode code, String message) {
        String correlationId = RequestContextHolder.get().map(c -> c.correlationId()).orElse("unknown");
        return new ApiErrorResponse(code.name(), message, correlationId);
    }
}

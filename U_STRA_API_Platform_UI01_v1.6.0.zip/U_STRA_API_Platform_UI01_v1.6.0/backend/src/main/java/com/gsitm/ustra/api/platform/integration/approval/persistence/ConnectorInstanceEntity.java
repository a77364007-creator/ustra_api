package com.gsitm.ustra.api.platform.integration.approval.persistence;
import jakarta.persistence.*; import java.time.Instant;
@Entity @Table(name="connector_instance") public class ConnectorInstanceEntity {
 @Id @Column(name="connector_instance_id",length=36,nullable=false,updatable=false) private String id;
 @Column(name="tenant_id",length=36,nullable=false,updatable=false) private String tenantId;
 @Column(name="integration_profile_id",length=36,nullable=false,updatable=false) private String integrationProfileId;
 @Column(name="connector_code",length=100,nullable=false) private String connectorCode;
 @Column(name="adapter_code",length=100,nullable=false) private String adapterCode;
 @Column(name="authority_code",length=80,nullable=false) private String authorityCode;
 @Column(name="secret_reference",length=500) private String secretReference;
 @Column(name="enabled",nullable=false) private boolean enabled;
 @Version @Column(name="row_version",nullable=false) private long rowVersion;
 @Column(name="created_at",nullable=false,updatable=false) private Instant createdAt; @Column(name="created_by",length=200,nullable=false,updatable=false) private String createdBy;
 @Column(name="updated_at",nullable=false) private Instant updatedAt; @Column(name="updated_by",length=200,nullable=false) private String updatedBy;
 protected ConnectorInstanceEntity(){}
 public ConnectorInstanceEntity(String id,String tenantId,String profileId,String connectorCode,String adapterCode,String authorityCode,String secretReference,boolean enabled,Instant now,String actor){this.id=id;this.tenantId=tenantId;this.integrationProfileId=profileId;this.connectorCode=connectorCode;this.adapterCode=adapterCode;this.authorityCode=authorityCode;this.secretReference=secretReference;this.enabled=enabled;this.createdAt=now;this.createdBy=actor;this.updatedAt=now;this.updatedBy=actor;}
 public String getId(){return id;} public String getTenantId(){return tenantId;} public String getIntegrationProfileId(){return integrationProfileId;} public String getConnectorCode(){return connectorCode;} public String getAdapterCode(){return adapterCode;} public String getAuthorityCode(){return authorityCode;} public String getSecretReference(){return secretReference;} public boolean isEnabled(){return enabled;} public long getRowVersion(){return rowVersion;}
}

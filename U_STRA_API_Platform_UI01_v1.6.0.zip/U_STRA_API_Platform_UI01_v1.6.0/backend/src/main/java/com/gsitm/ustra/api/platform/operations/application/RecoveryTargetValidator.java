package com.gsitm.ustra.api.platform.operations.application;

import com.gsitm.ustra.api.platform.common.error.*;
import com.gsitm.ustra.api.platform.operations.domain.*;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiProductRepository;
import com.gsitm.ustra.api.platform.subscription.approval.persistence.ApprovalReferenceRepository;
import com.gsitm.ustra.api.platform.subscription.entitlement.persistence.AccessFulfillmentRepository;
import com.gsitm.ustra.api.platform.subscription.entitlement.domain.AccessFulfillmentStatus;
import com.gsitm.ustra.api.platform.integration.approval.persistence.IntegrationOperationRepository;
import com.gsitm.ustra.api.platform.integration.approval.domain.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class RecoveryTargetValidator {
    private final ApprovalReferenceRepository approvals;
    private final AccessFulfillmentRepository fulfillments;
    private final ApiProductRepository products;
    private final IntegrationOperationRepository operations;
    public RecoveryTargetValidator(ApprovalReferenceRepository approvals,AccessFulfillmentRepository fulfillments,
                                   ApiProductRepository products,IntegrationOperationRepository operations) {
        this.approvals=approvals;this.fulfillments=fulfillments;this.products=products;this.operations=operations;
    }
    @Transactional(readOnly=true)
    public void validate(String tenantId, RecoveryRequest request) {
        long actualVersion;
        switch(request.actionType()) {
            case APPROVAL_STATUS_RECONCILE -> {
                var ref=approvals.findByIdAndTenantId(request.targetId(),tenantId).orElseThrow(this::notFound);
                var create=operations.findByTenantIdAndOperationTypeAndAggregateIdAndAggregateRevision(
                    tenantId,IntegrationOperationType.APPROVAL_CASE_CREATE,ref.getSubscriptionRequestId(),ref.getRequestRevisionNo())
                    .orElseThrow(this::notFound);
                if(create.getStatus()!=IntegrationOperationStatus.SUCCEEDED) throw invalid();
                actualVersion=ref.getRowVersion();
            }
            case GATEWAY_STATUS_RECONCILE -> {
                var f=fulfillments.findByIdAndTenantId(request.targetId(),tenantId).orElseThrow(this::notFound);
                if(f.getStatus()!=AccessFulfillmentStatus.UNKNOWN && f.getStatus()!=AccessFulfillmentStatus.FAILED) throw invalid();
                actualVersion=f.getRowVersion();
            }
            case SEARCH_PRODUCT_REINDEX -> actualVersion=products.findByIdAndTenantId(request.targetId(),tenantId)
                    .orElseThrow(this::notFound).getRowVersion();
            case SEARCH_TENANT_REBUILD -> {
                if(!tenantId.equals(request.targetId())) throw notFound();
                return; // There is no canonical search-generation revision to invent.
            }
            default -> throw invalid();
        }
        if(request.expectedTargetVersion()!=null && request.expectedTargetVersion()!=actualVersion)
            throw new BusinessException(ErrorCode.CONCURRENT_MODIFICATION,HttpStatus.CONFLICT,"대상 버전이 변경되었습니다.");
    }
    private BusinessException notFound(){return new BusinessException(ErrorCode.OPERATIONS_RECOVERY_NOT_FOUND,HttpStatus.NOT_FOUND,"복구 대상을 찾을 수 없습니다.");}
    private BusinessException invalid(){return new BusinessException(ErrorCode.OPERATIONS_RECOVERY_STATE_INVALID,HttpStatus.CONFLICT,"현재 상태에서 해당 조회/복구를 수행할 수 없습니다.");}
}

package com.gsitm.ustra.api.platform.tenant.persistence;

import com.gsitm.ustra.api.platform.tenant.domain.ReferenceStatus;
import com.gsitm.ustra.api.platform.tenant.domain.RoleScopeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "role_definition")
public class RoleEntity {
    @Id
    @Column(name = "role_id", length = 36, nullable = false)
    private String id;

    @Column(name = "role_code", length = 100, nullable = false, unique = true)
    private String code;

    @Column(name = "display_name", length = 200, nullable = false)
    private String displayName;

    @Enumerated(EnumType.STRING)
    @Column(name = "scope_type", length = 30, nullable = false)
    private RoleScopeType scopeType;

    @Column(name = "system_managed", nullable = false)
    private boolean systemManaged;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", length = 30, nullable = false)
    private ReferenceStatus status;

    protected RoleEntity() {
    }

    public String getId() { return id; }
    public String getCode() { return code; }
    public RoleScopeType getScopeType() { return scopeType; }
    public ReferenceStatus getStatus() { return status; }
}

package com.gsitm.ustra.api.platform.integration.approval.domain;
public enum ReconciliationIssueStatus { OPEN, RESOLVED }

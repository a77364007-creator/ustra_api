package com.gsitm.ustra.api.platform.consumer.api;

import com.gsitm.ustra.api.platform.consumer.application.ConsumerAppService;
import com.gsitm.ustra.api.platform.consumer.persistence.ConsumerAppEntity;
import com.gsitm.ustra.api.platform.tenant.api.VersionHeaderParser;
import jakarta.validation.Valid;
import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import java.time.Instant;
import java.util.List;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/consumer-apps")
public class ConsumerAppController {
    private final ConsumerAppService service;

    public ConsumerAppController(ConsumerAppService service) { this.service = service; }

    @GetMapping
    public List<ConsumerAppResponse> list() {
        return service.list().stream().map(ConsumerAppResponse::from).toList();
    }

    @GetMapping("/{consumerAppId}")
    public ResponseEntity<ConsumerAppResponse> get(@PathVariable String consumerAppId) {
        ConsumerAppEntity entity = service.get(consumerAppId);
        return ResponseEntity.ok().eTag(VersionHeaderParser.etag(entity.getRowVersion()))
                .body(ConsumerAppResponse.from(entity));
    }

    @PostMapping
    public ResponseEntity<ConsumerAppResponse> create(@Valid @RequestBody CreateConsumerAppRequest request) {
        ConsumerAppEntity entity = service.create(request.appCode(), request.name(), request.description(),
                request.ownerMembershipId(), request.organizationId());
        return ResponseEntity.status(HttpStatus.CREATED).eTag(VersionHeaderParser.etag(entity.getRowVersion()))
                .body(ConsumerAppResponse.from(entity));
    }

    @PatchMapping("/{consumerAppId}")
    public ResponseEntity<ConsumerAppResponse> update(
            @PathVariable String consumerAppId,
            @RequestHeader(value = HttpHeaders.IF_MATCH, required = false) String ifMatch,
            @Valid @RequestBody UpdateConsumerAppRequest request) {
        ConsumerAppEntity entity = service.update(consumerAppId, VersionHeaderParser.parse(ifMatch),
                request.name(), request.description(), request.ownerMembershipId(), request.organizationId());
        return ResponseEntity.ok().eTag(VersionHeaderParser.etag(entity.getRowVersion()))
                .body(ConsumerAppResponse.from(entity));
    }

    @PostMapping("/{consumerAppId}/activate")
    public ResponseEntity<ConsumerAppResponse> activate(@PathVariable String consumerAppId,
            @RequestHeader(value = HttpHeaders.IF_MATCH, required = false) String ifMatch) {
        return lifecycle(service.activate(consumerAppId, VersionHeaderParser.parse(ifMatch)));
    }

    @PostMapping("/{consumerAppId}/suspend")
    public ResponseEntity<ConsumerAppResponse> suspend(@PathVariable String consumerAppId,
            @RequestHeader(value = HttpHeaders.IF_MATCH, required = false) String ifMatch) {
        return lifecycle(service.suspend(consumerAppId, VersionHeaderParser.parse(ifMatch)));
    }

    @PostMapping("/{consumerAppId}/retire")
    public ResponseEntity<ConsumerAppResponse> retire(@PathVariable String consumerAppId,
            @RequestHeader(value = HttpHeaders.IF_MATCH, required = false) String ifMatch) {
        return lifecycle(service.retire(consumerAppId, VersionHeaderParser.parse(ifMatch)));
    }

    private ResponseEntity<ConsumerAppResponse> lifecycle(ConsumerAppEntity entity) {
        return ResponseEntity.ok().eTag(VersionHeaderParser.etag(entity.getRowVersion()))
                .body(ConsumerAppResponse.from(entity));
    }

    public record CreateConsumerAppRequest(
            @NotBlank @Size(max = 100) String appCode,
            @NotBlank @Size(max = 200) String name,
            @Size(max = 4000) String description,
            @NotBlank String ownerMembershipId,
            String organizationId) {}

    public record UpdateConsumerAppRequest(
            @NotBlank @Size(max = 200) String name,
            @Size(max = 4000) String description,
            @NotBlank String ownerMembershipId,
            String organizationId,
            String appCode,
            String tenantId,
            String lifecycleState,
            Long revision) {
        @AssertTrue(message = "appCode, tenantId, lifecycleState, revision은 PATCH로 변경할 수 없습니다.")
        public boolean isImmutableFieldMutationAbsent() {
            return appCode == null && tenantId == null && lifecycleState == null && revision == null;
        }
    }

    public record ConsumerAppResponse(
            String consumerAppId, String appCode, String name, String description,
            String ownerMembershipId, String organizationId, String lifecycleState, long revision,
            Instant createdAt, String createdBy, Instant updatedAt, String updatedBy) {
        static ConsumerAppResponse from(ConsumerAppEntity entity) {
            return new ConsumerAppResponse(entity.getId(), entity.getAppCode(), entity.getName(), entity.getDescription(),
                    entity.getOwnerMembershipId(), entity.getOrganizationId(), entity.getLifecycleState().name(),
                    entity.getRowVersion(), entity.getCreatedAt(), entity.getCreatedBy(),
                    entity.getUpdatedAt(), entity.getUpdatedBy());
        }
    }
}

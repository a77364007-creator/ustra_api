package com.gsitm.ustra.api.platform.security;

public record AuthenticatedIdentity(String principalId, String issuer) {
}

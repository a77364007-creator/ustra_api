package com.gsitm.ustra.api.platform.integration.gateway.application;

import com.gsitm.ustra.api.platform.common.error.BusinessException;
import com.gsitm.ustra.api.platform.common.error.ErrorCode;
import com.gsitm.ustra.api.platform.subscription.gateway.application.GatewayPort;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

@Component
public class GatewayConnectorRegistry {
    private final Map<String, GatewayPort> ports;

    public GatewayConnectorRegistry(List<GatewayConnectorRegistration> registrations) {
        Map<String, GatewayPort> found = new HashMap<>();
        for (GatewayConnectorRegistration registration : registrations) {
            String code = normalize(registration.adapterCode());
            if (found.putIfAbsent(code, registration.port()) != null) {
                throw new IllegalStateException("Duplicate gateway connector adapter code: " + code);
            }
        }
        this.ports = Map.copyOf(found);
    }

    public GatewayPort resolve(String adapterCode) {
        GatewayPort port = ports.get(normalize(adapterCode));
        if (port == null) {
            throw new BusinessException(
                    ErrorCode.INTEGRATION_CONNECTOR_UNAVAILABLE,
                    HttpStatus.CONFLICT,
                    "활성화된 Gateway connector adapter를 사용할 수 없습니다.");
        }
        return port;
    }

    private String normalize(String value) {
        return value == null ? "" : value.trim().toUpperCase(Locale.ROOT);
    }
}

package com.gsitm.ustra.api.platform.consumer.application;

import com.gsitm.ustra.api.platform.audit.AuditService;
import com.gsitm.ustra.api.platform.catalog.publication.application.StateTransitionHistoryService;
import com.gsitm.ustra.api.platform.common.error.BusinessException;
import com.gsitm.ustra.api.platform.common.error.ErrorCode;
import com.gsitm.ustra.api.platform.consumer.domain.ConsumerAppLifecycleState;
import com.gsitm.ustra.api.platform.consumer.persistence.ConsumerAppEntity;
import com.gsitm.ustra.api.platform.consumer.persistence.ConsumerAppRepository;
import com.gsitm.ustra.api.platform.tenant.application.TenantPermissionGuard;
import com.gsitm.ustra.api.platform.tenant.context.TenantContext;
import com.gsitm.ustra.api.platform.tenant.context.TenantContextResolver;
import com.gsitm.ustra.api.platform.tenant.persistence.MembershipEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.MembershipRepository;
import com.gsitm.ustra.api.platform.tenant.persistence.OrganizationRepository;
import java.time.Clock;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ConsumerAppService {
    private final TenantContextResolver contextResolver;
    private final TenantPermissionGuard permissionGuard;
    private final ConsumerAppRepository repository;
    private final MembershipRepository membershipRepository;
    private final OrganizationRepository organizationRepository;
    private final StateTransitionHistoryService historyService;
    private final AuditService auditService;
    private final Clock clock;

    public ConsumerAppService(TenantContextResolver contextResolver, TenantPermissionGuard permissionGuard,
                              ConsumerAppRepository repository, MembershipRepository membershipRepository,
                              OrganizationRepository organizationRepository,
                              StateTransitionHistoryService historyService, AuditService auditService, Clock clock) {
        this.contextResolver = contextResolver;
        this.permissionGuard = permissionGuard;
        this.repository = repository;
        this.membershipRepository = membershipRepository;
        this.organizationRepository = organizationRepository;
        this.historyService = historyService;
        this.auditService = auditService;
        this.clock = clock;
    }

    @Transactional(readOnly = true)
    public List<ConsumerAppEntity> list() {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "CONSUMER_APP:READ", "CONSUMER_APP", "list");
        return repository.findAllByTenantIdOrderByAppCodeNormalizedAsc(context.tenantId());
    }

    @Transactional(readOnly = true)
    public ConsumerAppEntity get(String id) {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "CONSUMER_APP:READ", "CONSUMER_APP", id);
        return owned(context, id);
    }

    @Transactional
    public ConsumerAppEntity create(String appCode, String name, String description,
                                    String ownerMembershipId, String organizationId) {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "CONSUMER_APP:CREATE", "CONSUMER_APP", "new");
        String canonical = ConsumerAppCodeNormalizer.appCode(appCode);
        if (repository.existsByTenantIdAndAppCodeNormalized(context.tenantId(), canonical)) {
            throw new BusinessException(ErrorCode.CONSUMER_APP_CODE_CONFLICT, HttpStatus.CONFLICT,
                    "현재 Tenant에서 이미 사용 중인 appCode입니다.");
        }
        validateOwnerAndOrganization(context.tenantId(), ownerMembershipId, organizationId);
        Instant now = Instant.now(clock);
        ConsumerAppEntity entity = repository.saveAndFlush(new ConsumerAppEntity(
                UUID.randomUUID().toString(), context.tenantId(), canonical, canonical, name, description,
                ownerMembershipId, organizationId, now, context.principalId()));
        return entity;
    }

    @Transactional
    public ConsumerAppEntity update(String id, long expectedVersion, String name, String description,
                                    String ownerMembershipId, String organizationId) {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "CONSUMER_APP:UPDATE", "CONSUMER_APP", id);
        ConsumerAppEntity entity = owned(context, id);
        requireVersion(entity, expectedVersion);
        validateOwnerAndOrganization(context.tenantId(), ownerMembershipId, organizationId);
        String previousOwner = entity.getOwnerMembershipId();
        String previousOrganization = entity.getOrganizationId();
        entity.update(name, description, ownerMembershipId, organizationId, Instant.now(clock), context.principalId());
        entity = repository.saveAndFlush(entity);
        if (!Objects.equals(previousOwner, ownerMembershipId) || !Objects.equals(previousOrganization, organizationId)) {
            auditService.success(context.tenantId(), "CONSUMER_APP_OWNERSHIP_UPDATE", "CONSUMER_APP", entity.getId(),
                    true, Map.of(
                            "ownerChanged", !Objects.equals(previousOwner, ownerMembershipId),
                            "organizationChanged", !Objects.equals(previousOrganization, organizationId)));
        }
        return entity;
    }

    @Transactional
    public ConsumerAppEntity activate(String id, long expectedVersion) {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "CONSUMER_APP:MANAGE_LIFECYCLE", "CONSUMER_APP", id);
        ConsumerAppEntity entity = owned(context, id);
        requireVersion(entity, expectedVersion);
        if (entity.getLifecycleState() != ConsumerAppLifecycleState.DRAFT
                && entity.getLifecycleState() != ConsumerAppLifecycleState.SUSPENDED) {
            throw invalidState("DRAFT 또는 SUSPENDED Consumer App만 활성화할 수 있습니다.");
        }
        return transition(context, entity, ConsumerAppLifecycleState.ACTIVE, "CONSUMER_APP_ACTIVATE");
    }

    @Transactional
    public ConsumerAppEntity suspend(String id, long expectedVersion) {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "CONSUMER_APP:MANAGE_LIFECYCLE", "CONSUMER_APP", id);
        ConsumerAppEntity entity = owned(context, id);
        requireVersion(entity, expectedVersion);
        if (entity.getLifecycleState() != ConsumerAppLifecycleState.ACTIVE) {
            throw invalidState("ACTIVE Consumer App만 중지할 수 있습니다.");
        }
        return transition(context, entity, ConsumerAppLifecycleState.SUSPENDED, "CONSUMER_APP_SUSPEND");
    }

    @Transactional
    public ConsumerAppEntity retire(String id, long expectedVersion) {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "CONSUMER_APP:MANAGE_LIFECYCLE", "CONSUMER_APP", id);
        ConsumerAppEntity entity = owned(context, id);
        requireVersion(entity, expectedVersion);
        if (entity.getLifecycleState() != ConsumerAppLifecycleState.ACTIVE
                && entity.getLifecycleState() != ConsumerAppLifecycleState.SUSPENDED) {
            throw invalidState("ACTIVE 또는 SUSPENDED Consumer App만 RETIRED로 전환할 수 있습니다.");
        }
        return transition(context, entity, ConsumerAppLifecycleState.RETIRED, "CONSUMER_APP_RETIRE");
    }

    private ConsumerAppEntity transition(TenantContext context, ConsumerAppEntity entity,
                                         ConsumerAppLifecycleState target, String auditAction) {
        String from = entity.getLifecycleState().name();
        Instant now = Instant.now(clock);
        switch (target) {
            case ACTIVE -> entity.activate(now, context.principalId());
            case SUSPENDED -> entity.suspend(now, context.principalId());
            case RETIRED -> entity.retire(now, context.principalId());
            default -> throw invalidState("지원하지 않는 Consumer App 상태전이입니다.");
        }
        entity = repository.saveAndFlush(entity);
        historyService.record(context.tenantId(), "CONSUMER_APP", entity.getId(), from, target.name());
        auditService.success(context.tenantId(), auditAction, "CONSUMER_APP", entity.getId(), true,
                Map.of("fromState", from, "toState", target.name()));
        return entity;
    }

    private void validateOwnerAndOrganization(String tenantId, String ownerMembershipId, String organizationId) {
        Instant now = Instant.now(clock);
        MembershipEntity owner = membershipRepository.findByIdAndTenantId(ownerMembershipId, tenantId)
                .orElseThrow(() -> new BusinessException(ErrorCode.MEMBERSHIP_NOT_FOUND, HttpStatus.BAD_REQUEST,
                        "같은 Tenant의 Owner Membership을 찾을 수 없습니다."));
        if (!owner.isEffectiveAt(now)) {
            throw new BusinessException(ErrorCode.MEMBERSHIP_NOT_ACTIVE, HttpStatus.BAD_REQUEST,
                    "Owner Membership은 현재 ACTIVE/effective 상태여야 합니다.");
        }
        if (organizationId != null && organizationRepository.findByIdAndTenantId(organizationId, tenantId).isEmpty()) {
            throw new BusinessException(ErrorCode.ORGANIZATION_NOT_FOUND, HttpStatus.BAD_REQUEST,
                    "같은 Tenant의 Organization을 찾을 수 없습니다.");
        }
    }

    private ConsumerAppEntity owned(TenantContext context, String id) {
        return repository.findByIdAndTenantId(id, context.tenantId())
                .orElseThrow(() -> new BusinessException(ErrorCode.CONSUMER_APP_NOT_FOUND, HttpStatus.NOT_FOUND,
                        "Consumer App을 찾을 수 없습니다."));
    }

    private void requireVersion(ConsumerAppEntity entity, long expectedVersion) {
        if (entity.getRowVersion() != expectedVersion) {
            throw new BusinessException(ErrorCode.CONCURRENT_MODIFICATION, HttpStatus.CONFLICT,
                    "Consumer App이 다른 요청에 의해 변경되었습니다.");
        }
    }

    private BusinessException invalidState(String message) {
        return new BusinessException(ErrorCode.CONSUMER_APP_STATE_INVALID, HttpStatus.CONFLICT, message);
    }
}

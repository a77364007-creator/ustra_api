package com.gsitm.ustra.api.platform.tenant.persistence;

import com.gsitm.ustra.api.platform.tenant.domain.MembershipStatus;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.Instant;

@Entity
@Table(name = "membership")
public class MembershipEntity {
    @Id
    @Column(name = "membership_id", length = 36, nullable = false, updatable = false)
    private String id;

    @Column(name = "tenant_id", length = 36, nullable = false, updatable = false)
    private String tenantId;

    @Column(name = "organization_id", length = 36)
    private String organizationId;

    @Column(name = "principal_id", length = 200, nullable = false, updatable = false)
    private String principalId;

    @Column(name = "issuer", length = 300, nullable = false, updatable = false)
    private String issuer;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", length = 30, nullable = false)
    private MembershipStatus status;

    @Column(name = "effective_from", nullable = false)
    private Instant effectiveFrom;

    @Column(name = "effective_to")
    private Instant effectiveTo;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;

    protected MembershipEntity() {
    }

    public MembershipEntity(String id, String tenantId, String organizationId, String principalId, String issuer,
                            Instant effectiveFrom, Instant effectiveTo, Instant now) {
        this.id = id;
        this.tenantId = tenantId;
        this.organizationId = organizationId;
        this.principalId = principalId;
        this.issuer = issuer;
        this.status = MembershipStatus.ACTIVE;
        this.effectiveFrom = effectiveFrom;
        this.effectiveTo = effectiveTo;
        this.createdAt = now;
        this.updatedAt = now;
    }

    public boolean isEffectiveAt(Instant now) {
        return status == MembershipStatus.ACTIVE
                && !effectiveFrom.isAfter(now)
                && (effectiveTo == null || now.isBefore(effectiveTo));
    }

    public void deactivate(Instant now) {
        this.status = MembershipStatus.INACTIVE;
        this.updatedAt = now;
    }

    public String getId() { return id; }
    public String getTenantId() { return tenantId; }
    public String getOrganizationId() { return organizationId; }
    public String getPrincipalId() { return principalId; }
    public String getIssuer() { return issuer; }
    public MembershipStatus getStatus() { return status; }
    public Instant getEffectiveFrom() { return effectiveFrom; }
    public Instant getEffectiveTo() { return effectiveTo; }
}

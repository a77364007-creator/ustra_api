package com.gsitm.ustra.api.platform.integration.approval.application;

import com.gsitm.ustra.api.platform.integration.approval.domain.IntegrationOperationStatus;
import com.gsitm.ustra.api.platform.subscription.approval.application.ApprovalPort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional(propagation = Propagation.NOT_SUPPORTED)
public class ApprovalIntegrationOrchestrator {
    private final ApprovalIntegrationStateService state;
    private final ApprovalConnectorRegistry connectors;

    public ApprovalIntegrationOrchestrator(ApprovalIntegrationStateService state, ApprovalConnectorRegistry connectors) {
        this.state = state;
        this.connectors = connectors;
    }

    public CreateResult startCase(String tenantId, String requestId) {
        var prepared = state.prepareCreate(tenantId, requestId);
        if (!prepared.invokeRequired()) {
            return new CreateResult(prepared.operation().getId(), prepared.operation().getStatus(), null);
        }
        // Missing adapter is a pre-call configuration failure. Do not mark IN_PROGRESS.
        ApprovalPort port = connectors.resolve(prepared.connector().getAdapterCode());
        String operationId = prepared.operation().getId();
        state.beginOutbound(tenantId, operationId);
        ApprovalPort.CaseReference external;
        try {
            external = port.createCase(prepared.command());
        } catch (ApprovalConnectorFailureException ex) {
            // Only a connector's explicit definitive-failure contract may prove failure.
            var op = state.markFailed(tenantId, operationId, ex.safeCode());
            return new CreateResult(op.getId(), op.getStatus(), null);
        } catch (ApprovalConnectorUnknownException ex) {
            return unknownCreate(tenantId, operationId, ex.safeCode(), ex.externalReference());
        } catch (RuntimeException ex) {
            return unknownCreate(tenantId, operationId, "UNCLASSIFIED_CONNECTOR_FAILURE", null);
        }
        try {
            var ref = state.completeCreate(tenantId, operationId, prepared.command(), external);
            return new CreateResult(operationId, IntegrationOperationStatus.SUCCEEDED, ref.getId());
        } catch (RuntimeException ex) {
            // The external effect already happened; persistence/validation failure is not definitive failure.
            return unknownCreate(tenantId, operationId, "CREATE_RESULT_PERSISTENCE_UNKNOWN", null);
        }
    }

    private CreateResult unknownCreate(String tenantId, String operationId, String code, String reference) {
        var op = state.markUnknown(tenantId, operationId,
                ApprovalIntegrationStateService.createUnknownIssueType(), code, reference);
        return new CreateResult(op.getId(), op.getStatus(), null);
    }

    public ApprovalIntegrationStateService.DecisionResult synchronize(String tenantId, String approvalReferenceId) {
        var prepared = state.prepareQuery(tenantId, approvalReferenceId);
        ApprovalPort port = connectors.resolve(prepared.connector().getAdapterCode());
        String operationId = prepared.operation().getId();
        state.beginOutbound(tenantId, operationId);
        ApprovalPort.Decision decision;
        try {
            decision = port.queryDecision(prepared.approvalReference().getExternalCaseRef());
        } catch (ApprovalConnectorFailureException ex) {
            state.markFailed(tenantId, operationId, ex.safeCode());
            throw ex;
        } catch (ApprovalConnectorUnknownException ex) {
            return unknownQuery(tenantId, operationId, ex.safeCode(), ex.externalReference());
        } catch (RuntimeException ex) {
            return unknownQuery(tenantId, operationId, "UNCLASSIFIED_CONNECTOR_QUERY_FAILURE", null);
        }
        try {
            return state.completeQuery(tenantId, operationId, approvalReferenceId, decision);
        } catch (RuntimeException ex) {
            return unknownQuery(tenantId, operationId, "QUERY_RESULT_PERSISTENCE_UNKNOWN", null);
        }
    }

    private ApprovalIntegrationStateService.DecisionResult unknownQuery(String tenantId, String operationId,
                                                                       String code, String reference) {
        var op = state.markUnknown(tenantId, operationId,
                ApprovalIntegrationStateService.queryUnknownIssueType(), code, reference);
        return new ApprovalIntegrationStateService.DecisionResult(op, ApprovalPort.DecisionStatus.PENDING, null);
    }

    public record CreateResult(String integrationOperationId, IntegrationOperationStatus status,
                               String approvalReferenceId) {}
}

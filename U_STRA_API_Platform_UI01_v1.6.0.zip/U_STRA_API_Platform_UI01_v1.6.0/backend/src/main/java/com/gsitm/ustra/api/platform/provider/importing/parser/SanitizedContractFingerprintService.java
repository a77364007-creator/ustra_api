package com.gsitm.ustra.api.platform.provider.importing.parser;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gsitm.ustra.api.platform.provider.importing.application.Sha256Service;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.media.Schema;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import org.springframework.stereotype.Component;

/**
 * Produces fingerprints from contract-significant, non-secret OpenAPI structure.
 * Raw source, descriptions, examples and credentials are deliberately excluded.
 */
@Component
public class SanitizedContractFingerprintService {
    private final ObjectMapper objectMapper;
    private final Sha256Service sha256Service;

    public SanitizedContractFingerprintService(ObjectMapper objectMapper, Sha256Service sha256Service) {
        this.objectMapper = objectMapper;
        this.sha256Service = sha256Service;
    }

    public String schemaFingerprint(Schema<?> schema, OpenAPI api) {
        return hash(schemaShape(schema, api, new LinkedHashSet<>()));
    }

    public String parameterFingerprint(String location, String name, boolean required, String schemaFingerprint) {
        Map<String, Object> canonical = new LinkedHashMap<>();
        canonical.put("location", safe(location));
        canonical.put("name", safe(name));
        canonical.put("required", required);
        canonical.put("schema", schemaFingerprint);
        return hash(canonical);
    }

    public String bodyFingerprint(boolean required, String mediaType, String schemaFingerprint) {
        Map<String, Object> canonical = new LinkedHashMap<>();
        canonical.put("required", required);
        canonical.put("mediaType", safe(mediaType));
        canonical.put("schema", schemaFingerprint);
        return hash(canonical);
    }

    public String responseFingerprint(String code, String mediaType, String schemaFingerprint) {
        Map<String, Object> canonical = new LinkedHashMap<>();
        canonical.put("code", safe(code));
        canonical.put("mediaType", safe(mediaType));
        canonical.put("schema", schemaFingerprint);
        return hash(canonical);
    }

    public String securityRequirementFingerprint(SecurityRequirement requirement, OpenAPI api) {
        Map<String, Object> canonical = new TreeMap<>();
        if (requirement != null) {
            requirement.forEach((schemeName, scopes) -> {
                List<String> sortedScopes = scopes == null ? new ArrayList<>() : new ArrayList<>(scopes);
                Collections.sort(sortedScopes);
                Map<String, Object> scheme = new LinkedHashMap<>();
                scheme.put("scopes", sortedScopes);
                scheme.put("scheme", securitySchemeFingerprint(schemeName, api));
                canonical.put(schemeName, scheme);
            });
        }
        return hash(canonical);
    }

    private String securitySchemeFingerprint(String schemeName, OpenAPI api) {
        SecurityScheme scheme = api.getComponents() == null || api.getComponents().getSecuritySchemes() == null
                ? null : api.getComponents().getSecuritySchemes().get(schemeName);
        if (scheme == null) {
            return hash(Map.of("name", safe(schemeName), "unresolved", true));
        }
        Map<String, Object> canonical = new LinkedHashMap<>();
        canonical.put("type", scheme.getType() == null ? null : scheme.getType().name());
        canonical.put("scheme", scheme.getScheme());
        canonical.put("bearerFormat", scheme.getBearerFormat());
        canonical.put("in", scheme.getIn() == null ? null : scheme.getIn().name());
        canonical.put("name", scheme.getName());
        return hash(canonical);
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private Object schemaShape(Schema<?> schema, OpenAPI api, Set<String> visitingRefs) {
        if (schema == null) {
            return Map.of("schema", "NONE");
        }
        String ref = schema.get$ref();
        if (ref != null && !ref.isBlank()) {
            if (ref.startsWith("#/components/schemas/")) {
                String key = ref.substring("#/components/schemas/".length());
                if (!visitingRefs.add(ref)) {
                    return Map.of("ref", key, "cycle", true);
                }
                Schema<?> resolved = api.getComponents() == null || api.getComponents().getSchemas() == null
                        ? null : api.getComponents().getSchemas().get(key);
                Map<String, Object> result = new LinkedHashMap<>();
                result.put("ref", key);
                result.put("resolved", resolved == null
                        ? Map.of("unresolved", true)
                        : schemaShape(resolved, api, visitingRefs));
                visitingRefs.remove(ref);
                return result;
            }
            return Map.of("ref", ref, "unresolved", true);
        }

        Map<String, Object> canonical = new LinkedHashMap<>();
        canonical.put("type", schema.getType());
        canonical.put("format", schema.getFormat());
        canonical.put("nullable", schema.getNullable());
        canonical.put("readOnly", schema.getReadOnly());
        canonical.put("writeOnly", schema.getWriteOnly());

        if (schema.getEnum() != null) {
            List<String> values = schema.getEnum().stream().map(String::valueOf).sorted().toList();
            canonical.put("enum", values);
        }
        if (schema.getRequired() != null) {
            canonical.put("required", schema.getRequired().stream().sorted().toList());
        }
        if (schema.getProperties() != null) {
            Map<String, Object> properties = new TreeMap<>();
            ((Map<String, Schema>) schema.getProperties()).forEach(
                    (name, child) -> properties.put(name, schemaShape(child, api, visitingRefs)));
            canonical.put("properties", properties);
        }
        if (schema.getItems() != null) {
            canonical.put("items", schemaShape(schema.getItems(), api, visitingRefs));
        }
        putSchemaList(canonical, "allOf", schema.getAllOf(), api, visitingRefs);
        putSchemaList(canonical, "oneOf", schema.getOneOf(), api, visitingRefs);
        putSchemaList(canonical, "anyOf", schema.getAnyOf(), api, visitingRefs);
        if (schema.getNot() != null) {
            canonical.put("not", schemaShape(schema.getNot(), api, visitingRefs));
        }
        Object additional = schema.getAdditionalProperties();
        if (additional instanceof Schema<?> additionalSchema) {
            canonical.put("additionalProperties", schemaShape(additionalSchema, api, visitingRefs));
        } else if (additional != null) {
            canonical.put("additionalProperties", additional);
        }
        return canonical;
    }

    private void putSchemaList(Map<String, Object> target, String key, List<Schema> schemas,
                               OpenAPI api, Set<String> visitingRefs) {
        if (schemas == null || schemas.isEmpty()) return;
        List<Object> values = new ArrayList<>();
        for (Schema<?> schema : schemas) {
            values.add(schemaShape(schema, api, visitingRefs));
        }
        target.put(key, values);
    }

    private String hash(Object value) {
        try {
            return sha256Service.hashText(objectMapper.writeValueAsString(value));
        } catch (JsonProcessingException ex) {
            throw new IllegalStateException("Sanitized OpenAPI fingerprint serialization failed", ex);
        }
    }

    private String safe(String value) {
        return value == null ? "" : value;
    }
}

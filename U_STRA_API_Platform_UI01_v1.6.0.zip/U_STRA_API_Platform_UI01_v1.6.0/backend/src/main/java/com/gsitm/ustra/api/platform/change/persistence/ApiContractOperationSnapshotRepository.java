package com.gsitm.ustra.api.platform.change.persistence;
import java.util.List; import org.springframework.data.jpa.repository.JpaRepository;
public interface ApiContractOperationSnapshotRepository extends JpaRepository<ApiContractOperationSnapshotEntity,String>{List<ApiContractOperationSnapshotEntity> findAllByTenantIdAndSnapshotIdOrderByMethodAscNormalizedPathAsc(String tenantId,String snapshotId);}

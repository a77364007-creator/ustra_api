package com.gsitm.ustra.api.platform.subscription.entitlement.domain;
public enum AccessFulfillmentType { PROVISION, DEPROVISION }

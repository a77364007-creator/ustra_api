package com.gsitm.ustra.api.platform.catalog.publication.application;

import com.gsitm.ustra.api.platform.catalog.publication.persistence.StateTransitionHistoryEntity;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.StateTransitionHistoryRepository;
import com.gsitm.ustra.api.platform.common.context.RequestContextHolder;
import com.gsitm.ustra.api.platform.security.AuthenticatedIdentityProvider;
import java.time.Clock;
import java.time.Instant;
import java.util.UUID;
import org.springframework.stereotype.Service;

@Service
public class StateTransitionHistoryService {
    private final StateTransitionHistoryRepository repository;
    private final AuthenticatedIdentityProvider identityProvider;
    private final Clock clock;

    public StateTransitionHistoryService(StateTransitionHistoryRepository repository,
                                         AuthenticatedIdentityProvider identityProvider,
                                         Clock clock) {
        this.repository = repository;
        this.identityProvider = identityProvider;
        this.clock = clock;
    }

    public void record(String tenantId, String aggregateType, String aggregateId,
                       String fromState, String toState) {
        repository.save(new StateTransitionHistoryEntity(
                UUID.randomUUID().toString(), tenantId, aggregateType, aggregateId, fromState, toState,
                Instant.now(clock), identityProvider.current().principalId(),
                RequestContextHolder.required().correlationId()));
    }
}

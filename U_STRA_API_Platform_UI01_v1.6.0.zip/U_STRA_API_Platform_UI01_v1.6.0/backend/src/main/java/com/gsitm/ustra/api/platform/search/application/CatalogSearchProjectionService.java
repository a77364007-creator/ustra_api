package com.gsitm.ustra.api.platform.search.application;

import com.gsitm.ustra.api.platform.catalog.localization.domain.LocalizationStatus;
import com.gsitm.ustra.api.platform.catalog.localization.persistence.LocalizedContentEntity;
import com.gsitm.ustra.api.platform.catalog.localization.persistence.LocalizedContentRepository;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiProductEntity;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiProductRepository;
import com.gsitm.ustra.api.platform.catalog.persistence.ProviderEntity;
import com.gsitm.ustra.api.platform.catalog.persistence.ProviderRepository;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.ApiProductVersionEntity;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.ApiProductVersionRepository;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.AudienceScopeEntity;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.AudienceScopeRepository;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.CatalogPublicationEntity;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.CatalogPublicationRepository;
import com.gsitm.ustra.api.platform.search.persistence.CatalogSearchDocumentEntity;
import com.gsitm.ustra.api.platform.search.persistence.CatalogSearchDocumentRepository;
import com.gsitm.ustra.api.platform.search.persistence.CatalogSearchVisibilityEntity;
import com.gsitm.ustra.api.platform.search.persistence.CatalogSearchVisibilityRepository;
import java.time.Clock;
import java.time.Instant;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service
public class CatalogSearchProjectionService implements CatalogSearchProjectionPort {
    public static final String CANONICAL_LOCALE_KEY = "CANONICAL";

    private final ApiProductRepository productRepository;
    private final ProviderRepository providerRepository;
    private final LocalizedContentRepository localizationRepository;
    private final ApiProductVersionRepository versionRepository;
    private final CatalogPublicationRepository publicationRepository;
    private final AudienceScopeRepository audienceRepository;
    private final CatalogSearchDocumentRepository documentRepository;
    private final CatalogSearchVisibilityRepository visibilityRepository;
    private final CatalogSearchProjectionHashService hashService;
    private final Clock clock;

    public CatalogSearchProjectionService(ApiProductRepository productRepository, ProviderRepository providerRepository,
                                          LocalizedContentRepository localizationRepository,
                                          ApiProductVersionRepository versionRepository,
                                          CatalogPublicationRepository publicationRepository,
                                          AudienceScopeRepository audienceRepository,
                                          CatalogSearchDocumentRepository documentRepository,
                                          CatalogSearchVisibilityRepository visibilityRepository,
                                          CatalogSearchProjectionHashService hashService, Clock clock) {
        this.productRepository=productRepository; this.providerRepository=providerRepository;
        this.localizationRepository=localizationRepository; this.versionRepository=versionRepository;
        this.publicationRepository=publicationRepository; this.audienceRepository=audienceRepository;
        this.documentRepository=documentRepository; this.visibilityRepository=visibilityRepository;
        this.hashService=hashService; this.clock=clock;
    }

    @Override
    @Transactional
    public RebuildResult rebuildTenant(String tenantId, String actor) {
        visibilityRepository.deleteByTenantId(tenantId);
        documentRepository.deleteByTenantId(tenantId);
        List<ApiProductEntity> products = productRepository.findAllByTenantIdOrderByProductCodeNormalizedAsc(tenantId);
        long documents=0; long visibilities=0;
        for (ApiProductEntity product : products) {
            ProjectionCounts counts = project(product, actor);
            documents += counts.documents(); visibilities += counts.visibilities();
        }
        return new RebuildResult(tenantId, products.size(), documents, visibilities);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public ReindexResult reindexProduct(String tenantId, String apiProductId, String actor) {
        visibilityRepository.deleteByTenantIdAndApiProductId(tenantId, apiProductId);
        documentRepository.deleteByTenantIdAndApiProductId(tenantId, apiProductId);
        ApiProductEntity product = productRepository.findByIdAndTenantId(apiProductId, tenantId).orElse(null);
        if (product == null) return new ReindexResult(tenantId, apiProductId, 0, 0);
        ProjectionCounts counts = project(product, actor);
        return new ReindexResult(tenantId, apiProductId, counts.documents(), counts.visibilities());
    }

    private ProjectionCounts project(ApiProductEntity product, String actor) {
        Instant now = Instant.now(clock);
        ProviderEntity provider = product.getProviderId() == null ? null
                : providerRepository.findByIdAndTenantId(product.getProviderId(), product.getTenantId()).orElse(null);
        int documents=0; int visibilities=0;
        documentRepository.save(document(product, provider, null, now));
        documents++;
        List<LocalizedContentEntity> localized = localizationRepository.findAllByTenantIdAndApiProductIdAndStatus(
                product.getTenantId(), product.getId(), LocalizationStatus.PUBLISHED);
        for (LocalizedContentEntity content : localized) {
            documentRepository.save(document(product, provider, content, now));
            documents++;
        }
        for (ApiProductVersionEntity version : versionRepository
                .findAllByTenantIdAndApiProductIdOrderByCreatedAtAsc(product.getTenantId(), product.getId())) {
            for (CatalogPublicationEntity publication : publicationRepository
                    .findAllByTenantIdAndApiProductVersionIdOrderByCreatedAtAsc(product.getTenantId(), version.getId())) {
                for (AudienceScopeEntity audience : audienceRepository
                        .findAllByTenantIdAndCatalogPublicationIdOrderByCreatedAtAsc(product.getTenantId(), publication.getId())) {
                    String canonical = product.getTenantId()+"|"+product.getId()+"|"+publication.getId()+"|"+version.getId()+"|"
                            +version.getVersionValue()+"|"+publication.getLifecycleState()+"|"+version.getLifecycleState()+"|"
                            +audience.getScopeType()+"|"+Objects.toString(audience.getOrganizationId(),"")+"|"
                            +publication.getRowVersion()+"|"+version.getRowVersion();
                    visibilityRepository.save(new CatalogSearchVisibilityEntity(UUID.randomUUID().toString(),
                            product.getTenantId(), product.getId(), publication.getId(), version.getId(),
                            version.getVersionValue(), publication.getLifecycleState().name(), version.getLifecycleState().name(),
                            audience.getScopeType().name(), audience.getOrganizationId(), publication.getRowVersion(),
                            version.getRowVersion(), hashService.hash(canonical), now));
                    visibilities++;
                }
            }
        }
        documentRepository.flush(); visibilityRepository.flush();
        return new ProjectionCounts(documents, visibilities);
    }

    private CatalogSearchDocumentEntity document(ApiProductEntity product, ProviderEntity provider,
                                                 LocalizedContentEntity localized, Instant now) {
        String localeKey = localized == null ? CANONICAL_LOCALE_KEY : localized.getLocale();
        String displayName = localized == null ? product.getName() : localized.getLocalizedName();
        String description = localized == null ? product.getDescription() : localized.getLocalizedDescription();
        Long localizedRevision = localized == null ? null : localized.getContentRevision();
        String providerId = provider == null ? null : provider.getId();
        String providerCode = provider == null ? null : provider.getProviderCode();
        String providerName = provider == null ? null : provider.getDisplayName();
        String canonical = product.getTenantId()+"|"+product.getId()+"|"+localeKey+"|"+product.getProductCode()+"|"
                +displayName+"|"+Objects.toString(description,"")+"|"+Objects.toString(providerId,"")+"|"
                +Objects.toString(providerCode,"")+"|"+Objects.toString(providerName,"")+"|"
                +product.getLifecycleState()+"|"+product.getRowVersion()+"|"+product.getLocalizationRevision()+"|"
                +Objects.toString(localizedRevision,"");
        return new CatalogSearchDocumentEntity(UUID.randomUUID().toString(), product.getTenantId(), product.getId(),
                localeKey, product.getProductCode(), displayName, description, providerId, providerCode, providerName,
                product.getLifecycleState().name(), product.getRowVersion(), product.getLocalizationRevision(),
                localizedRevision, hashService.hash(canonical), now);
    }

    private record ProjectionCounts(int documents, int visibilities) {}
}

package com.gsitm.ustra.api.platform.change.api;

import com.gsitm.ustra.api.platform.change.application.ConsumerImpactService;
import com.gsitm.ustra.api.platform.change.persistence.ConsumerImpactAnalysisEntity;
import com.gsitm.ustra.api.platform.change.persistence.ConsumerImpactEntity;
import java.time.Instant;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/api-changes/{apiChangeId}")
public class ConsumerImpactController {
    private final ConsumerImpactService service;
    public ConsumerImpactController(ConsumerImpactService service){this.service=service;}

    @PostMapping("/consumer-impact-analyses")
    public ResponseEntity<AnalysisResponse> analyze(@PathVariable String apiChangeId){
        ConsumerImpactAnalysisEntity entity=service.analyze(apiChangeId);
        return ResponseEntity.status(HttpStatus.CREATED).body(AnalysisResponse.from(entity));
    }
    @GetMapping("/consumer-impacts")
    public List<ImpactResponse> impacts(@PathVariable String apiChangeId){return service.latestImpacts(apiChangeId).stream().map(ImpactResponse::from).toList();}
    @GetMapping("/consumer-impact-summary")
    public ConsumerImpactService.ImpactSummary summary(@PathVariable String apiChangeId){return service.summary(apiChangeId);}

    public record AnalysisResponse(String consumerImpactAnalysisId,String apiChangeId,String impactBasisHash,int materializedRowCount,Instant analyzedAt){
        static AnalysisResponse from(ConsumerImpactAnalysisEntity e){return new AnalysisResponse(e.getId(),e.getApiChangeId(),e.getImpactBasisHash(),e.getMaterializedRowCount(),e.getAnalyzedAt());}
    }
    public record ImpactResponse(String consumerImpactId,String apiProductVersionId,String subscriptionId,String entitlementId,String consumerAppEnvironmentId,String consumerAppId,String subscriptionStatus,String entitlementStatus,String consumerAppState,int impactedOperationCount,String impactRowHash){
        static ImpactResponse from(ConsumerImpactEntity e){return new ImpactResponse(e.getId(),e.getApiProductVersionId(),e.getSubscriptionId(),e.getEntitlementId(),e.getConsumerAppEnvironmentId(),e.getConsumerAppId(),e.getSubscriptionStatus(),e.getEntitlementStatus(),e.getConsumerAppState(),e.getImpactedOperationCount(),e.getImpactRowHash());}
    }
}

package com.gsitm.ustra.api.platform.tenant.persistence;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrganizationRepository extends JpaRepository<OrganizationEntity, String> {
    Optional<OrganizationEntity> findByIdAndTenantId(String id, String tenantId);
    List<OrganizationEntity> findAllByTenantIdOrderByCodeAsc(String tenantId);
    boolean existsByTenantIdAndCode(String tenantId, String code);
}

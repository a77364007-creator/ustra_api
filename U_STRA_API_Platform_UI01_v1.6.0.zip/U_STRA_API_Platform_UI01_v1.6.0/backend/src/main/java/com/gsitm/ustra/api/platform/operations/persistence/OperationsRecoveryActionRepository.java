package com.gsitm.ustra.api.platform.operations.persistence;
import java.util.Optional;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import jakarta.persistence.LockModeType;
public interface OperationsRecoveryActionRepository extends JpaRepository<OperationsRecoveryActionEntity,String>,
        JpaSpecificationExecutor<OperationsRecoveryActionEntity> {
    java.util.Optional<OperationsRecoveryActionEntity> findByIdAndTenantIdAndActionTypeIn(String id,String tenantId,
            java.util.Collection<com.gsitm.ustra.api.platform.operations.domain.RecoveryActionType> actionTypes);

    Optional<OperationsRecoveryActionEntity> findByIdAndTenantId(String id,String tenantId);
    Optional<OperationsRecoveryActionEntity> findByTenantIdAndIdempotencyKey(String tenantId,String key);
    boolean existsByTenantIdAndActiveTargetKey(String tenantId,String activeKey);
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select a from OperationsRecoveryActionEntity a where a.tenantId=:tenantId and a.id=:id")
    Optional<OperationsRecoveryActionEntity> lockOwned(@Param("tenantId") String tenantId,@Param("id") String id);
}

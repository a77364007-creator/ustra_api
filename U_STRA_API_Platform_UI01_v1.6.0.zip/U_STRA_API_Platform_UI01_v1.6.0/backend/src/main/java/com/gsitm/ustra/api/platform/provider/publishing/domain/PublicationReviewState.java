package com.gsitm.ustra.api.platform.provider.publishing.domain;

public enum PublicationReviewState {
    SUBMITTED,
    IN_REVIEW,
    CHANGES_REQUESTED,
    APPROVED,
    REJECTED,
    CANCELLED
}

package com.gsitm.ustra.api.platform.tenant.persistence;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TenantRepository extends JpaRepository<TenantEntity, String> {
    @org.springframework.data.jpa.repository.Lock(jakarta.persistence.LockModeType.PESSIMISTIC_WRITE)
    @org.springframework.data.jpa.repository.Query("select t from TenantEntity t where t.id = :tenantId")
    java.util.Optional<TenantEntity> lockById(@org.springframework.data.repository.query.Param("tenantId") String tenantId);

    List<TenantEntity> findAllByOrderByCodeAsc();
}

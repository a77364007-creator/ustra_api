package com.gsitm.ustra.api.platform.change.domain;
public enum CompatibilityResult { BREAKING, REVIEW_REQUIRED, NO_CONTRACT_CHANGE }

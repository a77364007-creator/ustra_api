package com.gsitm.ustra.api.platform.subscription.entitlement.persistence;
import com.gsitm.ustra.api.platform.subscription.entitlement.domain.CredentialReferenceStatus; import jakarta.persistence.*; import java.time.Instant;
@Entity @Table(name="credential_reference")
public class CredentialReferenceEntity {
 @Id @Column(name="credential_reference_id",length=36,nullable=false,updatable=false) private String id;
 @Column(name="tenant_id",length=36,nullable=false,updatable=false) private String tenantId;
 @Column(name="entitlement_id",length=36,nullable=false,updatable=false) private String entitlementId;
 @Column(name="access_fulfillment_id",length=36) private String accessFulfillmentId;
 @Column(name="provider_type",length=100,nullable=false) private String providerType;
 @Column(name="external_reference",length=500,nullable=false) private String externalReference;
 @Enumerated(EnumType.STRING) @Column(name="status",length=30,nullable=false) private CredentialReferenceStatus status;
 @Column(name="expires_at") private Instant expiresAt;
 @Column(name="last_synced_at",nullable=false) private Instant lastSyncedAt;
 @Column(name="created_at",nullable=false,updatable=false) private Instant createdAt;
 @Column(name="created_by",length=200,nullable=false,updatable=false) private String createdBy;
 @Column(name="updated_at",nullable=false) private Instant updatedAt;
 @Column(name="updated_by",length=200,nullable=false) private String updatedBy;
 protected CredentialReferenceEntity(){}
 public CredentialReferenceEntity(String id,String tenantId,String entitlementId,String fulfillmentId,String providerType,String externalReference,CredentialReferenceStatus status,Instant expiresAt,Instant now,String actor){this.id=id;this.tenantId=tenantId;this.entitlementId=entitlementId;this.accessFulfillmentId=fulfillmentId;this.providerType=providerType;this.externalReference=externalReference;this.status=status;this.expiresAt=expiresAt;this.lastSyncedAt=now;this.createdAt=now;this.createdBy=actor;this.updatedAt=now;this.updatedBy=actor;}
 public void synchronize(String fulfillmentId,String providerType,String externalReference,CredentialReferenceStatus status,Instant expiresAt,Instant now,String actor){this.accessFulfillmentId=fulfillmentId;this.providerType=providerType;this.externalReference=externalReference;this.status=status;this.expiresAt=expiresAt;this.lastSyncedAt=now;this.updatedAt=now;this.updatedBy=actor;}
 public String getId(){return id;} public String getTenantId(){return tenantId;} public String getEntitlementId(){return entitlementId;} public String getAccessFulfillmentId(){return accessFulfillmentId;} public String getProviderType(){return providerType;} public String getExternalReference(){return externalReference;} public CredentialReferenceStatus getStatus(){return status;} public Instant getExpiresAt(){return expiresAt;} public Instant getLastSyncedAt(){return lastSyncedAt;}
}

package com.gsitm.ustra.api.platform.tenant.persistence;

import com.gsitm.ustra.api.platform.tenant.domain.OrganizationStatus;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Version;
import java.time.Instant;

@Entity
@Table(name = "organization")
public class OrganizationEntity {
    @Id
    @Column(name = "organization_id", length = 36, nullable = false, updatable = false)
    private String id;

    @Column(name = "tenant_id", length = 36, nullable = false, updatable = false)
    private String tenantId;

    @Column(name = "organization_code", length = 80, nullable = false)
    private String code;

    @Column(name = "display_name", length = 200, nullable = false)
    private String displayName;

    @Column(name = "parent_organization_id", length = 36)
    private String parentOrganizationId;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", length = 30, nullable = false)
    private OrganizationStatus status;

    @Version
    @Column(name = "row_version", nullable = false)
    private long rowVersion;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;

    protected OrganizationEntity() {
    }

    public OrganizationEntity(String id, String tenantId, String code, String displayName,
                              String parentOrganizationId, Instant now) {
        this.id = id;
        this.tenantId = tenantId;
        this.code = code;
        this.displayName = displayName;
        this.parentOrganizationId = parentOrganizationId;
        this.status = OrganizationStatus.ACTIVE;
        this.createdAt = now;
        this.updatedAt = now;
    }

    public void update(String displayName, String parentOrganizationId, Instant now) {
        this.displayName = displayName;
        this.parentOrganizationId = parentOrganizationId;
        this.updatedAt = now;
    }

    public void deactivate(Instant now) {
        this.status = OrganizationStatus.INACTIVE;
        this.updatedAt = now;
    }

    public String getId() { return id; }
    public String getTenantId() { return tenantId; }
    public String getCode() { return code; }
    public String getDisplayName() { return displayName; }
    public String getParentOrganizationId() { return parentOrganizationId; }
    public OrganizationStatus getStatus() { return status; }
    public long getRowVersion() { return rowVersion; }
}

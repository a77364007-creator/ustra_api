package com.gsitm.ustra.api.platform.provider.publishing.api;

import com.gsitm.ustra.api.platform.provider.publishing.application.PublicationReviewService;
import com.gsitm.ustra.api.platform.provider.publishing.application.PublishReadinessService;
import com.gsitm.ustra.api.platform.provider.publishing.persistence.PublicationReviewEntity;
import com.gsitm.ustra.api.platform.tenant.api.VersionHeaderParser;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import java.time.Instant;
import java.util.List;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1")
public class PublicationReviewController {
    private final PublicationReviewService reviewService;
    private final PublishReadinessService readinessService;

    public PublicationReviewController(
            PublicationReviewService reviewService,
            PublishReadinessService readinessService) {
        this.reviewService = reviewService;
        this.readinessService = readinessService;
    }

    @GetMapping("/api-product-versions/{id}/publish-readiness")
    public ReadinessResponse readiness(@PathVariable String id) {
        return ReadinessResponse.from(readinessService.evaluate(id));
    }

    @PostMapping("/api-products/{apiProductId}/review-requests")
    public ResponseEntity<ReviewResponse> submit(
            @PathVariable String apiProductId,
            @RequestHeader(value = HttpHeaders.IF_MATCH, required = false) String ifMatch,
            @Valid @RequestBody SubmitReviewRequest request) {
        PublicationReviewEntity review = reviewService.submit(
                apiProductId, request.apiProductVersionId(), VersionHeaderParser.parse(ifMatch));
        return ResponseEntity.status(HttpStatus.CREATED)
                .eTag(VersionHeaderParser.etag(review.getRowVersion()))
                .body(ReviewResponse.from(review));
    }

    @GetMapping("/publication-reviews/{reviewId}")
    public ResponseEntity<ReviewResponse> get(@PathVariable String reviewId) {
        PublicationReviewEntity review = reviewService.get(reviewId);
        return ResponseEntity.ok()
                .eTag(VersionHeaderParser.etag(review.getRowVersion()))
                .body(ReviewResponse.from(review));
    }

    @PostMapping("/publication-reviews/{reviewId}/start")
    public ResponseEntity<ReviewResponse> start(
            @PathVariable String reviewId,
            @RequestHeader(value = HttpHeaders.IF_MATCH, required = false) String ifMatch) {
        return response(reviewService.start(reviewId, VersionHeaderParser.parse(ifMatch)));
    }

    @PostMapping("/publication-reviews/{reviewId}/approve")
    public ResponseEntity<ReviewResponse> approve(
            @PathVariable String reviewId,
            @RequestHeader(value = HttpHeaders.IF_MATCH, required = false) String ifMatch,
            @Valid @RequestBody(required = false) DecisionRequest request) {
        DecisionRequest safe = request == null ? new DecisionRequest(null, null) : request;
        return response(reviewService.approve(
                reviewId, VersionHeaderParser.parse(ifMatch), safe.reasonCode(), safe.summary()));
    }

    @PostMapping("/publication-reviews/{reviewId}/request-changes")
    public ResponseEntity<ReviewResponse> requestChanges(
            @PathVariable String reviewId,
            @RequestHeader(value = HttpHeaders.IF_MATCH, required = false) String ifMatch,
            @Valid @RequestBody(required = false) DecisionRequest request) {
        DecisionRequest safe = request == null ? new DecisionRequest(null, null) : request;
        return response(reviewService.requestChanges(
                reviewId, VersionHeaderParser.parse(ifMatch), safe.reasonCode(), safe.summary()));
    }

    @PostMapping("/publication-reviews/{reviewId}/reject")
    public ResponseEntity<ReviewResponse> reject(
            @PathVariable String reviewId,
            @RequestHeader(value = HttpHeaders.IF_MATCH, required = false) String ifMatch,
            @Valid @RequestBody(required = false) DecisionRequest request) {
        DecisionRequest safe = request == null ? new DecisionRequest(null, null) : request;
        return response(reviewService.reject(
                reviewId, VersionHeaderParser.parse(ifMatch), safe.reasonCode(), safe.summary()));
    }

    @PostMapping("/publication-reviews/{reviewId}/cancel")
    public ResponseEntity<ReviewResponse> cancel(
            @PathVariable String reviewId,
            @RequestHeader(value = HttpHeaders.IF_MATCH, required = false) String ifMatch,
            @Valid @RequestBody(required = false) DecisionRequest request) {
        DecisionRequest safe = request == null ? new DecisionRequest(null, null) : request;
        return response(reviewService.cancel(
                reviewId, VersionHeaderParser.parse(ifMatch), safe.reasonCode(), safe.summary()));
    }

    private ResponseEntity<ReviewResponse> response(PublicationReviewEntity review) {
        return ResponseEntity.ok()
                .eTag(VersionHeaderParser.etag(review.getRowVersion()))
                .body(ReviewResponse.from(review));
    }

    public record SubmitReviewRequest(@NotBlank String apiProductVersionId) {}

    public record DecisionRequest(
            @Size(max = 100) String reasonCode,
            @Size(max = 500) String summary) {}

    public record ReadinessResponse(
            boolean ready,
            List<PublishReadinessService.ReadinessItem> blockers,
            List<PublishReadinessService.ReadinessItem> warnings,
            String snapshotCandidateHash) {
        static ReadinessResponse from(PublishReadinessService.Readiness readiness) {
            return new ReadinessResponse(readiness.ready(), readiness.blockers(),
                    readiness.warnings(), readiness.snapshotCandidateHash());
        }
    }

    public record ReviewResponse(
            String publicationReviewId,
            String apiProductId,
            String apiProductVersionId,
            String state,
            String submittedSnapshotHash,
            String approvedSnapshotHash,
            Instant submittedAt,
            String submittedBy,
            Instant decidedAt,
            String decidedBy,
            String decisionReasonCode,
            String decisionSummary,
            long revision) {
        static ReviewResponse from(PublicationReviewEntity review) {
            return new ReviewResponse(
                    review.getId(), review.getApiProductId(), review.getApiProductVersionId(),
                    review.getState().name(), review.getSubmittedSnapshotHash(), review.getApprovedSnapshotHash(),
                    review.getSubmittedAt(), review.getSubmittedBy(), review.getDecidedAt(), review.getDecidedBy(),
                    review.getDecisionReasonCode(), review.getDecisionSummary(), review.getRowVersion());
        }
    }
}

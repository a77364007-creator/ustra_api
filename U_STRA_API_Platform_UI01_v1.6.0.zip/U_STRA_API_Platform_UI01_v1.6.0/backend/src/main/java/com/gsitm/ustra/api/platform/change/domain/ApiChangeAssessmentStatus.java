package com.gsitm.ustra.api.platform.change.domain;
public enum ApiChangeAssessmentStatus { PENDING, ASSESSING, ASSESSED, FAILED }

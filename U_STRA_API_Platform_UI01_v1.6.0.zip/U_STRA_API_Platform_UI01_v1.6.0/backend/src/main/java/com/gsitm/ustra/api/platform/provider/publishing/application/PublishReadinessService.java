package com.gsitm.ustra.api.platform.provider.publishing.application;

import com.gsitm.ustra.api.platform.catalog.persistence.ApiProductEntity;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiProductRepository;
import com.gsitm.ustra.api.platform.catalog.publication.domain.ApiProductVersionState;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.ApiProductVersionEntity;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.ApiProductVersionRepository;
import com.gsitm.ustra.api.platform.common.error.BusinessException;
import com.gsitm.ustra.api.platform.common.error.ErrorCode;
import com.gsitm.ustra.api.platform.provider.importing.domain.ApiImportStatus;
import com.gsitm.ustra.api.platform.provider.importing.persistence.ApiImportEntity;
import com.gsitm.ustra.api.platform.provider.importing.persistence.ApiImportRepository;
import com.gsitm.ustra.api.platform.provider.publishing.domain.PublicationReviewState;
import com.gsitm.ustra.api.platform.provider.publishing.persistence.PublicationReviewEntity;
import com.gsitm.ustra.api.platform.provider.publishing.persistence.PublicationReviewRepository;
import com.gsitm.ustra.api.platform.provider.publishing.snapshot.PublicationSnapshotBuilder;
import com.gsitm.ustra.api.platform.provider.publishing.snapshot.PublicationSnapshotBuilder.ApiVersionEvidence;
import com.gsitm.ustra.api.platform.provider.publishing.snapshot.PublicationSnapshotBuilder.Snapshot;
import com.gsitm.ustra.api.platform.tenant.application.TenantPermissionGuard;
import com.gsitm.ustra.api.platform.tenant.context.TenantContext;
import com.gsitm.ustra.api.platform.tenant.context.TenantContextResolver;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class PublishReadinessService {
    private static final List<String> REVIEW_SUBMISSION_BLOCKERS = List.of(
            "OWNER_MISSING", "PRODUCT_VERSION_COMPOSITION_INVALID", "OPENAPI_INVALID");

    private final TenantContextResolver contextResolver;
    private final TenantPermissionGuard permissionGuard;
    private final ApiProductRepository productRepository;
    private final ApiProductVersionRepository productVersionRepository;
    private final ApiImportRepository importRepository;
    private final PublicationReviewRepository reviewRepository;
    private final PublicationSnapshotBuilder snapshotBuilder;
    private final PublishAuthorityPort authorityPort;

    public PublishReadinessService(
            TenantContextResolver contextResolver,
            TenantPermissionGuard permissionGuard,
            ApiProductRepository productRepository,
            ApiProductVersionRepository productVersionRepository,
            ApiImportRepository importRepository,
            PublicationReviewRepository reviewRepository,
            PublicationSnapshotBuilder snapshotBuilder,
            PublishAuthorityPort authorityPort) {
        this.contextResolver = contextResolver;
        this.permissionGuard = permissionGuard;
        this.productRepository = productRepository;
        this.productVersionRepository = productVersionRepository;
        this.importRepository = importRepository;
        this.reviewRepository = reviewRepository;
        this.snapshotBuilder = snapshotBuilder;
        this.authorityPort = authorityPort;
    }

    @Transactional(readOnly = true)
    public Readiness evaluate(String apiProductVersionId) {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "API_PRODUCT:READ", "API_PRODUCT_VERSION", apiProductVersionId);
        return evaluateInternal(context.tenantId(), apiProductVersionId);
    }

    @Transactional(readOnly = true)
    public Readiness evaluateInternal(String tenantId, String apiProductVersionId) {
        ApiProductVersionEntity version = productVersionRepository.findByIdAndTenantId(apiProductVersionId, tenantId)
                .orElseThrow(() -> new BusinessException(ErrorCode.API_PRODUCT_VERSION_NOT_FOUND, HttpStatus.NOT_FOUND,
                        "API Product Version을 찾을 수 없습니다."));
        ApiProductEntity product = productRepository.findByIdAndTenantId(version.getApiProductId(), tenantId)
                .orElseThrow(() -> new BusinessException(ErrorCode.API_PRODUCT_NOT_FOUND, HttpStatus.NOT_FOUND,
                        "API Product를 찾을 수 없습니다."));

        Snapshot snapshot = snapshotBuilder.build(tenantId, apiProductVersionId);
        List<ReadinessItem> blockers = new ArrayList<>();
        List<ReadinessItem> warnings = new ArrayList<>();

        if (product.getOwnerMembershipId() == null || product.getOwnerMembershipId().isBlank()) {
            blockers.add(item("OWNER_MISSING", "API Product owner가 지정되지 않았습니다."));
        }
        if (snapshot.components().isEmpty()) {
            blockers.add(item("PRODUCT_VERSION_COMPOSITION_INVALID", "ProductVersion composition이 비어 있습니다."));
        }

        for (ApiVersionEvidence evidence : snapshot.apiVersions()) {
            if (!evidence.hasImportEvidence() || !successfulImport(tenantId, evidence.sourceImportId())) {
                blockers.add(item("OPENAPI_INVALID", "참조 API Version의 성공 OpenAPI Import 근거가 없습니다."));
                break;
            }
        }

        if (snapshot.apiVersions().stream().anyMatch(e -> !e.hasReconstructableSourceReference())) {
            blockers.add(item("SOURCE_PROVENANCE_NOT_RECONSTRUCTABLE",
                    "Release에 필요한 복구 가능한 immutable source reference가 아직 없습니다."));
        }

        PublishAuthorityPort.AuthorityStatus authority =
                authorityPort.resolve(tenantId, product.getId(), version.getId());
        if (!authority.classificationResolved()) {
            blockers.add(item("REQUIRED_CLASSIFICATION_MISSING",
                    "Classification authority가 아직 확정/연결되지 않았습니다."));
        }
        if (!authority.accessPolicyResolved()) {
            blockers.add(item("REQUIRED_ACCESS_POLICY_MISSING",
                    "AccessPolicy authority가 아직 확정/연결되지 않았습니다."));
        }
        if (!authority.requiredLocalePolicyResolved()) {
            blockers.add(item("REQUIRED_LOCALE_MISSING",
                    "필수 locale 정책 authority가 아직 확정/연결되지 않았습니다."));
        }
        if (!authority.termsVersionResolved()) {
            blockers.add(item("TERMS_AUTHORITY_UNRESOLVED",
                    "Review snapshot에 결합할 Terms version authority가 아직 없습니다."));
        }
        if (!authority.criticalFindingAuthorityResolved()) {
            blockers.add(item("CRITICAL_FINDING_UNRESOLVED",
                    "Critical finding SoT가 아직 확정/연결되지 않았습니다."));
        }

        if (version.getLifecycleState() == ApiProductVersionState.APPROVED) {
            if (version.getApprovedReviewId() == null) {
                blockers.add(item("REVIEW_SNAPSHOT_MISMATCH", "APPROVED ProductVersion의 승인 Review 근거가 없습니다."));
            } else {
                PublicationReviewEntity review = reviewRepository
                        .findByIdAndTenantId(version.getApprovedReviewId(), tenantId)
                        .orElse(null);
                if (review == null || review.getState() != PublicationReviewState.APPROVED
                        || !Objects.equals(review.getApprovedSnapshotHash(), snapshot.hash())) {
                    blockers.add(item("REVIEW_SNAPSHOT_MISMATCH",
                            "현재 상태가 승인된 PublicationReview snapshot과 일치하지 않습니다."));
                }
            }
        }

        return new Readiness(blockers.isEmpty(), List.copyOf(blockers), List.copyOf(warnings), snapshot.hash());
    }

    public void requireReviewSubmittable(Readiness readiness) {
        boolean blocked = readiness.blockers().stream()
                .anyMatch(item -> REVIEW_SUBMISSION_BLOCKERS.contains(item.code()));
        if (blocked) {
            throw new BusinessException(ErrorCode.PUBLISH_READINESS_BLOCKED, HttpStatus.CONFLICT,
                    "PublicationReview 제출 전 필수 구조 조건을 충족해야 합니다.");
        }
    }

    public void requireReady(Readiness readiness) {
        if (!readiness.ready()) {
            throw new BusinessException(ErrorCode.PUBLISH_READINESS_BLOCKED, HttpStatus.CONFLICT,
                    "Publish Readiness blocker가 남아 있습니다.");
        }
    }

    private boolean successfulImport(String tenantId, String importId) {
        if (importId == null || importId.isBlank()) {
            return false;
        }
        ApiImportEntity sourceImport = importRepository.findByIdAndTenantId(importId, tenantId).orElse(null);
        return sourceImport != null && sourceImport.getStatus() == ApiImportStatus.SUCCEEDED;
    }

    private ReadinessItem item(String code, String message) {
        return new ReadinessItem(code, message);
    }

    public record Readiness(boolean ready, List<ReadinessItem> blockers,
                            List<ReadinessItem> warnings, String snapshotCandidateHash) {}

    public record ReadinessItem(String code, String message) {}
}

package com.gsitm.ustra.api.platform.catalog.publication.api;

import com.gsitm.ustra.api.platform.catalog.publication.application.CatalogPublicationService;
import com.gsitm.ustra.api.platform.catalog.publication.domain.AudienceScopeType;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.AudienceScopeEntity;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.CatalogPublicationEntity;
import com.gsitm.ustra.api.platform.tenant.api.VersionHeaderParser;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import java.time.Instant;
import java.util.List;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/catalog-publications")
public class CatalogPublicationController {
    private final CatalogPublicationService service;

    public CatalogPublicationController(CatalogPublicationService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<CatalogPublicationResponse> create(@Valid @RequestBody CreatePublicationRequest request) {
        List<CatalogPublicationService.AudienceScopeInput> scopes = request.audienceScopes().stream()
                .map(s -> new CatalogPublicationService.AudienceScopeInput(s.type(), s.organizationId())).toList();
        CatalogPublicationEntity entity = service.create(request.apiProductVersionId(), scopes);
        return ResponseEntity.status(HttpStatus.CREATED).eTag(VersionHeaderParser.etag(entity.getRowVersion()))
                .body(response(entity));
    }

    @GetMapping("/{id}")
    public ResponseEntity<CatalogPublicationResponse> get(@PathVariable String id) {
        CatalogPublicationEntity entity = service.get(id);
        return ResponseEntity.ok().eTag(VersionHeaderParser.etag(entity.getRowVersion()))
                .body(response(entity));
    }

    @PostMapping("/{id}/activate")
    public ResponseEntity<CatalogPublicationResponse> activate(
            @PathVariable String id,
            @RequestHeader(value = HttpHeaders.IF_MATCH, required = false) String ifMatch) {
        CatalogPublicationEntity entity = service.activate(id, VersionHeaderParser.parse(ifMatch));
        return ResponseEntity.ok().eTag(VersionHeaderParser.etag(entity.getRowVersion()))
                .body(response(entity));
    }

    @PostMapping("/{id}/suspend")
    public ResponseEntity<CatalogPublicationResponse> suspend(
            @PathVariable String id,
            @RequestHeader(value = HttpHeaders.IF_MATCH, required = false) String ifMatch) {
        CatalogPublicationEntity entity = service.suspend(id, VersionHeaderParser.parse(ifMatch));
        return ResponseEntity.ok().eTag(VersionHeaderParser.etag(entity.getRowVersion()))
                .body(response(entity));
    }

    @PostMapping("/{id}/withdraw")
    public ResponseEntity<CatalogPublicationResponse> withdraw(
            @PathVariable String id,
            @RequestHeader(value = HttpHeaders.IF_MATCH, required = false) String ifMatch) {
        CatalogPublicationEntity entity = service.withdraw(id, VersionHeaderParser.parse(ifMatch));
        return ResponseEntity.ok().eTag(VersionHeaderParser.etag(entity.getRowVersion()))
                .body(response(entity));
    }

    @GetMapping("/{id}/audience-scopes")
    public List<AudienceScopeResponse> audienceScopes(@PathVariable String id) {
        return service.scopes(id).stream().map(AudienceScopeResponse::from).toList();
    }

    private CatalogPublicationResponse response(CatalogPublicationEntity entity) {
        return new CatalogPublicationResponse(entity.getId(), entity.getApiProductVersionId(),
                entity.getLifecycleState().name(), entity.getRowVersion(), entity.getCreatedAt(),
                entity.getCreatedBy(), entity.getUpdatedAt(), entity.getUpdatedBy());
    }

    public record CreatePublicationRequest(@NotBlank String apiProductVersionId,
                                           @NotEmpty List<@NotNull @Valid AudienceScopeRequest> audienceScopes) {}
    public record AudienceScopeRequest(@NotNull AudienceScopeType type, String organizationId) {}
    public record AudienceScopeResponse(String audienceScopeId, String type, String organizationId) {
        static AudienceScopeResponse from(AudienceScopeEntity entity) {
            return new AudienceScopeResponse(entity.getId(), entity.getScopeType().name(), entity.getOrganizationId());
        }
    }
    public record CatalogPublicationResponse(String catalogPublicationId, String apiProductVersionId,
                                             String lifecycleState, long revision,
                                             Instant createdAt, String createdBy, Instant updatedAt, String updatedBy) {}
}

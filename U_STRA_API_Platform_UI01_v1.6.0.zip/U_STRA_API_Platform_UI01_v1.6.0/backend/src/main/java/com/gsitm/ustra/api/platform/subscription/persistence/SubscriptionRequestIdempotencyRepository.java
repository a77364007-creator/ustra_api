package com.gsitm.ustra.api.platform.subscription.persistence;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SubscriptionRequestIdempotencyRepository extends JpaRepository<SubscriptionRequestIdempotencyEntity, String> {
    Optional<SubscriptionRequestIdempotencyEntity> findByTenantIdAndOperationCodeAndIdempotencyKey(
            String tenantId, String operationCode, String idempotencyKey);
}

package com.gsitm.ustra.api.platform.consumer.api;

import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.gsitm.ustra.api.platform.consumer.application.ConsumerAppEnvironmentService;
import com.gsitm.ustra.api.platform.consumer.domain.ConsumerAppEnvironmentType;
import com.gsitm.ustra.api.platform.consumer.persistence.ConsumerAppEnvironmentEntity;
import com.gsitm.ustra.api.platform.tenant.api.VersionHeaderParser;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.time.Instant;
import java.util.List;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/consumer-apps/{consumerAppId}/environments")
public class ConsumerAppEnvironmentController {
    private final ConsumerAppEnvironmentService service;

    public ConsumerAppEnvironmentController(ConsumerAppEnvironmentService service) { this.service = service; }

    @GetMapping
    public List<EnvironmentResponse> list(@PathVariable String consumerAppId) {
        return service.list(consumerAppId).stream().map(EnvironmentResponse::from).toList();
    }

    @PostMapping
    public ResponseEntity<EnvironmentResponse> create(@PathVariable String consumerAppId,
                                                       @Valid @RequestBody CreateEnvironmentRequest request) {
        ConsumerAppEnvironmentEntity entity = service.create(consumerAppId, request.environmentType,
                request.gatewayClientReference, request.iamApplicationReference, request.authenticationMethod);
        return ResponseEntity.status(HttpStatus.CREATED).eTag(VersionHeaderParser.etag(entity.getRowVersion()))
                .body(EnvironmentResponse.from(entity));
    }

    @PatchMapping("/{environmentId}")
    public ResponseEntity<EnvironmentResponse> update(@PathVariable String consumerAppId,
                                                       @PathVariable String environmentId,
            @RequestHeader(value = HttpHeaders.IF_MATCH, required = false) String ifMatch,
            @Valid @RequestBody UpdateEnvironmentRequest request) {
        ConsumerAppEnvironmentEntity entity = service.update(consumerAppId, environmentId,
                VersionHeaderParser.parse(ifMatch), request.gatewayClientReference,
                request.iamApplicationReference, request.authenticationMethod);
        return ResponseEntity.ok().eTag(VersionHeaderParser.etag(entity.getRowVersion()))
                .body(EnvironmentResponse.from(entity));
    }

    public static final class CreateEnvironmentRequest {
        @NotNull
        public ConsumerAppEnvironmentType environmentType;
        @Size(max = 300)
        public String gatewayClientReference;
        @Size(max = 300)
        public String iamApplicationReference;
        @Size(max = 100)
        public String authenticationMethod;

        @JsonAnySetter
        public void rejectUnknown(String name, Object ignored) {
            throw new IllegalArgumentException("지원하지 않는 Consumer App Environment 요청 필드입니다: " + name);
        }
    }

    public static final class UpdateEnvironmentRequest {
        @Size(max = 300)
        public String gatewayClientReference;
        @Size(max = 300)
        public String iamApplicationReference;
        @Size(max = 100)
        public String authenticationMethod;

        @JsonAnySetter
        public void rejectUnknown(String name, Object ignored) {
            throw new IllegalArgumentException("지원하지 않는 Consumer App Environment 요청 필드입니다: " + name);
        }
    }

    public record EnvironmentResponse(
            String consumerAppEnvironmentId, String consumerAppId, String environmentType,
            String gatewayClientReference, String iamApplicationReference, String authenticationMethod,
            long revision, Instant createdAt, String createdBy, Instant updatedAt, String updatedBy) {
        static EnvironmentResponse from(ConsumerAppEnvironmentEntity entity) {
            return new EnvironmentResponse(entity.getId(), entity.getConsumerAppId(),
                    entity.getEnvironmentType().name(), entity.getGatewayClientReference(),
                    entity.getIamApplicationReference(), entity.getAuthenticationMethod(), entity.getRowVersion(),
                    entity.getCreatedAt(), entity.getCreatedBy(), entity.getUpdatedAt(), entity.getUpdatedBy());
        }
    }
}

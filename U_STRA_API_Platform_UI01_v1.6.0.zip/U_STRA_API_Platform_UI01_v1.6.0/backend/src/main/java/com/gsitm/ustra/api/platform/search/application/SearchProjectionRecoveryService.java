package com.gsitm.ustra.api.platform.search.application;

import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.*;

/** Observation failure never changes canonical data or pretends the index is globally fresh. */
@Service
@Transactional(propagation=Propagation.NOT_SUPPORTED)
public class SearchProjectionRecoveryService {
    private static final Logger log=LoggerFactory.getLogger(SearchProjectionRecoveryService.class);
    private final CatalogSearchProjectionPort projection;
    private final SearchProjectionFailureService failures;
    public SearchProjectionRecoveryService(CatalogSearchProjectionPort projection,SearchProjectionFailureService failures) {
        this.projection=projection;this.failures=failures;
    }
    public CatalogSearchProjectionPort.ReindexResult reindex(String tenantId,String productId,String actor) {
        Long version=null;
        try {version=failures.openVersion(tenantId,productId);} catch(RuntimeException ex){observationUnavailable(tenantId,productId);}
        CatalogSearchProjectionPort.ReindexResult result;
        try {result=projection.reindexProduct(tenantId,productId,actor);}
        catch(RuntimeException ex) {
            try {failures.observe(tenantId,productId);} catch(RuntimeException ignored){observationUnavailable(tenantId,productId);}
            throw ex; // caller only logs a fixed code; never serialize exception content
        }
        try {failures.resolve(tenantId,productId,version);} catch(RuntimeException ex){observationUnavailable(tenantId,productId);}
        return result;
    }
    public CatalogSearchProjectionPort.RebuildResult rebuild(String tenantId,String actor) {
        Map<String,Long> versions=Map.of();
        try {versions=failures.openVersions(tenantId);} catch(RuntimeException ex){observationUnavailable(tenantId,null);}
        // Existing synchronous, canonical-source rebuild. There is no asynchronous worker promise.
        var result=projection.rebuildTenant(tenantId,actor);
        for(var entry:versions.entrySet()) {
            try {failures.resolve(tenantId,entry.getKey(),entry.getValue());}
            catch(RuntimeException ex){observationUnavailable(tenantId,entry.getKey());}
        }
        return result;
    }
    private void observationUnavailable(String tenantId,String productId) {
        log.warn("SEARCH_OBSERVATION_UNAVAILABLE tenantId={} productId={}",tenantId,productId);
    }
}

package com.gsitm.ustra.api.platform.change.api;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiVersionEntity;
import com.gsitm.ustra.api.platform.change.application.ApiVersionLifecycleService;
import com.gsitm.ustra.api.platform.tenant.api.VersionHeaderParser;
import org.springframework.http.*; import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/api/v1/api-versions")
public class ApiVersionLifecycleController {
 private final ApiVersionLifecycleService service; public ApiVersionLifecycleController(ApiVersionLifecycleService service){this.service=service;}
 @PostMapping("/{id}/deprecate") public ResponseEntity<ApiVersionLifecycleResponse> deprecate(@PathVariable String id,@RequestHeader(value=HttpHeaders.IF_MATCH,required=false) String ifMatch){ApiVersionEntity e=service.deprecate(id,VersionHeaderParser.parse(ifMatch));return ResponseEntity.ok().eTag(VersionHeaderParser.etag(e.getRowVersion())).body(ApiVersionLifecycleResponse.from(e));}
 public record ApiVersionLifecycleResponse(String apiVersionId,String apiId,String version,String state,long revision){static ApiVersionLifecycleResponse from(ApiVersionEntity e){return new ApiVersionLifecycleResponse(e.getId(),e.getApiId(),e.getVersionValue(),e.getState().name(),e.getRowVersion());}}
}

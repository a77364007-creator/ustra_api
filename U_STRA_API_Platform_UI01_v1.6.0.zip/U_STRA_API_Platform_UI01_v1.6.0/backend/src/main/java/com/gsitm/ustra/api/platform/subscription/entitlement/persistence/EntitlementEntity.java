package com.gsitm.ustra.api.platform.subscription.entitlement.persistence;

import com.gsitm.ustra.api.platform.subscription.entitlement.domain.EntitlementStatus;
import jakarta.persistence.*;
import java.time.Instant;

@Entity @Table(name="entitlement")
public class EntitlementEntity {
 @Id @Column(name="entitlement_id",length=36,nullable=false,updatable=false) private String id;
 @Column(name="tenant_id",length=36,nullable=false,updatable=false) private String tenantId;
 @Column(name="subscription_id",length=36,nullable=false,updatable=false) private String subscriptionId;
 @Column(name="consumer_app_environment_id",length=36,nullable=false,updatable=false) private String consumerAppEnvironmentId;
 @Column(name="api_product_version_id",length=36,nullable=false,updatable=false) private String apiProductVersionId;
 @Enumerated(EnumType.STRING) @Column(name="status",length=30,nullable=false) private EntitlementStatus status;
 @Column(name="effective_from",nullable=false,updatable=false) private Instant effectiveFrom;
 @Column(name="effective_to",nullable=false,updatable=false) private Instant effectiveTo;
 @Column(name="policy_revision",nullable=false,updatable=false) private int policyRevision;
 @Version @Column(name="row_version",nullable=false) private long rowVersion;
 @Column(name="created_at",nullable=false,updatable=false) private Instant createdAt;
 @Column(name="created_by",length=200,nullable=false,updatable=false) private String createdBy;
 @Column(name="updated_at",nullable=false) private Instant updatedAt;
 @Column(name="updated_by",length=200,nullable=false) private String updatedBy;
 protected EntitlementEntity() {}
 public EntitlementEntity(String id,String tenantId,String subscriptionId,String environmentId,String productVersionId,Instant effectiveFrom,Instant effectiveTo,Instant now,String actor){this.id=id;this.tenantId=tenantId;this.subscriptionId=subscriptionId;this.consumerAppEnvironmentId=environmentId;this.apiProductVersionId=productVersionId;this.status=EntitlementStatus.GRANTED;this.effectiveFrom=effectiveFrom;this.effectiveTo=effectiveTo;this.policyRevision=1;this.createdAt=now;this.createdBy=actor;this.updatedAt=now;this.updatedBy=actor;}
 public void revoke(Instant now,String actor){this.status=EntitlementStatus.REVOKED;this.updatedAt=now;this.updatedBy=actor;}
 public String getId(){return id;} public String getTenantId(){return tenantId;} public String getSubscriptionId(){return subscriptionId;} public String getConsumerAppEnvironmentId(){return consumerAppEnvironmentId;} public String getApiProductVersionId(){return apiProductVersionId;} public EntitlementStatus getStatus(){return status;} public Instant getEffectiveFrom(){return effectiveFrom;} public Instant getEffectiveTo(){return effectiveTo;} public int getPolicyRevision(){return policyRevision;} public long getRowVersion(){return rowVersion;} public Instant getCreatedAt(){return createdAt;} public String getCreatedBy(){return createdBy;} public Instant getUpdatedAt(){return updatedAt;} public String getUpdatedBy(){return updatedBy;}
}

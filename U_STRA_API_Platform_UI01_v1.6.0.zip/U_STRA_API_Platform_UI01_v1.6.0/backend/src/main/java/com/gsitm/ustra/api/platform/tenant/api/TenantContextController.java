package com.gsitm.ustra.api.platform.tenant.api;

import com.gsitm.ustra.api.platform.tenant.context.TenantContext;
import com.gsitm.ustra.api.platform.tenant.context.TenantContextResolver;
import java.util.Set;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/me")
public class TenantContextController {
    private final TenantContextResolver resolver;

    public TenantContextController(TenantContextResolver resolver) {
        this.resolver = resolver;
    }

    @GetMapping("/tenant-context")
    public TenantContextResponse current() {
        TenantContext context = resolver.resolve();
        return new TenantContextResponse(context.tenantId(), context.tenantCode(), context.organizationId(),
                context.principalId(), context.membershipId(), context.roles(), context.locale());
    }

    public record TenantContextResponse(String tenantId, String tenantCode, String organizationId,
                                        String principalId, String membershipId, Set<String> roles, String locale) {
    }
}

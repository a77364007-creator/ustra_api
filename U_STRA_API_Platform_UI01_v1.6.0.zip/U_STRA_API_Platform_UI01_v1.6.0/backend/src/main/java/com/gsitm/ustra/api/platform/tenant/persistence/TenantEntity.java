package com.gsitm.ustra.api.platform.tenant.persistence;

import com.gsitm.ustra.api.platform.tenant.domain.TenantStatus;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Version;
import java.time.Instant;

@Entity
@Table(name = "tenant")
public class TenantEntity {
    @Id
    @Column(name = "tenant_id", length = 36, nullable = false, updatable = false)
    private String id;

    @Column(name = "customer_id", length = 36, nullable = false, updatable = false)
    private String customerId;

    @Column(name = "tenant_code", length = 80, nullable = false)
    private String code;

    @Column(name = "display_name", length = 200, nullable = false)
    private String displayName;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", length = 30, nullable = false)
    private TenantStatus status;

    @Column(name = "default_locale", length = 35, nullable = false)
    private String defaultLocale;

    @Column(name = "timezone", length = 80, nullable = false)
    private String timezone;

    @Column(name = "isolation_profile", length = 40, nullable = false)
    private String isolationProfile;

    @Version
    @Column(name = "row_version", nullable = false)
    private long rowVersion;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;

    protected TenantEntity() {
    }

    public TenantEntity(String id, String customerId, String code, String displayName,
                        String defaultLocale, String timezone, Instant now) {
        this.id = id;
        this.customerId = customerId;
        this.code = code;
        this.displayName = displayName;
        this.status = TenantStatus.DRAFT;
        this.defaultLocale = defaultLocale;
        this.timezone = timezone;
        this.isolationProfile = "SHARED_SCHEMA";
        this.createdAt = now;
        this.updatedAt = now;
    }

    public void activate(Instant now) {
        this.status = TenantStatus.ACTIVE;
        this.updatedAt = now;
    }

    public void suspend(Instant now) {
        this.status = TenantStatus.SUSPENDED;
        this.updatedAt = now;
    }

    public void retire(Instant now) {
        this.status = TenantStatus.RETIRED;
        this.updatedAt = now;
    }

    public String getId() { return id; }
    public String getCustomerId() { return customerId; }
    public String getCode() { return code; }
    public String getDisplayName() { return displayName; }
    public TenantStatus getStatus() { return status; }
    public String getDefaultLocale() { return defaultLocale; }
    public String getTimezone() { return timezone; }
    public String getIsolationProfile() { return isolationProfile; }
    public long getRowVersion() { return rowVersion; }
}

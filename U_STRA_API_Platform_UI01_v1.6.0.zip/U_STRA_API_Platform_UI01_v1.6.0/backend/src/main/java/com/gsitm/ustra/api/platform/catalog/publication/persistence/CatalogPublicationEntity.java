package com.gsitm.ustra.api.platform.catalog.publication.persistence;

import com.gsitm.ustra.api.platform.catalog.publication.domain.CatalogPublicationState;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Version;
import java.time.Instant;

@Entity
@Table(name = "catalog_publication")
public class CatalogPublicationEntity {
    @Id
    @Column(name = "catalog_publication_id", length = 36, nullable = false, updatable = false)
    private String id;
    @Column(name = "tenant_id", length = 36, nullable = false, updatable = false)
    private String tenantId;
    @Column(name = "api_product_version_id", length = 36, nullable = false, updatable = false)
    private String apiProductVersionId;
    @Enumerated(EnumType.STRING)
    @Column(name = "lifecycle_state", length = 30, nullable = false)
    private CatalogPublicationState lifecycleState;
    @Version
    @Column(name = "row_version", nullable = false)
    private long rowVersion;
    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;
    @Column(name = "created_by", length = 200, nullable = false, updatable = false)
    private String createdBy;
    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;
    @Column(name = "updated_by", length = 200, nullable = false)
    private String updatedBy;

    protected CatalogPublicationEntity() {}

    public CatalogPublicationEntity(String id, String tenantId, String apiProductVersionId, Instant now, String actor) {
        this.id = id;
        this.tenantId = tenantId;
        this.apiProductVersionId = apiProductVersionId;
        this.lifecycleState = CatalogPublicationState.DRAFT;
        this.createdAt = now;
        this.createdBy = actor;
        this.updatedAt = now;
        this.updatedBy = actor;
    }

    public void activate(Instant now, String actor) { lifecycleState = CatalogPublicationState.ACTIVE; touch(now, actor); }
    public void suspend(Instant now, String actor) { lifecycleState = CatalogPublicationState.SUSPENDED; touch(now, actor); }
    public void withdraw(Instant now, String actor) { lifecycleState = CatalogPublicationState.WITHDRAWN; touch(now, actor); }
    private void touch(Instant now, String actor) { updatedAt = now; updatedBy = actor; }

    public String getId() { return id; }
    public String getTenantId() { return tenantId; }
    public String getApiProductVersionId() { return apiProductVersionId; }
    public CatalogPublicationState getLifecycleState() { return lifecycleState; }
    public long getRowVersion() { return rowVersion; }
    public Instant getCreatedAt() { return createdAt; }
    public String getCreatedBy() { return createdBy; }
    public Instant getUpdatedAt() { return updatedAt; }
    public String getUpdatedBy() { return updatedBy; }
}

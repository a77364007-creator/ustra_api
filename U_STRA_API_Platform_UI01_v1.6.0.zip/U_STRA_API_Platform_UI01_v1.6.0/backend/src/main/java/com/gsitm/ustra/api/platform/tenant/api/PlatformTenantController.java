package com.gsitm.ustra.api.platform.tenant.api;

import com.gsitm.ustra.api.platform.tenant.application.PlatformTenantService;
import com.gsitm.ustra.api.platform.tenant.persistence.TenantEntity;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/admin/tenants")
public class PlatformTenantController {
    private final PlatformTenantService service;

    public PlatformTenantController(PlatformTenantService service) {
        this.service = service;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public TenantResponse create(@Valid @RequestBody CreateTenantRequest request) {
        return TenantResponse.from(service.create(request.customerId(), request.tenantCode(), request.displayName(),
                request.defaultLocale(), request.timezone()));
    }

    @GetMapping
    public List<TenantResponse> list() {
        return service.list().stream().map(TenantResponse::from).toList();
    }

    @GetMapping("/{tenantId}")
    public TenantResponse get(@PathVariable String tenantId) {
        return TenantResponse.from(service.get(tenantId));
    }

    @PostMapping("/{tenantId}/activate")
    public TenantResponse activate(@PathVariable String tenantId) {
        return TenantResponse.from(service.activate(tenantId));
    }

    @PostMapping("/{tenantId}/suspend")
    public TenantResponse suspend(@PathVariable String tenantId) {
        return TenantResponse.from(service.suspend(tenantId));
    }

    @PostMapping("/{tenantId}/retire")
    public TenantResponse retire(@PathVariable String tenantId) {
        return TenantResponse.from(service.retire(tenantId));
    }

    public record CreateTenantRequest(
            @NotBlank String customerId,
            @NotBlank @Size(max = 80) String tenantCode,
            @NotBlank @Size(max = 200) String displayName,
            @NotBlank @Size(max = 35) String defaultLocale,
            @NotBlank @Size(max = 80) String timezone) {
    }

    public record TenantResponse(String tenantId, String customerId, String tenantCode, String displayName,
                                 String status, String defaultLocale, String timezone, long version) {
        static TenantResponse from(TenantEntity entity) {
            return new TenantResponse(entity.getId(), entity.getCustomerId(), entity.getCode(), entity.getDisplayName(),
                    entity.getStatus().name(), entity.getDefaultLocale(), entity.getTimezone(), entity.getRowVersion());
        }
    }
}

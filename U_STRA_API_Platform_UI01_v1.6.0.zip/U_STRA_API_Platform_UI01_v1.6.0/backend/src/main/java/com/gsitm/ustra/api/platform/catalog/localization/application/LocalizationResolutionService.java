package com.gsitm.ustra.api.platform.catalog.localization.application;

import com.gsitm.ustra.api.platform.catalog.localization.domain.LocalizationStatus;
import com.gsitm.ustra.api.platform.catalog.localization.persistence.LocalizedContentEntity;
import com.gsitm.ustra.api.platform.catalog.localization.persistence.LocalizedContentRepository;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiProductEntity;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiProductRepository;
import com.gsitm.ustra.api.platform.common.error.BusinessException;
import com.gsitm.ustra.api.platform.common.error.ErrorCode;
import com.gsitm.ustra.api.platform.tenant.persistence.TenantConfigurationRepository;
import java.util.Optional;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class LocalizationResolutionService {
    private final ApiProductRepository productRepository;
    private final LocalizedContentRepository localizedContentRepository;
    private final TenantConfigurationRepository tenantConfigurationRepository;

    public LocalizationResolutionService(ApiProductRepository productRepository,
                                         LocalizedContentRepository localizedContentRepository,
                                         TenantConfigurationRepository tenantConfigurationRepository) {
        this.productRepository = productRepository;
        this.localizedContentRepository = localizedContentRepository;
        this.tenantConfigurationRepository = tenantConfigurationRepository;
    }

    @Transactional(readOnly = true)
    public ResolvedContent resolve(String tenantId, String apiProductId, String requestedLocale) {
        ApiProductEntity product = productRepository.findByIdAndTenantId(apiProductId, tenantId)
                .orElseThrow(() -> new BusinessException(ErrorCode.API_PRODUCT_NOT_FOUND, HttpStatus.NOT_FOUND,
                        "API Product를 찾을 수 없습니다."));

        String explicit = trimToNull(requestedLocale);
        if (explicit != null) {
            Optional<LocalizedContentEntity> requested = published(tenantId, apiProductId, explicit);
            if (requested.isPresent()) {
                return localized(requested.get(), ResolutionSource.REQUESTED_LOCALE);
            }
        }

        String tenantDefault = tenantConfigurationRepository.findByTenantId(tenantId)
                .map(x -> trimToNull(x.getDefaultLocale()))
                .orElse(null);
        if (tenantDefault != null && !tenantDefault.equals(explicit)) {
            Optional<LocalizedContentEntity> fallback = published(tenantId, apiProductId, tenantDefault);
            if (fallback.isPresent()) {
                return localized(fallback.get(), ResolutionSource.TENANT_DEFAULT);
            }
        }

        return new ResolvedContent(null, product.getName(), product.getDescription(), ResolutionSource.CANONICAL,
                product.getLocalizationRevision());
    }

    public LocalizationStatus status(String tenantId, String apiProductId, String locale) {
        return localizedContentRepository.findByTenantIdAndApiProductIdAndLocale(tenantId, apiProductId, locale)
                .map(LocalizedContentEntity::getStatus)
                .orElse(LocalizationStatus.MISSING);
    }

    private Optional<LocalizedContentEntity> published(String tenantId, String apiProductId, String locale) {
        return localizedContentRepository.findByTenantIdAndApiProductIdAndLocaleAndStatus(
                tenantId, apiProductId, locale, LocalizationStatus.PUBLISHED);
    }

    private ResolvedContent localized(LocalizedContentEntity content, ResolutionSource source) {
        return new ResolvedContent(content.getLocale(), content.getLocalizedName(), content.getLocalizedDescription(),
                source, content.getSourceLocalizationRevision());
    }

    private String trimToNull(String value) {
        if (value == null) {
            return null;
        }
        String trimmed = value.trim();
        return trimmed.isEmpty() ? null : trimmed;
    }

    public enum ResolutionSource {
        REQUESTED_LOCALE,
        TENANT_DEFAULT,
        CANONICAL
    }

    public record ResolvedContent(String locale, String name, String description, ResolutionSource source,
                                  long sourceLocalizationRevision) {
    }
}

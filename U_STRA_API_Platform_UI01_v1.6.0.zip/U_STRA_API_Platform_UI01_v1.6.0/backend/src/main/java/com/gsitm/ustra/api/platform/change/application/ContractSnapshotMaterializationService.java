package com.gsitm.ustra.api.platform.change.application;

import com.gsitm.ustra.api.platform.change.persistence.ApiContractBodySnapshotEntity;
import com.gsitm.ustra.api.platform.change.persistence.ApiContractBodySnapshotRepository;
import com.gsitm.ustra.api.platform.change.persistence.ApiContractOperationSnapshotEntity;
import com.gsitm.ustra.api.platform.change.persistence.ApiContractOperationSnapshotRepository;
import com.gsitm.ustra.api.platform.change.persistence.ApiContractParameterSnapshotEntity;
import com.gsitm.ustra.api.platform.change.persistence.ApiContractParameterSnapshotRepository;
import com.gsitm.ustra.api.platform.change.persistence.ApiContractResponseSnapshotEntity;
import com.gsitm.ustra.api.platform.change.persistence.ApiContractResponseSnapshotRepository;
import com.gsitm.ustra.api.platform.change.persistence.ApiContractSecuritySnapshotEntity;
import com.gsitm.ustra.api.platform.change.persistence.ApiContractSecuritySnapshotRepository;
import com.gsitm.ustra.api.platform.change.persistence.ApiContractSnapshotEntity;
import com.gsitm.ustra.api.platform.change.persistence.ApiContractSnapshotRepository;
import com.gsitm.ustra.api.platform.provider.importing.application.OperationPathNormalizer;
import com.gsitm.ustra.api.platform.provider.importing.application.Sha256Service;
import com.gsitm.ustra.api.platform.provider.importing.parser.OpenApiParserPort.ParsedBody;
import com.gsitm.ustra.api.platform.provider.importing.parser.OpenApiParserPort.ParsedOpenApi;
import com.gsitm.ustra.api.platform.provider.importing.parser.OpenApiParserPort.ParsedOperation;
import com.gsitm.ustra.api.platform.provider.importing.parser.OpenApiParserPort.ParsedParameter;
import com.gsitm.ustra.api.platform.provider.importing.parser.OpenApiParserPort.ParsedResponse;
import com.gsitm.ustra.api.platform.security.AuthenticatedIdentityProvider;
import java.time.Clock;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ContractSnapshotMaterializationService {
    public static final String SNAPSHOT_SCHEMA_VERSION = "CP11-STRUCTURE-V1";

    private final ApiContractSnapshotRepository snapshotRepository;
    private final ApiContractOperationSnapshotRepository operationRepository;
    private final ApiContractParameterSnapshotRepository parameterRepository;
    private final ApiContractBodySnapshotRepository bodyRepository;
    private final ApiContractResponseSnapshotRepository responseRepository;
    private final ApiContractSecuritySnapshotRepository securityRepository;
    private final OperationPathNormalizer pathNormalizer;
    private final Sha256Service sha256Service;
    private final AuthenticatedIdentityProvider identityProvider;
    private final Clock clock;

    public ContractSnapshotMaterializationService(
            ApiContractSnapshotRepository snapshotRepository,
            ApiContractOperationSnapshotRepository operationRepository,
            ApiContractParameterSnapshotRepository parameterRepository,
            ApiContractBodySnapshotRepository bodyRepository,
            ApiContractResponseSnapshotRepository responseRepository,
            ApiContractSecuritySnapshotRepository securityRepository,
            OperationPathNormalizer pathNormalizer,
            Sha256Service sha256Service,
            AuthenticatedIdentityProvider identityProvider,
            Clock clock) {
        this.snapshotRepository = snapshotRepository;
        this.operationRepository = operationRepository;
        this.parameterRepository = parameterRepository;
        this.bodyRepository = bodyRepository;
        this.responseRepository = responseRepository;
        this.securityRepository = securityRepository;
        this.pathNormalizer = pathNormalizer;
        this.sha256Service = sha256Service;
        this.identityProvider = identityProvider;
        this.clock = clock;
    }

    @Transactional
    public ApiContractSnapshotEntity materialize(
            String tenantId,
            String apiVersionId,
            String sourceContentHash,
            ParsedOpenApi parsed) {
        ApiContractSnapshotEntity existing = snapshotRepository
                .findByTenantIdAndApiVersionId(tenantId, apiVersionId)
                .orElse(null);
        if (existing != null) return existing;

        List<OperationFacts> facts = parsed.operations().stream()
                .map(this::facts)
                .sorted(Comparator.comparing(OperationFacts::identity))
                .toList();
        String structuralHash = sha256Service.hashText(facts.stream()
                .map(f -> f.identity() + "|" + f.fingerprint())
                .reduce("", (a, b) -> a + "\n" + b));

        Instant now = Instant.now(clock);
        String actor = identityProvider.current().principalId();
        ApiContractSnapshotEntity snapshot = snapshotRepository.saveAndFlush(new ApiContractSnapshotEntity(
                UUID.randomUUID().toString(), tenantId, apiVersionId, sourceContentHash,
                SNAPSHOT_SCHEMA_VERSION, structuralHash, now, actor));

        for (OperationFacts fact : facts) {
            ApiContractOperationSnapshotEntity op = operationRepository.saveAndFlush(
                    new ApiContractOperationSnapshotEntity(
                            UUID.randomUUID().toString(), tenantId, snapshot.getId(), fact.method(),
                            fact.normalizedPath(), fact.fingerprint()));
            persistChildren(tenantId, op.getId(), fact.operation());
        }
        return snapshot;
    }

    private OperationFacts facts(ParsedOperation operation) {
        String method = operation.method().toUpperCase(Locale.ROOT);
        String normalizedPath = pathNormalizer.normalize(operation.path());
        List<String> pieces = new ArrayList<>();
        operation.parameters().stream()
                .sorted(Comparator.comparing(p -> p.location() + "\u0000" + p.name()))
                .forEach(p -> pieces.add("P|" + p.location() + "|" + p.name() + "|" + p.parameterFingerprint()));
        operation.requestBodies().stream()
                .sorted(Comparator.comparing(ParsedBody::mediaType))
                .forEach(b -> pieces.add("B|" + b.mediaType() + "|" + b.bodyFingerprint()));
        operation.responses().stream()
                .sorted(Comparator.comparing(r -> r.responseCode() + "\u0000" + r.mediaType()))
                .forEach(r -> pieces.add("R|" + r.responseCode() + "|" + r.mediaType() + "|" + r.responseFingerprint()));
        operation.securityFingerprints().stream().sorted()
                .forEach(s -> pieces.add("S|" + s));
        String fingerprint = sha256Service.hashText(method + "|" + normalizedPath + "\n" + String.join("\n", pieces));
        return new OperationFacts(method, normalizedPath, fingerprint, operation);
    }

    private void persistChildren(String tenantId, String operationSnapshotId, ParsedOperation parsed) {
        for (ParsedParameter parameter : parsed.parameters()) {
            parameterRepository.save(new ApiContractParameterSnapshotEntity(
                    UUID.randomUUID().toString(), tenantId, operationSnapshotId,
                    parameter.location(), parameter.name(), parameter.required(),
                    parameter.schemaFingerprint(), parameter.parameterFingerprint()));
        }
        for (ParsedBody body : parsed.requestBodies()) {
            bodyRepository.save(new ApiContractBodySnapshotEntity(
                    UUID.randomUUID().toString(), tenantId, operationSnapshotId,
                    body.required(), body.mediaType(), body.schemaFingerprint(), body.bodyFingerprint()));
        }
        for (ParsedResponse response : parsed.responses()) {
            responseRepository.save(new ApiContractResponseSnapshotEntity(
                    UUID.randomUUID().toString(), tenantId, operationSnapshotId,
                    response.responseCode(), response.mediaType(), response.schemaFingerprint(),
                    response.responseFingerprint()));
        }
        for (int i = 0; i < parsed.securityFingerprints().size(); i++) {
            securityRepository.save(new ApiContractSecuritySnapshotEntity(
                    UUID.randomUUID().toString(), tenantId, operationSnapshotId, i,
                    parsed.securityFingerprints().get(i)));
        }
    }

    private record OperationFacts(
            String method,
            String normalizedPath,
            String fingerprint,
            ParsedOperation operation) {
        String identity() { return method + " " + normalizedPath; }
    }
}

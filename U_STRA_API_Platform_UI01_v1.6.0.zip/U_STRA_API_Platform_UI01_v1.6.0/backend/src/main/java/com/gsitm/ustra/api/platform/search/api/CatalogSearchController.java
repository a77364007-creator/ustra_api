package com.gsitm.ustra.api.platform.search.api;

import com.gsitm.ustra.api.platform.search.application.CatalogSearchPort;
import java.util.List;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/catalog-search")
public class CatalogSearchController {
    private final CatalogSearchPort searchPort;
    public CatalogSearchController(CatalogSearchPort searchPort){this.searchPort=searchPort;}

    @GetMapping
    public SearchResponse search(@RequestParam(required=false) String q,
                                 @RequestParam(required=false) String locale,
                                 @RequestParam(required=false) String providerId,
                                 @RequestParam(defaultValue="0") int page,
                                 @RequestParam(defaultValue="20") int size) {
        var result=searchPort.search(new CatalogSearchPort.SearchRequest(q,locale,providerId,page,size));
        return SearchResponse.from(result);
    }

    public record SearchResponse(List<CatalogSearchPort.SearchResult> items,int page,int size,long totalElements,boolean hasNext){
        static SearchResponse from(CatalogSearchPort.SearchPage page){
            return new SearchResponse(page.items(),page.page(),page.size(),page.totalElements(),page.hasNext());
        }
    }
}

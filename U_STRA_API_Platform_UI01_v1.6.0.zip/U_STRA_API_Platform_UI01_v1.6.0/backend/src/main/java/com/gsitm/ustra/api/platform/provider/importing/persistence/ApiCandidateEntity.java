package com.gsitm.ustra.api.platform.provider.importing.persistence;

import com.gsitm.ustra.api.platform.provider.importing.domain.ApiCandidateState;
import com.gsitm.ustra.api.platform.provider.importing.domain.ApiImportSourceType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Version;
import java.time.Instant;

@Entity
@Table(name = "api_candidate")
public class ApiCandidateEntity {
    @Id
    @Column(name = "api_candidate_id", length = 36)
    private String id;

    @Column(name = "tenant_id", length = 36, nullable = false, updatable = false)
    private String tenantId;

    @Column(name = "provider_id", length = 36, nullable = false, updatable = false)
    private String providerId;

    @Enumerated(EnumType.STRING)
    @Column(name = "source_type", length = 40, nullable = false)
    private ApiImportSourceType sourceType;

    @Enumerated(EnumType.STRING)
    @Column(name = "state", length = 30, nullable = false)
    private ApiCandidateState state;

    @Column(name = "current_import_id", length = 36)
    private String currentImportId;

    @Column(name = "api_product_id", length = 36)
    private String apiProductId;

    @Column(name = "api_product_version_id", length = 36)
    private String apiProductVersionId;

    @Version
    @Column(name = "row_version", nullable = false)
    private long rowVersion;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @Column(name = "created_by", length = 200, nullable = false, updatable = false)
    private String createdBy;

    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;

    @Column(name = "updated_by", length = 200, nullable = false)
    private String updatedBy;

    protected ApiCandidateEntity() {}

    public ApiCandidateEntity(String id, String tenantId, String providerId, Instant now, String actor) {
        this.id = id;
        this.tenantId = tenantId;
        this.providerId = providerId;
        this.sourceType = ApiImportSourceType.OPENAPI_UPLOAD;
        this.state = ApiCandidateState.DETECTED;
        this.createdAt = now;
        this.createdBy = actor;
        this.updatedAt = now;
        this.updatedBy = actor;
    }

    public void move(ApiCandidateState next, String importId, Instant now, String actor) {
        this.state = next;
        this.currentImportId = importId;
        this.updatedAt = now;
        this.updatedBy = actor;
    }

    public void startProductization(String productId, Instant now, String actor) {
        this.state = ApiCandidateState.PRODUCTIZING;
        this.apiProductId = productId;
        this.apiProductVersionId = null;
        this.updatedAt = now;
        this.updatedBy = actor;
    }

    public void completeProductization(String productVersionId, Instant now, String actor) {
        this.state = ApiCandidateState.COMPLETED;
        this.apiProductVersionId = productVersionId;
        this.updatedAt = now;
        this.updatedBy = actor;
    }

    public String getId() { return id; }
    public String getTenantId() { return tenantId; }
    public String getProviderId() { return providerId; }
    public ApiImportSourceType getSourceType() { return sourceType; }
    public ApiCandidateState getState() { return state; }
    public String getCurrentImportId() { return currentImportId; }
    public String getApiProductId() { return apiProductId; }
    public String getApiProductVersionId() { return apiProductVersionId; }
    public long getRowVersion() { return rowVersion; }
}

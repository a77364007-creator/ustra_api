package com.gsitm.ustra.api.platform.tenant.application;

import com.gsitm.ustra.api.platform.audit.AuditService;
import com.gsitm.ustra.api.platform.common.error.BusinessException;
import com.gsitm.ustra.api.platform.common.error.ErrorCode;
import com.gsitm.ustra.api.platform.outbox.OutboxService;
import com.gsitm.ustra.api.platform.tenant.context.TenantContext;
import com.gsitm.ustra.api.platform.tenant.context.TenantContextResolver;
import com.gsitm.ustra.api.platform.tenant.persistence.OrganizationEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.OrganizationRepository;
import java.time.Clock;
import java.time.Instant;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class OrganizationService {
    private final TenantContextResolver contextResolver;
    private final TenantPermissionGuard permissionGuard;
    private final OrganizationRepository repository;
    private final AuditService auditService;
    private final OutboxService outboxService;
    private final Clock clock;

    public OrganizationService(TenantContextResolver contextResolver, TenantPermissionGuard permissionGuard,
                               OrganizationRepository repository, AuditService auditService,
                               OutboxService outboxService, Clock clock) {
        this.contextResolver = contextResolver;
        this.permissionGuard = permissionGuard;
        this.repository = repository;
        this.auditService = auditService;
        this.outboxService = outboxService;
        this.clock = clock;
    }

    @Transactional(readOnly = true)
    public List<OrganizationEntity> list() {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "ORGANIZATION:MANAGE", "ORGANIZATION", "list");
        return repository.findAllByTenantIdOrderByCodeAsc(context.tenantId());
    }

    @Transactional
    public OrganizationEntity create(String code, String displayName, String parentOrganizationId) {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "ORGANIZATION:MANAGE", "ORGANIZATION", "new");
        if (repository.existsByTenantIdAndCode(context.tenantId(), code)) {
            throw Cp01Validation.validation("현재 Tenant에서 이미 사용 중인 organizationCode입니다.");
        }
        validateParent(context.tenantId(), null, parentOrganizationId);
        OrganizationEntity entity = new OrganizationEntity(UUID.randomUUID().toString(), context.tenantId(),
                code, displayName, parentOrganizationId, Instant.now(clock));
        repository.save(entity);
        auditService.success(context.tenantId(), "ORGANIZATION_CREATE", "ORGANIZATION", entity.getId(), true,
                Map.of("organizationCode", code));
        outboxService.enqueue("OrganizationCreated", "ORGANIZATION", entity.getId(), context.tenantId(),
                Map.of("organizationId", entity.getId()));
        return entity;
    }

    @Transactional
    public OrganizationEntity update(String id, long expectedVersion, String displayName, String parentOrganizationId) {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "ORGANIZATION:MANAGE", "ORGANIZATION", id);
        OrganizationEntity entity = owned(context, id);
        if (entity.getRowVersion() != expectedVersion) {
            throw new BusinessException(ErrorCode.CONCURRENT_MODIFICATION, HttpStatus.CONFLICT,
                    "Organization이 다른 요청에 의해 변경되었습니다.");
        }
        validateParent(context.tenantId(), id, parentOrganizationId);
        entity.update(displayName, parentOrganizationId, Instant.now(clock));
        auditService.success(context.tenantId(), "ORGANIZATION_UPDATE", "ORGANIZATION", id, true,
                Map.of("displayName", displayName));
        return entity;
    }

    @Transactional
    public OrganizationEntity deactivate(String id) {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "ORGANIZATION:MANAGE", "ORGANIZATION", id);
        OrganizationEntity entity = owned(context, id);
        entity.deactivate(Instant.now(clock));
        auditService.success(context.tenantId(), "ORGANIZATION_DEACTIVATE", "ORGANIZATION", id, true, Map.of());
        outboxService.enqueue("OrganizationDeactivated", "ORGANIZATION", id, context.tenantId(),
                Map.of("organizationId", id));
        return entity;
    }

    private OrganizationEntity owned(TenantContext context, String id) {
        return repository.findByIdAndTenantId(id, context.tenantId())
                .orElseThrow(() -> new BusinessException(ErrorCode.ORGANIZATION_NOT_FOUND, HttpStatus.NOT_FOUND,
                        "Organization을 찾을 수 없습니다."));
    }

    private void validateParent(String tenantId, String currentOrganizationId, String parentId) {
        if (parentId == null) {
            return;
        }
        OrganizationEntity parent = repository.findByIdAndTenantId(parentId, tenantId)
                .orElseThrow(() -> new BusinessException(ErrorCode.ORGANIZATION_TENANT_MISMATCH, HttpStatus.BAD_REQUEST,
                        "상위 Organization은 현재 Tenant에 속해야 합니다."));
        if (currentOrganizationId == null) {
            return;
        }
        Set<String> visited = new HashSet<>();
        String cursor = parentId;
        while (cursor != null && visited.add(cursor)) {
            if (cursor.equals(currentOrganizationId)) {
                throw Cp01Validation.validation("Organization 계층에 순환 관계를 만들 수 없습니다.");
            }
            cursor = repository.findByIdAndTenantId(cursor, tenantId)
                    .map(OrganizationEntity::getParentOrganizationId)
                    .orElse(null);
        }
    }
}

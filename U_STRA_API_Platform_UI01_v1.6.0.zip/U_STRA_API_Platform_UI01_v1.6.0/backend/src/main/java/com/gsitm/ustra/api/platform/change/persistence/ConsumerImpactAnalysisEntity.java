package com.gsitm.ustra.api.platform.change.persistence;
import jakarta.persistence.*; import java.time.Instant;
@Entity @Table(name="consumer_impact_analysis")
public class ConsumerImpactAnalysisEntity {
 @Id @Column(name="consumer_impact_analysis_id",length=36,nullable=false,updatable=false) private String id;
 @Column(name="tenant_id",length=36,nullable=false,updatable=false) private String tenantId;
 @Column(name="api_change_id",length=36,nullable=false,updatable=false) private String apiChangeId;
 @Column(name="impact_basis_hash",length=64,nullable=false,updatable=false) private String impactBasisHash;
 @Column(name="materialized_row_count",nullable=false,updatable=false) private int materializedRowCount;
 @Column(name="analyzed_at",nullable=false,updatable=false) private Instant analyzedAt;
 @Column(name="analyzed_by",length=200,nullable=false,updatable=false) private String analyzedBy;
 @Column(name="created_at",nullable=false,updatable=false) private Instant createdAt;
 @Column(name="created_by",length=200,nullable=false,updatable=false) private String createdBy;
 protected ConsumerImpactAnalysisEntity(){}
 public ConsumerImpactAnalysisEntity(String id,String tenantId,String apiChangeId,String impactBasisHash,int materializedRowCount,Instant now,String actor){this.id=id;this.tenantId=tenantId;this.apiChangeId=apiChangeId;this.impactBasisHash=impactBasisHash;this.materializedRowCount=materializedRowCount;this.analyzedAt=now;this.analyzedBy=actor;this.createdAt=now;this.createdBy=actor;}
 public String getId(){return id;} public String getTenantId(){return tenantId;} public String getApiChangeId(){return apiChangeId;} public String getImpactBasisHash(){return impactBasisHash;} public int getMaterializedRowCount(){return materializedRowCount;} public Instant getAnalyzedAt(){return analyzedAt;} public String getAnalyzedBy(){return analyzedBy;}
}

package com.gsitm.ustra.api.platform.tenant.domain;

public enum RoleScopeType {
    PLATFORM,
    TENANT
}

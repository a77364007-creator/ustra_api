package com.gsitm.ustra.api.platform.change.persistence;
import java.util.*; import org.springframework.data.jpa.repository.JpaRepository;
public interface ConsumerImpactRepository extends JpaRepository<ConsumerImpactEntity,String>{
 List<ConsumerImpactEntity> findAllByTenantIdAndAnalysisIdOrderBySubscriptionIdAscEntitlementIdAsc(String tenantId,String analysisId);
}

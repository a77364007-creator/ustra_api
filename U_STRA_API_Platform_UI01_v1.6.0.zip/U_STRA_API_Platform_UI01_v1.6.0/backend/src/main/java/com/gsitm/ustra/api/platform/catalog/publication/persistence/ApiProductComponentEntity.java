package com.gsitm.ustra.api.platform.catalog.publication.persistence;

import com.gsitm.ustra.api.platform.catalog.publication.domain.ApiProductComponentTargetType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.Instant;

@Entity
@Table(name = "api_product_component")
public class ApiProductComponentEntity {
    @Id
    @Column(name = "api_product_component_id", length = 36, nullable = false, updatable = false)
    private String id;
    @Column(name = "tenant_id", length = 36, nullable = false, updatable = false)
    private String tenantId;
    @Column(name = "api_product_version_id", length = 36, nullable = false, updatable = false)
    private String apiProductVersionId;
    @Enumerated(EnumType.STRING)
    @Column(name = "target_type", length = 30, nullable = false, updatable = false)
    private ApiProductComponentTargetType targetType;
    @Column(name = "api_version_id", length = 36, updatable = false)
    private String apiVersionId;
    @Column(name = "api_operation_id", length = 36, updatable = false)
    private String apiOperationId;
    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;
    @Column(name = "created_by", length = 200, nullable = false, updatable = false)
    private String createdBy;

    protected ApiProductComponentEntity() {}

    public ApiProductComponentEntity(String id, String tenantId, String apiProductVersionId,
                                     ApiProductComponentTargetType targetType, String apiVersionId,
                                     String apiOperationId, Instant now, String actor) {
        this.id = id;
        this.tenantId = tenantId;
        this.apiProductVersionId = apiProductVersionId;
        this.targetType = targetType;
        this.apiVersionId = apiVersionId;
        this.apiOperationId = apiOperationId;
        this.createdAt = now;
        this.createdBy = actor;
    }

    public String getId() { return id; }
    public String getTenantId() { return tenantId; }
    public String getApiProductVersionId() { return apiProductVersionId; }
    public ApiProductComponentTargetType getTargetType() { return targetType; }
    public String getApiVersionId() { return apiVersionId; }
    public String getApiOperationId() { return apiOperationId; }
    public Instant getCreatedAt() { return createdAt; }
    public String getCreatedBy() { return createdBy; }
}

package com.gsitm.ustra.api.platform.provider.publishing.application;

import com.gsitm.ustra.api.platform.catalog.domain.ApiProductLifecycleState;
import com.gsitm.ustra.api.platform.catalog.domain.ApiVersionState;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiProductEntity;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiProductRepository;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiVersionEntity;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiVersionRepository;
import com.gsitm.ustra.api.platform.catalog.publication.application.StateTransitionHistoryService;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.ApiProductVersionEntity;
import com.gsitm.ustra.api.platform.common.error.BusinessException;
import com.gsitm.ustra.api.platform.common.error.ErrorCode;
import com.gsitm.ustra.api.platform.provider.publishing.domain.PublicationReviewState;
import com.gsitm.ustra.api.platform.provider.publishing.persistence.PublicationReviewEntity;
import com.gsitm.ustra.api.platform.provider.publishing.persistence.PublicationReviewRepository;
import com.gsitm.ustra.api.platform.provider.publishing.snapshot.PublicationSnapshotBuilder;
import com.gsitm.ustra.api.platform.provider.publishing.snapshot.PublicationSnapshotBuilder.Snapshot;
import com.gsitm.ustra.api.platform.tenant.context.TenantContext;
import java.time.Clock;
import java.time.Instant;
import java.util.Objects;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

@Service
public class PublicationReleaseGate {
    private final PublicationReviewRepository reviewRepository;
    private final PublicationSnapshotBuilder snapshotBuilder;
    private final PublishReadinessService readinessService;
    private final ApiVersionRepository apiVersionRepository;
    private final ApiProductRepository productRepository;
    private final StateTransitionHistoryService historyService;
    private final Clock clock;

    public PublicationReleaseGate(
            PublicationReviewRepository reviewRepository,
            PublicationSnapshotBuilder snapshotBuilder,
            PublishReadinessService readinessService,
            ApiVersionRepository apiVersionRepository,
            ApiProductRepository productRepository,
            StateTransitionHistoryService historyService,
            Clock clock) {
        this.reviewRepository = reviewRepository;
        this.snapshotBuilder = snapshotBuilder;
        this.readinessService = readinessService;
        this.apiVersionRepository = apiVersionRepository;
        this.productRepository = productRepository;
        this.historyService = historyService;
        this.clock = clock;
    }

    public void requireReleaseAllowed(TenantContext context, ApiProductVersionEntity version) {
        if (version.getApprovedReviewId() == null) {
            throw new BusinessException(ErrorCode.PUBLICATION_REVIEW_NOT_APPROVED, HttpStatus.CONFLICT,
                    "승인된 PublicationReview 근거가 없습니다.");
        }
        PublicationReviewEntity review = reviewRepository
                .findByIdAndTenantId(version.getApprovedReviewId(), context.tenantId())
                .orElseThrow(() -> new BusinessException(
                        ErrorCode.PUBLICATION_REVIEW_NOT_APPROVED, HttpStatus.CONFLICT,
                        "승인된 PublicationReview 근거를 찾을 수 없습니다."));
        if (review.getState() != PublicationReviewState.APPROVED) {
            throw new BusinessException(ErrorCode.PUBLICATION_REVIEW_NOT_APPROVED, HttpStatus.CONFLICT,
                    "APPROVED PublicationReview만 Release 근거가 될 수 있습니다.");
        }

        Snapshot current = snapshotBuilder.build(context.tenantId(), version.getId());
        if (!Objects.equals(review.getApprovedSnapshotHash(), current.hash())) {
            throw new BusinessException(ErrorCode.PUBLICATION_REVIEW_SNAPSHOT_MISMATCH, HttpStatus.CONFLICT,
                    "승인 이후 ProductVersion snapshot이 변경되어 Release할 수 없습니다.");
        }

        readinessService.requireReady(readinessService.evaluateInternal(context.tenantId(), version.getId()));
    }

    public void afterProductVersionReleased(TenantContext context, ApiProductVersionEntity version) {
        Instant now = Instant.now(clock);
        Snapshot current = snapshotBuilder.build(context.tenantId(), version.getId());

        for (String apiVersionId : current.referencedApiVersionIds()) {
            ApiVersionEntity apiVersion = apiVersionRepository.findByIdAndTenantId(apiVersionId, context.tenantId())
                    .orElseThrow(() -> new BusinessException(ErrorCode.API_VERSION_NOT_FOUND, HttpStatus.CONFLICT,
                            "Release 대상 API Version을 찾을 수 없습니다."));
            ApiVersionState from = apiVersion.getState();
            if (from == ApiVersionState.VALIDATED) {
                apiVersion.releaseForPublication(now, context.principalId());
                apiVersionRepository.saveAndFlush(apiVersion);
                historyService.record(context.tenantId(), "API_VERSION", apiVersion.getId(),
                        from.name(), apiVersion.getState().name());
            } else if (from != ApiVersionState.RELEASED) {
                throw new BusinessException(ErrorCode.API_VERSION_STATE_INVALID, HttpStatus.CONFLICT,
                        "VALIDATED API Version만 ProductVersion Release와 함께 RELEASED가 될 수 있습니다.");
            }
        }

        ApiProductEntity product = productRepository.findByIdAndTenantId(version.getApiProductId(), context.tenantId())
                .orElseThrow(() -> new BusinessException(ErrorCode.API_PRODUCT_NOT_FOUND, HttpStatus.NOT_FOUND,
                        "API Product를 찾을 수 없습니다."));
        ApiProductLifecycleState from = product.getLifecycleState();
        if (product.activate(now, context.principalId())) {
            productRepository.saveAndFlush(product);
            historyService.record(context.tenantId(), "API_PRODUCT", product.getId(),
                    from.name(), product.getLifecycleState().name());
        }
    }
}

package com.gsitm.ustra.api.platform.common.error;

public record ApiErrorResponse(String code, String message, String correlationId) {
}

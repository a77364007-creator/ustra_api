package com.gsitm.ustra.api.platform.catalog.publication.persistence;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CatalogPublicationRepository extends JpaRepository<CatalogPublicationEntity, String> {
    Optional<CatalogPublicationEntity> findByIdAndTenantId(String id, String tenantId);
    List<CatalogPublicationEntity> findAllByTenantIdAndApiProductVersionIdOrderByCreatedAtAsc(
            String tenantId, String apiProductVersionId);
}

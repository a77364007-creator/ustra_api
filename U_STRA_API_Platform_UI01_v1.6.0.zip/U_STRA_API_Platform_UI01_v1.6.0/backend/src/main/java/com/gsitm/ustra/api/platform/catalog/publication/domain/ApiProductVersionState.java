package com.gsitm.ustra.api.platform.catalog.publication.domain;

public enum ApiProductVersionState {
    DRAFT,
    VALIDATING,
    APPROVED,
    RELEASED,
    DEPRECATED,
    RETIRED
}

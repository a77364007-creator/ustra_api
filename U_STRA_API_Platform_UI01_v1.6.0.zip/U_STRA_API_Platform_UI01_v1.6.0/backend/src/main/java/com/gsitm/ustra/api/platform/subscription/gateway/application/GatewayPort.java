package com.gsitm.ustra.api.platform.subscription.gateway.application;
import java.math.BigDecimal; import java.time.Instant; import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
public interface GatewayPort {Result provision(Command c);Result deprovision(Command c);Result queryStatus(StatusQuery q);
 record Command(String tenantId,String fulfillmentId,String entitlementId,String consumerAppEnvironmentId,String apiProductVersionId,List<String> apiOperationIds,List<Quota> quotas,String idempotencyKey,String requestFingerprint){
  public Command {
   // Preserve the captured scope/quota even if the adapter reuses a mutable input list.
   // Nulls, invalid elements and ordering stay intact for existing domain validation.
   apiOperationIds=apiOperationIds==null?null:Collections.unmodifiableList(new ArrayList<>(apiOperationIds));
   quotas=quotas==null?null:Collections.unmodifiableList(new ArrayList<>(quotas));
  }
 }
 record Quota(String metricCode,BigDecimal limitValue,long windowSeconds,String unitCode){}
 record StatusQuery(String tenantId,String idempotencyKey,String requestFingerprint,String externalOperationRef){}
 record Result(ResultStatus status,String externalOperationRef,String runtimePolicyReference,String credentialReference,Instant credentialExpiresAt,String safeErrorCode){}
 enum ResultStatus { SUCCEEDED, FAILED, UNKNOWN }
}

package com.gsitm.ustra.api.platform.integration.approval.application;
import com.gsitm.ustra.api.platform.subscription.approval.application.ApprovalPort;
public interface ApprovalConnectorRegistration { String adapterCode(); ApprovalPort port(); }

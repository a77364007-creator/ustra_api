package com.gsitm.ustra.api.platform.catalog.localization.persistence;

import com.gsitm.ustra.api.platform.catalog.localization.domain.LocalizationStatus;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Version;
import java.time.Instant;

@Entity
@Table(name = "api_product_localized_content")
public class LocalizedContentEntity {
    @Id
    @Column(name = "localized_content_id", length = 36, nullable = false, updatable = false)
    private String id;

    @Column(name = "tenant_id", length = 36, nullable = false, updatable = false)
    private String tenantId;

    @Column(name = "api_product_id", length = 36, nullable = false, updatable = false)
    private String apiProductId;

    @Column(name = "locale", length = 35, nullable = false, updatable = false)
    private String locale;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", length = 20, nullable = false)
    private LocalizationStatus status;

    @Column(name = "content_revision", nullable = false)
    private long contentRevision;

    @Column(name = "source_localization_revision", nullable = false)
    private long sourceLocalizationRevision;

    @Column(name = "localized_name", length = 200, nullable = false)
    private String localizedName;

    @Column(name = "localized_description", columnDefinition = "TEXT")
    private String localizedDescription;

    @Column(name = "published_at")
    private Instant publishedAt;

    @Column(name = "published_by", length = 200)
    private String publishedBy;

    @Version
    @Column(name = "row_version", nullable = false)
    private long rowVersion;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @Column(name = "created_by", length = 200, nullable = false, updatable = false)
    private String createdBy;

    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;

    @Column(name = "updated_by", length = 200, nullable = false)
    private String updatedBy;

    protected LocalizedContentEntity() {
    }

    public LocalizedContentEntity(String id, String tenantId, String apiProductId, String locale,
                                  long sourceLocalizationRevision, String localizedName,
                                  String localizedDescription, Instant now, String actor) {
        this.id = id;
        this.tenantId = tenantId;
        this.apiProductId = apiProductId;
        this.locale = locale;
        this.status = LocalizationStatus.DRAFT;
        this.contentRevision = 1;
        this.sourceLocalizationRevision = sourceLocalizationRevision;
        this.localizedName = localizedName;
        this.localizedDescription = localizedDescription;
        this.createdAt = now;
        this.createdBy = actor;
        this.updatedAt = now;
        this.updatedBy = actor;
    }

    public void saveDraft(long sourceRevision, String name, String description, Instant now, String actor) {
        this.localizedName = name;
        this.localizedDescription = description;
        this.sourceLocalizationRevision = sourceRevision;
        this.status = LocalizationStatus.DRAFT;
        this.contentRevision++;
        this.updatedAt = now;
        this.updatedBy = actor;
    }

    public boolean markStale(Instant now, String actor) {
        if (this.status != LocalizationStatus.PUBLISHED) {
            return false;
        }
        this.status = LocalizationStatus.STALE;
        this.updatedAt = now;
        this.updatedBy = actor;
        return true;
    }

    public String getId() { return id; }
    public String getTenantId() { return tenantId; }
    public String getApiProductId() { return apiProductId; }
    public String getLocale() { return locale; }
    public LocalizationStatus getStatus() { return status; }
    public long getContentRevision() { return contentRevision; }
    public long getSourceLocalizationRevision() { return sourceLocalizationRevision; }
    public String getLocalizedName() { return localizedName; }
    public String getLocalizedDescription() { return localizedDescription; }
    public Instant getPublishedAt() { return publishedAt; }
    public String getPublishedBy() { return publishedBy; }
    public long getRowVersion() { return rowVersion; }
    public Instant getCreatedAt() { return createdAt; }
    public String getCreatedBy() { return createdBy; }
    public Instant getUpdatedAt() { return updatedAt; }
    public String getUpdatedBy() { return updatedBy; }
}

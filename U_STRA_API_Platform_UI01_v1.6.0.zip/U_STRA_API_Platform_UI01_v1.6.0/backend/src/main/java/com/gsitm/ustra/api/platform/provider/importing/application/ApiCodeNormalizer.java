package com.gsitm.ustra.api.platform.provider.importing.application;
import java.util.Locale;
import org.springframework.stereotype.Component;
@Component public class ApiCodeNormalizer { public String normalize(String value){ return value.trim().toUpperCase(Locale.ROOT); } }

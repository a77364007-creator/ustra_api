package com.gsitm.ustra.api.platform.catalog.application;

import com.gsitm.ustra.api.platform.catalog.localization.application.LocalizationStalenessService;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiProductEntity;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiProductRepository;
import com.gsitm.ustra.api.platform.catalog.persistence.ProviderRepository;
import com.gsitm.ustra.api.platform.common.error.BusinessException;
import com.gsitm.ustra.api.platform.common.error.ErrorCode;
import com.gsitm.ustra.api.platform.search.application.CatalogSearchReindexPublisher;
import com.gsitm.ustra.api.platform.tenant.application.TenantPermissionGuard;
import com.gsitm.ustra.api.platform.tenant.context.TenantContext;
import com.gsitm.ustra.api.platform.tenant.context.TenantContextResolver;
import com.gsitm.ustra.api.platform.tenant.persistence.MembershipRepository;
import java.time.Clock;
import java.time.Instant;
import java.util.List;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ApiProductService {
    private static final Logger log = LoggerFactory.getLogger(ApiProductService.class);

    private final TenantContextResolver contextResolver;
    private final TenantPermissionGuard permissionGuard;
    private final ApiProductRepository repository;
    private final ProviderRepository providerRepository;
    private final MembershipRepository membershipRepository;
    private final LocalizationStalenessService localizationStalenessService;
    private final CatalogSearchReindexPublisher searchReindexPublisher;
    private final Clock clock;

    public ApiProductService(TenantContextResolver contextResolver, TenantPermissionGuard permissionGuard,
                             ApiProductRepository repository, ProviderRepository providerRepository,
                             MembershipRepository membershipRepository,
                             LocalizationStalenessService localizationStalenessService,
                             CatalogSearchReindexPublisher searchReindexPublisher, Clock clock) {
        this.contextResolver = contextResolver;
        this.permissionGuard = permissionGuard;
        this.repository = repository;
        this.providerRepository = providerRepository;
        this.membershipRepository = membershipRepository;
        this.localizationStalenessService = localizationStalenessService;
        this.searchReindexPublisher = searchReindexPublisher;
        this.clock = clock;
    }

    @Transactional(readOnly = true)
    public List<ApiProductEntity> list() {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "API_PRODUCT:READ", "API_PRODUCT", "list");
        return repository.findAllByTenantIdOrderByProductCodeNormalizedAsc(context.tenantId());
    }

    @Transactional(readOnly = true)
    public ApiProductEntity get(String id) {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "API_PRODUCT:READ", "API_PRODUCT", id);
        return owned(context, id);
    }

    @Transactional
    public ApiProductEntity create(String productCode, String name, String description,
                                   String providerId, String ownerMembershipId) {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "API_PRODUCT:CREATE", "API_PRODUCT", "new");
        String canonicalCode = CatalogCodeNormalizer.productCode(productCode);
        if (repository.existsByTenantIdAndProductCodeNormalized(context.tenantId(), canonicalCode)) {
            throw codeConflict();
        }
        validateReferences(context.tenantId(), providerId, ownerMembershipId);
        Instant now = Instant.now(clock);
        ApiProductEntity entity = new ApiProductEntity(UUID.randomUUID().toString(), context.tenantId(),
                canonicalCode, canonicalCode, name, description, providerId, ownerMembershipId,
                now, context.principalId());
        entity = repository.saveAndFlush(entity);
        log.info("API product created productId={} tenantId={}", entity.getId(), context.tenantId());
        searchReindexPublisher.request(context.tenantId(), entity.getId(), context.principalId(), "API_PRODUCT_CREATED");
        return entity;
    }

    @Transactional
    public ApiProductEntity update(String id, long expectedVersion, String name, String description,
                                   String providerId, String ownerMembershipId) {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "API_PRODUCT:UPDATE", "API_PRODUCT", id);
        ApiProductEntity entity = owned(context, id);
        if (entity.getRowVersion() != expectedVersion) {
            throw new BusinessException(ErrorCode.CONCURRENT_MODIFICATION, HttpStatus.CONFLICT,
                    "API Product가 다른 요청에 의해 변경되었습니다.");
        }
        validateReferences(context.tenantId(), providerId, ownerMembershipId);
        boolean translatableChanged = entity.update(name, description, providerId, ownerMembershipId,
                Instant.now(clock), context.principalId());
        if (translatableChanged) {
            localizationStalenessService.markPublishedStale(context.tenantId(), entity.getId(),
                    entity.getLocalizationRevision(), context.principalId());
        }
        log.info("API product updated productId={} tenantId={} translatableChanged={}",
                entity.getId(), context.tenantId(), translatableChanged);
        searchReindexPublisher.request(context.tenantId(), entity.getId(), context.principalId(), "API_PRODUCT_UPDATED");
        return entity;
    }

    private ApiProductEntity owned(TenantContext context, String id) {
        return repository.findByIdAndTenantId(id, context.tenantId())
                .orElseThrow(() -> new BusinessException(ErrorCode.API_PRODUCT_NOT_FOUND, HttpStatus.NOT_FOUND,
                        "API Product를 찾을 수 없습니다."));
    }

    private void validateReferences(String tenantId, String providerId, String ownerMembershipId) {
        if (providerId != null && providerRepository.findByIdAndTenantId(providerId, tenantId).isEmpty()) {
            throw new BusinessException(ErrorCode.PROVIDER_NOT_FOUND, HttpStatus.BAD_REQUEST,
                    "Provider를 찾을 수 없습니다.");
        }
        if (ownerMembershipId != null && membershipRepository.findByIdAndTenantId(ownerMembershipId, tenantId).isEmpty()) {
            throw new BusinessException(ErrorCode.MEMBERSHIP_NOT_FOUND, HttpStatus.BAD_REQUEST,
                    "Owner Membership을 찾을 수 없습니다.");
        }
    }

    private BusinessException codeConflict() {
        return new BusinessException(ErrorCode.API_PRODUCT_CODE_CONFLICT, HttpStatus.CONFLICT,
                "현재 Tenant에서 이미 사용 중인 productCode입니다.");
    }
}

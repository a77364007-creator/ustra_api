package com.gsitm.ustra.api.platform.consumer.persistence;

import com.gsitm.ustra.api.platform.consumer.domain.ConsumerAppLifecycleState;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Version;
import java.time.Instant;

@Entity
@Table(name = "consumer_app")
public class ConsumerAppEntity {
    @Id
    @Column(name = "consumer_app_id", length = 36, nullable = false, updatable = false)
    private String id;
    @Column(name = "tenant_id", length = 36, nullable = false, updatable = false)
    private String tenantId;
    @Column(name = "app_code", length = 100, nullable = false, updatable = false)
    private String appCode;
    @Column(name = "app_code_normalized", length = 100, nullable = false, updatable = false)
    private String appCodeNormalized;
    @Column(name = "name", length = 200, nullable = false)
    private String name;
    @Column(name = "description", columnDefinition = "TEXT")
    private String description;
    @Column(name = "owner_membership_id", length = 36, nullable = false)
    private String ownerMembershipId;
    @Column(name = "organization_id", length = 36)
    private String organizationId;
    @Enumerated(EnumType.STRING)
    @Column(name = "lifecycle_state", length = 30, nullable = false)
    private ConsumerAppLifecycleState lifecycleState;
    @Version
    @Column(name = "row_version", nullable = false)
    private long rowVersion;
    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;
    @Column(name = "created_by", length = 200, nullable = false, updatable = false)
    private String createdBy;
    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;
    @Column(name = "updated_by", length = 200, nullable = false)
    private String updatedBy;

    protected ConsumerAppEntity() {}

    public ConsumerAppEntity(String id, String tenantId, String appCode, String appCodeNormalized, String name,
                             String description, String ownerMembershipId, String organizationId,
                             Instant now, String actor) {
        this.id = id;
        this.tenantId = tenantId;
        this.appCode = appCode;
        this.appCodeNormalized = appCodeNormalized;
        this.name = name;
        this.description = description;
        this.ownerMembershipId = ownerMembershipId;
        this.organizationId = organizationId;
        this.lifecycleState = ConsumerAppLifecycleState.DRAFT;
        this.createdAt = now;
        this.createdBy = actor;
        this.updatedAt = now;
        this.updatedBy = actor;
    }

    public void update(String name, String description, String ownerMembershipId, String organizationId,
                       Instant now, String actor) {
        this.name = name;
        this.description = description;
        this.ownerMembershipId = ownerMembershipId;
        this.organizationId = organizationId;
        this.updatedAt = now;
        this.updatedBy = actor;
    }

    public void activate(Instant now, String actor) {
        this.lifecycleState = ConsumerAppLifecycleState.ACTIVE;
        touch(now, actor);
    }
    public void suspend(Instant now, String actor) {
        this.lifecycleState = ConsumerAppLifecycleState.SUSPENDED;
        touch(now, actor);
    }
    public void retire(Instant now, String actor) {
        this.lifecycleState = ConsumerAppLifecycleState.RETIRED;
        touch(now, actor);
    }
    private void touch(Instant now, String actor) { this.updatedAt = now; this.updatedBy = actor; }

    public String getId() { return id; }
    public String getTenantId() { return tenantId; }
    public String getAppCode() { return appCode; }
    public String getAppCodeNormalized() { return appCodeNormalized; }
    public String getName() { return name; }
    public String getDescription() { return description; }
    public String getOwnerMembershipId() { return ownerMembershipId; }
    public String getOrganizationId() { return organizationId; }
    public ConsumerAppLifecycleState getLifecycleState() { return lifecycleState; }
    public long getRowVersion() { return rowVersion; }
    public Instant getCreatedAt() { return createdAt; }
    public String getCreatedBy() { return createdBy; }
    public Instant getUpdatedAt() { return updatedAt; }
    public String getUpdatedBy() { return updatedBy; }
}

package com.gsitm.ustra.api.platform.tenant.persistence;

import com.gsitm.ustra.api.platform.tenant.domain.RoleAssignmentStatus;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Version;
import java.time.Instant;

@Entity
@Table(name = "role_assignment")
public class RoleAssignmentEntity {
    @Id
    @Column(name = "role_assignment_id", length = 36, nullable = false, updatable = false)
    private String id;

    @Column(name = "tenant_id", length = 36)
    private String tenantId;

    @Column(name = "membership_id", length = 36)
    private String membershipId;

    @Column(name = "principal_id", length = 200)
    private String principalId;

    @Column(name = "role_id", length = 36, nullable = false)
    private String roleId;

    @Column(name = "organization_scope_id", length = 36)
    private String organizationScopeId;

    @Column(name = "effective_from", nullable = false)
    private Instant effectiveFrom;

    @Column(name = "effective_to")
    private Instant effectiveTo;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", length = 30, nullable = false)
    private RoleAssignmentStatus status;

    @Column(name = "assigned_by", length = 200, nullable = false)
    private String assignedBy;

    @Column(name = "assigned_at", nullable = false)
    private Instant assignedAt;

    @Column(name = "revoked_by", length = 200)
    private String revokedBy;

    @Column(name = "revoked_at")
    private Instant revokedAt;

    @Version
    @Column(name = "row_version", nullable = false)
    private long rowVersion;

    protected RoleAssignmentEntity() {
    }

    public RoleAssignmentEntity(String id, String tenantId, String membershipId, String roleId,
                                String organizationScopeId, Instant effectiveFrom, Instant effectiveTo,
                                String assignedBy, Instant now) {
        this.id = id;
        this.tenantId = tenantId;
        this.membershipId = membershipId;
        this.roleId = roleId;
        this.organizationScopeId = organizationScopeId;
        this.effectiveFrom = effectiveFrom;
        this.effectiveTo = effectiveTo;
        this.status = RoleAssignmentStatus.ACTIVE;
        this.assignedBy = assignedBy;
        this.assignedAt = now;
    }

    public boolean isEffectiveAt(Instant now) {
        return status == RoleAssignmentStatus.ACTIVE
                && !effectiveFrom.isAfter(now)
                && (effectiveTo == null || now.isBefore(effectiveTo));
    }

    public boolean overlaps(Instant from, Instant to) {
        Instant thisEnd = effectiveTo;
        boolean startsBeforeOtherEnds = to == null || effectiveFrom.isBefore(to);
        boolean otherStartsBeforeThisEnds = thisEnd == null || from.isBefore(thisEnd);
        return status == RoleAssignmentStatus.ACTIVE && startsBeforeOtherEnds && otherStartsBeforeThisEnds;
    }

    public void revoke(String actor, Instant now) {
        this.status = RoleAssignmentStatus.REVOKED;
        this.revokedBy = actor;
        this.revokedAt = now;
    }

    public String getId() { return id; }
    public String getTenantId() { return tenantId; }
    public String getMembershipId() { return membershipId; }
    public String getRoleId() { return roleId; }
    public String getOrganizationScopeId() { return organizationScopeId; }
    public Instant getEffectiveFrom() { return effectiveFrom; }
    public Instant getEffectiveTo() { return effectiveTo; }
    public RoleAssignmentStatus getStatus() { return status; }
    public long getRowVersion() { return rowVersion; }
}

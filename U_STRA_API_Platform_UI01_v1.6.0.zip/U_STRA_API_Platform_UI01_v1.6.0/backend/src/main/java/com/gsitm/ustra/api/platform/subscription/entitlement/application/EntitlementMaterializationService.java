package com.gsitm.ustra.api.platform.subscription.entitlement.application;

import com.gsitm.ustra.api.platform.audit.AuditService;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiOperationEntity;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiOperationRepository;
import com.gsitm.ustra.api.platform.catalog.publication.application.StateTransitionHistoryService;
import com.gsitm.ustra.api.platform.catalog.publication.domain.ApiProductComponentTargetType;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.ApiProductComponentEntity;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.ApiProductComponentRepository;
import com.gsitm.ustra.api.platform.common.error.BusinessException;
import com.gsitm.ustra.api.platform.common.error.ErrorCode;
import com.gsitm.ustra.api.platform.outbox.OutboxService;
import com.gsitm.ustra.api.platform.security.AuthenticatedIdentityProvider;
import com.gsitm.ustra.api.platform.subscription.entitlement.domain.AccessFulfillmentType;
import com.gsitm.ustra.api.platform.subscription.entitlement.persistence.*;
import com.gsitm.ustra.api.platform.subscription.persistence.*;
import java.math.BigDecimal;
import java.time.Clock;
import java.time.Instant;
import java.util.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class EntitlementMaterializationService implements ApprovedSubscriptionDecisionPort {
 private final SubscriptionRequestRepository requestRepository; private final SubscriptionRequestRevisionRepository revisionRepository;
 private final ApiProductComponentRepository componentRepository; private final ApiOperationRepository operationRepository;
 private final SubscriptionRepository subscriptionRepository; private final EntitlementRepository entitlementRepository;
 private final EntitlementOperationScopeRepository scopeRepository; private final QuotaProfileRepository quotaProfileRepository;
 private final QuotaLimitRepository quotaLimitRepository; private final AccessFulfillmentRepository fulfillmentRepository;
 private final StateTransitionHistoryService historyService; private final AuditService auditService; private final OutboxService outboxService;
 private final FulfillmentFingerprintService fingerprintService; private final AuthenticatedIdentityProvider identityProvider; private final Clock clock;
 public EntitlementMaterializationService(SubscriptionRequestRepository requestRepository,SubscriptionRequestRevisionRepository revisionRepository,ApiProductComponentRepository componentRepository,ApiOperationRepository operationRepository,SubscriptionRepository subscriptionRepository,EntitlementRepository entitlementRepository,EntitlementOperationScopeRepository scopeRepository,QuotaProfileRepository quotaProfileRepository,QuotaLimitRepository quotaLimitRepository,AccessFulfillmentRepository fulfillmentRepository,StateTransitionHistoryService historyService,AuditService auditService,OutboxService outboxService,FulfillmentFingerprintService fingerprintService,AuthenticatedIdentityProvider identityProvider,Clock clock){this.requestRepository=requestRepository;this.revisionRepository=revisionRepository;this.componentRepository=componentRepository;this.operationRepository=operationRepository;this.subscriptionRepository=subscriptionRepository;this.entitlementRepository=entitlementRepository;this.scopeRepository=scopeRepository;this.quotaProfileRepository=quotaProfileRepository;this.quotaLimitRepository=quotaLimitRepository;this.fulfillmentRepository=fulfillmentRepository;this.historyService=historyService;this.auditService=auditService;this.outboxService=outboxService;this.fingerprintService=fingerprintService;this.identityProvider=identityProvider;this.clock=clock;}
 @Override @Transactional public MaterializationResult materialize(ApprovedSubscriptionDecision decision){
  validateDecision(decision);
  var existing=subscriptionRepository.findByTenantIdAndSourceSubscriptionRequestId(decision.tenantId(),decision.subscriptionRequestId());
  if(existing.isPresent()) return existingResult(decision,existing.get());
  SubscriptionRequestEntity request=requestRepository.findByIdAndTenantId(decision.subscriptionRequestId(),decision.tenantId()).orElseThrow(()->new BusinessException(ErrorCode.SUBSCRIPTION_REQUEST_NOT_FOUND,HttpStatus.NOT_FOUND,"승인 대상 Subscription Request를 찾을 수 없습니다."));
  if(request.getCurrentRevisionNo()!=decision.requestRevisionNo()) throw conflict(ErrorCode.APPROVAL_DECISION_MISMATCH,"승인 revision이 현재 신청 revision과 일치하지 않습니다.");
  SubscriptionRequestRevisionEntity revision=revisionRepository.findByTenantIdAndSubscriptionRequestIdAndRevisionNo(decision.tenantId(),request.getId(),decision.requestRevisionNo()).orElseThrow(()->new BusinessException(ErrorCode.SUBSCRIPTION_REQUEST_REVISION_NOT_FOUND,HttpStatus.NOT_FOUND,"승인 대상 Subscription Request revision을 찾을 수 없습니다."));
  if(!revision.getSnapshotHash().equals(decision.snapshotHash())) throw conflict(ErrorCode.APPROVAL_DECISION_MISMATCH,"승인 snapshot hash가 신청 snapshot과 일치하지 않습니다.");
  if(!request.getConsumerAppEnvironmentId().equals(decision.consumerAppEnvironmentId())) throw conflict(ErrorCode.APPROVAL_DECISION_MISMATCH,"승인 Consumer App Environment가 신청 snapshot과 일치하지 않습니다.");
  if(!request.getApiProductVersionId().equals(decision.apiProductVersionId())) throw conflict(ErrorCode.APPROVAL_DECISION_MISMATCH,"승인 ProductVersion이 신청 snapshot과 일치하지 않습니다.");
  validateOperations(decision);
  validateQuotas(decision.quotaLimits());
  Instant now=Instant.now(clock); String actor=identityProvider.current().principalId();
  String subscriptionId=UUID.randomUUID().toString();
  SubscriptionEntity subscription=subscriptionRepository.saveAndFlush(new SubscriptionEntity(subscriptionId,decision.tenantId(),request.getId(),decision.requestRevisionNo(),decision.snapshotHash(),decision.approvalReferenceId(),decision.consumerAppEnvironmentId(),decision.apiProductVersionId(),decision.effectiveFrom(),decision.effectiveTo(),now,actor));
  historyService.record(decision.tenantId(),"SUBSCRIPTION",subscriptionId,"NONE","PENDING_ACTIVATION");
  String entitlementId=UUID.randomUUID().toString();
  EntitlementEntity entitlement=entitlementRepository.saveAndFlush(new EntitlementEntity(entitlementId,decision.tenantId(),subscriptionId,decision.consumerAppEnvironmentId(),decision.apiProductVersionId(),decision.effectiveFrom(),decision.effectiveTo(),now,actor));
  historyService.record(decision.tenantId(),"ENTITLEMENT",entitlementId,"NONE","GRANTED");
  for(String opId:new LinkedHashSet<>(decision.apiOperationIds())) scopeRepository.save(new EntitlementOperationScopeEntity(UUID.randomUUID().toString(),decision.tenantId(),entitlementId,opId,now,actor));
  if(!decision.quotaLimits().isEmpty()){
   QuotaProfileEntity profile=quotaProfileRepository.saveAndFlush(new QuotaProfileEntity(UUID.randomUUID().toString(),decision.tenantId(),entitlementId,now,actor));
   for(var q:decision.quotaLimits()) quotaLimitRepository.save(new QuotaLimitEntity(UUID.randomUUID().toString(),decision.tenantId(),profile.getId(),q.metricCode().trim(),q.limitValue(),q.windowSeconds(),q.unitCode().trim(),now,actor));
  }
  String fulfillmentId=UUID.randomUUID().toString(); String key="PROVISION:"+entitlementId+":1"; String fp=fingerprintService.fingerprint(decision.tenantId(),entitlementId,"PROVISION",1);
  AccessFulfillmentEntity fulfillment=fulfillmentRepository.saveAndFlush(new AccessFulfillmentEntity(fulfillmentId,decision.tenantId(),entitlementId,1,AccessFulfillmentType.PROVISION,key,fp,now,actor));
  subscription.activate(now,actor); subscription=subscriptionRepository.saveAndFlush(subscription); historyService.record(decision.tenantId(),"SUBSCRIPTION",subscriptionId,"PENDING_ACTIVATION","ACTIVE");
  auditService.success(decision.tenantId(),"ENTITLEMENT_GRANT","ENTITLEMENT",entitlementId,true,Map.of("subscriptionId",subscriptionId,"sourceRequestId",request.getId(),"sourceRevisionNo",decision.requestRevisionNo(),"operationCount",new LinkedHashSet<>(decision.apiOperationIds()).size(),"quotaCount",decision.quotaLimits().size(),"fulfillmentId",fulfillmentId));
  outboxService.enqueue("EntitlementGranted","ENTITLEMENT",entitlementId,decision.tenantId(),Map.of("entitlementId",entitlementId,"subscriptionId",subscriptionId,"consumerAppEnvironmentId",decision.consumerAppEnvironmentId(),"apiProductVersionId",decision.apiProductVersionId(),"sourceSubscriptionRequestId",request.getId(),"sourceRequestRevisionNo",decision.requestRevisionNo(),"snapshotHash",decision.snapshotHash(),"accessFulfillmentId",fulfillmentId));
  return new MaterializationResult(subscription,entitlement,fulfillment);
 }
 private void validateDecision(ApprovedSubscriptionDecision d){if(d==null||blank(d.tenantId())||blank(d.approvalReferenceId())||blank(d.subscriptionRequestId())||blank(d.snapshotHash())||blank(d.consumerAppEnvironmentId())||blank(d.apiProductVersionId())) throw bad("승인결정 필수값이 누락되었습니다."); if(d.requestRevisionNo()<1) throw bad("requestRevisionNo는 1 이상이어야 합니다."); if(d.effectiveFrom()==null||d.effectiveTo()==null||!d.effectiveFrom().isBefore(d.effectiveTo())) throw new BusinessException(ErrorCode.ENTITLEMENT_EFFECTIVE_PERIOD_INVALID,HttpStatus.BAD_REQUEST,"승인 유효기간이 올바르지 않습니다."); if(d.apiOperationIds()==null||d.apiOperationIds().isEmpty()) throw new BusinessException(ErrorCode.ENTITLEMENT_SCOPE_REQUIRED,HttpStatus.BAD_REQUEST,"빈 operation scope를 전체 권한으로 해석할 수 없습니다."); if(d.apiOperationIds().stream().anyMatch(this::blank)) throw bad("apiOperationId는 비어 있을 수 없습니다.");}
 private void validateOperations(ApprovedSubscriptionDecision d){List<ApiProductComponentEntity> components=componentRepository.findAllByTenantIdAndApiProductVersionIdOrderByCreatedAtAsc(d.tenantId(),d.apiProductVersionId()); Set<String> direct=new HashSet<>(); Set<String> versions=new HashSet<>(); for(var c:components){if(c.getTargetType()==ApiProductComponentTargetType.API_OPERATION) direct.add(c.getApiOperationId()); else if(c.getTargetType()==ApiProductComponentTargetType.API_VERSION) versions.add(c.getApiVersionId());} for(String opId:new LinkedHashSet<>(d.apiOperationIds())){ApiOperationEntity op=operationRepository.findByIdAndTenantId(opId,d.tenantId()).orElseThrow(()->new BusinessException(ErrorCode.API_OPERATION_NOT_FOUND,HttpStatus.NOT_FOUND,"승인 Operation을 찾을 수 없습니다.")); if(!direct.contains(opId)&&!versions.contains(op.getApiVersionId())) throw new BusinessException(ErrorCode.ENTITLEMENT_SCOPE_INVALID,HttpStatus.CONFLICT,"승인 Operation이 고정 ProductVersion 구성에 속하지 않습니다.");}}
 private void validateQuotas(List<ApprovedSubscriptionDecision.QuotaLimitDecision> quotas){Set<String> keys=new HashSet<>(); for(var q:quotas){if(q==null||blank(q.metricCode())||blank(q.unitCode())||q.limitValue()==null||q.limitValue().compareTo(BigDecimal.ZERO)<=0||q.windowSeconds()<=0) throw new BusinessException(ErrorCode.ENTITLEMENT_QUOTA_INVALID,HttpStatus.BAD_REQUEST,"승인 Quota 값이 올바르지 않습니다."); String key=q.metricCode().trim()+"|"+q.windowSeconds()+"|"+q.unitCode().trim(); if(!keys.add(key)) throw new BusinessException(ErrorCode.ENTITLEMENT_QUOTA_INVALID,HttpStatus.CONFLICT,"중복 Quota 항목이 있습니다.");}}
 private MaterializationResult existingResult(ApprovedSubscriptionDecision d,SubscriptionEntity s){
  if(s.getSourceRequestRevisionNo()!=d.requestRevisionNo()||!s.getSourceSnapshotHash().equals(d.snapshotHash())||!s.getApprovalReferenceId().equals(d.approvalReferenceId())||!s.getConsumerAppEnvironmentId().equals(d.consumerAppEnvironmentId())||!s.getApiProductVersionId().equals(d.apiProductVersionId())||!s.getEffectiveFrom().equals(d.effectiveFrom())||!s.getEffectiveTo().equals(d.effectiveTo())) throw conflict(ErrorCode.APPROVAL_DECISION_MISMATCH,"동일 신청에 서로 다른 승인결정을 재적용할 수 없습니다.");
  List<EntitlementEntity> es=entitlementRepository.findAllByTenantIdAndSubscriptionId(d.tenantId(),s.getId()); if(es.size()!=1) throw new BusinessException(ErrorCode.ENTITLEMENT_MATERIALIZATION_INCONSISTENT,HttpStatus.INTERNAL_SERVER_ERROR,"기존 Subscription의 Entitlement 상태가 일관되지 않습니다."); EntitlementEntity e=es.get(0);
  Set<String> storedScopes=new LinkedHashSet<>(scopeRepository.findAllByTenantIdAndEntitlementIdOrderByApiOperationIdAsc(d.tenantId(),e.getId()).stream().map(EntitlementOperationScopeEntity::getApiOperationId).toList()); Set<String> requestedScopes=new LinkedHashSet<>(d.apiOperationIds()); if(!storedScopes.equals(requestedScopes)) throw conflict(ErrorCode.APPROVAL_DECISION_MISMATCH,"동일 신청의 승인 Operation scope가 기존 materialization과 다릅니다.");
  var profile=quotaProfileRepository.findByTenantIdAndEntitlementId(d.tenantId(),e.getId()); List<QuotaLimitEntity> storedQuota=profile.map(x->quotaLimitRepository.findAllByTenantIdAndQuotaProfileIdOrderByMetricCodeAsc(d.tenantId(),x.getId())).orElse(List.of()); if(storedQuota.size()!=d.quotaLimits().size()) throw conflict(ErrorCode.APPROVAL_DECISION_MISMATCH,"동일 신청의 승인 Quota가 기존 materialization과 다릅니다."); for(var q:d.quotaLimits()){boolean match=storedQuota.stream().anyMatch(x->x.getMetricCode().equals(q.metricCode().trim())&&x.getLimitValue().compareTo(q.limitValue())==0&&x.getWindowSeconds()==q.windowSeconds()&&x.getUnitCode().equals(q.unitCode().trim())); if(!match) throw conflict(ErrorCode.APPROVAL_DECISION_MISMATCH,"동일 신청의 승인 Quota가 기존 materialization과 다릅니다.");}
  AccessFulfillmentEntity f=fulfillmentRepository.findFirstByTenantIdAndEntitlementIdOrderByCreatedAtDesc(d.tenantId(),e.getId()).orElseThrow(()->new BusinessException(ErrorCode.ACCESS_FULFILLMENT_NOT_FOUND,HttpStatus.INTERNAL_SERVER_ERROR,"기존 Fulfillment를 찾을 수 없습니다.")); return new MaterializationResult(s,e,f);
 }
 private boolean blank(String s){return s==null||s.isBlank();} private BusinessException bad(String m){return new BusinessException(ErrorCode.VALIDATION_ERROR,HttpStatus.BAD_REQUEST,m);} private BusinessException conflict(ErrorCode c,String m){return new BusinessException(c,HttpStatus.CONFLICT,m);}
 public record MaterializationResult(SubscriptionEntity subscription,EntitlementEntity entitlement,AccessFulfillmentEntity fulfillment){}
}

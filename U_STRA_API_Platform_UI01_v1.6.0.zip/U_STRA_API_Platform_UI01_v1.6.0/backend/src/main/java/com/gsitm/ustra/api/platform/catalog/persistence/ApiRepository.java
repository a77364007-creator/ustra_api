package com.gsitm.ustra.api.platform.catalog.persistence;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ApiRepository extends JpaRepository<ApiEntity, String> {
    Optional<ApiEntity> findByIdAndTenantId(String id, String tenantId);
    Optional<ApiEntity> findByTenantIdAndApiCodeNormalized(String tenantId, String apiCodeNormalized);
}

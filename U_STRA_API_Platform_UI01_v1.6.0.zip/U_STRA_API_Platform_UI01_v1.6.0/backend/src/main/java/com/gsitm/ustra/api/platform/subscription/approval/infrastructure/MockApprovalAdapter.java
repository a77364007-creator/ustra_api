package com.gsitm.ustra.api.platform.subscription.approval.infrastructure;
import com.gsitm.ustra.api.platform.subscription.approval.application.ApprovalPort; import java.util.*; import java.util.concurrent.ConcurrentHashMap; import org.springframework.context.annotation.Profile; import org.springframework.stereotype.Component;
@Component @Profile({"local","test","mock-integration"})
public class MockApprovalAdapter implements ApprovalPort {
 private final Map<String,Decision> decisions=new ConcurrentHashMap<>();
 public CaseReference createCase(CaseCommand command){String ref="MOCK-ITSM:"+command.subscriptionRequestId()+":"+command.requestRevisionNo();decisions.putIfAbsent(ref,new Decision(ref,DecisionStatus.PENDING,command.requestRevisionNo(),command.snapshotHash(),List.of(),List.of(),null,null,null,null,null));return new CaseReference("MOCK_ITSM",ref,"CP08-MOCK-v1");}
 public Decision queryDecision(String externalCaseRef){Decision d=decisions.get(externalCaseRef);if(d==null)throw new IllegalArgumentException("Unknown mock approval case");return d;}
 public void setDecision(String externalCaseRef,Decision decision){if(decision==null||decision.status()==DecisionStatus.PENDING)throw new IllegalArgumentException("Mock decision must be explicit APPROVED or REJECTED");if(!externalCaseRef.equals(decision.externalCaseRef()))throw new IllegalArgumentException("Mock approval reference mismatch");decisions.put(externalCaseRef,decision);}
 public int caseCount(){return decisions.size();}
}

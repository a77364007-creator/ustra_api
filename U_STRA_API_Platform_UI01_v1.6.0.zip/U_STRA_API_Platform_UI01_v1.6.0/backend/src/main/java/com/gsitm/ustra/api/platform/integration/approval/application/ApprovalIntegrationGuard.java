package com.gsitm.ustra.api.platform.integration.approval.application;
import org.springframework.stereotype.Component;
@Component public class ApprovalIntegrationGuard {private final ApprovalIntegrationStateService state;public ApprovalIntegrationGuard(ApprovalIntegrationStateService state){this.state=state;}public boolean blocksCancellation(String tenantId,String requestId,int revisionNo){return state.hasUnresolvedCaseCreation(tenantId,requestId,revisionNo);}}

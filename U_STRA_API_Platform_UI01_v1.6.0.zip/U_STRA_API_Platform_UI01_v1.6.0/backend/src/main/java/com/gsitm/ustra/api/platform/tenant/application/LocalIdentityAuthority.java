package com.gsitm.ustra.api.platform.tenant.application;

import java.util.Arrays;
import java.util.Set;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Component
@Profile({"local", "test"})
public class LocalIdentityAuthority implements IdentityAuthority {
    private final Set<String> allowedPrincipals;

    public LocalIdentityAuthority(@Value("${app.identity.test-principals:}") String configured) {
        this.allowedPrincipals = Arrays.stream(configured.split(","))
                .map(String::trim)
                .filter(s -> !s.isBlank())
                .collect(Collectors.toUnmodifiableSet());
    }

    @Override
    public boolean exists(String principalId, String issuer) {
        return allowedPrincipals.contains(principalId);
    }
}

package com.gsitm.ustra.api.platform.consumer.persistence;

import com.gsitm.ustra.api.platform.consumer.domain.ConsumerAppEnvironmentType;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ConsumerAppEnvironmentRepository extends JpaRepository<ConsumerAppEnvironmentEntity, String> {
    Optional<ConsumerAppEnvironmentEntity> findByIdAndTenantId(String id, String tenantId);
    Optional<ConsumerAppEnvironmentEntity> findByIdAndTenantIdAndConsumerAppId(String id, String tenantId, String consumerAppId);
    List<ConsumerAppEnvironmentEntity> findAllByTenantIdAndConsumerAppIdOrderByEnvironmentTypeAsc(String tenantId, String consumerAppId);
    boolean existsByTenantIdAndConsumerAppIdAndEnvironmentType(String tenantId, String consumerAppId, ConsumerAppEnvironmentType environmentType);
}

package com.gsitm.ustra.api.platform.catalog.publication.domain;

public enum CatalogPublicationState {
    DRAFT,
    ACTIVE,
    SUSPENDED,
    WITHDRAWN
}

package com.gsitm.ustra.api.platform.outbox;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.Instant;

@Entity
@Table(name = "outbox_event")
public class OutboxEventEntity {
    @Id
    @Column(name = "outbox_id", length = 36, nullable = false, updatable = false)
    private String id;

    @Column(name = "event_id", length = 36, nullable = false, updatable = false, unique = true)
    private String eventId;

    @Column(name = "event_type", length = 120, nullable = false, updatable = false)
    private String eventType;

    @Column(name = "event_version", nullable = false, updatable = false)
    private int eventVersion;

    @Column(name = "aggregate_type", length = 80, nullable = false, updatable = false)
    private String aggregateType;

    @Column(name = "aggregate_id", length = 200, nullable = false, updatable = false)
    private String aggregateId;

    @Column(name = "tenant_id", length = 36, updatable = false)
    private String tenantId;

    @Column(name = "payload", columnDefinition = "LONGTEXT", nullable = false, updatable = false)
    private String payload;

    @Column(name = "correlation_id", length = 100, nullable = false, updatable = false)
    private String correlationId;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @Column(name = "published_at")
    private Instant publishedAt;

    @Column(name = "publish_attempts", nullable = false)
    private int publishAttempts;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", length = 30, nullable = false)
    private OutboxStatus status;

    protected OutboxEventEntity() {
    }

    public OutboxEventEntity(String id, String eventId, String eventType, int eventVersion,
                             String aggregateType, String aggregateId, String tenantId,
                             String payload, String correlationId, Instant createdAt) {
        this.id = id;
        this.eventId = eventId;
        this.eventType = eventType;
        this.eventVersion = eventVersion;
        this.aggregateType = aggregateType;
        this.aggregateId = aggregateId;
        this.tenantId = tenantId;
        this.payload = payload;
        this.correlationId = correlationId;
        this.createdAt = createdAt;
        this.status = OutboxStatus.PENDING;
    }

    public void markPublished(Instant now) {
        this.publishAttempts++;
        this.status = OutboxStatus.PUBLISHED;
        this.publishedAt = now;
    }

    public void markAttemptFailed() {
        this.publishAttempts++;
        this.status = OutboxStatus.PENDING;
    }

    public String getId() { return id; }
    public String getEventId() { return eventId; }
    public String getEventType() { return eventType; }
    public int getEventVersion() { return eventVersion; }
    public String getAggregateType() { return aggregateType; }
    public String getAggregateId() { return aggregateId; }
    public String getTenantId() { return tenantId; }
    public String getPayload() { return payload; }
    public String getCorrelationId() { return correlationId; }
    public Instant getCreatedAt() { return createdAt; }
    public OutboxStatus getStatus() { return status; }
    public int getPublishAttempts() { return publishAttempts; }
}

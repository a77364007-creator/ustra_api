package com.gsitm.ustra.api.platform.consumer.application;

import com.gsitm.ustra.api.platform.audit.AuditService;
import com.gsitm.ustra.api.platform.common.error.BusinessException;
import com.gsitm.ustra.api.platform.common.error.ErrorCode;
import com.gsitm.ustra.api.platform.consumer.domain.ConsumerAppEnvironmentType;
import com.gsitm.ustra.api.platform.consumer.persistence.ConsumerAppEnvironmentEntity;
import com.gsitm.ustra.api.platform.consumer.persistence.ConsumerAppEnvironmentRepository;
import com.gsitm.ustra.api.platform.consumer.persistence.ConsumerAppRepository;
import com.gsitm.ustra.api.platform.tenant.application.TenantPermissionGuard;
import com.gsitm.ustra.api.platform.tenant.context.TenantContext;
import com.gsitm.ustra.api.platform.tenant.context.TenantContextResolver;
import java.time.Clock;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ConsumerAppEnvironmentService {
    private final TenantContextResolver contextResolver;
    private final TenantPermissionGuard permissionGuard;
    private final ConsumerAppRepository appRepository;
    private final ConsumerAppEnvironmentRepository environmentRepository;
    private final AuditService auditService;
    private final Clock clock;

    public ConsumerAppEnvironmentService(TenantContextResolver contextResolver, TenantPermissionGuard permissionGuard,
                                         ConsumerAppRepository appRepository,
                                         ConsumerAppEnvironmentRepository environmentRepository,
                                         AuditService auditService, Clock clock) {
        this.contextResolver = contextResolver;
        this.permissionGuard = permissionGuard;
        this.appRepository = appRepository;
        this.environmentRepository = environmentRepository;
        this.auditService = auditService;
        this.clock = clock;
    }

    @Transactional(readOnly = true)
    public List<ConsumerAppEnvironmentEntity> list(String consumerAppId) {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "CONSUMER_APP:READ", "CONSUMER_APP", consumerAppId);
        ownedApp(context, consumerAppId);
        return environmentRepository.findAllByTenantIdAndConsumerAppIdOrderByEnvironmentTypeAsc(
                context.tenantId(), consumerAppId);
    }

    @Transactional
    public ConsumerAppEnvironmentEntity create(String consumerAppId, ConsumerAppEnvironmentType environmentType,
                                               String gatewayClientReference, String iamApplicationReference,
                                               String authenticationMethod) {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "CONSUMER_APP:MANAGE_ENVIRONMENT", "CONSUMER_APP", consumerAppId);
        ownedApp(context, consumerAppId);
        if (environmentRepository.existsByTenantIdAndConsumerAppIdAndEnvironmentType(
                context.tenantId(), consumerAppId, environmentType)) {
            throw new BusinessException(ErrorCode.CONSUMER_APP_ENVIRONMENT_CONFLICT, HttpStatus.CONFLICT,
                    "해당 환경은 Consumer App에 이미 등록되어 있습니다.");
        }
        Instant now = Instant.now(clock);
        ConsumerAppEnvironmentEntity entity = environmentRepository.saveAndFlush(new ConsumerAppEnvironmentEntity(
                UUID.randomUUID().toString(), context.tenantId(), consumerAppId, environmentType,
                normalize(gatewayClientReference), normalize(iamApplicationReference), normalize(authenticationMethod),
                now, context.principalId()));
        auditService.success(context.tenantId(), "CONSUMER_APP_ENVIRONMENT_CREATE", "CONSUMER_APP_ENVIRONMENT",
                entity.getId(), true, Map.of(
                        "environmentType", environmentType.name(),
                        "gatewayReferencePresent", entity.getGatewayClientReference() != null,
                        "iamReferencePresent", entity.getIamApplicationReference() != null,
                        "authenticationMethodPresent", entity.getAuthenticationMethod() != null));
        return entity;
    }

    @Transactional
    public ConsumerAppEnvironmentEntity update(String consumerAppId, String environmentId, long expectedVersion,
                                               String gatewayClientReference, String iamApplicationReference,
                                               String authenticationMethod) {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "CONSUMER_APP:MANAGE_ENVIRONMENT", "CONSUMER_APP", consumerAppId);
        ownedApp(context, consumerAppId);
        ConsumerAppEnvironmentEntity entity = environmentRepository
                .findByIdAndTenantIdAndConsumerAppId(environmentId, context.tenantId(), consumerAppId)
                .orElseThrow(() -> new BusinessException(ErrorCode.CONSUMER_APP_ENVIRONMENT_NOT_FOUND,
                        HttpStatus.NOT_FOUND, "Consumer App Environment를 찾을 수 없습니다."));
        if (entity.getRowVersion() != expectedVersion) {
            throw new BusinessException(ErrorCode.CONCURRENT_MODIFICATION, HttpStatus.CONFLICT,
                    "Consumer App Environment가 다른 요청에 의해 변경되었습니다.");
        }
        String oldGateway = entity.getGatewayClientReference();
        String oldIam = entity.getIamApplicationReference();
        String oldAuth = entity.getAuthenticationMethod();
        entity.update(normalize(gatewayClientReference), normalize(iamApplicationReference), normalize(authenticationMethod),
                Instant.now(clock), context.principalId());
        entity = environmentRepository.saveAndFlush(entity);
        auditService.success(context.tenantId(), "CONSUMER_APP_ENVIRONMENT_EXTERNAL_REFERENCE_UPDATE",
                "CONSUMER_APP_ENVIRONMENT", entity.getId(), true, Map.of(
                        "gatewayReferenceChanged", !Objects.equals(oldGateway, entity.getGatewayClientReference()),
                        "iamReferenceChanged", !Objects.equals(oldIam, entity.getIamApplicationReference()),
                        "authenticationMethodChanged", !Objects.equals(oldAuth, entity.getAuthenticationMethod())));
        return entity;
    }

    private void ownedApp(TenantContext context, String consumerAppId) {
        if (appRepository.findByIdAndTenantId(consumerAppId, context.tenantId()).isEmpty()) {
            throw new BusinessException(ErrorCode.CONSUMER_APP_NOT_FOUND, HttpStatus.NOT_FOUND,
                    "Consumer App을 찾을 수 없습니다.");
        }
    }

    private String normalize(String value) {
        if (value == null || value.isBlank()) return null;
        return value.trim();
    }
}

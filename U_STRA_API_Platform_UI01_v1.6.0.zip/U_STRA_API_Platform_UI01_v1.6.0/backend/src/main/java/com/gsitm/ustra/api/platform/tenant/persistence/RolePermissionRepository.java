package com.gsitm.ustra.api.platform.tenant.persistence;

import java.util.Collection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface RolePermissionRepository extends JpaRepository<RolePermissionEntity, RolePermissionId> {
    @Query("""
            select count(rp) from RolePermissionEntity rp, RoleEntity r, PermissionEntity p
            where rp.id.roleId = r.id
              and rp.id.permissionId = p.id
              and r.code in :roleCodes
              and r.status = com.gsitm.ustra.api.platform.tenant.domain.ReferenceStatus.ACTIVE
              and p.status = com.gsitm.ustra.api.platform.tenant.domain.ReferenceStatus.ACTIVE
              and p.code = :permissionCode
            """)
    long countPermissionForRoles(@Param("roleCodes") Collection<String> roleCodes,
                                 @Param("permissionCode") String permissionCode);
}

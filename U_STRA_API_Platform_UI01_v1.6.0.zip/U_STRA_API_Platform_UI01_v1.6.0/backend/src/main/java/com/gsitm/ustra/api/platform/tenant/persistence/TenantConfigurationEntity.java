package com.gsitm.ustra.api.platform.tenant.persistence;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Version;
import java.time.Instant;

@Entity
@Table(name = "tenant_configuration")
public class TenantConfigurationEntity {
    @Id
    @Column(name = "tenant_configuration_id", length = 36, nullable = false, updatable = false)
    private String id;

    @Column(name = "tenant_id", length = 36, nullable = false, updatable = false, unique = true)
    private String tenantId;

    @Column(name = "config_revision", nullable = false)
    private long configRevision;

    @Column(name = "default_locale", length = 35, nullable = false)
    private String defaultLocale;

    @Column(name = "timezone", length = 80, nullable = false)
    private String timezone;

    @Version
    @Column(name = "row_version", nullable = false)
    private long rowVersion;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;

    protected TenantConfigurationEntity() {
    }

    public TenantConfigurationEntity(String id, String tenantId, String defaultLocale, String timezone, Instant now) {
        this.id = id;
        this.tenantId = tenantId;
        this.configRevision = 1;
        this.defaultLocale = defaultLocale;
        this.timezone = timezone;
        this.createdAt = now;
        this.updatedAt = now;
    }

    public void update(String defaultLocale, String timezone, Instant now) {
        this.defaultLocale = defaultLocale;
        this.timezone = timezone;
        this.configRevision++;
        this.updatedAt = now;
    }

    public String getId() { return id; }
    public String getTenantId() { return tenantId; }
    public long getConfigRevision() { return configRevision; }
    public String getDefaultLocale() { return defaultLocale; }
    public String getTimezone() { return timezone; }
    public long getRowVersion() { return rowVersion; }
}

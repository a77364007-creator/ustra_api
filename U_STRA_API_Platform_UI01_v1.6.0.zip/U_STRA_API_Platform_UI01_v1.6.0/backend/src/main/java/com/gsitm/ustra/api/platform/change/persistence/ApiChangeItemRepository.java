package com.gsitm.ustra.api.platform.change.persistence;
import java.util.List; import org.springframework.data.jpa.repository.JpaRepository;
public interface ApiChangeItemRepository extends JpaRepository<ApiChangeItemEntity,String>{List<ApiChangeItemEntity> findAllByTenantIdAndApiChangeIdOrderByCreatedAtAsc(String tenantId,String apiChangeId);}

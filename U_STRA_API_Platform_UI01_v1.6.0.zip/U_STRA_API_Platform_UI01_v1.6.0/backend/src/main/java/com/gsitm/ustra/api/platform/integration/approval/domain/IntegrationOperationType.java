package com.gsitm.ustra.api.platform.integration.approval.domain;

public enum IntegrationOperationType {
    APPROVAL_CASE_CREATE,
    APPROVAL_STATUS_QUERY,
    GATEWAY_PROVISION,
    GATEWAY_DEPROVISION,
    GATEWAY_STATUS_QUERY
}

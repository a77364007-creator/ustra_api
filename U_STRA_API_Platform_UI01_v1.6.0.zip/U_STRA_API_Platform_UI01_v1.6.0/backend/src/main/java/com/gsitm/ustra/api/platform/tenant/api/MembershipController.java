package com.gsitm.ustra.api.platform.tenant.api;

import com.gsitm.ustra.api.platform.tenant.application.MembershipService;
import com.gsitm.ustra.api.platform.tenant.persistence.MembershipEntity;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.time.Instant;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/memberships")
public class MembershipController {
    private final MembershipService service;

    public MembershipController(MembershipService service) {
        this.service = service;
    }

    @GetMapping
    public List<MembershipResponse> list() {
        return service.list().stream().map(MembershipResponse::from).toList();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public MembershipResponse add(@Valid @RequestBody AddMembershipRequest request) {
        return MembershipResponse.from(service.add(request.principalId(), request.issuer(), request.organizationId(),
                request.effectiveFrom(), request.effectiveTo()));
    }

    @PostMapping("/{membershipId}/deactivate")
    public MembershipResponse deactivate(@PathVariable String membershipId) {
        return MembershipResponse.from(service.deactivate(membershipId));
    }

    public record AddMembershipRequest(
            @NotBlank @Size(max = 200) String principalId,
            @NotBlank @Size(max = 300) String issuer,
            String organizationId,
            @NotNull Instant effectiveFrom,
            Instant effectiveTo) {
    }

    public record MembershipResponse(String membershipId, String organizationId, String principalId,
                                     String issuer, String status, Instant effectiveFrom, Instant effectiveTo) {
        static MembershipResponse from(MembershipEntity entity) {
            return new MembershipResponse(entity.getId(), entity.getOrganizationId(), entity.getPrincipalId(),
                    entity.getIssuer(), entity.getStatus().name(), entity.getEffectiveFrom(), entity.getEffectiveTo());
        }
    }
}

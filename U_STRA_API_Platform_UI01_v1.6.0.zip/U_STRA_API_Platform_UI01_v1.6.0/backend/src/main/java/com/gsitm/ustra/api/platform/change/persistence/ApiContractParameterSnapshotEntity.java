package com.gsitm.ustra.api.platform.change.persistence;
import jakarta.persistence.*;
@Entity @Table(name="api_contract_parameter_snapshot")
public class ApiContractParameterSnapshotEntity {
 @Id @Column(name="api_contract_parameter_snapshot_id",length=36,nullable=false,updatable=false) private String id;
 @Column(name="tenant_id",length=36,nullable=false,updatable=false) private String tenantId;
 @Column(name="api_contract_operation_snapshot_id",length=36,nullable=false,updatable=false) private String operationSnapshotId;
 @Column(name="parameter_location",length=20,nullable=false,updatable=false) private String location;
 @Column(name="parameter_name",length=300,nullable=false,updatable=false) private String name;
 @Column(name="required_flag",nullable=false,updatable=false) private boolean required;
 @Column(name="schema_fingerprint",length=64,nullable=false,updatable=false) private String schemaFingerprint;
 @Column(name="parameter_fingerprint",length=64,nullable=false,updatable=false) private String parameterFingerprint;
 protected ApiContractParameterSnapshotEntity(){}
 public ApiContractParameterSnapshotEntity(String id,String tenantId,String operationSnapshotId,String location,String name,boolean required,String schemaFingerprint,String parameterFingerprint){this.id=id;this.tenantId=tenantId;this.operationSnapshotId=operationSnapshotId;this.location=location;this.name=name;this.required=required;this.schemaFingerprint=schemaFingerprint;this.parameterFingerprint=parameterFingerprint;}
 public String getId(){return id;} public String getTenantId(){return tenantId;} public String getOperationSnapshotId(){return operationSnapshotId;} public String getLocation(){return location;} public String getName(){return name;} public boolean isRequired(){return required;} public String getSchemaFingerprint(){return schemaFingerprint;} public String getParameterFingerprint(){return parameterFingerprint;}
}

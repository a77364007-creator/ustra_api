package com.gsitm.ustra.api.platform.search.persistence;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.Instant;

@Entity
@Table(name = "catalog_search_document")
public class CatalogSearchDocumentEntity {
    @Id @Column(name = "search_document_id", length = 36, nullable = false, updatable = false)
    private String id;
    @Column(name = "tenant_id", length = 36, nullable = false, updatable = false)
    private String tenantId;
    @Column(name = "api_product_id", length = 36, nullable = false, updatable = false)
    private String apiProductId;
    @Column(name = "locale_key", length = 35, nullable = false, updatable = false)
    private String localeKey;
    @Column(name = "product_code", length = 100, nullable = false)
    private String productCode;
    @Column(name = "display_name", length = 200, nullable = false)
    private String displayName;
    @Column(name = "description", columnDefinition = "TEXT")
    private String description;
    @Column(name = "provider_id", length = 36)
    private String providerId;
    @Column(name = "provider_code", length = 100)
    private String providerCode;
    @Column(name = "provider_display_name", length = 200)
    private String providerDisplayName;
    @Column(name = "product_lifecycle_state", length = 30, nullable = false)
    private String productLifecycleState;
    @Column(name = "source_product_row_version", nullable = false)
    private long sourceProductRowVersion;
    @Column(name = "source_localization_revision", nullable = false)
    private long sourceLocalizationRevision;
    @Column(name = "source_localized_content_revision")
    private Long sourceLocalizedContentRevision;
    @Column(name = "projection_hash", length = 64, nullable = false)
    private String projectionHash;
    @Column(name = "projected_at", nullable = false)
    private Instant projectedAt;

    protected CatalogSearchDocumentEntity() {}

    public CatalogSearchDocumentEntity(String id, String tenantId, String apiProductId, String localeKey,
                                       String productCode, String displayName, String description,
                                       String providerId, String providerCode, String providerDisplayName,
                                       String productLifecycleState, long sourceProductRowVersion,
                                       long sourceLocalizationRevision, Long sourceLocalizedContentRevision,
                                       String projectionHash, Instant projectedAt) {
        this.id = id; this.tenantId = tenantId; this.apiProductId = apiProductId; this.localeKey = localeKey;
        this.productCode = productCode; this.displayName = displayName; this.description = description;
        this.providerId = providerId; this.providerCode = providerCode; this.providerDisplayName = providerDisplayName;
        this.productLifecycleState = productLifecycleState; this.sourceProductRowVersion = sourceProductRowVersion;
        this.sourceLocalizationRevision = sourceLocalizationRevision;
        this.sourceLocalizedContentRevision = sourceLocalizedContentRevision;
        this.projectionHash = projectionHash; this.projectedAt = projectedAt;
    }

    public String getId(){return id;} public String getTenantId(){return tenantId;}
    public String getApiProductId(){return apiProductId;} public String getLocaleKey(){return localeKey;}
    public String getProductCode(){return productCode;} public String getDisplayName(){return displayName;}
    public String getDescription(){return description;} public String getProviderId(){return providerId;}
    public String getProviderCode(){return providerCode;} public String getProviderDisplayName(){return providerDisplayName;}
    public String getProductLifecycleState(){return productLifecycleState;}
    public long getSourceProductRowVersion(){return sourceProductRowVersion;}
    public long getSourceLocalizationRevision(){return sourceLocalizationRevision;}
    public Long getSourceLocalizedContentRevision(){return sourceLocalizedContentRevision;}
    public String getProjectionHash(){return projectionHash;} public Instant getProjectedAt(){return projectedAt;}
}

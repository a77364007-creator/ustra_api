package com.gsitm.ustra.api.platform.subscription.entitlement.persistence;
import com.gsitm.ustra.api.platform.subscription.entitlement.domain.*; import jakarta.persistence.*; import java.time.Instant;
@Entity @Table(name="access_fulfillment")
public class AccessFulfillmentEntity {
 @Id @Column(name="access_fulfillment_id",length=36,nullable=false,updatable=false) private String id;
 @Column(name="tenant_id",length=36,nullable=false,updatable=false) private String tenantId;
 @Column(name="entitlement_id",length=36,nullable=false,updatable=false) private String entitlementId;
 @Column(name="fulfillment_revision",nullable=false,updatable=false) private int fulfillmentRevision;
 @Enumerated(EnumType.STRING) @Column(name="fulfillment_type",length=20,nullable=false,updatable=false) private AccessFulfillmentType fulfillmentType;
 @Enumerated(EnumType.STRING) @Column(name="status",length=30,nullable=false) private AccessFulfillmentStatus status;
 @Column(name="idempotency_key",length=200,nullable=false,updatable=false) private String idempotencyKey;
 @Column(name="request_fingerprint",length=64,nullable=false,updatable=false) private String requestFingerprint;
 @Column(name="external_operation_ref",length=500) private String externalOperationRef;
 @Column(name="last_error_code",length=100) private String lastErrorCode;
 @Version @Column(name="row_version",nullable=false) private long rowVersion;
 @Column(name="created_at",nullable=false,updatable=false) private Instant createdAt;
 @Column(name="created_by",length=200,nullable=false,updatable=false) private String createdBy;
 @Column(name="updated_at",nullable=false) private Instant updatedAt;
 @Column(name="updated_by",length=200,nullable=false) private String updatedBy;
 protected AccessFulfillmentEntity(){}
 public AccessFulfillmentEntity(String id,String tenantId,String entitlementId,int revision,AccessFulfillmentType type,String key,String fingerprint,Instant now,String actor){this.id=id;this.tenantId=tenantId;this.entitlementId=entitlementId;this.fulfillmentRevision=revision;this.fulfillmentType=type;this.status=AccessFulfillmentStatus.PENDING;this.idempotencyKey=key;this.requestFingerprint=fingerprint;this.createdAt=now;this.createdBy=actor;this.updatedAt=now;this.updatedBy=actor;}
 public void transition(AccessFulfillmentStatus next,String externalRef,String safeErrorCode,Instant now,String actor){this.status=next;this.externalOperationRef=externalRef;this.lastErrorCode=safeErrorCode;this.updatedAt=now;this.updatedBy=actor;}
 public String getId(){return id;} public String getTenantId(){return tenantId;} public String getEntitlementId(){return entitlementId;} public int getFulfillmentRevision(){return fulfillmentRevision;} public AccessFulfillmentType getFulfillmentType(){return fulfillmentType;} public AccessFulfillmentStatus getStatus(){return status;} public String getIdempotencyKey(){return idempotencyKey;} public String getRequestFingerprint(){return requestFingerprint;} public String getExternalOperationRef(){return externalOperationRef;} public String getLastErrorCode(){return lastErrorCode;} public long getRowVersion(){return rowVersion;}
}

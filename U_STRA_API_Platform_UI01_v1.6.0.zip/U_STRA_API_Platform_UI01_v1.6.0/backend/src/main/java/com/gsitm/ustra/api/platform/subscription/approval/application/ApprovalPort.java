package com.gsitm.ustra.api.platform.subscription.approval.application;
import java.math.BigDecimal; import java.time.Instant; import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
public interface ApprovalPort {
 CaseReference createCase(CaseCommand command); Decision queryDecision(String externalCaseRef);
 record CaseCommand(String tenantId,String subscriptionRequestId,int requestRevisionNo,String snapshotHash,List<String> requestedApiOperationIds){
  public CaseCommand {
   // Copy at the boundary; do not normalize or reinterpret validation inputs.
   requestedApiOperationIds=requestedApiOperationIds==null?null:Collections.unmodifiableList(new ArrayList<>(requestedApiOperationIds));
  }
 }
 record CaseReference(String authorityCode,String externalCaseRef,String workflowVersion){}
 record Decision(String externalCaseRef,DecisionStatus status,int requestRevisionNo,String snapshotHash,List<String> approvedApiOperationIds,List<QuotaDecision> quotaLimits,Instant effectiveFrom,Instant effectiveTo,String evidenceReference,String reviewerReference,Instant decidedAt){
  public Decision {
   // Prevent post-validation list mutation from changing the captured decision.
   approvedApiOperationIds=approvedApiOperationIds==null?null:Collections.unmodifiableList(new ArrayList<>(approvedApiOperationIds));
   quotaLimits=quotaLimits==null?null:Collections.unmodifiableList(new ArrayList<>(quotaLimits));
  }
 }
 record QuotaDecision(String metricCode,BigDecimal limitValue,long windowSeconds,String unitCode){}
 enum DecisionStatus { PENDING, APPROVED, REJECTED }
}

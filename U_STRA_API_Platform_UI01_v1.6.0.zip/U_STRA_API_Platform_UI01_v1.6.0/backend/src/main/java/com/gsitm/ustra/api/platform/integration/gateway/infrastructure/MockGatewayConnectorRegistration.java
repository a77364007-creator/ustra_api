package com.gsitm.ustra.api.platform.integration.gateway.infrastructure;

import com.gsitm.ustra.api.platform.integration.gateway.application.GatewayConnectorRegistration;
import com.gsitm.ustra.api.platform.subscription.gateway.application.GatewayPort;
import com.gsitm.ustra.api.platform.subscription.gateway.infrastructure.MockGatewayAdapter;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Component
@Profile({"local", "test", "mock-integration"})
public class MockGatewayConnectorRegistration implements GatewayConnectorRegistration {
    private final MockGatewayAdapter adapter;

    public MockGatewayConnectorRegistration(MockGatewayAdapter adapter) {
        this.adapter = adapter;
    }

    @Override
    public String adapterCode() {
        return "MOCK_GATEWAY";
    }

    @Override
    public GatewayPort port() {
        return adapter;
    }
}

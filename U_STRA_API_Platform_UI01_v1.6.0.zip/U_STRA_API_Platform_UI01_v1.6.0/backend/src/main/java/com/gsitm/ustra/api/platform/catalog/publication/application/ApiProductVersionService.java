package com.gsitm.ustra.api.platform.catalog.publication.application;

import com.gsitm.ustra.api.platform.audit.AuditService;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiOperationEntity;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiOperationRepository;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiProductRepository;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiVersionEntity;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiVersionRepository;
import com.gsitm.ustra.api.platform.catalog.publication.domain.ApiProductComponentTargetType;
import com.gsitm.ustra.api.platform.catalog.publication.domain.ApiProductVersionState;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.ApiProductComponentEntity;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.ApiProductComponentRepository;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.ApiProductVersionEntity;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.ApiProductVersionRepository;
import com.gsitm.ustra.api.platform.common.error.BusinessException;
import com.gsitm.ustra.api.platform.common.error.ErrorCode;
import com.gsitm.ustra.api.platform.outbox.OutboxService;
import com.gsitm.ustra.api.platform.provider.publishing.application.PublicationReleaseGate;
import com.gsitm.ustra.api.platform.tenant.application.TenantPermissionGuard;
import com.gsitm.ustra.api.platform.tenant.context.TenantContext;
import com.gsitm.ustra.api.platform.tenant.context.TenantContextResolver;
import java.time.Clock;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ApiProductVersionService {
    private final TenantContextResolver contextResolver;
    private final TenantPermissionGuard permissionGuard;
    private final ApiProductRepository productRepository;
    private final ApiProductVersionRepository versionRepository;
    private final ApiProductComponentRepository componentRepository;
    private final ApiVersionRepository apiVersionRepository;
    private final ApiOperationRepository apiOperationRepository;
    private final StateTransitionHistoryService historyService;
    private final AuditService auditService;
    private final OutboxService outboxService;
    private final PublicationReleaseGate publicationReleaseGate;
    private final Clock clock;

    public ApiProductVersionService(TenantContextResolver contextResolver, TenantPermissionGuard permissionGuard,
                                    ApiProductRepository productRepository, ApiProductVersionRepository versionRepository,
                                    ApiProductComponentRepository componentRepository, ApiVersionRepository apiVersionRepository,
                                    ApiOperationRepository apiOperationRepository, StateTransitionHistoryService historyService,
                                    AuditService auditService, OutboxService outboxService,
                                    PublicationReleaseGate publicationReleaseGate, Clock clock) {
        this.contextResolver = contextResolver;
        this.permissionGuard = permissionGuard;
        this.productRepository = productRepository;
        this.versionRepository = versionRepository;
        this.componentRepository = componentRepository;
        this.apiVersionRepository = apiVersionRepository;
        this.apiOperationRepository = apiOperationRepository;
        this.historyService = historyService;
        this.auditService = auditService;
        this.outboxService = outboxService;
        this.publicationReleaseGate = publicationReleaseGate;
        this.clock = clock;
    }

    @Transactional(readOnly = true)
    public List<ApiProductVersionEntity> list(String apiProductId) {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "API_PRODUCT:READ", "API_PRODUCT", apiProductId);
        ownedProduct(context, apiProductId);
        return versionRepository.findAllByTenantIdAndApiProductIdOrderByCreatedAtAsc(context.tenantId(), apiProductId);
    }

    @Transactional(readOnly = true)
    public ApiProductVersionEntity get(String id) {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "API_PRODUCT:READ", "API_PRODUCT_VERSION", id);
        return ownedVersion(context, id);
    }

    @Transactional
    public ApiProductVersionEntity create(String apiProductId, String versionValue) {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "API_PRODUCT:UPDATE", "API_PRODUCT", apiProductId);
        ownedProduct(context, apiProductId);
        String canonical = requireVersionValue(versionValue);
        if (versionRepository.existsByApiProductIdAndVersionValue(apiProductId, canonical)) {
            throw new BusinessException(ErrorCode.API_PRODUCT_VERSION_CONFLICT, HttpStatus.CONFLICT,
                    "동일 API Product에서 이미 사용 중인 version입니다.");
        }
        Instant now = Instant.now(clock);
        return versionRepository.saveAndFlush(new ApiProductVersionEntity(UUID.randomUUID().toString(),
                context.tenantId(), apiProductId, canonical, now, context.principalId()));
    }

    @Transactional(readOnly = true)
    public List<ApiProductComponentEntity> listComponents(String versionId) {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "API_PRODUCT:READ", "API_PRODUCT_VERSION", versionId);
        ownedVersion(context, versionId);
        return componentRepository.findAllByTenantIdAndApiProductVersionIdOrderByCreatedAtAsc(
                context.tenantId(), versionId);
    }

    @Transactional
    public ApiProductComponentEntity addComponent(String versionId, long expectedVersion,
                                                   ApiProductComponentTargetType targetType, String targetId) {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "API_PRODUCT:UPDATE", "API_PRODUCT_VERSION", versionId);
        ApiProductVersionEntity productVersion = ownedVersion(context, versionId);
        requireRevision(productVersion, expectedVersion);
        requireDraft(productVersion);
        if (targetType == null || targetId == null || targetId.isBlank()) {
            throw new BusinessException(ErrorCode.API_PRODUCT_COMPONENT_TARGET_INVALID, HttpStatus.BAD_REQUEST,
                    "Component targetType과 targetId가 필요합니다.");
        }
        String apiVersionId = null;
        String apiOperationId = null;
        if (targetType == ApiProductComponentTargetType.API_VERSION) {
            ApiVersionEntity target = apiVersionRepository.findByIdAndTenantId(targetId, context.tenantId())
                    .orElseThrow(() -> new BusinessException(ErrorCode.API_VERSION_NOT_FOUND, HttpStatus.BAD_REQUEST,
                            "같은 Tenant의 API Version을 찾을 수 없습니다."));
            apiVersionId = target.getId();
        } else if (targetType == ApiProductComponentTargetType.API_OPERATION) {
            ApiOperationEntity target = apiOperationRepository.findByIdAndTenantId(targetId, context.tenantId())
                    .orElseThrow(() -> new BusinessException(ErrorCode.API_OPERATION_NOT_FOUND, HttpStatus.BAD_REQUEST,
                            "같은 Tenant의 API Operation을 찾을 수 없습니다."));
            apiOperationId = target.getId();
        } else {
            throw new BusinessException(ErrorCode.API_PRODUCT_COMPONENT_TARGET_INVALID, HttpStatus.BAD_REQUEST,
                    "지원하지 않는 Component targetType입니다.");
        }
        Instant now = Instant.now(clock);
        ApiProductComponentEntity component = componentRepository.saveAndFlush(new ApiProductComponentEntity(
                UUID.randomUUID().toString(), context.tenantId(), versionId, targetType, apiVersionId,
                apiOperationId, now, context.principalId()));
        productVersion.touch(now, context.principalId());
        versionRepository.saveAndFlush(productVersion);
        return component;
    }

    @Transactional
    public ApiProductVersionEntity removeComponent(String versionId, String componentId, long expectedVersion) {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "API_PRODUCT:UPDATE", "API_PRODUCT_VERSION", versionId);
        ApiProductVersionEntity productVersion = ownedVersion(context, versionId);
        requireRevision(productVersion, expectedVersion);
        requireDraft(productVersion);
        ApiProductComponentEntity component = componentRepository
                .findByIdAndTenantIdAndApiProductVersionId(componentId, context.tenantId(), versionId)
                .orElseThrow(() -> new BusinessException(ErrorCode.API_PRODUCT_COMPONENT_NOT_FOUND, HttpStatus.NOT_FOUND,
                        "API Product Component를 찾을 수 없습니다."));
        componentRepository.delete(component);
        productVersion.touch(Instant.now(clock), context.principalId());
        return versionRepository.saveAndFlush(productVersion);
    }

    @Transactional
    public ApiProductVersionEntity release(String id, long expectedVersion) {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "API_PRODUCT:PUBLISH", "API_PRODUCT_VERSION", id);
        ApiProductVersionEntity entity = ownedVersion(context, id);
        requireRevision(entity, expectedVersion);
        if (entity.getLifecycleState() != ApiProductVersionState.APPROVED) {
            throw new BusinessException(ErrorCode.API_PRODUCT_VERSION_STATE_INVALID, HttpStatus.CONFLICT,
                    "APPROVED 상태의 ProductVersion만 Release할 수 있습니다.");
        }
        publicationReleaseGate.requireReleaseAllowed(context, entity);
        String from = entity.getLifecycleState().name();
        entity.release(Instant.now(clock), context.principalId());
        entity = versionRepository.saveAndFlush(entity);
        publicationReleaseGate.afterProductVersionReleased(context, entity);
        historyService.record(context.tenantId(), "API_PRODUCT_VERSION", entity.getId(), from,
                entity.getLifecycleState().name());
        auditService.success(context.tenantId(), "API_PRODUCT_VERSION_RELEASE", "API_PRODUCT_VERSION", entity.getId(),
                true, Map.of("fromState", from, "toState", entity.getLifecycleState().name()));
        outboxService.enqueue("APIProductVersionReleased", "API_PRODUCT_VERSION", entity.getId(), context.tenantId(),
                Map.of("apiProductVersionId", entity.getId(), "apiProductId", entity.getApiProductId(),
                        "version", entity.getVersionValue()));
        return entity;
    }

    private void ownedProduct(TenantContext context, String apiProductId) {
        productRepository.findByIdAndTenantId(apiProductId, context.tenantId())
                .orElseThrow(() -> new BusinessException(ErrorCode.API_PRODUCT_NOT_FOUND, HttpStatus.NOT_FOUND,
                        "API Product를 찾을 수 없습니다."));
    }

    private ApiProductVersionEntity ownedVersion(TenantContext context, String id) {
        return versionRepository.findByIdAndTenantId(id, context.tenantId())
                .orElseThrow(() -> new BusinessException(ErrorCode.API_PRODUCT_VERSION_NOT_FOUND, HttpStatus.NOT_FOUND,
                        "API Product Version을 찾을 수 없습니다."));
    }

    private void requireRevision(ApiProductVersionEntity entity, long expectedVersion) {
        if (entity.getRowVersion() != expectedVersion) {
            throw new BusinessException(ErrorCode.CONCURRENT_MODIFICATION, HttpStatus.CONFLICT,
                    "API Product Version이 다른 요청에 의해 변경되었습니다.");
        }
    }

    private void requireDraft(ApiProductVersionEntity entity) {
        if (entity.getLifecycleState() != ApiProductVersionState.DRAFT) {
            throw new BusinessException(ErrorCode.API_PRODUCT_VERSION_STATE_INVALID, HttpStatus.CONFLICT,
                    "DRAFT ProductVersion에서만 composition을 변경할 수 있습니다.");
        }
    }

    private String requireVersionValue(String versionValue) {
        String value = versionValue == null ? "" : versionValue.trim();
        if (value.isEmpty() || value.length() > 100) {
            throw new BusinessException(ErrorCode.VALIDATION_ERROR, HttpStatus.BAD_REQUEST,
                    "version은 1~100자의 값이어야 합니다.");
        }
        return value;
    }
}

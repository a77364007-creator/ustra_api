package com.gsitm.ustra.api.platform.search.application;

public record CatalogSearchReindexEvent(String tenantId, String apiProductId, String actor, String reason) {}

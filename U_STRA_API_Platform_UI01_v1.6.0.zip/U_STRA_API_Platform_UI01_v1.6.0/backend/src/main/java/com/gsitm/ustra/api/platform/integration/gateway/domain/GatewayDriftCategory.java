package com.gsitm.ustra.api.platform.integration.gateway.domain;

/**
 * Contract-neutral expected-vs-actual drift vocabulary.
 * Live evidence acquisition remains vendor-contract gated.
 */
public enum GatewayDriftCategory {
    MISSING_RUNTIME_POLICY,
    UNEXPECTED_RUNTIME_POLICY,
    SCOPE_MISMATCH,
    QUOTA_MISMATCH,
    VERSION_MISMATCH,
    EXPIRED_ENTITLEMENT_ACTIVE,
    CREDENTIAL_STATE_MISMATCH,
    TENANT_SCOPE_MISMATCH
}

package com.gsitm.ustra.api.platform.tenant.domain;

public enum CustomerStatus {
    ACTIVE,
    INACTIVE
}

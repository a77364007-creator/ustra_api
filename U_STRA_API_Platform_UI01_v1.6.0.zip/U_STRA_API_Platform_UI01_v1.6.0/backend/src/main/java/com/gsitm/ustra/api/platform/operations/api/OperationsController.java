package com.gsitm.ustra.api.platform.operations.api;
import com.gsitm.ustra.api.platform.operations.application.OperationsQueryService;
import com.gsitm.ustra.api.platform.integration.approval.domain.*;
import com.gsitm.ustra.api.platform.outbox.OutboxStatus;
import java.time.Instant;
import org.springframework.web.bind.annotation.*;

@RestController @RequestMapping("/api/v1/admin/operations")
public class OperationsController {
    private final OperationsQueryService service;
    public OperationsController(OperationsQueryService service){this.service=service;}
    @GetMapping("/summary")
    public OperationsQueryService.Summary summary(){return service.summary();}
    @GetMapping("/integration-operations")
    public OperationsPage<OperationsQueryService.OperationView> operations(@RequestParam IntegrationType type,
            @RequestParam(required=false) IntegrationOperationStatus status,@RequestParam(required=false) Instant from,
            @RequestParam(required=false) Instant to,@RequestParam(defaultValue="0") int page,
            @RequestParam(defaultValue="50") int size,@RequestParam(defaultValue="NEWEST") String order) {
        return service.operations(type,status,from,to,page,size,order);
    }
    @GetMapping("/reconciliation-issues")
    public OperationsPage<OperationsQueryService.IssueView> issues(@RequestParam IntegrationType type,
            @RequestParam(required=false) ReconciliationIssueStatus status,@RequestParam(required=false) Instant from,
            @RequestParam(required=false) Instant to,@RequestParam(defaultValue="0") int page,
            @RequestParam(defaultValue="50") int size,@RequestParam(defaultValue="NEWEST") String order) {
        return service.issues(type,status,from,to,page,size,order);
    }
    @GetMapping("/outbox-events")
    public OperationsPage<OperationsQueryService.OutboxView> outbox(@RequestParam(required=false) OutboxStatus status,
            @RequestParam(required=false) Instant from,@RequestParam(required=false) Instant to,
            @RequestParam(defaultValue="0") int page,@RequestParam(defaultValue="50") int size,
            @RequestParam(defaultValue="NEWEST") String order) {return service.outbox(status,from,to,page,size,order);}
    @GetMapping("/connectors")
    public OperationsPage<OperationsQueryService.ConnectorView> connectors(@RequestParam IntegrationType type,
            @RequestParam(defaultValue="0") int page,@RequestParam(defaultValue="50") int size,
            @RequestParam(defaultValue="NEWEST") String order){return service.connectors(type,page,size,order);}
    @GetMapping("/search-failures")
    public OperationsPage<OperationsQueryService.SearchFailureView> searchFailures(@RequestParam(required=false) Instant from,
            @RequestParam(required=false) Instant to,@RequestParam(defaultValue="0") int page,
            @RequestParam(defaultValue="50") int size,@RequestParam(defaultValue="NEWEST") String order) {
        return service.searchFailures(from,to,page,size,order);
    }
}

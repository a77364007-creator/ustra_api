package com.gsitm.ustra.api.platform.tenant.application;

import com.gsitm.ustra.api.platform.audit.AuditService;
import com.gsitm.ustra.api.platform.common.error.BusinessException;
import com.gsitm.ustra.api.platform.common.error.ErrorCode;
import com.gsitm.ustra.api.platform.outbox.OutboxService;
import com.gsitm.ustra.api.platform.tenant.domain.CustomerStatus;
import com.gsitm.ustra.api.platform.tenant.domain.TenantStatus;
import com.gsitm.ustra.api.platform.tenant.persistence.CustomerEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.CustomerRepository;
import com.gsitm.ustra.api.platform.tenant.persistence.TenantConfigurationEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.TenantConfigurationRepository;
import com.gsitm.ustra.api.platform.tenant.persistence.TenantEntity;
import com.gsitm.ustra.api.platform.tenant.persistence.TenantRepository;
import java.time.Clock;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class PlatformTenantService {
    private final PlatformPermissionGuard platformPermissionGuard;
    private final CustomerRepository customerRepository;
    private final TenantRepository tenantRepository;
    private final TenantConfigurationRepository configurationRepository;
    private final AuditService auditService;
    private final OutboxService outboxService;
    private final Clock clock;

    public PlatformTenantService(PlatformPermissionGuard platformPermissionGuard,
                                 CustomerRepository customerRepository,
                                 TenantRepository tenantRepository,
                                 TenantConfigurationRepository configurationRepository,
                                 AuditService auditService,
                                 OutboxService outboxService,
                                 Clock clock) {
        this.platformPermissionGuard = platformPermissionGuard;
        this.customerRepository = customerRepository;
        this.tenantRepository = tenantRepository;
        this.configurationRepository = configurationRepository;
        this.auditService = auditService;
        this.outboxService = outboxService;
        this.clock = clock;
    }

    @Transactional
    public TenantEntity create(String customerId, String tenantCode, String displayName,
                               String defaultLocale, String timezone) {
        platformPermissionGuard.require("TENANT:CREATE");
        Cp01Validation.locale(defaultLocale);
        Cp01Validation.timezone(timezone);
        CustomerEntity customer = customerRepository.findById(customerId)
                .orElseThrow(() -> new BusinessException(ErrorCode.CUSTOMER_NOT_FOUND, HttpStatus.BAD_REQUEST,
                        "Customer를 찾을 수 없습니다."));
        if (customer.getStatus() != CustomerStatus.ACTIVE) {
            throw new BusinessException(ErrorCode.CUSTOMER_NOT_ACTIVE, HttpStatus.BAD_REQUEST,
                    "Customer가 활성 상태가 아닙니다.");
        }

        Instant now = Instant.now(clock);
        TenantEntity tenant = new TenantEntity(UUID.randomUUID().toString(), customerId,
                tenantCode, displayName, defaultLocale, timezone, now);
        tenantRepository.save(tenant);
        configurationRepository.save(new TenantConfigurationEntity(
                UUID.randomUUID().toString(), tenant.getId(), defaultLocale, timezone, now));
        auditService.success(tenant.getId(), "TENANT_CREATE", "TENANT", tenant.getId(), true,
                Map.of("status", TenantStatus.DRAFT.name(), "tenantCode", tenantCode));
        outboxService.enqueue("TenantCreated", "TENANT", tenant.getId(), tenant.getId(),
                Map.of("tenantId", tenant.getId(), "customerId", customerId));
        return tenant;
    }

    @Transactional(readOnly = true)
    public List<TenantEntity> list() {
        platformPermissionGuard.require("TENANT:MANAGE");
        return tenantRepository.findAllByOrderByCodeAsc();
    }

    @Transactional(readOnly = true)
    public TenantEntity get(String tenantId) {
        platformPermissionGuard.require("TENANT:MANAGE");
        return tenantRepository.findById(tenantId)
                .orElseThrow(() -> tenantNotFound());
    }

    @Transactional
    public TenantEntity activate(String tenantId) {
        platformPermissionGuard.require("TENANT:MANAGE");
        TenantEntity tenant = tenantRepository.findById(tenantId).orElseThrow(this::tenantNotFound);
        if (tenant.getStatus() != TenantStatus.DRAFT && tenant.getStatus() != TenantStatus.SUSPENDED) {
            throw Cp01Validation.validation("현재 Tenant 상태에서는 활성화할 수 없습니다.");
        }
        configurationRepository.findByTenantId(tenantId)
                .orElseThrow(() -> Cp01Validation.validation("Tenant 필수 설정이 없습니다."));
        tenant.activate(Instant.now(clock));
        auditService.success(tenantId, "TENANT_ACTIVATE", "TENANT", tenantId, true,
                Map.of("status", TenantStatus.ACTIVE.name()));
        outboxService.enqueue("TenantActivated", "TENANT", tenantId, tenantId, Map.of("tenantId", tenantId));
        return tenant;
    }

    @Transactional
    public TenantEntity suspend(String tenantId) {
        platformPermissionGuard.require("TENANT:MANAGE");
        TenantEntity tenant = tenantRepository.findById(tenantId).orElseThrow(this::tenantNotFound);
        if (tenant.getStatus() != TenantStatus.ACTIVE) {
            throw Cp01Validation.validation("ACTIVE Tenant만 중지할 수 있습니다.");
        }
        tenant.suspend(Instant.now(clock));
        auditService.success(tenantId, "TENANT_SUSPEND", "TENANT", tenantId, true,
                Map.of("status", TenantStatus.SUSPENDED.name()));
        outboxService.enqueue("TenantSuspended", "TENANT", tenantId, tenantId, Map.of("tenantId", tenantId));
        return tenant;
    }

    @Transactional
    public TenantEntity retire(String tenantId) {
        platformPermissionGuard.require("TENANT:MANAGE");
        TenantEntity tenant = tenantRepository.findById(tenantId).orElseThrow(this::tenantNotFound);
        if (tenant.getStatus() == TenantStatus.RETIRED) {
            throw Cp01Validation.validation("이미 RETIRED 상태입니다.");
        }
        tenant.retire(Instant.now(clock));
        auditService.success(tenantId, "TENANT_RETIRE", "TENANT", tenantId, true,
                Map.of("status", TenantStatus.RETIRED.name()));
        outboxService.enqueue("TenantRetired", "TENANT", tenantId, tenantId, Map.of("tenantId", tenantId));
        return tenant;
    }

    private BusinessException tenantNotFound() {
        return new BusinessException(ErrorCode.TENANT_NOT_FOUND, HttpStatus.NOT_FOUND, "Tenant를 찾을 수 없습니다.");
    }
}

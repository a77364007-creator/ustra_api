package com.gsitm.ustra.api.platform.operations.domain;

public enum RecoveryActionType {
    APPROVAL_STATUS_RECONCILE("APPROVAL_REFERENCE","APPROVAL_INTEGRATION:RECONCILE","APPROVAL_INTEGRATION:READ"),
    GATEWAY_STATUS_RECONCILE("ACCESS_FULFILLMENT","GATEWAY_INTEGRATION:RECONCILE","GATEWAY_INTEGRATION:READ"),
    SEARCH_PRODUCT_REINDEX("API_PRODUCT","CATALOG_SEARCH:REBUILD","API_PRODUCT:READ"),
    SEARCH_TENANT_REBUILD("TENANT","CATALOG_SEARCH:REBUILD","API_PRODUCT:READ");
    private final String targetType;
    private final String executePermission;
    private final String readPermission;
    RecoveryActionType(String targetType,String executePermission,String readPermission) {
        this.targetType=targetType; this.executePermission=executePermission; this.readPermission=readPermission;
    }
    public String targetType(){return targetType;}
    public String executePermission(){return executePermission;}
    public String readPermission(){return readPermission;}
    public String activeKey(String tenantId,String targetId) {
        // Conservative manual-search serialization also excludes tenant rebuild/product reindex overlap.
        return name().startsWith("SEARCH_") ? "SEARCH:"+tenantId : targetType+":"+targetId;
    }
}

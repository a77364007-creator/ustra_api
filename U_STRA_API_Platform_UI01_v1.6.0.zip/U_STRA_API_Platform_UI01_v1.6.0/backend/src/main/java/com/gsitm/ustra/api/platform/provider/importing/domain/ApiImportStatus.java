package com.gsitm.ustra.api.platform.provider.importing.domain;
public enum ApiImportStatus { RECEIVED, VALIDATING, SUCCEEDED, FAILED }

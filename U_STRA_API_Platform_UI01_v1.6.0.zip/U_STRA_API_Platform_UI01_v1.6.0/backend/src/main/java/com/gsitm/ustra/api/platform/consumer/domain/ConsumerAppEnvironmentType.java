package com.gsitm.ustra.api.platform.consumer.domain;

public enum ConsumerAppEnvironmentType {
    DEV, TEST, PROD
}

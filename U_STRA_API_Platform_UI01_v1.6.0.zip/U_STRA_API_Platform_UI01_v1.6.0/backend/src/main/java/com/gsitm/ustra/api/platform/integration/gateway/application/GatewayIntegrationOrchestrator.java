package com.gsitm.ustra.api.platform.integration.gateway.application;

import com.gsitm.ustra.api.platform.integration.approval.domain.IntegrationOperationStatus;
import com.gsitm.ustra.api.platform.subscription.entitlement.domain.AccessFulfillmentType;
import com.gsitm.ustra.api.platform.subscription.gateway.application.GatewayPort;
import org.springframework.stereotype.Service;

@Service
@org.springframework.transaction.annotation.Transactional(propagation = org.springframework.transaction.annotation.Propagation.NOT_SUPPORTED)
public class GatewayIntegrationOrchestrator {
    private final GatewayIntegrationStateService state;
    private final GatewayConnectorRegistry connectors;

    public GatewayIntegrationOrchestrator(
            GatewayIntegrationStateService state,
            GatewayConnectorRegistry connectors) {
        this.state = state;
        this.connectors = connectors;
    }

    public Result process(String tenantId, String fulfillmentId) {
        var prepared = state.prepareEffect(tenantId, fulfillmentId);
        if (!prepared.invokeRequired()) {
            return new Result(
                    prepared.operation().getId(),
                    prepared.operation().getStatus(),
                    null);
        }

        // Resolve adapter before changing Fulfillment to PROCESSING.
        GatewayPort port = connectors.resolve(prepared.connector().getAdapterCode());
        var outbound = state.beginOutbound(
                tenantId,
                prepared.operation().getId(),
                fulfillmentId);
        try {
            GatewayPort.Result external = outbound.fulfillmentType() == AccessFulfillmentType.PROVISION
                    ? port.provision(outbound.command())
                    : port.deprovision(outbound.command());
            var applied = state.completeEffect(
                    tenantId,
                    outbound.operation().getId(),
                    fulfillmentId,
                    external);
            return new Result(
                    applied.operation().getId(),
                    applied.operation().getStatus(),
                    applied.fulfillment().getStatus().name());
        } catch (RuntimeException ex) {
            var applied = state.markOutboundExceptionUnknown(
                    tenantId,
                    outbound.operation().getId(),
                    fulfillmentId,
                    "UNCLASSIFIED_GATEWAY_EXCEPTION");
            return new Result(
                    applied.operation().getId(),
                    applied.operation().getStatus(),
                    applied.fulfillment().getStatus().name());
        }
    }

    public Result reconcile(String tenantId, String fulfillmentId) {
        var prepared = state.prepareQuery(tenantId, fulfillmentId);
        // Resolve adapter before changing Fulfillment to RECONCILING.
        GatewayPort port = connectors.resolve(prepared.connector().getAdapterCode());
        var outbound = state.beginQuery(
                tenantId,
                prepared.queryOperation().getId(),
                fulfillmentId);
        try {
            GatewayPort.Result external = port.queryStatus(outbound.query());
            var applied = state.completeQuery(
                    tenantId,
                    outbound.queryOperation().getId(),
                    fulfillmentId,
                    external);
            return new Result(
                    applied.operation().getId(),
                    applied.operation().getStatus(),
                    applied.fulfillment().getStatus().name());
        } catch (RuntimeException ex) {
            var applied = state.markQueryExceptionUnknown(
                    tenantId,
                    outbound.queryOperation().getId(),
                    fulfillmentId,
                    "UNCLASSIFIED_GATEWAY_QUERY_EXCEPTION");
            return new Result(
                    applied.operation().getId(),
                    applied.operation().getStatus(),
                    applied.fulfillment().getStatus().name());
        }
    }

    public record Result(
            String integrationOperationId,
            IntegrationOperationStatus operationStatus,
            String fulfillmentStatus) {}
}

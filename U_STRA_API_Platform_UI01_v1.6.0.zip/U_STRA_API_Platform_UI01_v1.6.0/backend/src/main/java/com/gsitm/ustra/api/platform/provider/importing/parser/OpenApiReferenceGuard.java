package com.gsitm.ustra.api.platform.provider.importing.parser;

import com.gsitm.ustra.api.platform.common.error.BusinessException;
import com.gsitm.ustra.api.platform.common.error.ErrorCode;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

@Component
public class OpenApiReferenceGuard {
    private static final Pattern REF = Pattern.compile(
            "(?m)(?:\"\\$ref\"|\\$ref)\\s*:\\s*[\"']?([^\"'\\s]+)");

    public void validate(String source) {
        Matcher matcher = REF.matcher(source);
        while (matcher.find()) {
            String ref = matcher.group(1).trim();
            if (ref.startsWith("#/") || ref.equals("#")) {
                continue;
            }
            throw new BusinessException(
                    ErrorCode.OPENAPI_EXTERNAL_REFERENCE_FORBIDDEN,
                    HttpStatus.BAD_REQUEST,
                    "외부 OpenAPI $ref는 허용되지 않습니다.");
        }
    }
}

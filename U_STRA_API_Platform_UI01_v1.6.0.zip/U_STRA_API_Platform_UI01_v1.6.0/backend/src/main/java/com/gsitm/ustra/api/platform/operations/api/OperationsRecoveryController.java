package com.gsitm.ustra.api.platform.operations.api;
import com.gsitm.ustra.api.platform.operations.application.*;
import com.gsitm.ustra.api.platform.operations.domain.RecoveryRequest;
import org.springframework.web.bind.annotation.*;

@RestController @RequestMapping("/api/v1/admin/operations/recovery-actions")
public class OperationsRecoveryController {
    private final RecoveryActionOrchestrator service;
    public OperationsRecoveryController(RecoveryActionOrchestrator service){this.service=service;}
    @PostMapping
    public RecoveryActionService.View execute(@RequestHeader("Idempotency-Key") String key,@RequestBody Body request) {
        return service.execute(key,new RecoveryRequest(request.actionType(),request.targetId(),request.expectedTargetVersion()));
    }
    @GetMapping("/{id}")
    public RecoveryActionService.View get(@PathVariable String id){return service.get(id);}
    public record Body(com.gsitm.ustra.api.platform.operations.domain.RecoveryActionType actionType,
                       String targetId,Long expectedTargetVersion) {
        @com.fasterxml.jackson.annotation.JsonAnySetter
        public void rejectUnknown(String name,Object value) {
            throw new IllegalArgumentException("RECOVERY_UNKNOWN_FIELD");
        }
    }
}

package com.gsitm.ustra.api.platform.provider.publishing.persistence;

import com.gsitm.ustra.api.platform.provider.publishing.domain.PublicationReviewState;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Version;
import java.time.Instant;

@Entity
@Table(name = "publication_review")
public class PublicationReviewEntity {
    @Id
    @Column(name = "publication_review_id", length = 36, nullable = false, updatable = false)
    private String id;

    @Column(name = "tenant_id", length = 36, nullable = false, updatable = false)
    private String tenantId;

    @Column(name = "api_product_id", length = 36, nullable = false, updatable = false)
    private String apiProductId;

    @Column(name = "api_product_version_id", length = 36, nullable = false, updatable = false)
    private String apiProductVersionId;

    @Enumerated(EnumType.STRING)
    @Column(name = "state", length = 30, nullable = false)
    private PublicationReviewState state;

    @Column(name = "submitted_snapshot_hash", length = 64, nullable = false, updatable = false)
    private String submittedSnapshotHash;

    @Column(name = "submitted_snapshot_json", columnDefinition = "LONGTEXT", nullable = false, updatable = false)
    private String submittedSnapshotJson;

    @Column(name = "approved_snapshot_hash", length = 64)
    private String approvedSnapshotHash;

    @Column(name = "approved_snapshot_json", columnDefinition = "LONGTEXT")
    private String approvedSnapshotJson;

    @Column(name = "submitted_product_row_version", nullable = false, updatable = false)
    private long submittedProductRowVersion;

    @Column(name = "submitted_product_localization_revision", nullable = false, updatable = false)
    private long submittedProductLocalizationRevision;

    @Column(name = "submitted_product_version_row_version", nullable = false, updatable = false)
    private long submittedProductVersionRowVersion;

    @Column(name = "submitted_at", nullable = false, updatable = false)
    private Instant submittedAt;

    @Column(name = "submitted_by", length = 200, nullable = false, updatable = false)
    private String submittedBy;

    @Column(name = "decided_at")
    private Instant decidedAt;

    @Column(name = "decided_by", length = 200)
    private String decidedBy;

    @Column(name = "decision_reason_code", length = 100)
    private String decisionReasonCode;

    @Column(name = "decision_summary", length = 500)
    private String decisionSummary;

    @Version
    @Column(name = "row_version", nullable = false)
    private long rowVersion;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @Column(name = "created_by", length = 200, nullable = false, updatable = false)
    private String createdBy;

    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;

    @Column(name = "updated_by", length = 200, nullable = false)
    private String updatedBy;

    protected PublicationReviewEntity() {}

    public PublicationReviewEntity(
            String id,
            String tenantId,
            String apiProductId,
            String apiProductVersionId,
            String submittedSnapshotHash,
            String submittedSnapshotJson,
            long submittedProductRowVersion,
            long submittedProductLocalizationRevision,
            long submittedProductVersionRowVersion,
            Instant now,
            String actor) {
        this.id = id;
        this.tenantId = tenantId;
        this.apiProductId = apiProductId;
        this.apiProductVersionId = apiProductVersionId;
        this.state = PublicationReviewState.SUBMITTED;
        this.submittedSnapshotHash = submittedSnapshotHash;
        this.submittedSnapshotJson = submittedSnapshotJson;
        this.submittedProductRowVersion = submittedProductRowVersion;
        this.submittedProductLocalizationRevision = submittedProductLocalizationRevision;
        this.submittedProductVersionRowVersion = submittedProductVersionRowVersion;
        this.submittedAt = now;
        this.submittedBy = actor;
        this.createdAt = now;
        this.createdBy = actor;
        this.updatedAt = now;
        this.updatedBy = actor;
    }

    public void start(Instant now, String actor) {
        this.state = PublicationReviewState.IN_REVIEW;
        touch(now, actor);
    }

    public void approve(String approvedHash, String approvedJson, String reasonCode, String summary,
                        Instant now, String actor) {
        this.state = PublicationReviewState.APPROVED;
        this.approvedSnapshotHash = approvedHash;
        this.approvedSnapshotJson = approvedJson;
        decide(reasonCode, summary, now, actor);
    }

    public void requestChanges(String reasonCode, String summary, Instant now, String actor) {
        this.state = PublicationReviewState.CHANGES_REQUESTED;
        decide(reasonCode, summary, now, actor);
    }

    public void reject(String reasonCode, String summary, Instant now, String actor) {
        this.state = PublicationReviewState.REJECTED;
        decide(reasonCode, summary, now, actor);
    }

    public void cancel(String reasonCode, String summary, Instant now, String actor) {
        this.state = PublicationReviewState.CANCELLED;
        decide(reasonCode, summary, now, actor);
    }

    private void decide(String reasonCode, String summary, Instant now, String actor) {
        this.decisionReasonCode = reasonCode;
        this.decisionSummary = summary;
        this.decidedAt = now;
        this.decidedBy = actor;
        touch(now, actor);
    }

    private void touch(Instant now, String actor) {
        this.updatedAt = now;
        this.updatedBy = actor;
    }

    public String getId() { return id; }
    public String getTenantId() { return tenantId; }
    public String getApiProductId() { return apiProductId; }
    public String getApiProductVersionId() { return apiProductVersionId; }
    public PublicationReviewState getState() { return state; }
    public String getSubmittedSnapshotHash() { return submittedSnapshotHash; }
    public String getSubmittedSnapshotJson() { return submittedSnapshotJson; }
    public String getApprovedSnapshotHash() { return approvedSnapshotHash; }
    public String getApprovedSnapshotJson() { return approvedSnapshotJson; }
    public long getSubmittedProductRowVersion() { return submittedProductRowVersion; }
    public long getSubmittedProductLocalizationRevision() { return submittedProductLocalizationRevision; }
    public long getSubmittedProductVersionRowVersion() { return submittedProductVersionRowVersion; }
    public Instant getSubmittedAt() { return submittedAt; }
    public String getSubmittedBy() { return submittedBy; }
    public Instant getDecidedAt() { return decidedAt; }
    public String getDecidedBy() { return decidedBy; }
    public String getDecisionReasonCode() { return decisionReasonCode; }
    public String getDecisionSummary() { return decisionSummary; }
    public long getRowVersion() { return rowVersion; }
    public Instant getCreatedAt() { return createdAt; }
    public Instant getUpdatedAt() { return updatedAt; }
}

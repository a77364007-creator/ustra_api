package com.gsitm.ustra.api.platform.tenant.api;

import com.gsitm.ustra.api.platform.tenant.application.TenantConfigurationService;
import com.gsitm.ustra.api.platform.tenant.persistence.TenantConfigurationEntity;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/tenant-config")
public class TenantConfigurationController {
    private final TenantConfigurationService service;

    public TenantConfigurationController(TenantConfigurationService service) {
        this.service = service;
    }

    @GetMapping
    public ResponseEntity<TenantConfigurationResponse> get() {
        TenantConfigurationEntity entity = service.get();
        return ResponseEntity.ok().eTag(VersionHeaderParser.etag(entity.getConfigRevision()))
                .body(TenantConfigurationResponse.from(entity));
    }

    @PatchMapping
    public ResponseEntity<TenantConfigurationResponse> update(
            @RequestHeader(value = HttpHeaders.IF_MATCH, required = false) String ifMatch,
            @Valid @RequestBody UpdateTenantConfigurationRequest request) {
        TenantConfigurationEntity entity = service.update(VersionHeaderParser.parse(ifMatch),
                request.defaultLocale(), request.timezone());
        return ResponseEntity.ok().eTag(VersionHeaderParser.etag(entity.getConfigRevision()))
                .body(TenantConfigurationResponse.from(entity));
    }

    public record UpdateTenantConfigurationRequest(
            @NotBlank @Size(max = 35) String defaultLocale,
            @NotBlank @Size(max = 80) String timezone) {
    }

    public record TenantConfigurationResponse(String tenantId, long revision, String defaultLocale, String timezone) {
        static TenantConfigurationResponse from(TenantConfigurationEntity entity) {
            return new TenantConfigurationResponse(entity.getTenantId(), entity.getConfigRevision(),
                    entity.getDefaultLocale(), entity.getTimezone());
        }
    }
}

package com.gsitm.ustra.api.platform.change.domain;
public enum ApiChangeItemEffect { BREAKING, REVIEW_REQUIRED, INFORMATIONAL }

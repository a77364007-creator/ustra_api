package com.gsitm.ustra.api.platform.tenant.persistence;

import com.gsitm.ustra.api.platform.tenant.domain.MembershipStatus;
import jakarta.persistence.LockModeType;
import java.time.Instant;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface MembershipRepository extends JpaRepository<MembershipEntity, String> {
    Optional<MembershipEntity> findByIdAndTenantId(String id, String tenantId);
    List<MembershipEntity> findAllByTenantIdOrderByCreatedAtAsc(String tenantId);
    List<MembershipEntity> findAllByPrincipalIdAndIssuer(String principalId, String issuer);

    @Query("""
            select m from MembershipEntity m
            where m.principalId = :principalId
              and m.issuer = :issuer
              and m.status = :status
              and m.effectiveFrom <= :now
              and (m.effectiveTo is null or m.effectiveTo > :now)
            """)
    List<MembershipEntity> findEffectiveMemberships(
            @Param("principalId") String principalId,
            @Param("issuer") String issuer,
            @Param("status") MembershipStatus status,
            @Param("now") Instant now);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select m from MembershipEntity m where m.id = :id and m.tenantId = :tenantId")
    Optional<MembershipEntity> findByIdAndTenantIdForUpdate(@Param("id") String id, @Param("tenantId") String tenantId);
}

package com.gsitm.ustra.api.platform.integration.approval.application;
public class ApprovalConnectorFailureException extends RuntimeException {
 private final String safeCode;
 public ApprovalConnectorFailureException(String safeCode){super("Approval connector call failed");this.safeCode=safeCode;}
 public String safeCode(){return safeCode;}
}

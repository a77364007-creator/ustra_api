package com.gsitm.ustra.api.platform.catalog.publication.application;

import com.gsitm.ustra.api.platform.audit.AuditService;
import com.gsitm.ustra.api.platform.catalog.domain.ApiProductLifecycleState;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiProductEntity;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiProductRepository;
import com.gsitm.ustra.api.platform.catalog.publication.domain.ApiProductVersionState;
import com.gsitm.ustra.api.platform.catalog.publication.domain.AudienceScopeType;
import com.gsitm.ustra.api.platform.catalog.publication.domain.CatalogPublicationState;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.ApiProductVersionEntity;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.ApiProductVersionRepository;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.AudienceScopeEntity;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.AudienceScopeRepository;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.CatalogPublicationEntity;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.CatalogPublicationRepository;
import com.gsitm.ustra.api.platform.common.error.BusinessException;
import com.gsitm.ustra.api.platform.common.error.ErrorCode;
import com.gsitm.ustra.api.platform.outbox.OutboxService;
import com.gsitm.ustra.api.platform.search.application.CatalogSearchReindexPublisher;
import com.gsitm.ustra.api.platform.tenant.application.TenantPermissionGuard;
import com.gsitm.ustra.api.platform.tenant.context.TenantContext;
import com.gsitm.ustra.api.platform.tenant.context.TenantContextResolver;
import com.gsitm.ustra.api.platform.tenant.persistence.OrganizationRepository;
import java.time.Clock;
import java.time.Instant;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class CatalogPublicationService {
    public record AudienceScopeInput(AudienceScopeType type, String organizationId) {}

    private final TenantContextResolver contextResolver;
    private final TenantPermissionGuard permissionGuard;
    private final CatalogPublicationRepository publicationRepository;
    private final AudienceScopeRepository audienceRepository;
    private final ApiProductVersionRepository versionRepository;
    private final ApiProductRepository productRepository;
    private final OrganizationRepository organizationRepository;
    private final StateTransitionHistoryService historyService;
    private final AuditService auditService;
    private final OutboxService outboxService;
    private final CatalogSearchReindexPublisher searchReindexPublisher;
    private final Clock clock;

    public CatalogPublicationService(TenantContextResolver contextResolver, TenantPermissionGuard permissionGuard,
                                     CatalogPublicationRepository publicationRepository,
                                     AudienceScopeRepository audienceRepository,
                                     ApiProductVersionRepository versionRepository,
                                     ApiProductRepository productRepository,
                                     OrganizationRepository organizationRepository,
                                     StateTransitionHistoryService historyService, AuditService auditService,
                                     OutboxService outboxService, CatalogSearchReindexPublisher searchReindexPublisher,
                                     Clock clock) {
        this.contextResolver = contextResolver;
        this.permissionGuard = permissionGuard;
        this.publicationRepository = publicationRepository;
        this.audienceRepository = audienceRepository;
        this.versionRepository = versionRepository;
        this.productRepository = productRepository;
        this.organizationRepository = organizationRepository;
        this.historyService = historyService;
        this.auditService = auditService;
        this.outboxService = outboxService;
        this.searchReindexPublisher = searchReindexPublisher;
        this.clock = clock;
    }

    @Transactional(readOnly = true)
    public CatalogPublicationEntity get(String id) {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "API_PRODUCT:READ", "CATALOG_PUBLICATION", id);
        return ownedPublication(context, id);
    }

    @Transactional(readOnly = true)
    public List<AudienceScopeEntity> scopes(String publicationId) {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "API_PRODUCT:READ", "CATALOG_PUBLICATION", publicationId);
        ownedPublication(context, publicationId);
        return audienceRepository.findAllByTenantIdAndCatalogPublicationIdOrderByCreatedAtAsc(
                context.tenantId(), publicationId);
    }

    @Transactional
    public CatalogPublicationEntity create(String apiProductVersionId, List<AudienceScopeInput> scopes) {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "API_PRODUCT:PUBLISH", "CATALOG_PUBLICATION", "new");
        versionRepository.findByIdAndTenantId(apiProductVersionId, context.tenantId())
                .orElseThrow(() -> new BusinessException(ErrorCode.API_PRODUCT_VERSION_NOT_FOUND, HttpStatus.BAD_REQUEST,
                        "같은 Tenant의 API Product Version을 찾을 수 없습니다."));
        validateScopes(context.tenantId(), scopes);
        Instant now = Instant.now(clock);
        CatalogPublicationEntity publication = publicationRepository.saveAndFlush(new CatalogPublicationEntity(
                UUID.randomUUID().toString(), context.tenantId(), apiProductVersionId, now, context.principalId()));
        for (AudienceScopeInput scope : scopes) {
            audienceRepository.save(new AudienceScopeEntity(UUID.randomUUID().toString(), context.tenantId(),
                    publication.getId(), scope.type(), scope.organizationId(), now, context.principalId()));
        }
        audienceRepository.flush();
        return publication;
    }

    @Transactional
    public CatalogPublicationEntity activate(String id, long expectedVersion) {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "API_PRODUCT:PUBLISH", "CATALOG_PUBLICATION", id);
        CatalogPublicationEntity publication = ownedPublication(context, id);
        requireRevision(publication, expectedVersion);
        if (publication.getLifecycleState() != CatalogPublicationState.DRAFT
                && publication.getLifecycleState() != CatalogPublicationState.SUSPENDED) {
            throw invalidState("DRAFT 또는 SUSPENDED Publication만 활성화할 수 있습니다.");
        }
        ApiProductVersionEntity version = versionRepository
                .findByIdAndTenantId(publication.getApiProductVersionId(), context.tenantId())
                .orElseThrow(() -> new BusinessException(ErrorCode.API_PRODUCT_VERSION_NOT_FOUND, HttpStatus.CONFLICT,
                        "Publication의 ProductVersion을 찾을 수 없습니다."));
        if (version.getLifecycleState() != ApiProductVersionState.RELEASED) {
            throw invalidState("RELEASED ProductVersion만 Publication을 활성화할 수 있습니다.");
        }
        ApiProductEntity product = productRepository.findByIdAndTenantId(version.getApiProductId(), context.tenantId())
                .orElseThrow(() -> new BusinessException(ErrorCode.API_PRODUCT_NOT_FOUND, HttpStatus.CONFLICT,
                        "Publication의 API Product를 찾을 수 없습니다."));
        if (product.getLifecycleState() == ApiProductLifecycleState.RETIRED) {
            throw invalidState("RETIRED API Product의 Publication은 활성화할 수 없습니다.");
        }
        if (audienceRepository.countByTenantIdAndCatalogPublicationId(context.tenantId(), id) == 0) {
            throw new BusinessException(ErrorCode.AUDIENCE_SCOPE_REQUIRED, HttpStatus.CONFLICT,
                    "Publication 활성화에는 AudienceScope가 필요합니다.");
        }
        String from = publication.getLifecycleState().name();
        publication.activate(Instant.now(clock), context.principalId());
        publication = publicationRepository.saveAndFlush(publication);
        recordPublicationTransition(context, publication, from, "CATALOG_PUBLICATION_ACTIVATE");
        outboxService.enqueue("CatalogPublicationActivated", "CATALOG_PUBLICATION", publication.getId(),
                context.tenantId(), Map.of("catalogPublicationId", publication.getId(),
                        "apiProductVersionId", publication.getApiProductVersionId()));
        searchReindexPublisher.request(context.tenantId(), version.getApiProductId(), context.principalId(),
                "CATALOG_PUBLICATION_ACTIVATED");
        return publication;
    }

    @Transactional
    public CatalogPublicationEntity suspend(String id, long expectedVersion) {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "API_PRODUCT:PUBLISH", "CATALOG_PUBLICATION", id);
        CatalogPublicationEntity publication = ownedPublication(context, id);
        requireRevision(publication, expectedVersion);
        if (publication.getLifecycleState() != CatalogPublicationState.ACTIVE) {
            throw invalidState("ACTIVE Publication만 중지할 수 있습니다.");
        }
        String from = publication.getLifecycleState().name();
        publication.suspend(Instant.now(clock), context.principalId());
        publication = publicationRepository.saveAndFlush(publication);
        recordPublicationTransition(context, publication, from, "CATALOG_PUBLICATION_SUSPEND");
        searchReindexPublisher.request(context.tenantId(), productIdForPublication(context, publication),
                context.principalId(), "CATALOG_PUBLICATION_SUSPENDED");
        return publication;
    }

    @Transactional
    public CatalogPublicationEntity withdraw(String id, long expectedVersion) {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "API_PRODUCT:PUBLISH", "CATALOG_PUBLICATION", id);
        CatalogPublicationEntity publication = ownedPublication(context, id);
        requireRevision(publication, expectedVersion);
        if (publication.getLifecycleState() != CatalogPublicationState.SUSPENDED) {
            throw invalidState("SUSPENDED Publication만 철회할 수 있습니다.");
        }
        String from = publication.getLifecycleState().name();
        publication.withdraw(Instant.now(clock), context.principalId());
        publication = publicationRepository.saveAndFlush(publication);
        recordPublicationTransition(context, publication, from, "CATALOG_PUBLICATION_WITHDRAW");
        searchReindexPublisher.request(context.tenantId(), productIdForPublication(context, publication),
                context.principalId(), "CATALOG_PUBLICATION_WITHDRAWN");
        return publication;
    }

    private void recordPublicationTransition(TenantContext context, CatalogPublicationEntity publication,
                                             String from, String action) {
        String to = publication.getLifecycleState().name();
        historyService.record(context.tenantId(), "CATALOG_PUBLICATION", publication.getId(), from, to);
        auditService.success(context.tenantId(), action, "CATALOG_PUBLICATION", publication.getId(), true,
                Map.of("fromState", from, "toState", to));
    }

    private void validateScopes(String tenantId, List<AudienceScopeInput> scopes) {
        if (scopes == null || scopes.isEmpty()) {
            throw new BusinessException(ErrorCode.AUDIENCE_SCOPE_REQUIRED, HttpStatus.BAD_REQUEST,
                    "AudienceScope가 하나 이상 필요합니다.");
        }
        if (scopes.stream().anyMatch(java.util.Objects::isNull)) {
            throw new BusinessException(ErrorCode.AUDIENCE_SCOPE_INVALID, HttpStatus.BAD_REQUEST,
                    "AudienceScope 항목은 null일 수 없습니다.");
        }
        boolean hasTenant = scopes.stream().anyMatch(s -> s.type() == AudienceScopeType.TENANT);
        boolean hasOrganization = scopes.stream().anyMatch(s -> s.type() == AudienceScopeType.ORGANIZATION);
        if (hasTenant && hasOrganization) {
            throw new BusinessException(ErrorCode.AUDIENCE_SCOPE_MIXED, HttpStatus.BAD_REQUEST,
                    "TENANT와 ORGANIZATION AudienceScope는 혼합할 수 없습니다.");
        }
        if (hasTenant && scopes.size() != 1) {
            throw new BusinessException(ErrorCode.AUDIENCE_SCOPE_INVALID, HttpStatus.BAD_REQUEST,
                    "TENANT AudienceScope는 하나만 지정할 수 있습니다.");
        }
        Set<String> organizationIds = new HashSet<>();
        for (AudienceScopeInput scope : scopes) {
            if (scope.type() == null) {
                throw new BusinessException(ErrorCode.AUDIENCE_SCOPE_INVALID, HttpStatus.BAD_REQUEST,
                        "AudienceScope type이 필요합니다.");
            }
            if (scope.type() == AudienceScopeType.TENANT) {
                if (scope.organizationId() != null) {
                    throw new BusinessException(ErrorCode.AUDIENCE_SCOPE_INVALID, HttpStatus.BAD_REQUEST,
                            "TENANT scope에는 organizationId를 지정할 수 없습니다.");
                }
            } else if (scope.type() == AudienceScopeType.ORGANIZATION) {
                if (scope.organizationId() == null || scope.organizationId().isBlank()
                        || !organizationIds.add(scope.organizationId())) {
                    throw new BusinessException(ErrorCode.AUDIENCE_SCOPE_INVALID, HttpStatus.BAD_REQUEST,
                            "ORGANIZATION scope에는 중복되지 않는 organizationId가 필요합니다.");
                }
                if (organizationRepository.findByIdAndTenantId(scope.organizationId(), tenantId).isEmpty()) {
                    throw new BusinessException(ErrorCode.AUDIENCE_SCOPE_INVALID, HttpStatus.BAD_REQUEST,
                            "같은 Tenant의 Organization을 찾을 수 없습니다.");
                }
            }
        }
    }

    private String productIdForPublication(TenantContext context, CatalogPublicationEntity publication) {
        return versionRepository.findByIdAndTenantId(publication.getApiProductVersionId(), context.tenantId())
                .map(ApiProductVersionEntity::getApiProductId)
                .orElseThrow(() -> new BusinessException(ErrorCode.API_PRODUCT_VERSION_NOT_FOUND, HttpStatus.CONFLICT,
                        "Publication의 ProductVersion을 찾을 수 없습니다."));
    }

    private CatalogPublicationEntity ownedPublication(TenantContext context, String id) {
        return publicationRepository.findByIdAndTenantId(id, context.tenantId())
                .orElseThrow(() -> new BusinessException(ErrorCode.CATALOG_PUBLICATION_NOT_FOUND, HttpStatus.NOT_FOUND,
                        "Catalog Publication을 찾을 수 없습니다."));
    }

    private void requireRevision(CatalogPublicationEntity publication, long expectedVersion) {
        if (publication.getRowVersion() != expectedVersion) {
            throw new BusinessException(ErrorCode.CONCURRENT_MODIFICATION, HttpStatus.CONFLICT,
                    "Catalog Publication이 다른 요청에 의해 변경되었습니다.");
        }
    }

    private BusinessException invalidState(String message) {
        return new BusinessException(ErrorCode.CATALOG_PUBLICATION_STATE_INVALID, HttpStatus.CONFLICT, message);
    }
}

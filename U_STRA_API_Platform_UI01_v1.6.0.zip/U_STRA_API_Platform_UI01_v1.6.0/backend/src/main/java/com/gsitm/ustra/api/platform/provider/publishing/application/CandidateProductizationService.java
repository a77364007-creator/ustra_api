package com.gsitm.ustra.api.platform.provider.publishing.application;

import com.gsitm.ustra.api.platform.audit.AuditService;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiOperationEntity;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiOperationRepository;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiProductEntity;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiProductRepository;
import com.gsitm.ustra.api.platform.catalog.publication.domain.ApiProductComponentTargetType;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.ApiProductComponentEntity;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.ApiProductComponentRepository;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.ApiProductVersionEntity;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.ApiProductVersionRepository;
import com.gsitm.ustra.api.platform.common.error.BusinessException;
import com.gsitm.ustra.api.platform.common.error.ErrorCode;
import com.gsitm.ustra.api.platform.provider.importing.domain.ApiCandidateState;
import com.gsitm.ustra.api.platform.provider.importing.domain.ApiImportStatus;
import com.gsitm.ustra.api.platform.provider.importing.persistence.ApiCandidateEntity;
import com.gsitm.ustra.api.platform.provider.importing.persistence.ApiCandidateRepository;
import com.gsitm.ustra.api.platform.provider.importing.persistence.ApiCandidateStateHistoryEntity;
import com.gsitm.ustra.api.platform.provider.importing.persistence.ApiCandidateStateHistoryRepository;
import com.gsitm.ustra.api.platform.provider.importing.persistence.ApiImportEntity;
import com.gsitm.ustra.api.platform.provider.importing.persistence.ApiImportRepository;
import com.gsitm.ustra.api.platform.tenant.application.TenantPermissionGuard;
import com.gsitm.ustra.api.platform.tenant.context.TenantContext;
import com.gsitm.ustra.api.platform.tenant.context.TenantContextResolver;
import java.time.Clock;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class CandidateProductizationService {
    private final TenantContextResolver contextResolver;
    private final TenantPermissionGuard permissionGuard;
    private final ApiCandidateRepository candidateRepository;
    private final ApiCandidateStateHistoryRepository historyRepository;
    private final ApiImportRepository importRepository;
    private final ApiProductRepository productRepository;
    private final ApiProductVersionRepository productVersionRepository;
    private final ApiProductComponentRepository componentRepository;
    private final ApiOperationRepository operationRepository;
    private final AuditService auditService;
    private final Clock clock;

    public CandidateProductizationService(
            TenantContextResolver contextResolver,
            TenantPermissionGuard permissionGuard,
            ApiCandidateRepository candidateRepository,
            ApiCandidateStateHistoryRepository historyRepository,
            ApiImportRepository importRepository,
            ApiProductRepository productRepository,
            ApiProductVersionRepository productVersionRepository,
            ApiProductComponentRepository componentRepository,
            ApiOperationRepository operationRepository,
            AuditService auditService,
            Clock clock) {
        this.contextResolver = contextResolver;
        this.permissionGuard = permissionGuard;
        this.candidateRepository = candidateRepository;
        this.historyRepository = historyRepository;
        this.importRepository = importRepository;
        this.productRepository = productRepository;
        this.productVersionRepository = productVersionRepository;
        this.componentRepository = componentRepository;
        this.operationRepository = operationRepository;
        this.auditService = auditService;
        this.clock = clock;
    }

    @Transactional
    public ApiCandidateEntity start(String candidateId, long expectedVersion, String apiProductId) {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "API_CANDIDATE:PRODUCTIZE", "API_CANDIDATE", candidateId);
        ApiCandidateEntity candidate = ownedCandidate(context, candidateId);
        requireRevision(candidate, expectedVersion);
        if (candidate.getState() != ApiCandidateState.ACCEPTED) {
            throw stateInvalid("ACCEPTED Candidate만 Productization을 시작할 수 있습니다.");
        }

        ApiProductEntity product = productRepository.findByIdAndTenantId(apiProductId, context.tenantId())
                .orElseThrow(() -> new BusinessException(ErrorCode.API_PRODUCT_NOT_FOUND, HttpStatus.NOT_FOUND,
                        "API Product를 찾을 수 없습니다."));
        if (!Objects.equals(candidate.getProviderId(), product.getProviderId())) {
            throw new BusinessException(ErrorCode.API_CANDIDATE_PRODUCT_PROVIDER_MISMATCH, HttpStatus.CONFLICT,
                    "Candidate와 API Product의 Provider가 일치해야 합니다.");
        }

        Instant now = Instant.now(clock);
        ApiCandidateState from = candidate.getState();
        candidate.startProductization(product.getId(), now, context.principalId());
        candidate = candidateRepository.saveAndFlush(candidate);
        historyRepository.save(new ApiCandidateStateHistoryEntity(
                UUID.randomUUID().toString(), context.tenantId(), candidate.getId(),
                from, ApiCandidateState.PRODUCTIZING, null, now, context.principalId()));
        auditService.success(context.tenantId(), "API_CANDIDATE_PRODUCTIZATION_STARTED",
                "API_CANDIDATE", candidate.getId(), true,
                Map.of("apiProductId", product.getId(), "providerId", candidate.getProviderId()));
        return candidate;
    }

    @Transactional
    public ApiCandidateEntity complete(String candidateId, long expectedVersion, String apiProductVersionId) {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "API_CANDIDATE:PRODUCTIZE", "API_CANDIDATE", candidateId);
        ApiCandidateEntity candidate = ownedCandidate(context, candidateId);
        requireRevision(candidate, expectedVersion);
        if (candidate.getState() != ApiCandidateState.PRODUCTIZING) {
            throw stateInvalid("PRODUCTIZING Candidate만 완료할 수 있습니다.");
        }

        ApiProductVersionEntity productVersion =
                productVersionRepository.findByIdAndTenantId(apiProductVersionId, context.tenantId())
                        .orElseThrow(() -> new BusinessException(
                                ErrorCode.API_PRODUCT_VERSION_NOT_FOUND, HttpStatus.NOT_FOUND,
                                "API Product Version을 찾을 수 없습니다."));
        if (!Objects.equals(candidate.getApiProductId(), productVersion.getApiProductId())) {
            throw productizationInvalid("선택한 ProductVersion이 Candidate에 연결된 Product에 속하지 않습니다.");
        }

        ApiImportEntity sourceImport = importRepository
                .findByIdAndTenantId(candidate.getCurrentImportId(), context.tenantId())
                .orElseThrow(() -> productizationInvalid("Candidate의 성공 Import 근거를 찾을 수 없습니다."));
        if (sourceImport.getStatus() != ApiImportStatus.SUCCEEDED || sourceImport.getResultApiVersionId() == null) {
            throw productizationInvalid("성공한 OpenAPI Import만 Productization을 완료할 수 있습니다.");
        }

        List<ApiProductComponentEntity> components =
                componentRepository.findAllByTenantIdAndApiProductVersionIdOrderByCreatedAtAsc(
                        context.tenantId(), productVersion.getId());
        boolean containsImportedTarget = components.stream()
                .anyMatch(component -> referencesImportedVersion(
                        context.tenantId(), component, sourceImport.getResultApiVersionId()));
        if (!containsImportedTarget) {
            throw productizationInvalid("ProductVersion composition이 Candidate의 imported API Version을 포함해야 합니다.");
        }

        Instant now = Instant.now(clock);
        ApiCandidateState from = candidate.getState();
        candidate.completeProductization(productVersion.getId(), now, context.principalId());
        candidate = candidateRepository.saveAndFlush(candidate);
        historyRepository.save(new ApiCandidateStateHistoryEntity(
                UUID.randomUUID().toString(), context.tenantId(), candidate.getId(),
                from, ApiCandidateState.COMPLETED, null, now, context.principalId()));
        auditService.success(context.tenantId(), "API_CANDIDATE_PRODUCTIZATION_COMPLETED",
                "API_CANDIDATE", candidate.getId(), true,
                Map.of("apiProductId", candidate.getApiProductId(),
                        "apiProductVersionId", productVersion.getId(),
                        "sourceApiVersionId", sourceImport.getResultApiVersionId()));
        return candidate;
    }

    private boolean referencesImportedVersion(String tenantId, ApiProductComponentEntity component,
                                              String importedApiVersionId) {
        if (component.getTargetType() == ApiProductComponentTargetType.API_VERSION) {
            return Objects.equals(component.getApiVersionId(), importedApiVersionId);
        }
        if (component.getTargetType() == ApiProductComponentTargetType.API_OPERATION) {
            ApiOperationEntity operation = operationRepository
                    .findByIdAndTenantId(component.getApiOperationId(), tenantId)
                    .orElse(null);
            return operation != null && Objects.equals(operation.getApiVersionId(), importedApiVersionId);
        }
        return false;
    }

    private ApiCandidateEntity ownedCandidate(TenantContext context, String candidateId) {
        return candidateRepository.findByIdAndTenantId(candidateId, context.tenantId())
                .orElseThrow(() -> new BusinessException(ErrorCode.API_CANDIDATE_NOT_FOUND, HttpStatus.NOT_FOUND,
                        "API Candidate를 찾을 수 없습니다."));
    }

    private void requireRevision(ApiCandidateEntity candidate, long expectedVersion) {
        if (candidate.getRowVersion() != expectedVersion) {
            throw new BusinessException(ErrorCode.CONCURRENT_MODIFICATION, HttpStatus.CONFLICT,
                    "API Candidate가 다른 요청에 의해 변경되었습니다.");
        }
    }

    private BusinessException stateInvalid(String message) {
        return new BusinessException(ErrorCode.API_CANDIDATE_STATE_INVALID, HttpStatus.CONFLICT, message);
    }

    private BusinessException productizationInvalid(String message) {
        return new BusinessException(ErrorCode.API_CANDIDATE_PRODUCTIZATION_INVALID, HttpStatus.CONFLICT, message);
    }
}

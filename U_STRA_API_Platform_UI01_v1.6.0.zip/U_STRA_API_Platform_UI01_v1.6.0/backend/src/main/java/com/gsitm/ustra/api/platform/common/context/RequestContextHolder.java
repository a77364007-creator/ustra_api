package com.gsitm.ustra.api.platform.common.context;

import java.util.Optional;

public final class RequestContextHolder {
    private static final ThreadLocal<RequestContext> HOLDER = new ThreadLocal<>();

    private RequestContextHolder() {
    }

    public static void set(RequestContext context) {
        HOLDER.set(context);
    }

    public static Optional<RequestContext> get() {
        return Optional.ofNullable(HOLDER.get());
    }

    public static RequestContext required() {
        return get().orElseThrow(() -> new IllegalStateException("RequestContext is not initialized"));
    }

    public static void clear() {
        HOLDER.remove();
    }
}

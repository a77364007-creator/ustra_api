package com.gsitm.ustra.api.platform.change.persistence;
import jakarta.persistence.*; import java.time.Instant;
@Entity @Table(name="consumer_impact")
public class ConsumerImpactEntity {
 @Id @Column(name="consumer_impact_id",length=36,nullable=false,updatable=false) private String id;
 @Column(name="tenant_id",length=36,nullable=false,updatable=false) private String tenantId;
 @Column(name="consumer_impact_analysis_id",length=36,nullable=false,updatable=false) private String analysisId;
 @Column(name="api_change_id",length=36,nullable=false,updatable=false) private String apiChangeId;
 @Column(name="api_product_version_id",length=36,nullable=false,updatable=false) private String apiProductVersionId;
 @Column(name="subscription_id",length=36,nullable=false,updatable=false) private String subscriptionId;
 @Column(name="entitlement_id",length=36,updatable=false) private String entitlementId;
 @Column(name="consumer_app_environment_id",length=36,nullable=false,updatable=false) private String consumerAppEnvironmentId;
 @Column(name="consumer_app_id",length=36,nullable=false,updatable=false) private String consumerAppId;
 @Column(name="subscription_status",length=30,nullable=false,updatable=false) private String subscriptionStatus;
 @Column(name="entitlement_status",length=30,updatable=false) private String entitlementStatus;
 @Column(name="consumer_app_state",length=30,nullable=false,updatable=false) private String consumerAppState;
 @Column(name="impacted_operation_count",nullable=false,updatable=false) private int impactedOperationCount;
 @Column(name="impact_row_hash",length=64,nullable=false,updatable=false) private String impactRowHash;
 @Column(name="analyzed_at",nullable=false,updatable=false) private Instant analyzedAt;
 protected ConsumerImpactEntity(){}
 public ConsumerImpactEntity(String id,String tenantId,String analysisId,String apiChangeId,String apiProductVersionId,String subscriptionId,String entitlementId,String environmentId,String consumerAppId,String subscriptionStatus,String entitlementStatus,String consumerAppState,int impactedOperationCount,String impactRowHash,Instant analyzedAt){this.id=id;this.tenantId=tenantId;this.analysisId=analysisId;this.apiChangeId=apiChangeId;this.apiProductVersionId=apiProductVersionId;this.subscriptionId=subscriptionId;this.entitlementId=entitlementId;this.consumerAppEnvironmentId=environmentId;this.consumerAppId=consumerAppId;this.subscriptionStatus=subscriptionStatus;this.entitlementStatus=entitlementStatus;this.consumerAppState=consumerAppState;this.impactedOperationCount=impactedOperationCount;this.impactRowHash=impactRowHash;this.analyzedAt=analyzedAt;}
 public String getId(){return id;} public String getTenantId(){return tenantId;} public String getAnalysisId(){return analysisId;} public String getApiChangeId(){return apiChangeId;} public String getApiProductVersionId(){return apiProductVersionId;} public String getSubscriptionId(){return subscriptionId;} public String getEntitlementId(){return entitlementId;} public String getConsumerAppEnvironmentId(){return consumerAppEnvironmentId;} public String getConsumerAppId(){return consumerAppId;} public String getSubscriptionStatus(){return subscriptionStatus;} public String getEntitlementStatus(){return entitlementStatus;} public String getConsumerAppState(){return consumerAppState;} public int getImpactedOperationCount(){return impactedOperationCount;} public String getImpactRowHash(){return impactRowHash;} public Instant getAnalyzedAt(){return analyzedAt;}
}

package com.gsitm.ustra.api.platform.subscription.persistence;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SubscriptionRequestRepository extends JpaRepository<SubscriptionRequestEntity, String> {
    Optional<SubscriptionRequestEntity> findByIdAndTenantId(String id, String tenantId);
}

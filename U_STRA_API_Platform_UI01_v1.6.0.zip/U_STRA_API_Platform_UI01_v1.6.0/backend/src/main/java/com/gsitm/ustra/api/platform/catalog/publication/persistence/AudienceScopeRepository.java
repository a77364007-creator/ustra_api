package com.gsitm.ustra.api.platform.catalog.publication.persistence;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AudienceScopeRepository extends JpaRepository<AudienceScopeEntity, String> {
    List<AudienceScopeEntity> findAllByTenantIdAndCatalogPublicationIdOrderByCreatedAtAsc(String tenantId, String catalogPublicationId);
    long countByTenantIdAndCatalogPublicationId(String tenantId, String catalogPublicationId);
}

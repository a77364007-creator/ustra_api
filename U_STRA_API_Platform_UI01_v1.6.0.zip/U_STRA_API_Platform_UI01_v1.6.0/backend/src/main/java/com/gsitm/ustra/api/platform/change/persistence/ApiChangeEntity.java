package com.gsitm.ustra.api.platform.change.persistence;

import com.gsitm.ustra.api.platform.change.domain.ApiChangeAssessmentStatus;
import com.gsitm.ustra.api.platform.change.domain.CompatibilityResult;
import jakarta.persistence.*;
import java.time.Instant;

@Entity @Table(name="api_change")
public class ApiChangeEntity {
 @Id @Column(name="api_change_id",length=36,nullable=false,updatable=false) private String id;
 @Column(name="tenant_id",length=36,nullable=false,updatable=false) private String tenantId;
 @Column(name="api_id",length=36,nullable=false,updatable=false) private String apiId;
 @Column(name="baseline_api_version_id",length=36,nullable=false,updatable=false) private String baselineApiVersionId;
 @Column(name="target_api_version_id",length=36,nullable=false,updatable=false) private String targetApiVersionId;
 @Enumerated(EnumType.STRING) @Column(name="assessment_status",length=30,nullable=false) private ApiChangeAssessmentStatus assessmentStatus;
 @Enumerated(EnumType.STRING) @Column(name="compatibility_result",length=30) private CompatibilityResult compatibilityResult;
 @Column(name="baseline_structural_hash",length=80,nullable=false,updatable=false) private String baselineStructuralHash;
 @Column(name="target_structural_hash",length=80,nullable=false,updatable=false) private String targetStructuralHash;
 @Column(name="rule_set_version",length=50,nullable=false,updatable=false) private String ruleSetVersion;
 @Column(name="change_summary_hash",length=64) private String changeSummaryHash;
 @Column(name="idempotency_key",length=200,nullable=false,updatable=false) private String idempotencyKey;
 @Column(name="request_fingerprint",length=64,nullable=false,updatable=false) private String requestFingerprint;
 @Column(name="assessed_at") private Instant assessedAt;
 @Column(name="assessed_by",length=200) private String assessedBy;
 @Version @Column(name="row_version",nullable=false) private long rowVersion;
 @Column(name="created_at",nullable=false,updatable=false) private Instant createdAt;
 @Column(name="created_by",length=200,nullable=false,updatable=false) private String createdBy;
 @Column(name="updated_at",nullable=false) private Instant updatedAt;
 @Column(name="updated_by",length=200,nullable=false) private String updatedBy;
 protected ApiChangeEntity(){}
 public ApiChangeEntity(String id,String tenantId,String apiId,String baselineApiVersionId,String targetApiVersionId,String baselineStructuralHash,String targetStructuralHash,String ruleSetVersion,String idempotencyKey,String requestFingerprint,Instant now,String actor){this.id=id;this.tenantId=tenantId;this.apiId=apiId;this.baselineApiVersionId=baselineApiVersionId;this.targetApiVersionId=targetApiVersionId;this.assessmentStatus=ApiChangeAssessmentStatus.PENDING;this.baselineStructuralHash=baselineStructuralHash;this.targetStructuralHash=targetStructuralHash;this.ruleSetVersion=ruleSetVersion;this.idempotencyKey=idempotencyKey;this.requestFingerprint=requestFingerprint;this.createdAt=now;this.createdBy=actor;this.updatedAt=now;this.updatedBy=actor;}
 public void begin(Instant now,String actor){this.assessmentStatus=ApiChangeAssessmentStatus.ASSESSING;touch(now,actor);}
 public void complete(CompatibilityResult result,String summaryHash,Instant now,String actor){this.assessmentStatus=ApiChangeAssessmentStatus.ASSESSED;this.compatibilityResult=result;this.changeSummaryHash=summaryHash;this.assessedAt=now;this.assessedBy=actor;touch(now,actor);}
 public void fail(Instant now,String actor){this.assessmentStatus=ApiChangeAssessmentStatus.FAILED;this.assessedAt=now;this.assessedBy=actor;touch(now,actor);}
 private void touch(Instant now,String actor){this.updatedAt=now;this.updatedBy=actor;}
 public String getId(){return id;} public String getTenantId(){return tenantId;} public String getApiId(){return apiId;} public String getBaselineApiVersionId(){return baselineApiVersionId;} public String getTargetApiVersionId(){return targetApiVersionId;} public ApiChangeAssessmentStatus getAssessmentStatus(){return assessmentStatus;} public CompatibilityResult getCompatibilityResult(){return compatibilityResult;} public String getBaselineStructuralHash(){return baselineStructuralHash;} public String getTargetStructuralHash(){return targetStructuralHash;} public String getRuleSetVersion(){return ruleSetVersion;} public String getChangeSummaryHash(){return changeSummaryHash;} public String getIdempotencyKey(){return idempotencyKey;} public String getRequestFingerprint(){return requestFingerprint;} public Instant getAssessedAt(){return assessedAt;} public String getAssessedBy(){return assessedBy;} public long getRowVersion(){return rowVersion;} public Instant getCreatedAt(){return createdAt;} public String getCreatedBy(){return createdBy;} public Instant getUpdatedAt(){return updatedAt;} public String getUpdatedBy(){return updatedBy;}
}

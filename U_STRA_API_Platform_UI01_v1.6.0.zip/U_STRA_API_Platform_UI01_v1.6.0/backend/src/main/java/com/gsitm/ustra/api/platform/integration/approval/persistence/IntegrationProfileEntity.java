package com.gsitm.ustra.api.platform.integration.approval.persistence;
import com.gsitm.ustra.api.platform.integration.approval.domain.IntegrationType;
import jakarta.persistence.*; import java.time.Instant;
@Entity @Table(name="integration_profile") public class IntegrationProfileEntity {
 @Id @Column(name="integration_profile_id",length=36,nullable=false,updatable=false) private String id;
 @Column(name="tenant_id",length=36,nullable=false,updatable=false) private String tenantId;
 @Column(name="profile_code",length=100,nullable=false) private String profileCode;
 @Enumerated(EnumType.STRING) @Column(name="integration_type",length=40,nullable=false) private IntegrationType integrationType;
 @Column(name="display_name",length=200,nullable=false) private String displayName;
 @Column(name="enabled",nullable=false) private boolean enabled;
 @Version @Column(name="row_version",nullable=false) private long rowVersion;
 @Column(name="created_at",nullable=false,updatable=false) private Instant createdAt; @Column(name="created_by",length=200,nullable=false,updatable=false) private String createdBy;
 @Column(name="updated_at",nullable=false) private Instant updatedAt; @Column(name="updated_by",length=200,nullable=false) private String updatedBy;
 protected IntegrationProfileEntity(){}
 public IntegrationProfileEntity(String id,String tenantId,String code,IntegrationType type,String name,boolean enabled,Instant now,String actor){this.id=id;this.tenantId=tenantId;this.profileCode=code;this.integrationType=type;this.displayName=name;this.enabled=enabled;this.createdAt=now;this.createdBy=actor;this.updatedAt=now;this.updatedBy=actor;}
 public String getId(){return id;} public String getTenantId(){return tenantId;} public String getProfileCode(){return profileCode;} public IntegrationType getIntegrationType(){return integrationType;} public String getDisplayName(){return displayName;} public boolean isEnabled(){return enabled;} public long getRowVersion(){return rowVersion;}
}

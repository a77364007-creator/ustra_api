package com.gsitm.ustra.api.platform.outbox;

public enum OutboxStatus {
    PENDING,
    PUBLISHED,
    FAILED
}

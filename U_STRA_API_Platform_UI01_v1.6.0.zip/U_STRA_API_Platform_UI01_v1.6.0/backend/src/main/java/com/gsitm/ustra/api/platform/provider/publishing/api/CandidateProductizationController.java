package com.gsitm.ustra.api.platform.provider.publishing.api;

import com.gsitm.ustra.api.platform.provider.importing.persistence.ApiCandidateEntity;
import com.gsitm.ustra.api.platform.provider.publishing.application.CandidateProductizationService;
import com.gsitm.ustra.api.platform.tenant.api.VersionHeaderParser;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/api-candidates")
public class CandidateProductizationController {
    private final CandidateProductizationService service;

    public CandidateProductizationController(CandidateProductizationService service) {
        this.service = service;
    }

    @PostMapping("/{id}/productization/start")
    public ResponseEntity<CandidateResponse> start(
            @PathVariable String id,
            @RequestHeader(value = HttpHeaders.IF_MATCH, required = false) String ifMatch,
            @Valid @RequestBody StartProductizationRequest request) {
        ApiCandidateEntity entity = service.start(id, VersionHeaderParser.parse(ifMatch), request.apiProductId());
        return ResponseEntity.ok()
                .eTag(VersionHeaderParser.etag(entity.getRowVersion()))
                .body(CandidateResponse.from(entity));
    }

    @PostMapping("/{id}/productization/complete")
    public ResponseEntity<CandidateResponse> complete(
            @PathVariable String id,
            @RequestHeader(value = HttpHeaders.IF_MATCH, required = false) String ifMatch,
            @Valid @RequestBody CompleteProductizationRequest request) {
        ApiCandidateEntity entity =
                service.complete(id, VersionHeaderParser.parse(ifMatch), request.apiProductVersionId());
        return ResponseEntity.ok()
                .eTag(VersionHeaderParser.etag(entity.getRowVersion()))
                .body(CandidateResponse.from(entity));
    }

    public record StartProductizationRequest(@NotBlank String apiProductId) {}
    public record CompleteProductizationRequest(@NotBlank String apiProductVersionId) {}

    public record CandidateResponse(
            String apiCandidateId,
            String state,
            String apiProductId,
            String apiProductVersionId,
            long revision) {
        static CandidateResponse from(ApiCandidateEntity entity) {
            return new CandidateResponse(entity.getId(), entity.getState().name(),
                    entity.getApiProductId(), entity.getApiProductVersionId(), entity.getRowVersion());
        }
    }
}

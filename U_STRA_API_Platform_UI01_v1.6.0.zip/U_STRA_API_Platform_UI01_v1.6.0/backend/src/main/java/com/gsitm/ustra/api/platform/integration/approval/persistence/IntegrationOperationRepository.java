package com.gsitm.ustra.api.platform.integration.approval.persistence;
import com.gsitm.ustra.api.platform.integration.approval.domain.*; import java.util.List; import java.util.Optional; import org.springframework.data.jpa.repository.JpaRepository;
public interface IntegrationOperationRepository extends JpaRepository<IntegrationOperationEntity, String>, org.springframework.data.jpa.repository.JpaSpecificationExecutor<IntegrationOperationEntity>{Optional<IntegrationOperationEntity> findByIdAndTenantId(String id,String tenantId);Optional<IntegrationOperationEntity> findByTenantIdAndOperationTypeAndAggregateIdAndAggregateRevision(String tenantId,IntegrationOperationType type,String aggregateId,Integer revision);List<IntegrationOperationEntity> findAllByTenantIdOrderByCreatedAtDesc(String tenantId);List<IntegrationOperationEntity> findAllByTenantIdAndStatusOrderByCreatedAtDesc(String tenantId,IntegrationOperationStatus status);List<IntegrationOperationEntity> findAllByTenantIdAndAggregateTypeAndAggregateIdOrderByCreatedAtDesc(String tenantId,String aggregateType,String aggregateId);
 @org.springframework.data.jpa.repository.Query("select o from IntegrationOperationEntity o where o.tenantId=:tenantId and o.operationType in :types and (:status is null or o.status=:status) order by o.createdAt desc, o.id desc")
 List<IntegrationOperationEntity> findScoped(@org.springframework.data.repository.query.Param("tenantId") String tenantId,
     @org.springframework.data.repository.query.Param("types") java.util.Collection<IntegrationOperationType> types,
     @org.springframework.data.repository.query.Param("status") IntegrationOperationStatus status);
 @org.springframework.data.jpa.repository.Lock(jakarta.persistence.LockModeType.PESSIMISTIC_WRITE)
 @org.springframework.data.jpa.repository.Query("select o from IntegrationOperationEntity o where o.tenantId=:tenantId and o.id=:id")
 Optional<IntegrationOperationEntity> lockOwned(@org.springframework.data.repository.query.Param("tenantId") String tenantId,
     @org.springframework.data.repository.query.Param("id") String id);
}

package com.gsitm.ustra.api.platform.outbox;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class OutboxWorker {
    private static final Logger log = LoggerFactory.getLogger(OutboxWorker.class);

    private final OutboxEventRepository repository;
    private final OutboxDispatchService dispatchService;
    private final boolean enabled;

    public OutboxWorker(OutboxEventRepository repository,
                        OutboxDispatchService dispatchService,
                        @Value("${app.outbox.worker-enabled:false}") boolean enabled) {
        this.repository = repository;
        this.dispatchService = dispatchService;
        this.enabled = enabled;
        dispatchService.requireWorkerConfiguration(enabled);
    }

    @Scheduled(fixedDelayString = "${app.outbox.poll-delay-ms:5000}")
    public void poll() {
        if (!enabled) {
            return;
        }
        List<OutboxEventEntity> pending = repository.findTop100ByStatusOrderByCreatedAtAsc(OutboxStatus.PENDING);
        for (OutboxEventEntity event : pending) {
            if (!dispatchService.dispatchOne(event.getId())) {
                log.warn("Outbox dispatch remains pending eventId={}", event.getEventId());
            }
        }
    }
}

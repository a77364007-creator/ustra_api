package com.gsitm.ustra.api.platform.change.application;

import com.gsitm.ustra.api.platform.audit.AuditService;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiOperationEntity;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiOperationRepository;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.ApiProductComponentEntity;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.ApiProductComponentRepository;
import com.gsitm.ustra.api.platform.change.domain.ApiChangeAssessmentStatus;
import com.gsitm.ustra.api.platform.change.domain.ApiChangeKind;
import com.gsitm.ustra.api.platform.change.domain.CompatibilityResult;
import com.gsitm.ustra.api.platform.change.persistence.ApiChangeEntity;
import com.gsitm.ustra.api.platform.change.persistence.ApiChangeItemEntity;
import com.gsitm.ustra.api.platform.change.persistence.ApiChangeItemRepository;
import com.gsitm.ustra.api.platform.change.persistence.ApiChangeRepository;
import com.gsitm.ustra.api.platform.change.persistence.ConsumerImpactAnalysisEntity;
import com.gsitm.ustra.api.platform.change.persistence.ConsumerImpactAnalysisRepository;
import com.gsitm.ustra.api.platform.change.persistence.ConsumerImpactEntity;
import com.gsitm.ustra.api.platform.change.persistence.ConsumerImpactRepository;
import com.gsitm.ustra.api.platform.common.error.BusinessException;
import com.gsitm.ustra.api.platform.common.error.ErrorCode;
import com.gsitm.ustra.api.platform.consumer.persistence.ConsumerAppEntity;
import com.gsitm.ustra.api.platform.consumer.persistence.ConsumerAppEnvironmentEntity;
import com.gsitm.ustra.api.platform.consumer.persistence.ConsumerAppEnvironmentRepository;
import com.gsitm.ustra.api.platform.consumer.persistence.ConsumerAppRepository;
import com.gsitm.ustra.api.platform.outbox.OutboxService;
import com.gsitm.ustra.api.platform.provider.importing.application.Sha256Service;
import com.gsitm.ustra.api.platform.subscription.entitlement.persistence.EntitlementEntity;
import com.gsitm.ustra.api.platform.subscription.entitlement.persistence.EntitlementRepository;
import com.gsitm.ustra.api.platform.subscription.entitlement.persistence.SubscriptionEntity;
import com.gsitm.ustra.api.platform.subscription.entitlement.persistence.SubscriptionRepository;
import com.gsitm.ustra.api.platform.tenant.application.TenantPermissionGuard;
import com.gsitm.ustra.api.platform.tenant.context.TenantContext;
import com.gsitm.ustra.api.platform.tenant.context.TenantContextResolver;
import java.time.Clock;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TreeMap;
import java.util.UUID;
import java.util.stream.Collectors;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ConsumerImpactService {
    private final TenantContextResolver contextResolver;
    private final TenantPermissionGuard permissionGuard;
    private final ApiChangeRepository changeRepository;
    private final ApiChangeItemRepository itemRepository;
    private final ApiOperationRepository operationRepository;
    private final ApiProductComponentRepository componentRepository;
    private final SubscriptionRepository subscriptionRepository;
    private final EntitlementRepository entitlementRepository;
    private final ConsumerAppEnvironmentRepository environmentRepository;
    private final ConsumerAppRepository appRepository;
    private final ConsumerImpactAnalysisRepository analysisRepository;
    private final ConsumerImpactRepository impactRepository;
    private final Sha256Service sha256Service;
    private final AuditService auditService;
    private final OutboxService outboxService;
    private final Clock clock;

    public ConsumerImpactService(
            TenantContextResolver contextResolver,
            TenantPermissionGuard permissionGuard,
            ApiChangeRepository changeRepository,
            ApiChangeItemRepository itemRepository,
            ApiOperationRepository operationRepository,
            ApiProductComponentRepository componentRepository,
            SubscriptionRepository subscriptionRepository,
            EntitlementRepository entitlementRepository,
            ConsumerAppEnvironmentRepository environmentRepository,
            ConsumerAppRepository appRepository,
            ConsumerImpactAnalysisRepository analysisRepository,
            ConsumerImpactRepository impactRepository,
            Sha256Service sha256Service,
            AuditService auditService,
            OutboxService outboxService,
            Clock clock) {
        this.contextResolver = contextResolver;
        this.permissionGuard = permissionGuard;
        this.changeRepository = changeRepository;
        this.itemRepository = itemRepository;
        this.operationRepository = operationRepository;
        this.componentRepository = componentRepository;
        this.subscriptionRepository = subscriptionRepository;
        this.entitlementRepository = entitlementRepository;
        this.environmentRepository = environmentRepository;
        this.appRepository = appRepository;
        this.analysisRepository = analysisRepository;
        this.impactRepository = impactRepository;
        this.sha256Service = sha256Service;
        this.auditService = auditService;
        this.outboxService = outboxService;
        this.clock = clock;
    }

    @Transactional
    public ConsumerImpactAnalysisEntity analyze(String apiChangeId) {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "CONSUMER_IMPACT:ANALYZE", "API_CHANGE", apiChangeId);
        ApiChangeEntity change = ownedChange(context, apiChangeId);
        if (change.getAssessmentStatus() != ApiChangeAssessmentStatus.ASSESSED) {
            throw new BusinessException(ErrorCode.API_CHANGE_STATE_INVALID, HttpStatus.CONFLICT,
                    "ASSESSED API Change만 Consumer Impact를 분석할 수 있습니다.");
        }

        List<DraftImpact> drafts = materializeDrafts(context, change);
        String basisHash = basisHash(change, drafts);
        ConsumerImpactAnalysisEntity prior = analysisRepository
                .findByTenantIdAndApiChangeIdAndImpactBasisHash(context.tenantId(), change.getId(), basisHash)
                .orElse(null);
        if (prior != null) return prior;

        Instant now = Instant.now(clock);
        ConsumerImpactAnalysisEntity analysis = analysisRepository.saveAndFlush(new ConsumerImpactAnalysisEntity(
                UUID.randomUUID().toString(), context.tenantId(), change.getId(), basisHash,
                drafts.size(), now, context.principalId()));
        for (DraftImpact draft : drafts) {
            impactRepository.save(new ConsumerImpactEntity(
                    UUID.randomUUID().toString(), context.tenantId(), analysis.getId(), change.getId(),
                    draft.apiProductVersionId(), draft.subscriptionId(), draft.entitlementId(),
                    draft.environmentId(), draft.consumerAppId(), draft.subscriptionStatus(),
                    draft.entitlementStatus(), draft.consumerAppState(), draft.impactedOperationCount(),
                    rowHash(draft), now));
        }

        auditService.success(context.tenantId(), "CONSUMER_IMPACT_ANALYZED", "API_CHANGE", change.getId(), true,
                Map.of("consumerImpactAnalysisId", analysis.getId(), "impactBasisHash", basisHash,
                        "materializedRowCount", drafts.size()));
        outboxService.enqueue("ConsumerImpactAnalyzed", "API_CHANGE", change.getId(), context.tenantId(),
                Map.of("apiChangeId", change.getId(), "consumerImpactAnalysisId", analysis.getId(),
                        "impactBasisHash", basisHash, "materializedRowCount", drafts.size()));
        return analysis;
    }

    @Transactional(readOnly = true)
    public List<ConsumerImpactEntity> latestImpacts(String apiChangeId) {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "CONSUMER_IMPACT:READ", "API_CHANGE", apiChangeId);
        ownedChange(context, apiChangeId);
        ConsumerImpactAnalysisEntity analysis = latestAnalysis(context, apiChangeId);
        if (analysis == null) return List.of();
        return impactRepository.findAllByTenantIdAndAnalysisIdOrderBySubscriptionIdAscEntitlementIdAsc(
                context.tenantId(), analysis.getId());
    }

    @Transactional(readOnly = true)
    public ImpactSummary summary(String apiChangeId) {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "CONSUMER_IMPACT:READ", "API_CHANGE", apiChangeId);
        ownedChange(context, apiChangeId);
        ConsumerImpactAnalysisEntity analysis = latestAnalysis(context, apiChangeId);
        if (analysis == null) return new ImpactSummary(null, 0, 0, Map.of(), Map.of());
        List<ConsumerImpactEntity> rows = impactRepository
                .findAllByTenantIdAndAnalysisIdOrderBySubscriptionIdAscEntitlementIdAsc(
                        context.tenantId(), analysis.getId());
        long distinctSubscriptions = rows.stream().map(ConsumerImpactEntity::getSubscriptionId).distinct().count();
        Map<String, Long> bySubscriptionStatus = rows.stream().collect(Collectors.groupingBy(
                ConsumerImpactEntity::getSubscriptionStatus, TreeMap::new, Collectors.counting()));
        Map<String, Long> byEntitlementStatus = rows.stream()
                .filter(r -> r.getEntitlementStatus() != null)
                .collect(Collectors.groupingBy(
                        ConsumerImpactEntity::getEntitlementStatus, TreeMap::new, Collectors.counting()));
        return new ImpactSummary(analysis.getId(), rows.size(), distinctSubscriptions,
                bySubscriptionStatus, byEntitlementStatus);
    }

    private List<DraftImpact> materializeDrafts(TenantContext context, ApiChangeEntity change) {
        if (change.getCompatibilityResult() == CompatibilityResult.NO_CONTRACT_CHANGE) return List.of();
        List<ApiOperationEntity> baselineOperations = operationRepository
                .findAllByTenantIdAndApiVersionIdOrderByIdAsc(context.tenantId(), change.getBaselineApiVersionId());
        Map<String, ApiOperationEntity> baselineByIdentity = baselineOperations.stream().collect(Collectors.toMap(
                o -> o.getMethod() + " " + o.getNormalizedPath(), o -> o, (a, b) -> a, LinkedHashMap::new));
        List<ApiChangeItemEntity> items = itemRepository
                .findAllByTenantIdAndApiChangeIdOrderByCreatedAtAsc(context.tenantId(), change.getId());

        Set<String> changedOperationIds = new LinkedHashSet<>();
        for (ApiChangeItemEntity item : items) {
            if (item.getMethod() == null || item.getNormalizedPath() == null
                    || item.getChangeKind() == ApiChangeKind.OPERATION_ADDED) continue;
            ApiOperationEntity operation = baselineByIdentity.get(item.getMethod() + " " + item.getNormalizedPath());
            if (operation != null) changedOperationIds.add(operation.getId());
        }
        if (change.getCompatibilityResult() == CompatibilityResult.REVIEW_REQUIRED && changedOperationIds.isEmpty()) {
            baselineOperations.forEach(o -> changedOperationIds.add(o.getId()));
        }

        Map<String, Set<String>> impactedByProductVersion = new LinkedHashMap<>();
        for (ApiProductComponentEntity component : componentRepository
                .findAllByTenantIdAndApiVersionId(context.tenantId(), change.getBaselineApiVersionId())) {
            impactedByProductVersion.computeIfAbsent(component.getApiProductVersionId(), ignored -> new LinkedHashSet<>())
                    .addAll(changedOperationIds);
        }
        if (!changedOperationIds.isEmpty()) {
            for (ApiProductComponentEntity component : componentRepository
                    .findAllByTenantIdAndApiOperationIdIn(context.tenantId(), changedOperationIds)) {
                impactedByProductVersion.computeIfAbsent(component.getApiProductVersionId(), ignored -> new LinkedHashSet<>())
                        .add(component.getApiOperationId());
            }
        }

        List<DraftImpact> result = new ArrayList<>();
        for (Map.Entry<String, Set<String>> entry : impactedByProductVersion.entrySet()) {
            String productVersionId = entry.getKey();
            int impactedOperationCount = entry.getValue().size();
            List<SubscriptionEntity> subscriptions = subscriptionRepository
                    .findAllByTenantIdAndApiProductVersionIdOrderByCreatedAtAsc(context.tenantId(), productVersionId);
            for (SubscriptionEntity subscription : subscriptions) {
                ConsumerAppEnvironmentEntity environment = environmentRepository
                        .findByIdAndTenantId(subscription.getConsumerAppEnvironmentId(), context.tenantId())
                        .orElseThrow(() -> inconsistent("ConsumerAppEnvironment를 찾을 수 없습니다."));
                ConsumerAppEntity app = appRepository.findByIdAndTenantId(environment.getConsumerAppId(), context.tenantId())
                        .orElseThrow(() -> inconsistent("ConsumerApp을 찾을 수 없습니다."));
                List<EntitlementEntity> entitlements = entitlementRepository
                        .findAllByTenantIdAndSubscriptionId(context.tenantId(), subscription.getId());
                if (entitlements.isEmpty()) {
                    result.add(new DraftImpact(productVersionId, subscription.getId(), null, environment.getId(),
                            app.getId(), subscription.getStatus().name(), null, app.getLifecycleState().name(),
                            impactedOperationCount));
                } else {
                    entitlements.stream().sorted(Comparator.comparing(EntitlementEntity::getId)).forEach(entitlement ->
                            result.add(new DraftImpact(productVersionId, subscription.getId(), entitlement.getId(),
                                    environment.getId(), app.getId(), subscription.getStatus().name(),
                                    entitlement.getStatus().name(), app.getLifecycleState().name(),
                                    impactedOperationCount)));
                }
            }
        }
        result.sort(Comparator.comparing(DraftImpact::apiProductVersionId)
                .thenComparing(DraftImpact::subscriptionId)
                .thenComparing(d -> Objects.toString(d.entitlementId(), "")));
        return List.copyOf(result);
    }

    private String basisHash(ApiChangeEntity change, List<DraftImpact> drafts) {
        String canonical = drafts.stream().map(this::draftCanonical)
                .reduce(change.getId() + "|" + change.getChangeSummaryHash(), (a, b) -> a + "\n" + b);
        return sha256Service.hashText(canonical);
    }

    private String rowHash(DraftImpact draft) {
        return sha256Service.hashText(draftCanonical(draft));
    }

    private String draftCanonical(DraftImpact d) {
        return d.apiProductVersionId() + "|" + d.subscriptionId() + "|"
                + Objects.toString(d.entitlementId(), "") + "|" + d.environmentId() + "|" + d.consumerAppId()
                + "|" + d.subscriptionStatus() + "|" + Objects.toString(d.entitlementStatus(), "")
                + "|" + d.consumerAppState() + "|" + d.impactedOperationCount();
    }

    private ConsumerImpactAnalysisEntity latestAnalysis(TenantContext context, String apiChangeId) {
        List<ConsumerImpactAnalysisEntity> values = analysisRepository
                .findAllByTenantIdAndApiChangeIdOrderByAnalyzedAtDesc(context.tenantId(), apiChangeId);
        return values.isEmpty() ? null : values.get(0);
    }

    private ApiChangeEntity ownedChange(TenantContext context, String id) {
        return changeRepository.findByIdAndTenantId(id, context.tenantId())
                .orElseThrow(() -> new BusinessException(ErrorCode.API_CHANGE_NOT_FOUND, HttpStatus.NOT_FOUND,
                        "API Change를 찾을 수 없습니다."));
    }

    private BusinessException inconsistent(String message) {
        return new BusinessException(ErrorCode.CONSUMER_IMPACT_INCONSISTENT, HttpStatus.CONFLICT, message);
    }

    private record DraftImpact(
            String apiProductVersionId,
            String subscriptionId,
            String entitlementId,
            String environmentId,
            String consumerAppId,
            String subscriptionStatus,
            String entitlementStatus,
            String consumerAppState,
            int impactedOperationCount) {}

    public record ImpactSummary(
            String consumerImpactAnalysisId,
            long materializedRowCount,
            long distinctSubscriptionCount,
            Map<String, Long> materializedRowsBySubscriptionStatus,
            Map<String, Long> materializedRowsByEntitlementStatus) {}
}

package com.gsitm.ustra.api.platform.common.context;

public record RequestContext(String requestId, String correlationId) {
}

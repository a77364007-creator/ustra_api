package com.gsitm.ustra.api.platform.tenant.application;

public interface IdentityAuthority {
    boolean exists(String principalId, String issuer);
}

package com.gsitm.ustra.api.platform.operations.application;

import com.gsitm.ustra.api.platform.audit.AuditService;
import com.gsitm.ustra.api.platform.common.error.*;
import com.gsitm.ustra.api.platform.operations.domain.*;
import com.gsitm.ustra.api.platform.operations.persistence.*;
import com.gsitm.ustra.api.platform.tenant.context.TenantContext;
import com.gsitm.ustra.api.platform.tenant.persistence.TenantRepository;
import java.time.*;
import java.util.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.*;

@Service
public class RecoveryActionService {
    private final OperationsRecoveryActionRepository repository;
    private final TenantRepository tenants;
    private final RecoveryTargetValidator targets;
    private final AuditService audit;
    private final Clock clock;
    public RecoveryActionService(OperationsRecoveryActionRepository repository,TenantRepository tenants,
                                 RecoveryTargetValidator targets,AuditService audit,Clock clock) {
        this.repository=repository;this.tenants=tenants;this.targets=targets;this.audit=audit;this.clock=clock;
    }
    @Transactional(propagation=Propagation.REQUIRES_NEW)
    public Prepared prepare(TenantContext context,String key,RecoveryRequest request) {
        // A short tenant lock serializes key insertion even when the journal row does not yet exist.
        tenants.lockById(context.tenantId()).orElseThrow(this::notFound);
        var previous=repository.findByTenantIdAndIdempotencyKey(context.tenantId(),key);
        if(previous.isPresent()) {
            var existing=previous.get();
            if(!existing.getRequestFingerprint().equals(request.fingerprint()))
                throw new BusinessException(ErrorCode.IDEMPOTENCY_KEY_CONFLICT,HttpStatus.CONFLICT,"동일 키의 요청 내용이 다릅니다.");
            return new Prepared(existing,false); // replay precedes current-state validation, never re-executes
        }
        targets.validate(context.tenantId(),request);
        if(repository.existsByTenantIdAndActiveTargetKey(context.tenantId(),request.actionType().activeKey(context.tenantId(),request.targetId())))
            throw new BusinessException(ErrorCode.OPERATIONS_RECOVERY_TARGET_BUSY,HttpStatus.CONFLICT,"대상에 미해결 복구 요청이 있습니다.");
        var row=repository.saveAndFlush(new OperationsRecoveryActionEntity(UUID.randomUUID().toString(),context.tenantId(),key,
                request,context.principalId(),context.correlationId(),Instant.now(clock)));
        audit.success(context.tenantId(),"OPERATIONS_RECOVERY_REQUESTED","OPERATIONS_RECOVERY_ACTION",row.getId(),true,
                Map.of("actionType",request.actionType().name(),"targetId",request.targetId()));
        return new Prepared(row,true);
    }
    @Transactional(propagation=Propagation.REQUIRES_NEW)
    public boolean claim(String tenantId,String id) {
        var row=repository.lockOwned(tenantId,id).orElseThrow(this::notFound);
        if(!row.claim(Instant.now(clock))) return false;
        repository.saveAndFlush(row);
        audit.success(tenantId,"OPERATIONS_RECOVERY_STARTED","OPERATIONS_RECOVERY_ACTION",id,true,
                Map.of("actionType",row.getActionType().name(),"targetId",row.getTargetId()));
        return true;
    }
    @Transactional(propagation=Propagation.REQUIRES_NEW)
    public View complete(String tenantId,String id,RecoveryActionStatus status,String targetStatus,String operationId,String safeCode) {
        var row=repository.lockOwned(tenantId,id).orElseThrow(this::notFound);
        row.complete(status,targetStatus,operationId,safeCode,Instant.now(clock));
        repository.saveAndFlush(row);
        audit.success(tenantId,"OPERATIONS_RECOVERY_RECORDED","OPERATIONS_RECOVERY_ACTION",id,true,
                Map.of("actionStatus",status.name(),"targetStatus",targetStatus==null?"UNCONFIRMED":targetStatus,
                        "safeResultCode",safeCode,"actionType",row.getActionType().name()));
        return View.from(row);
    }
    @Transactional(readOnly=true,propagation=Propagation.REQUIRES_NEW)
    public OperationsRecoveryActionEntity owned(String tenantId,String id){return repository.findByIdAndTenantId(id,tenantId).orElseThrow(this::notFound);}
    @Transactional(readOnly=true,propagation=Propagation.REQUIRES_NEW)
    public OperationsRecoveryActionEntity ownedReadable(String tenantId,String id,Collection<RecoveryActionType> types) {
        if(types.isEmpty()) throw notFound();
        return repository.findByIdAndTenantIdAndActionTypeIn(id,tenantId,types).orElseThrow(this::notFound);
    }
    private BusinessException notFound(){return new BusinessException(ErrorCode.OPERATIONS_RECOVERY_NOT_FOUND,HttpStatus.NOT_FOUND,"복구 실행기록을 찾을 수 없습니다.");}
    public record Prepared(OperationsRecoveryActionEntity row,boolean created) {}
    public record View(String recoveryActionId,String actionType,String targetType,String targetId,String actionStatus,
                       String targetStatus,String integrationOperationId,String safeResultCode,String correlationId,
                       String requestedBy,Instant requestedAt,Instant startedAt,Instant completedAt,long rowVersion) {
        public static View from(OperationsRecoveryActionEntity e){return new View(e.getId(),e.getActionType().name(),e.getTargetType(),e.getTargetId(),
                e.getStatus().name(),e.getTargetStatus(),e.getIntegrationOperationId(),e.getSafeResultCode(),e.getCorrelationId(),e.getRequestedBy(),
                e.getRequestedAt(),e.getStartedAt(),e.getCompletedAt(),e.getRowVersion());}
    }
}

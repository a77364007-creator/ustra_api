package com.gsitm.ustra.api.platform.search.application;

import com.gsitm.ustra.api.platform.catalog.domain.ApiProductLifecycleState;
import com.gsitm.ustra.api.platform.catalog.localization.application.LocalizationResolutionService;
import com.gsitm.ustra.api.platform.catalog.localization.domain.LocalizationStatus;
import com.gsitm.ustra.api.platform.catalog.localization.persistence.LocalizedContentRepository;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiProductEntity;
import com.gsitm.ustra.api.platform.catalog.persistence.ApiProductRepository;
import com.gsitm.ustra.api.platform.catalog.persistence.ProviderEntity;
import com.gsitm.ustra.api.platform.catalog.persistence.ProviderRepository;
import com.gsitm.ustra.api.platform.catalog.publication.application.CatalogVisibilityService;
import com.gsitm.ustra.api.platform.catalog.publication.domain.ApiProductVersionState;
import com.gsitm.ustra.api.platform.catalog.publication.domain.CatalogPublicationState;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.ApiProductVersionEntity;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.ApiProductVersionRepository;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.CatalogPublicationEntity;
import com.gsitm.ustra.api.platform.catalog.publication.persistence.CatalogPublicationRepository;
import com.gsitm.ustra.api.platform.common.error.BusinessException;
import com.gsitm.ustra.api.platform.common.error.ErrorCode;
import com.gsitm.ustra.api.platform.search.persistence.CatalogSearchDocumentEntity;
import com.gsitm.ustra.api.platform.search.persistence.CatalogSearchDocumentRepository;
import com.gsitm.ustra.api.platform.tenant.application.TenantPermissionGuard;
import com.gsitm.ustra.api.platform.tenant.context.TenantContext;
import com.gsitm.ustra.api.platform.tenant.context.TenantContextResolver;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class CatalogSearchService implements CatalogSearchPort {
    private static final int MAX_PAGE_SIZE = 100;
    private static final int MAX_QUERY_LENGTH = 200;

    private final TenantContextResolver contextResolver;
    private final TenantPermissionGuard permissionGuard;
    private final CatalogSearchDocumentRepository documentRepository;
    private final ApiProductRepository productRepository;
    private final ProviderRepository providerRepository;
    private final LocalizedContentRepository localizationRepository;
    private final LocalizationResolutionService localizationResolutionService;
    private final ApiProductVersionRepository versionRepository;
    private final CatalogPublicationRepository publicationRepository;
    private final CatalogVisibilityService visibilityService;

    public CatalogSearchService(TenantContextResolver contextResolver, TenantPermissionGuard permissionGuard,
                                CatalogSearchDocumentRepository documentRepository,
                                ApiProductRepository productRepository, ProviderRepository providerRepository,
                                LocalizedContentRepository localizationRepository,
                                LocalizationResolutionService localizationResolutionService,
                                ApiProductVersionRepository versionRepository,
                                CatalogPublicationRepository publicationRepository,
                                CatalogVisibilityService visibilityService) {
        this.contextResolver=contextResolver; this.permissionGuard=permissionGuard;
        this.documentRepository=documentRepository; this.productRepository=productRepository;
        this.providerRepository=providerRepository; this.localizationRepository=localizationRepository;
        this.localizationResolutionService=localizationResolutionService; this.versionRepository=versionRepository;
        this.publicationRepository=publicationRepository; this.visibilityService=visibilityService;
    }

    @Override
    @Transactional(readOnly = true)
    public SearchPage search(SearchRequest request) {
        TenantContext context = contextResolver.resolve();
        permissionGuard.require(context, "API_PRODUCT:READ", "CATALOG_SEARCH", "search");
        SearchRequest normalized = validate(request);
        if (normalized.providerId()!=null && providerRepository
                .findByIdAndTenantId(normalized.providerId(), context.tenantId()).isEmpty()) {
            throw new BusinessException(ErrorCode.PROVIDER_NOT_FOUND, HttpStatus.BAD_REQUEST,
                    "같은 Tenant의 Provider를 찾을 수 없습니다.");
        }

        Set<String> allowedLocaleKeys = allowedLocaleKeys(normalized.locale(), context.locale());
        String needle = normalize(normalized.query());
        Map<String,List<CatalogSearchDocumentEntity>> matched = new LinkedHashMap<>();
        for (CatalogSearchDocumentEntity document : documentRepository
                .findAllByTenantIdOrderByApiProductIdAscLocaleKeyAsc(context.tenantId())) {
            if (!allowedLocaleKeys.contains(document.getLocaleKey())) continue;
            if (normalized.providerId()!=null && !Objects.equals(normalized.providerId(), document.getProviderId())) continue;
            if (!fresh(context, document)) continue;
            if (!matches(document, needle)) continue;
            matched.computeIfAbsent(document.getApiProductId(), ignored -> new ArrayList<>()).add(document);
        }

        List<SearchResult> results = new ArrayList<>();
        for (Map.Entry<String,List<CatalogSearchDocumentEntity>> entry : matched.entrySet()) {
            ApiProductEntity product = productRepository.findByIdAndTenantId(entry.getKey(), context.tenantId()).orElse(null);
            if (product == null || product.getLifecycleState() == ApiProductLifecycleState.RETIRED) continue;
            List<VisibleVersion> visibleVersions = visibleVersions(context, product.getId());
            if (visibleVersions.isEmpty()) continue;
            LocalizationResolutionService.ResolvedContent resolved = localizationResolutionService
                    .resolve(context.tenantId(), product.getId(), normalized.locale());
            ProviderSummary provider = providerSummary(context, product.getProviderId());
            List<String> matchedLocales = entry.getValue().stream().map(CatalogSearchDocumentEntity::getLocaleKey)
                    .distinct().sorted().toList();
            results.add(new SearchResult(product.getId(), product.getProductCode(), resolved.name(), resolved.description(),
                    resolved.locale(), resolved.source().name(), provider, visibleVersions, matchedLocales));
        }
        results.sort(Comparator.comparing((SearchResult r) -> normalize(r.displayName()))
                .thenComparing(r -> normalize(r.productCode())).thenComparing(SearchResult::apiProductId));

        long total = results.size();
        int from = Math.min(normalized.page()*normalized.size(), results.size());
        int to = Math.min(from + normalized.size(), results.size());
        List<SearchResult> page = List.copyOf(results.subList(from, to));
        return new SearchPage(page, normalized.page(), normalized.size(), total, to < results.size());
    }

    private SearchRequest validate(SearchRequest request) {
        if (request == null) throw invalid("검색 요청이 필요합니다.");
        if (request.page() < 0) throw invalid("page는 0 이상이어야 합니다.");
        if (request.size() < 1 || request.size() > MAX_PAGE_SIZE) throw invalid("size는 1~100 범위여야 합니다.");
        String q = trimToNull(request.query());
        if (q != null && q.length() > MAX_QUERY_LENGTH) throw invalid("q 길이는 200자를 초과할 수 없습니다.");
        String locale = trimToNull(request.locale());
        if (locale != null && locale.length() > 35) throw invalid("locale 길이는 35자를 초과할 수 없습니다.");
        return new SearchRequest(q, locale, trimToNull(request.providerId()), request.page(), request.size());
    }

    private boolean fresh(TenantContext context, CatalogSearchDocumentEntity document) {
        ApiProductEntity product = productRepository.findByIdAndTenantId(document.getApiProductId(), context.tenantId()).orElse(null);
        if (product == null || product.getRowVersion()!=document.getSourceProductRowVersion()
                || product.getLocalizationRevision()!=document.getSourceLocalizationRevision()) return false;
        if (CatalogSearchProjectionService.CANONICAL_LOCALE_KEY.equals(document.getLocaleKey())) return true;
        return localizationRepository.findByTenantIdAndApiProductIdAndLocaleAndStatus(
                        context.tenantId(), product.getId(), document.getLocaleKey(), LocalizationStatus.PUBLISHED)
                .filter(content -> Objects.equals(content.getContentRevision(), document.getSourceLocalizedContentRevision()))
                .isPresent();
    }

    private List<VisibleVersion> visibleVersions(TenantContext context, String apiProductId) {
        List<VisibleVersion> result = new ArrayList<>();
        Set<String> seen = new LinkedHashSet<>();
        for (ApiProductVersionEntity version : versionRepository
                .findAllByTenantIdAndApiProductIdOrderByCreatedAtAsc(context.tenantId(), apiProductId)) {
            if (version.getLifecycleState()!=ApiProductVersionState.RELEASED) continue;
            for (CatalogPublicationEntity publication : publicationRepository
                    .findAllByTenantIdAndApiProductVersionIdOrderByCreatedAtAsc(context.tenantId(), version.getId())) {
                if (publication.getLifecycleState()!=CatalogPublicationState.ACTIVE) continue;
                if (!visibilityService.isDiscoverable(context.tenantId(), context.organizationId(), publication.getId())) continue;
                if (seen.add(publication.getId())) {
                    result.add(new VisibleVersion(version.getId(), version.getVersionValue(), publication.getId()));
                }
            }
        }
        result.sort(Comparator.comparing(VisibleVersion::versionValue).thenComparing(VisibleVersion::catalogPublicationId));
        return List.copyOf(result);
    }

    private ProviderSummary providerSummary(TenantContext context, String providerId) {
        if (providerId == null) return null;
        ProviderEntity provider = providerRepository.findByIdAndTenantId(providerId, context.tenantId()).orElse(null);
        return provider == null ? null : new ProviderSummary(provider.getId(), provider.getProviderCode(), provider.getDisplayName());
    }

    private Set<String> allowedLocaleKeys(String requested, String tenantDefault) {
        Set<String> keys = new LinkedHashSet<>();
        keys.add(CatalogSearchProjectionService.CANONICAL_LOCALE_KEY);
        if (requested != null) keys.add(requested);
        if (tenantDefault != null && !tenantDefault.isBlank()) keys.add(tenantDefault.trim());
        return Set.copyOf(keys);
    }

    private boolean matches(CatalogSearchDocumentEntity document, String needle) {
        if (needle == null) return true;
        return contains(document.getProductCode(), needle) || contains(document.getDisplayName(), needle)
                || contains(document.getDescription(), needle) || contains(document.getProviderCode(), needle)
                || contains(document.getProviderDisplayName(), needle);
    }
    private boolean contains(String value, String needle){return value!=null && normalize(value).contains(needle);}
    private String normalize(String value){return value==null?null:value.toLowerCase(Locale.ROOT);}
    private String trimToNull(String value){if(value==null)return null;String v=value.trim();return v.isEmpty()?null:v;}
    private BusinessException invalid(String message){return new BusinessException(ErrorCode.VALIDATION_ERROR,HttpStatus.BAD_REQUEST,message);}
}

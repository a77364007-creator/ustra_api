package com.gsitm.ustra.api.platform.operations.domain;
public enum RecoveryActionStatus { REQUESTED, IN_PROGRESS, SUCCEEDED, FAILED, UNKNOWN }

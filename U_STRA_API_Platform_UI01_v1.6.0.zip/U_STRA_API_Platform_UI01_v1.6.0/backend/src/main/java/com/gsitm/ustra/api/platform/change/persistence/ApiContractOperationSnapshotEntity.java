package com.gsitm.ustra.api.platform.change.persistence;
import jakarta.persistence.*;
@Entity @Table(name="api_contract_operation_snapshot")
public class ApiContractOperationSnapshotEntity {
 @Id @Column(name="api_contract_operation_snapshot_id",length=36,nullable=false,updatable=false) private String id;
 @Column(name="tenant_id",length=36,nullable=false,updatable=false) private String tenantId;
 @Column(name="api_contract_snapshot_id",length=36,nullable=false,updatable=false) private String snapshotId;
 @Column(name="method",length=20,nullable=false,updatable=false) private String method;
 @Column(name="normalized_path",length=1000,nullable=false,updatable=false) private String normalizedPath;
 @Column(name="operation_fingerprint",length=64,nullable=false,updatable=false) private String operationFingerprint;
 protected ApiContractOperationSnapshotEntity(){}
 public ApiContractOperationSnapshotEntity(String id,String tenantId,String snapshotId,String method,String normalizedPath,String operationFingerprint){this.id=id;this.tenantId=tenantId;this.snapshotId=snapshotId;this.method=method;this.normalizedPath=normalizedPath;this.operationFingerprint=operationFingerprint;}
 public String getId(){return id;} public String getTenantId(){return tenantId;} public String getSnapshotId(){return snapshotId;} public String getMethod(){return method;} public String getNormalizedPath(){return normalizedPath;} public String getOperationFingerprint(){return operationFingerprint;}
}

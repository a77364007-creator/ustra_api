package com.gsitm.ustra.api.platform.provider.importing.parser;

import com.gsitm.ustra.api.platform.common.error.BusinessException;
import com.gsitm.ustra.api.platform.common.error.ErrorCode;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.Operation;
import io.swagger.v3.oas.models.PathItem;
import io.swagger.v3.oas.models.media.MediaType;
import io.swagger.v3.oas.models.parameters.Parameter;
import io.swagger.v3.oas.models.parameters.RequestBody;
import io.swagger.v3.oas.models.responses.ApiResponse;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.parser.OpenAPIV3Parser;
import io.swagger.v3.parser.core.models.ParseOptions;
import io.swagger.v3.parser.core.models.SwaggerParseResult;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

@Component
public class SwaggerOpenApiParserAdapter implements OpenApiParserPort {
    private final OpenApiReferenceGuard guard;
    private final SanitizedContractFingerprintService fingerprints;

    public SwaggerOpenApiParserAdapter(
            OpenApiReferenceGuard guard,
            SanitizedContractFingerprintService fingerprints) {
        this.guard = guard;
        this.fingerprints = fingerprints;
    }

    @Override
    public ParsedOpenApi parse(String source) {
        guard.validate(source);
        ParseOptions options = new ParseOptions();
        options.setResolve(false);
        options.setResolveFully(false);
        options.setResolveCombinators(false);
        SwaggerParseResult result = new OpenAPIV3Parser().readContents(source, null, options);
        OpenAPI api = result.getOpenAPI();
        if (api == null || api.getOpenapi() == null
                || !(api.getOpenapi().startsWith("3.0.") || api.getOpenapi().startsWith("3.1."))
                || api.getInfo() == null || api.getInfo().getVersion() == null) {
            throw invalid();
        }
        if (result.getMessages() != null
                && result.getMessages().stream().anyMatch(m -> m != null && m.toLowerCase(Locale.ROOT).contains("error"))) {
            throw invalid();
        }

        List<ParsedOperation> operations = new ArrayList<>();
        if (api.getPaths() != null) {
            api.getPaths().forEach((path, item) -> collect(operations, api, path, item));
        }
        return new ParsedOpenApi(
                api.getInfo().getTitle(),
                api.getInfo().getDescription(),
                api.getInfo().getVersion(),
                List.copyOf(operations));
    }

    private void collect(List<ParsedOperation> out, OpenAPI api, String path, PathItem item) {
        if (item == null) return;
        item.readOperationsMap().forEach((method, operation) ->
                out.add(toParsed(api, path, method.name(), item, operation)));
    }

    private ParsedOperation toParsed(OpenAPI api, String path, String method, PathItem item, Operation operation) {
        List<ParsedParameter> parameters = parseParameters(api, item, operation);
        List<ParsedBody> bodies = parseBodies(api, operation);
        List<ParsedResponse> responses = parseResponses(api, operation);
        List<String> security = parseSecurity(api, operation);
        return new ParsedOperation(
                method,
                path,
                operation == null ? null : operation.getOperationId(),
                operation == null ? null : operation.getSummary(),
                parameters,
                bodies,
                responses,
                security);
    }

    private List<ParsedParameter> parseParameters(OpenAPI api, PathItem item, Operation operation) {
        Map<String, Parameter> effective = new LinkedHashMap<>();
        if (item.getParameters() != null) {
            for (Parameter parameter : item.getParameters()) putParameter(api, effective, parameter);
        }
        if (operation != null && operation.getParameters() != null) {
            for (Parameter parameter : operation.getParameters()) putParameter(api, effective, parameter);
        }
        List<ParsedParameter> parsed = new ArrayList<>();
        for (Parameter parameter : effective.values()) {
            Parameter resolved = resolveParameter(api, parameter);
            String location = resolved.getIn() == null ? "unknown" : resolved.getIn();
            String name = resolved.getName() == null ? "__unresolved__" : resolved.getName();
            boolean required = Boolean.TRUE.equals(resolved.getRequired()) || "path".equals(location);
            String schema = fingerprints.schemaFingerprint(resolved.getSchema(), api);
            parsed.add(new ParsedParameter(location, name, required, schema,
                    fingerprints.parameterFingerprint(location, name, required, schema)));
        }
        parsed.sort((left, right) -> (left.location() + "\u0000" + left.name())
                .compareTo(right.location() + "\u0000" + right.name()));
        return List.copyOf(parsed);
    }

    private void putParameter(OpenAPI api, Map<String, Parameter> target, Parameter parameter) {
        Parameter resolved = resolveParameter(api, parameter);
        String key = String.valueOf(resolved.getIn()) + "\u0000" + String.valueOf(resolved.getName());
        target.put(key, resolved);
    }

    private Parameter resolveParameter(OpenAPI api, Parameter parameter) {
        if (parameter == null || parameter.get$ref() == null) return parameter == null ? new Parameter() : parameter;
        String prefix = "#/components/parameters/";
        if (parameter.get$ref().startsWith(prefix) && api.getComponents() != null
                && api.getComponents().getParameters() != null) {
            Parameter resolved = api.getComponents().getParameters().get(parameter.get$ref().substring(prefix.length()));
            if (resolved != null) return resolved;
        }
        return parameter;
    }

    private List<ParsedBody> parseBodies(OpenAPI api, Operation operation) {
        if (operation == null || operation.getRequestBody() == null) return List.of();
        RequestBody body = resolveRequestBody(api, operation.getRequestBody());
        if (body.getContent() == null || body.getContent().isEmpty()) return List.of();
        boolean required = Boolean.TRUE.equals(body.getRequired());
        List<ParsedBody> result = new ArrayList<>();
        body.getContent().forEach((mediaType, content) -> {
            String schema = fingerprints.schemaFingerprint(content == null ? null : content.getSchema(), api);
            result.add(new ParsedBody(required, mediaType, schema,
                    fingerprints.bodyFingerprint(required, mediaType, schema)));
        });
        result.sort((a, b) -> a.mediaType().compareTo(b.mediaType()));
        return List.copyOf(result);
    }

    private RequestBody resolveRequestBody(OpenAPI api, RequestBody body) {
        if (body.get$ref() == null) return body;
        String prefix = "#/components/requestBodies/";
        if (body.get$ref().startsWith(prefix) && api.getComponents() != null
                && api.getComponents().getRequestBodies() != null) {
            RequestBody resolved = api.getComponents().getRequestBodies().get(body.get$ref().substring(prefix.length()));
            if (resolved != null) return resolved;
        }
        return body;
    }

    private List<ParsedResponse> parseResponses(OpenAPI api, Operation operation) {
        if (operation == null || operation.getResponses() == null) return List.of();
        List<ParsedResponse> result = new ArrayList<>();
        operation.getResponses().forEach((code, response) -> {
            ApiResponse resolved = resolveResponse(api, response);
            if (resolved.getContent() == null || resolved.getContent().isEmpty()) {
                String schema = fingerprints.schemaFingerprint(null, api);
                result.add(new ParsedResponse(code, "", schema,
                        fingerprints.responseFingerprint(code, "", schema)));
                return;
            }
            for (Map.Entry<String, MediaType> entry : resolved.getContent().entrySet()) {
                String schema = fingerprints.schemaFingerprint(
                        entry.getValue() == null ? null : entry.getValue().getSchema(), api);
                result.add(new ParsedResponse(code, entry.getKey(), schema,
                        fingerprints.responseFingerprint(code, entry.getKey(), schema)));
            }
        });
        result.sort((a, b) -> (a.responseCode() + "\u0000" + a.mediaType())
                .compareTo(b.responseCode() + "\u0000" + b.mediaType()));
        return List.copyOf(result);
    }

    private ApiResponse resolveResponse(OpenAPI api, ApiResponse response) {
        if (response == null) return new ApiResponse();
        if (response.get$ref() == null) return response;
        String prefix = "#/components/responses/";
        if (response.get$ref().startsWith(prefix) && api.getComponents() != null
                && api.getComponents().getResponses() != null) {
            ApiResponse resolved = api.getComponents().getResponses().get(response.get$ref().substring(prefix.length()));
            if (resolved != null) return resolved;
        }
        return response;
    }

    private List<String> parseSecurity(OpenAPI api, Operation operation) {
        List<SecurityRequirement> effective;
        if (operation != null && operation.getSecurity() != null) {
            effective = operation.getSecurity();
        } else {
            effective = api.getSecurity();
        }
        if (effective == null || effective.isEmpty()) return List.of();
        List<String> fingerprintsByRequirement = new ArrayList<>();
        for (SecurityRequirement requirement : effective) {
            fingerprintsByRequirement.add(fingerprints.securityRequirementFingerprint(requirement, api));
        }
        fingerprintsByRequirement.sort(String::compareTo);
        return List.copyOf(fingerprintsByRequirement);
    }

    private BusinessException invalid() {
        return new BusinessException(
                ErrorCode.OPENAPI_INVALID,
                HttpStatus.BAD_REQUEST,
                "유효한 OpenAPI 3.0/3.1 문서가 아닙니다.");
    }
}

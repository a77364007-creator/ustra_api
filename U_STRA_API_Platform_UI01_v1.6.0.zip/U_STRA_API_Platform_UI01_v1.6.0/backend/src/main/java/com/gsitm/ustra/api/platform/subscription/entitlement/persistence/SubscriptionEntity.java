package com.gsitm.ustra.api.platform.subscription.entitlement.persistence;

import com.gsitm.ustra.api.platform.subscription.entitlement.domain.SubscriptionStatus;
import jakarta.persistence.*;
import java.time.Instant;

@Entity @Table(name="subscription")
public class SubscriptionEntity {
 @Id @Column(name="subscription_id",length=36,nullable=false,updatable=false) private String id;
 @Column(name="tenant_id",length=36,nullable=false,updatable=false) private String tenantId;
 @Column(name="source_subscription_request_id",length=36,nullable=false,updatable=false) private String sourceSubscriptionRequestId;
 @Column(name="source_request_revision_no",nullable=false,updatable=false) private int sourceRequestRevisionNo;
 @Column(name="source_snapshot_hash",length=64,nullable=false,updatable=false) private String sourceSnapshotHash;
 @Column(name="approval_reference_id",length=200,nullable=false,updatable=false) private String approvalReferenceId;
 @Column(name="consumer_app_environment_id",length=36,nullable=false,updatable=false) private String consumerAppEnvironmentId;
 @Column(name="api_product_version_id",length=36,nullable=false,updatable=false) private String apiProductVersionId;
 @Enumerated(EnumType.STRING) @Column(name="status",length=30,nullable=false) private SubscriptionStatus status;
 @Column(name="effective_from",nullable=false,updatable=false) private Instant effectiveFrom;
 @Column(name="effective_to",nullable=false,updatable=false) private Instant effectiveTo;
 @Version @Column(name="row_version",nullable=false) private long rowVersion;
 @Column(name="created_at",nullable=false,updatable=false) private Instant createdAt;
 @Column(name="created_by",length=200,nullable=false,updatable=false) private String createdBy;
 @Column(name="updated_at",nullable=false) private Instant updatedAt;
 @Column(name="updated_by",length=200,nullable=false) private String updatedBy;
 protected SubscriptionEntity() {}
 public SubscriptionEntity(String id,String tenantId,String requestId,int revisionNo,String snapshotHash,String approvalReferenceId,String environmentId,String productVersionId,Instant effectiveFrom,Instant effectiveTo,Instant now,String actor){
  this.id=id;this.tenantId=tenantId;this.sourceSubscriptionRequestId=requestId;this.sourceRequestRevisionNo=revisionNo;this.sourceSnapshotHash=snapshotHash;this.approvalReferenceId=approvalReferenceId;this.consumerAppEnvironmentId=environmentId;this.apiProductVersionId=productVersionId;this.status=SubscriptionStatus.PENDING_ACTIVATION;this.effectiveFrom=effectiveFrom;this.effectiveTo=effectiveTo;this.createdAt=now;this.createdBy=actor;this.updatedAt=now;this.updatedBy=actor;
 }
 public void activate(Instant now,String actor){this.status=SubscriptionStatus.ACTIVE;this.updatedAt=now;this.updatedBy=actor;}
 public String getId(){return id;} public String getTenantId(){return tenantId;} public String getSourceSubscriptionRequestId(){return sourceSubscriptionRequestId;} public int getSourceRequestRevisionNo(){return sourceRequestRevisionNo;} public String getSourceSnapshotHash(){return sourceSnapshotHash;} public String getApprovalReferenceId(){return approvalReferenceId;} public String getConsumerAppEnvironmentId(){return consumerAppEnvironmentId;} public String getApiProductVersionId(){return apiProductVersionId;} public SubscriptionStatus getStatus(){return status;} public Instant getEffectiveFrom(){return effectiveFrom;} public Instant getEffectiveTo(){return effectiveTo;} public long getRowVersion(){return rowVersion;} public Instant getCreatedAt(){return createdAt;} public String getCreatedBy(){return createdBy;} public Instant getUpdatedAt(){return updatedAt;} public String getUpdatedBy(){return updatedBy;}
}

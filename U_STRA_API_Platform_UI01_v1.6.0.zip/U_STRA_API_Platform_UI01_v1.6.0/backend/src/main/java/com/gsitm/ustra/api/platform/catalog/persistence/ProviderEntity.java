package com.gsitm.ustra.api.platform.catalog.persistence;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Version;
import java.time.Instant;

@Entity
@Table(name = "provider")
public class ProviderEntity {
    @Id
    @Column(name = "provider_id", length = 36, nullable = false, updatable = false)
    private String id;

    @Column(name = "tenant_id", length = 36, nullable = false, updatable = false)
    private String tenantId;

    @Column(name = "provider_code", length = 100, nullable = false)
    private String providerCode;

    @Column(name = "display_name", length = 200, nullable = false)
    private String displayName;

    @Column(name = "organization_id", length = 36)
    private String organizationId;

    @Version
    @Column(name = "row_version", nullable = false)
    private long rowVersion;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @Column(name = "created_by", length = 200, nullable = false, updatable = false)
    private String createdBy;

    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;

    @Column(name = "updated_by", length = 200, nullable = false)
    private String updatedBy;

    protected ProviderEntity() {
    }

    public ProviderEntity(String id, String tenantId, String providerCode, String displayName,
                          String organizationId, Instant now, String actor) {
        this.id = id;
        this.tenantId = tenantId;
        this.providerCode = providerCode;
        this.displayName = displayName;
        this.organizationId = organizationId;
        this.createdAt = now;
        this.createdBy = actor;
        this.updatedAt = now;
        this.updatedBy = actor;
    }

    public String getId() { return id; }
    public String getTenantId() { return tenantId; }
    public String getProviderCode() { return providerCode; }
    public String getDisplayName() { return displayName; }
    public String getOrganizationId() { return organizationId; }
    public long getRowVersion() { return rowVersion; }
}

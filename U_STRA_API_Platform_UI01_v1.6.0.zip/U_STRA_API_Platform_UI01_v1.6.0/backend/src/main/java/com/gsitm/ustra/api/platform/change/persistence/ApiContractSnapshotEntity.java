package com.gsitm.ustra.api.platform.change.persistence;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.Instant;

@Entity
@Table(name = "api_contract_snapshot")
public class ApiContractSnapshotEntity {
    @Id @Column(name="api_contract_snapshot_id", length=36, nullable=false, updatable=false) private String id;
    @Column(name="tenant_id", length=36, nullable=false, updatable=false) private String tenantId;
    @Column(name="api_version_id", length=36, nullable=false, updatable=false) private String apiVersionId;
    @Column(name="source_content_hash", length=64, nullable=false, updatable=false) private String sourceContentHash;
    @Column(name="snapshot_schema_version", length=30, nullable=false, updatable=false) private String snapshotSchemaVersion;
    @Column(name="structural_hash", length=64, nullable=false, updatable=false) private String structuralHash;
    @Column(name="created_at", nullable=false, updatable=false) private Instant createdAt;
    @Column(name="created_by", length=200, nullable=false, updatable=false) private String createdBy;
    protected ApiContractSnapshotEntity() {}
    public ApiContractSnapshotEntity(String id,String tenantId,String apiVersionId,String sourceContentHash,String snapshotSchemaVersion,String structuralHash,Instant now,String actor){this.id=id;this.tenantId=tenantId;this.apiVersionId=apiVersionId;this.sourceContentHash=sourceContentHash;this.snapshotSchemaVersion=snapshotSchemaVersion;this.structuralHash=structuralHash;this.createdAt=now;this.createdBy=actor;}
    public String getId(){return id;} public String getTenantId(){return tenantId;} public String getApiVersionId(){return apiVersionId;} public String getSourceContentHash(){return sourceContentHash;} public String getSnapshotSchemaVersion(){return snapshotSchemaVersion;} public String getStructuralHash(){return structuralHash;} public Instant getCreatedAt(){return createdAt;} public String getCreatedBy(){return createdBy;}
}

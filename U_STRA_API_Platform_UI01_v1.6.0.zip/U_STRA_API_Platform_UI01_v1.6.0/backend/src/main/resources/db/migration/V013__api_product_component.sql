ALTER TABLE api_operation
    ADD CONSTRAINT uq_api_operation_tenant_id UNIQUE (tenant_id, api_operation_id);

CREATE TABLE api_product_component (
    api_product_component_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NOT NULL,
    api_product_version_id CHAR(36) NOT NULL,
    target_type VARCHAR(30) NOT NULL,
    api_version_id CHAR(36) NULL,
    api_operation_id CHAR(36) NULL,
    created_at DATETIME(6) NOT NULL,
    created_by VARCHAR(200) NOT NULL,
    CONSTRAINT pk_api_product_component PRIMARY KEY (api_product_component_id),
    CONSTRAINT fk_product_component_tenant FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id),
    CONSTRAINT uq_product_component_tenant_id UNIQUE (tenant_id, api_product_component_id),
    CONSTRAINT fk_product_component_product_version_tenant FOREIGN KEY (tenant_id, api_product_version_id)
        REFERENCES api_product_version(tenant_id, api_product_version_id),
    CONSTRAINT fk_product_component_api_version_tenant FOREIGN KEY (tenant_id, api_version_id)
        REFERENCES api_version(tenant_id, api_version_id),
    CONSTRAINT fk_product_component_api_operation_tenant FOREIGN KEY (tenant_id, api_operation_id)
        REFERENCES api_operation(tenant_id, api_operation_id),
    CONSTRAINT ck_product_component_target_type CHECK (target_type IN ('API_VERSION', 'API_OPERATION')),
    CONSTRAINT ck_product_component_exact_target CHECK (
        (target_type = 'API_VERSION' AND api_version_id IS NOT NULL AND api_operation_id IS NULL)
        OR
        (target_type = 'API_OPERATION' AND api_version_id IS NULL AND api_operation_id IS NOT NULL)
    )
);

CREATE INDEX ix_product_component_version ON api_product_component(tenant_id, api_product_version_id);

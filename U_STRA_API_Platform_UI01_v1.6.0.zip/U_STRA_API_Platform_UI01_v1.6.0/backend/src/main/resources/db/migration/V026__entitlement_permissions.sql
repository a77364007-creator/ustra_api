INSERT INTO permission (permission_id, permission_code, resource_type, action, status) VALUES
('14000000-0000-0000-0000-000000000001', 'SUBSCRIPTION:READ', 'SUBSCRIPTION', 'READ', 'ACTIVE'),
('14000000-0000-0000-0000-000000000002', 'ENTITLEMENT:READ', 'ENTITLEMENT', 'READ', 'ACTIVE'),
('14000000-0000-0000-0000-000000000003', 'ENTITLEMENT:REVOKE', 'ENTITLEMENT', 'REVOKE', 'ACTIVE');

-- Deliberately no role_permission rows. Role -> Permission mapping remains tenant administration policy.

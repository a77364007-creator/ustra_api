INSERT INTO permission (permission_id, permission_code, resource_type, action, status) VALUES
('18000000-0000-0000-0000-000000000001', 'CATALOG_SEARCH:REBUILD', 'CATALOG_SEARCH', 'REBUILD', 'ACTIVE');

-- Deliberately no role_permission rows. Rebuild authority remains tenant administration policy.

CREATE TABLE subscription_request (
    subscription_request_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NOT NULL,
    consumer_app_environment_id CHAR(36) NOT NULL,
    catalog_publication_id CHAR(36) NOT NULL,
    api_product_version_id CHAR(36) NOT NULL,
    requester_membership_id CHAR(36) NOT NULL,
    status VARCHAR(30) NOT NULL,
    current_revision_no INT NOT NULL,
    row_version BIGINT NOT NULL DEFAULT 0,
    created_at DATETIME(6) NOT NULL,
    created_by VARCHAR(200) NOT NULL,
    updated_at DATETIME(6) NOT NULL,
    updated_by VARCHAR(200) NOT NULL,
    CONSTRAINT pk_subscription_request PRIMARY KEY (subscription_request_id),
    CONSTRAINT fk_subscription_request_tenant FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id),
    CONSTRAINT uq_subscription_request_tenant_id UNIQUE (tenant_id, subscription_request_id),
    CONSTRAINT fk_subscription_request_environment_tenant FOREIGN KEY (tenant_id, consumer_app_environment_id)
        REFERENCES consumer_app_environment(tenant_id, consumer_app_environment_id),
    CONSTRAINT fk_subscription_request_publication_tenant FOREIGN KEY (tenant_id, catalog_publication_id)
        REFERENCES catalog_publication(tenant_id, catalog_publication_id),
    CONSTRAINT fk_subscription_request_product_version_tenant FOREIGN KEY (tenant_id, api_product_version_id)
        REFERENCES api_product_version(tenant_id, api_product_version_id),
    CONSTRAINT fk_subscription_request_requester_tenant FOREIGN KEY (tenant_id, requester_membership_id)
        REFERENCES membership(tenant_id, membership_id),
    CONSTRAINT ck_subscription_request_status CHECK (status IN (
        'SUBMITTED', 'VALIDATING', 'PENDING_APPROVAL', 'APPROVED', 'COMPLETED',
        'NEEDS_INFORMATION', 'REJECTED', 'CANCELLED', 'EXPIRED'
    )),
    CONSTRAINT ck_subscription_request_revision CHECK (current_revision_no >= 1)
);

CREATE INDEX ix_subscription_request_tenant_requester
    ON subscription_request(tenant_id, requester_membership_id, created_at);
CREATE INDEX ix_subscription_request_tenant_environment
    ON subscription_request(tenant_id, consumer_app_environment_id, created_at);
CREATE INDEX ix_subscription_request_tenant_publication
    ON subscription_request(tenant_id, catalog_publication_id, created_at);
CREATE INDEX ix_subscription_request_tenant_status
    ON subscription_request(tenant_id, status, created_at);

CREATE TABLE api_change (
    api_change_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NOT NULL,
    api_id CHAR(36) NOT NULL,
    baseline_api_version_id CHAR(36) NOT NULL,
    target_api_version_id CHAR(36) NOT NULL,
    assessment_status VARCHAR(30) NOT NULL,
    compatibility_result VARCHAR(30) NULL,
    baseline_structural_hash VARCHAR(80) NOT NULL,
    target_structural_hash VARCHAR(80) NOT NULL,
    rule_set_version VARCHAR(50) NOT NULL,
    change_summary_hash CHAR(64) NULL,
    idempotency_key VARCHAR(200) NOT NULL,
    request_fingerprint CHAR(64) NOT NULL,
    assessed_at DATETIME(6) NULL,
    assessed_by VARCHAR(200) NULL,
    row_version BIGINT NOT NULL DEFAULT 0,
    created_at DATETIME(6) NOT NULL,
    created_by VARCHAR(200) NOT NULL,
    updated_at DATETIME(6) NOT NULL,
    updated_by VARCHAR(200) NOT NULL,
    CONSTRAINT pk_api_change PRIMARY KEY (api_change_id),
    CONSTRAINT fk_api_change_tenant FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id),
    CONSTRAINT uq_api_change_tenant_id UNIQUE (tenant_id, api_change_id),
    CONSTRAINT fk_api_change_api_tenant FOREIGN KEY (tenant_id, api_id)
        REFERENCES api(tenant_id, api_id),
    CONSTRAINT fk_api_change_baseline_tenant FOREIGN KEY (tenant_id, baseline_api_version_id)
        REFERENCES api_version(tenant_id, api_version_id),
    CONSTRAINT fk_api_change_target_tenant FOREIGN KEY (tenant_id, target_api_version_id)
        REFERENCES api_version(tenant_id, api_version_id),
    CONSTRAINT uq_api_change_idempotency UNIQUE (tenant_id, idempotency_key),
    CONSTRAINT uq_api_change_exact_assessment UNIQUE (
        tenant_id, baseline_api_version_id, target_api_version_id,
        baseline_structural_hash, target_structural_hash, rule_set_version),
    CONSTRAINT ck_api_change_status CHECK (assessment_status IN ('PENDING','ASSESSING','ASSESSED','FAILED')),
    CONSTRAINT ck_api_change_result CHECK (
        compatibility_result IS NULL OR compatibility_result IN ('BREAKING','REVIEW_REQUIRED','NO_CONTRACT_CHANGE')),
    CONSTRAINT ck_api_change_distinct_versions CHECK (baseline_api_version_id <> target_api_version_id)
);
CREATE INDEX ix_api_change_api_created ON api_change(tenant_id, api_id, created_at);

CREATE TABLE api_change_item (
    api_change_item_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NOT NULL,
    api_change_id CHAR(36) NOT NULL,
    change_kind VARCHAR(50) NOT NULL,
    method VARCHAR(20) NULL,
    normalized_path VARCHAR(1000) NULL,
    contract_location VARCHAR(100) NULL,
    baseline_fingerprint VARCHAR(80) NULL,
    target_fingerprint VARCHAR(80) NULL,
    compatibility_effect VARCHAR(30) NOT NULL,
    evidence_code VARCHAR(100) NOT NULL,
    created_at DATETIME(6) NOT NULL,
    created_by VARCHAR(200) NOT NULL,
    CONSTRAINT pk_api_change_item PRIMARY KEY (api_change_item_id),
    CONSTRAINT fk_api_change_item_tenant FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id),
    CONSTRAINT fk_api_change_item_parent_tenant FOREIGN KEY (tenant_id, api_change_id)
        REFERENCES api_change(tenant_id, api_change_id),
    CONSTRAINT ck_api_change_item_effect CHECK (compatibility_effect IN ('BREAKING','REVIEW_REQUIRED','INFORMATIONAL'))
);
CREATE INDEX ix_api_change_item_parent ON api_change_item(tenant_id, api_change_id, compatibility_effect);

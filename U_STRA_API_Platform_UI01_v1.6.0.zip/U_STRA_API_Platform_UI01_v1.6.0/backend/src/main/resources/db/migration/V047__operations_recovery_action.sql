CREATE TABLE operations_recovery_action (
    recovery_action_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NOT NULL,
    action_type VARCHAR(40) NOT NULL,
    target_type VARCHAR(40) NOT NULL,
    target_id CHAR(36) NOT NULL,
    idempotency_key VARCHAR(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
    request_fingerprint CHAR(64) NOT NULL,
    expected_target_version BIGINT NULL,
    action_status VARCHAR(30) NOT NULL,
    active_target_key VARCHAR(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
    integration_operation_id CHAR(36) NULL,
    safe_result_code VARCHAR(120) NULL,
    target_status VARCHAR(80) NULL,
    correlation_id VARCHAR(100) NOT NULL,
    requested_by VARCHAR(200) NOT NULL,
    requested_at DATETIME(6) NOT NULL,
    started_at DATETIME(6) NULL,
    completed_at DATETIME(6) NULL,
    row_version BIGINT NOT NULL DEFAULT 0,
    CONSTRAINT pk_operations_recovery PRIMARY KEY(recovery_action_id),
    CONSTRAINT uq_recovery_tenant_id UNIQUE(tenant_id,recovery_action_id),
    CONSTRAINT fk_recovery_tenant FOREIGN KEY(tenant_id) REFERENCES tenant(tenant_id),
    CONSTRAINT uq_recovery_key UNIQUE(tenant_id,idempotency_key),
    CONSTRAINT uq_recovery_active_target UNIQUE(tenant_id,active_target_key),
    CONSTRAINT fk_recovery_operation_tenant FOREIGN KEY(tenant_id,integration_operation_id)
        REFERENCES integration_operation(tenant_id,integration_operation_id),
    CONSTRAINT ck_recovery_type CHECK(action_type IN ('APPROVAL_STATUS_RECONCILE','GATEWAY_STATUS_RECONCILE','SEARCH_PRODUCT_REINDEX','SEARCH_TENANT_REBUILD')),
    CONSTRAINT ck_recovery_status CHECK(action_status IN ('REQUESTED','IN_PROGRESS','SUCCEEDED','FAILED','UNKNOWN')),
    CONSTRAINT ck_recovery_version CHECK(expected_target_version IS NULL OR expected_target_version >= 0),
    CONSTRAINT ck_recovery_target CHECK(
       (action_type='APPROVAL_STATUS_RECONCILE' AND target_type='APPROVAL_REFERENCE') OR
       (action_type='GATEWAY_STATUS_RECONCILE' AND target_type='ACCESS_FULFILLMENT') OR
       (action_type='SEARCH_PRODUCT_REINDEX' AND target_type='API_PRODUCT') OR
       (action_type='SEARCH_TENANT_REBUILD' AND target_type='TENANT' AND target_id=tenant_id)),
    CONSTRAINT ck_recovery_claim CHECK(
       (action_status IN ('SUCCEEDED','FAILED') AND active_target_key IS NULL) OR
       (action_status IN ('REQUESTED','IN_PROGRESS','UNKNOWN') AND active_target_key IS NOT NULL))
);
CREATE INDEX ix_recovery_tenant_requested ON operations_recovery_action(tenant_id,requested_at,recovery_action_id);
-- active_target_key is a short-transaction manual action mutex, NOT a worker lease.
-- UNKNOWN/IN_PROGRESS are never reclaimed based on elapsed time.

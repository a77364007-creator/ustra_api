CREATE TABLE entitlement_operation_scope (
    entitlement_operation_scope_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NOT NULL,
    entitlement_id CHAR(36) NOT NULL,
    api_operation_id CHAR(36) NOT NULL,
    created_at DATETIME(6) NOT NULL,
    created_by VARCHAR(200) NOT NULL,
    CONSTRAINT pk_entitlement_operation_scope PRIMARY KEY (entitlement_operation_scope_id),
    CONSTRAINT fk_entitlement_scope_tenant FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id),
    CONSTRAINT fk_entitlement_scope_entitlement_tenant FOREIGN KEY (tenant_id, entitlement_id)
        REFERENCES entitlement(tenant_id, entitlement_id),
    CONSTRAINT fk_entitlement_scope_operation_tenant FOREIGN KEY (tenant_id, api_operation_id)
        REFERENCES api_operation(tenant_id, api_operation_id),
    CONSTRAINT uq_entitlement_operation_scope UNIQUE (tenant_id, entitlement_id, api_operation_id)
);
CREATE INDEX ix_entitlement_scope_entitlement ON entitlement_operation_scope(tenant_id, entitlement_id);

CREATE TABLE quota_profile (
    quota_profile_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NOT NULL,
    entitlement_id CHAR(36) NOT NULL,
    profile_revision INT NOT NULL,
    status VARCHAR(20) NOT NULL,
    created_at DATETIME(6) NOT NULL,
    created_by VARCHAR(200) NOT NULL,
    CONSTRAINT pk_quota_profile PRIMARY KEY (quota_profile_id),
    CONSTRAINT fk_quota_profile_tenant FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id),
    CONSTRAINT uq_quota_profile_tenant_id UNIQUE (tenant_id, quota_profile_id),
    CONSTRAINT uq_quota_profile_entitlement UNIQUE (tenant_id, entitlement_id),
    CONSTRAINT fk_quota_profile_entitlement_tenant FOREIGN KEY (tenant_id, entitlement_id)
        REFERENCES entitlement(tenant_id, entitlement_id),
    CONSTRAINT ck_quota_profile_revision CHECK (profile_revision >= 1),
    CONSTRAINT ck_quota_profile_status CHECK (status IN ('ACTIVE'))
);

CREATE TABLE quota_limit (
    quota_limit_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NOT NULL,
    quota_profile_id CHAR(36) NOT NULL,
    metric_code VARCHAR(100) NOT NULL,
    limit_value DECIMAL(20,4) NOT NULL,
    window_seconds BIGINT NOT NULL,
    unit_code VARCHAR(50) NOT NULL,
    created_at DATETIME(6) NOT NULL,
    created_by VARCHAR(200) NOT NULL,
    CONSTRAINT pk_quota_limit PRIMARY KEY (quota_limit_id),
    CONSTRAINT fk_quota_limit_tenant FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id),
    CONSTRAINT fk_quota_limit_profile_tenant FOREIGN KEY (tenant_id, quota_profile_id)
        REFERENCES quota_profile(tenant_id, quota_profile_id),
    CONSTRAINT uq_quota_limit_metric UNIQUE (tenant_id, quota_profile_id, metric_code, window_seconds, unit_code),
    CONSTRAINT ck_quota_limit_value CHECK (limit_value > 0),
    CONSTRAINT ck_quota_limit_window CHECK (window_seconds > 0)
);

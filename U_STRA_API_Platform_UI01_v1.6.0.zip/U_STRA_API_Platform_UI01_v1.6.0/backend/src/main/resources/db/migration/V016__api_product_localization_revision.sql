ALTER TABLE api_product
    ADD COLUMN localization_revision BIGINT NOT NULL DEFAULT 1;

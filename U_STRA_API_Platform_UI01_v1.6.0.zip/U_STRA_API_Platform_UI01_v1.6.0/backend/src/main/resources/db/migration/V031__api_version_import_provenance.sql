ALTER TABLE api_version
    ADD COLUMN source_type VARCHAR(40) NULL,
    ADD COLUMN source_repository VARCHAR(500) NULL,
    ADD COLUMN source_path VARCHAR(1000) NULL,
    ADD COLUMN source_revision VARCHAR(200) NULL,
    ADD COLUMN source_content_hash CHAR(64) NULL,
    ADD COLUMN source_import_id CHAR(36) NULL,
    ADD COLUMN source_imported_at DATETIME(6) NULL;

ALTER TABLE api_version
    ADD CONSTRAINT fk_api_version_source_import_tenant FOREIGN KEY (tenant_id, source_import_id)
        REFERENCES api_import(tenant_id, api_import_id);
CREATE INDEX ix_api_version_source_hash ON api_version(tenant_id, api_id, version, source_content_hash);

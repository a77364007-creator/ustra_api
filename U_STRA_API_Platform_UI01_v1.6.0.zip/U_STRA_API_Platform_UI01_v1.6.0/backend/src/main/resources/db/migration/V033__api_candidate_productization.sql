ALTER TABLE api_candidate
    DROP CONSTRAINT ck_api_candidate_state;

ALTER TABLE api_candidate
    ADD COLUMN api_product_id CHAR(36) NULL,
    ADD COLUMN api_product_version_id CHAR(36) NULL,
    ADD CONSTRAINT ck_api_candidate_state
        CHECK (state IN ('DETECTED','ASSESSING','ACCEPTED','REJECTED','PRODUCTIZING','COMPLETED')),
    ADD CONSTRAINT fk_api_candidate_product_tenant
        FOREIGN KEY (tenant_id, api_product_id)
        REFERENCES api_product(tenant_id, api_product_id),
    ADD CONSTRAINT fk_api_candidate_product_version_tenant
        FOREIGN KEY (tenant_id, api_product_version_id)
        REFERENCES api_product_version(tenant_id, api_product_version_id);

CREATE INDEX ix_api_candidate_productization
    ON api_candidate(tenant_id, api_product_id, api_product_version_id, state);

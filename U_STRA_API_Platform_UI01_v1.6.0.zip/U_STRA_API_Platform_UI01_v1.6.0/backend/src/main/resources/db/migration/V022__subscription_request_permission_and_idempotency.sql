INSERT INTO permission (permission_id, permission_code, resource_type, action, status) VALUES
('13000000-0000-0000-0000-000000000001', 'SUBSCRIPTION:REQUEST', 'SUBSCRIPTION_REQUEST', 'REQUEST', 'ACTIVE');

-- Deliberately no role_permission row. Role -> Permission mapping remains administrator/configuration policy.

CREATE TABLE subscription_request_idempotency (
    subscription_request_idempotency_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NOT NULL,
    operation_code VARCHAR(80) NOT NULL,
    idempotency_key VARCHAR(200) NOT NULL,
    request_fingerprint CHAR(64) NOT NULL,
    subscription_request_id CHAR(36) NOT NULL,
    created_at DATETIME(6) NOT NULL,
    CONSTRAINT pk_subscription_request_idempotency PRIMARY KEY (subscription_request_idempotency_id),
    CONSTRAINT fk_subscription_request_idempotency_tenant FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id),
    CONSTRAINT fk_subscription_request_idempotency_request_tenant FOREIGN KEY (tenant_id, subscription_request_id)
        REFERENCES subscription_request(tenant_id, subscription_request_id),
    CONSTRAINT uq_subscription_request_idempotency_key
        UNIQUE (tenant_id, operation_code, idempotency_key)
);

CREATE INDEX ix_subscription_request_idempotency_request
    ON subscription_request_idempotency(tenant_id, subscription_request_id);

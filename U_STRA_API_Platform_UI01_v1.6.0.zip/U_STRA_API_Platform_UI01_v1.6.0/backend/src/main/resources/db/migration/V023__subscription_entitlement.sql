CREATE TABLE subscription (
    subscription_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NOT NULL,
    source_subscription_request_id CHAR(36) NOT NULL,
    source_request_revision_no INT NOT NULL,
    source_snapshot_hash CHAR(64) NOT NULL,
    approval_reference_id VARCHAR(200) NOT NULL,
    consumer_app_environment_id CHAR(36) NOT NULL,
    api_product_version_id CHAR(36) NOT NULL,
    status VARCHAR(30) NOT NULL,
    effective_from DATETIME(6) NOT NULL,
    effective_to DATETIME(6) NOT NULL,
    row_version BIGINT NOT NULL DEFAULT 0,
    created_at DATETIME(6) NOT NULL,
    created_by VARCHAR(200) NOT NULL,
    updated_at DATETIME(6) NOT NULL,
    updated_by VARCHAR(200) NOT NULL,
    CONSTRAINT pk_subscription PRIMARY KEY (subscription_id),
    CONSTRAINT fk_subscription_tenant FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id),
    CONSTRAINT uq_subscription_tenant_id UNIQUE (tenant_id, subscription_id),
    CONSTRAINT uq_subscription_source_request UNIQUE (tenant_id, source_subscription_request_id),
    CONSTRAINT fk_subscription_request_tenant FOREIGN KEY (tenant_id, source_subscription_request_id)
        REFERENCES subscription_request(tenant_id, subscription_request_id),
    CONSTRAINT fk_subscription_environment_tenant FOREIGN KEY (tenant_id, consumer_app_environment_id)
        REFERENCES consumer_app_environment(tenant_id, consumer_app_environment_id),
    CONSTRAINT fk_subscription_product_version_tenant FOREIGN KEY (tenant_id, api_product_version_id)
        REFERENCES api_product_version(tenant_id, api_product_version_id),
    CONSTRAINT ck_subscription_status CHECK (status IN ('PENDING_ACTIVATION','ACTIVE','SUSPENDED','EXPIRED','TERMINATED')),
    CONSTRAINT ck_subscription_effective_period CHECK (effective_from < effective_to),
    CONSTRAINT ck_subscription_source_revision CHECK (source_request_revision_no >= 1)
);
CREATE INDEX ix_subscription_tenant_status ON subscription(tenant_id, status, created_at);
CREATE INDEX ix_subscription_tenant_environment ON subscription(tenant_id, consumer_app_environment_id);
CREATE INDEX ix_subscription_tenant_product_version ON subscription(tenant_id, api_product_version_id);

CREATE TABLE entitlement (
    entitlement_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NOT NULL,
    subscription_id CHAR(36) NOT NULL,
    consumer_app_environment_id CHAR(36) NOT NULL,
    api_product_version_id CHAR(36) NOT NULL,
    status VARCHAR(30) NOT NULL,
    effective_from DATETIME(6) NOT NULL,
    effective_to DATETIME(6) NOT NULL,
    policy_revision INT NOT NULL,
    row_version BIGINT NOT NULL DEFAULT 0,
    created_at DATETIME(6) NOT NULL,
    created_by VARCHAR(200) NOT NULL,
    updated_at DATETIME(6) NOT NULL,
    updated_by VARCHAR(200) NOT NULL,
    CONSTRAINT pk_entitlement PRIMARY KEY (entitlement_id),
    CONSTRAINT fk_entitlement_tenant FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id),
    CONSTRAINT uq_entitlement_tenant_id UNIQUE (tenant_id, entitlement_id),
    CONSTRAINT fk_entitlement_subscription_tenant FOREIGN KEY (tenant_id, subscription_id)
        REFERENCES subscription(tenant_id, subscription_id),
    CONSTRAINT fk_entitlement_environment_tenant FOREIGN KEY (tenant_id, consumer_app_environment_id)
        REFERENCES consumer_app_environment(tenant_id, consumer_app_environment_id),
    CONSTRAINT fk_entitlement_product_version_tenant FOREIGN KEY (tenant_id, api_product_version_id)
        REFERENCES api_product_version(tenant_id, api_product_version_id),
    CONSTRAINT ck_entitlement_status CHECK (status IN ('GRANTED','SUSPENDED','REVOKED','EXPIRED')),
    CONSTRAINT ck_entitlement_effective_period CHECK (effective_from < effective_to),
    CONSTRAINT ck_entitlement_policy_revision CHECK (policy_revision >= 1)
);
CREATE INDEX ix_entitlement_tenant_subscription ON entitlement(tenant_id, subscription_id);
CREATE INDEX ix_entitlement_tenant_environment ON entitlement(tenant_id, consumer_app_environment_id);
CREATE INDEX ix_entitlement_tenant_status ON entitlement(tenant_id, status, effective_to);

CREATE TABLE provider (
    provider_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NOT NULL,
    provider_code VARCHAR(100) NOT NULL,
    display_name VARCHAR(200) NOT NULL,
    organization_id CHAR(36) NULL,
    row_version BIGINT NOT NULL DEFAULT 0,
    created_at DATETIME(6) NOT NULL,
    created_by VARCHAR(200) NOT NULL,
    updated_at DATETIME(6) NOT NULL,
    updated_by VARCHAR(200) NOT NULL,
    CONSTRAINT pk_provider PRIMARY KEY (provider_id),
    CONSTRAINT fk_provider_tenant FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id),
    CONSTRAINT uq_provider_tenant_id UNIQUE (tenant_id, provider_id),
    CONSTRAINT fk_provider_organization_tenant FOREIGN KEY (tenant_id, organization_id)
        REFERENCES organization(tenant_id, organization_id)
);

CREATE INDEX ix_provider_tenant_code ON provider(tenant_id, provider_code);

CREATE TABLE api_product (
    api_product_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NOT NULL,
    product_code VARCHAR(100) NOT NULL,
    product_code_normalized VARCHAR(100) NOT NULL,
    name VARCHAR(200) NOT NULL,
    description TEXT NULL,
    provider_id CHAR(36) NULL,
    owner_membership_id CHAR(36) NULL,
    lifecycle_state VARCHAR(30) NOT NULL,
    row_version BIGINT NOT NULL DEFAULT 0,
    created_at DATETIME(6) NOT NULL,
    created_by VARCHAR(200) NOT NULL,
    updated_at DATETIME(6) NOT NULL,
    updated_by VARCHAR(200) NOT NULL,
    CONSTRAINT pk_api_product PRIMARY KEY (api_product_id),
    CONSTRAINT fk_api_product_tenant FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id),
    CONSTRAINT uq_api_product_tenant_id UNIQUE (tenant_id, api_product_id),
    CONSTRAINT uq_api_product_tenant_code UNIQUE (tenant_id, product_code_normalized),
    CONSTRAINT fk_api_product_provider_tenant FOREIGN KEY (tenant_id, provider_id)
        REFERENCES provider(tenant_id, provider_id),
    CONSTRAINT fk_api_product_owner_tenant FOREIGN KEY (tenant_id, owner_membership_id)
        REFERENCES membership(tenant_id, membership_id),
    CONSTRAINT ck_api_product_lifecycle CHECK (lifecycle_state IN ('DRAFT', 'REVIEWING', 'ACTIVE', 'DEPRECATED', 'RETIRED'))
);

CREATE INDEX ix_api_product_tenant_state_code ON api_product(tenant_id, lifecycle_state, product_code_normalized);
CREATE INDEX ix_api_product_tenant_provider ON api_product(tenant_id, provider_id);
CREATE INDEX ix_api_product_tenant_owner ON api_product(tenant_id, owner_membership_id);

CREATE TABLE api (
    api_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NOT NULL,
    api_code VARCHAR(100) NOT NULL,
    api_code_normalized VARCHAR(100) NOT NULL,
    name VARCHAR(200) NOT NULL,
    description TEXT NULL,
    provider_id CHAR(36) NULL,
    row_version BIGINT NOT NULL DEFAULT 0,
    created_at DATETIME(6) NOT NULL,
    created_by VARCHAR(200) NOT NULL,
    updated_at DATETIME(6) NOT NULL,
    updated_by VARCHAR(200) NOT NULL,
    CONSTRAINT pk_api PRIMARY KEY (api_id),
    CONSTRAINT fk_api_tenant FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id),
    CONSTRAINT uq_api_tenant_id UNIQUE (tenant_id, api_id),
    CONSTRAINT fk_api_provider_tenant FOREIGN KEY (tenant_id, provider_id)
        REFERENCES provider(tenant_id, provider_id)
);

CREATE INDEX ix_api_tenant_code ON api(tenant_id, api_code_normalized);

CREATE TABLE api_version (
    api_version_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NOT NULL,
    api_id CHAR(36) NOT NULL,
    version VARCHAR(100) NOT NULL,
    state VARCHAR(30) NOT NULL,
    row_version BIGINT NOT NULL DEFAULT 0,
    created_at DATETIME(6) NOT NULL,
    created_by VARCHAR(200) NOT NULL,
    updated_at DATETIME(6) NOT NULL,
    updated_by VARCHAR(200) NOT NULL,
    CONSTRAINT pk_api_version PRIMARY KEY (api_version_id),
    CONSTRAINT fk_api_version_tenant FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id),
    CONSTRAINT uq_api_version_tenant_id UNIQUE (tenant_id, api_version_id),
    CONSTRAINT fk_api_version_api_tenant FOREIGN KEY (tenant_id, api_id)
        REFERENCES api(tenant_id, api_id),
    CONSTRAINT uq_api_version_api_version UNIQUE (api_id, version),
    CONSTRAINT ck_api_version_state CHECK (state IN ('DRAFT', 'VALIDATED', 'RELEASED', 'DEPRECATED', 'RETIRED'))
);

CREATE INDEX ix_api_version_tenant_api ON api_version(tenant_id, api_id);

CREATE TABLE api_operation (
    api_operation_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NOT NULL,
    api_version_id CHAR(36) NOT NULL,
    method VARCHAR(20) NOT NULL,
    path VARCHAR(1000) NOT NULL,
    normalized_path VARCHAR(1000) NOT NULL,
    operation_key VARCHAR(200) NULL,
    summary VARCHAR(500) NULL,
    row_version BIGINT NOT NULL DEFAULT 0,
    created_at DATETIME(6) NOT NULL,
    created_by VARCHAR(200) NOT NULL,
    updated_at DATETIME(6) NOT NULL,
    updated_by VARCHAR(200) NOT NULL,
    CONSTRAINT pk_api_operation PRIMARY KEY (api_operation_id),
    CONSTRAINT fk_api_operation_tenant FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id),
    CONSTRAINT fk_api_operation_version_tenant FOREIGN KEY (tenant_id, api_version_id)
        REFERENCES api_version(tenant_id, api_version_id),
    CONSTRAINT uq_api_operation_version_method_path UNIQUE (api_version_id, method, normalized_path)
);

CREATE INDEX ix_api_operation_tenant_version ON api_operation(tenant_id, api_version_id);

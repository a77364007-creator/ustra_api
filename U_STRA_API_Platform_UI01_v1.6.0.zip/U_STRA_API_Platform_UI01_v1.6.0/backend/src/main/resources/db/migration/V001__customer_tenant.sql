CREATE TABLE customer (
    customer_id CHAR(36) NOT NULL,
    customer_code VARCHAR(80) NOT NULL,
    display_name VARCHAR(200) NOT NULL,
    status VARCHAR(30) NOT NULL,
    created_at DATETIME(6) NOT NULL,
    updated_at DATETIME(6) NOT NULL,
    CONSTRAINT pk_customer PRIMARY KEY (customer_id),
    CONSTRAINT ck_customer_status CHECK (status IN ('ACTIVE', 'INACTIVE'))
);

CREATE TABLE tenant (
    tenant_id CHAR(36) NOT NULL,
    customer_id CHAR(36) NOT NULL,
    tenant_code VARCHAR(80) NOT NULL,
    display_name VARCHAR(200) NOT NULL,
    status VARCHAR(30) NOT NULL,
    default_locale VARCHAR(35) NOT NULL,
    timezone VARCHAR(80) NOT NULL,
    isolation_profile VARCHAR(40) NOT NULL,
    row_version BIGINT NOT NULL DEFAULT 0,
    created_at DATETIME(6) NOT NULL,
    updated_at DATETIME(6) NOT NULL,
    CONSTRAINT pk_tenant PRIMARY KEY (tenant_id),
    CONSTRAINT fk_tenant_customer FOREIGN KEY (customer_id) REFERENCES customer(customer_id),
    CONSTRAINT ck_tenant_status CHECK (status IN ('DRAFT', 'ACTIVE', 'SUSPENDED', 'RETIRED'))
);

CREATE INDEX ix_tenant_customer ON tenant(customer_id);
CREATE INDEX ix_tenant_code ON tenant(tenant_code);

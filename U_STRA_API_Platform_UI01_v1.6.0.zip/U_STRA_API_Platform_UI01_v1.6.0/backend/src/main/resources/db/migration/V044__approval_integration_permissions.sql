INSERT INTO permission (permission_id, permission_code, resource_type, action, status) VALUES
('19000000-0000-0000-0000-000000000001', 'APPROVAL_INTEGRATION:READ', 'APPROVAL_INTEGRATION', 'READ', 'ACTIVE'),
('19000000-0000-0000-0000-000000000002', 'APPROVAL_INTEGRATION:RECONCILE', 'APPROVAL_INTEGRATION', 'RECONCILE', 'ACTIVE');

-- Deliberately no role_permission rows. Operator authority remains tenant administration policy.

CREATE TABLE catalog_publication (
    catalog_publication_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NOT NULL,
    api_product_version_id CHAR(36) NOT NULL,
    lifecycle_state VARCHAR(30) NOT NULL,
    row_version BIGINT NOT NULL DEFAULT 0,
    created_at DATETIME(6) NOT NULL,
    created_by VARCHAR(200) NOT NULL,
    updated_at DATETIME(6) NOT NULL,
    updated_by VARCHAR(200) NOT NULL,
    CONSTRAINT pk_catalog_publication PRIMARY KEY (catalog_publication_id),
    CONSTRAINT fk_catalog_publication_tenant FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id),
    CONSTRAINT uq_catalog_publication_tenant_id UNIQUE (tenant_id, catalog_publication_id),
    CONSTRAINT fk_catalog_publication_version_tenant FOREIGN KEY (tenant_id, api_product_version_id)
        REFERENCES api_product_version(tenant_id, api_product_version_id),
    CONSTRAINT ck_catalog_publication_state CHECK (lifecycle_state IN ('DRAFT', 'ACTIVE', 'SUSPENDED', 'WITHDRAWN'))
);

CREATE INDEX ix_catalog_publication_tenant_version ON catalog_publication(tenant_id, api_product_version_id);
CREATE INDEX ix_catalog_publication_tenant_state ON catalog_publication(tenant_id, lifecycle_state);

CREATE TABLE audience_scope (
    audience_scope_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NOT NULL,
    catalog_publication_id CHAR(36) NOT NULL,
    scope_type VARCHAR(30) NOT NULL,
    organization_id CHAR(36) NULL,
    created_at DATETIME(6) NOT NULL,
    created_by VARCHAR(200) NOT NULL,
    CONSTRAINT pk_audience_scope PRIMARY KEY (audience_scope_id),
    CONSTRAINT fk_audience_scope_tenant FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id),
    CONSTRAINT fk_audience_scope_publication_tenant FOREIGN KEY (tenant_id, catalog_publication_id)
        REFERENCES catalog_publication(tenant_id, catalog_publication_id),
    CONSTRAINT fk_audience_scope_organization_tenant FOREIGN KEY (tenant_id, organization_id)
        REFERENCES organization(tenant_id, organization_id),
    CONSTRAINT ck_audience_scope_type CHECK (scope_type IN ('TENANT', 'ORGANIZATION')),
    CONSTRAINT ck_audience_scope_target CHECK (
        (scope_type = 'TENANT' AND organization_id IS NULL)
        OR
        (scope_type = 'ORGANIZATION' AND organization_id IS NOT NULL)
    )
);

CREATE INDEX ix_audience_scope_publication ON audience_scope(tenant_id, catalog_publication_id);
CREATE INDEX ix_audience_scope_organization ON audience_scope(tenant_id, organization_id);

CREATE TABLE state_transition_history (
    state_transition_history_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NOT NULL,
    aggregate_type VARCHAR(80) NOT NULL,
    aggregate_id VARCHAR(200) NOT NULL,
    from_state VARCHAR(40) NOT NULL,
    to_state VARCHAR(40) NOT NULL,
    occurred_at DATETIME(6) NOT NULL,
    actor_principal_id VARCHAR(200) NOT NULL,
    correlation_id VARCHAR(100) NOT NULL,
    CONSTRAINT pk_state_transition_history PRIMARY KEY (state_transition_history_id),
    CONSTRAINT fk_state_transition_tenant FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id)
);

CREATE INDEX ix_state_transition_tenant_aggregate
    ON state_transition_history(tenant_id, aggregate_type, aggregate_id, occurred_at);

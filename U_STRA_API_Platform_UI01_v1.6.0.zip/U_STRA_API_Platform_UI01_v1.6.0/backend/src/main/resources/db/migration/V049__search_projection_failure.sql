CREATE TABLE search_projection_failure (
    failure_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NOT NULL,
    api_product_id CHAR(36) NOT NULL,
    observed_at DATETIME(6) NOT NULL,
    last_checked_at DATETIME(6) NOT NULL,
    resolved_at DATETIME(6) NULL,
    safe_error_code VARCHAR(120) NOT NULL,
    status VARCHAR(30) NOT NULL,
    observation_count BIGINT NOT NULL DEFAULT 0,
    row_version BIGINT NOT NULL DEFAULT 0,
    CONSTRAINT pk_search_projection_failure PRIMARY KEY(failure_id),
    CONSTRAINT fk_search_failure_tenant FOREIGN KEY(tenant_id) REFERENCES tenant(tenant_id),
    CONSTRAINT uq_search_failure_product UNIQUE(tenant_id,api_product_id),
    CONSTRAINT ck_search_failure_status CHECK(status IN ('OPEN','RESOLVED'))
);
CREATE INDEX ix_search_failure_tenant_status ON search_projection_failure(tenant_id,status,last_checked_at,failure_id);
-- No Product FK: an observation must survive deletion/cleanup of the source Product.
-- No fake ConnectorInstance/IntegrationOperation is created for search failures.

CREATE TABLE role_definition (
    role_id CHAR(36) NOT NULL,
    role_code VARCHAR(100) NOT NULL,
    display_name VARCHAR(200) NOT NULL,
    scope_type VARCHAR(30) NOT NULL,
    system_managed BOOLEAN NOT NULL,
    status VARCHAR(30) NOT NULL,
    CONSTRAINT pk_role PRIMARY KEY (role_id),
    CONSTRAINT uq_role_code UNIQUE (role_code),
    CONSTRAINT ck_role_scope_type CHECK (scope_type IN ('PLATFORM', 'TENANT')),
    CONSTRAINT ck_role_status CHECK (status IN ('ACTIVE', 'INACTIVE'))
);

CREATE TABLE permission (
    permission_id CHAR(36) NOT NULL,
    permission_code VARCHAR(120) NOT NULL,
    resource_type VARCHAR(80) NOT NULL,
    action VARCHAR(80) NOT NULL,
    status VARCHAR(30) NOT NULL,
    CONSTRAINT pk_permission PRIMARY KEY (permission_id),
    CONSTRAINT uq_permission_code UNIQUE (permission_code),
    CONSTRAINT ck_permission_status CHECK (status IN ('ACTIVE', 'INACTIVE'))
);

CREATE TABLE role_permission (
    role_id CHAR(36) NOT NULL,
    permission_id CHAR(36) NOT NULL,
    CONSTRAINT pk_role_permission PRIMARY KEY (role_id, permission_id),
    CONSTRAINT fk_role_permission_role FOREIGN KEY (role_id) REFERENCES role_definition(role_id),
    CONSTRAINT fk_role_permission_permission FOREIGN KEY (permission_id) REFERENCES permission(permission_id)
);

CREATE TABLE subscription_request_revision (
    subscription_request_revision_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NOT NULL,
    subscription_request_id CHAR(36) NOT NULL,
    revision_no INT NOT NULL,
    author_membership_id CHAR(36) NOT NULL,
    purpose TEXT NOT NULL,
    expected_call_volume VARCHAR(500) NULL,
    snapshot_hash CHAR(64) NOT NULL,
    created_at DATETIME(6) NOT NULL,
    created_by VARCHAR(200) NOT NULL,
    CONSTRAINT pk_subscription_request_revision PRIMARY KEY (subscription_request_revision_id),
    CONSTRAINT fk_subscription_request_revision_tenant FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id),
    CONSTRAINT fk_subscription_request_revision_request_tenant FOREIGN KEY (tenant_id, subscription_request_id)
        REFERENCES subscription_request(tenant_id, subscription_request_id),
    CONSTRAINT fk_subscription_request_revision_author_tenant FOREIGN KEY (tenant_id, author_membership_id)
        REFERENCES membership(tenant_id, membership_id),
    CONSTRAINT uq_subscription_request_revision_number
        UNIQUE (tenant_id, subscription_request_id, revision_no),
    CONSTRAINT ck_subscription_request_revision_no CHECK (revision_no >= 1)
);

CREATE INDEX ix_subscription_request_revision_request
    ON subscription_request_revision(tenant_id, subscription_request_id, revision_no);

ALTER TABLE integration_profile
    DROP CONSTRAINT ck_integration_profile_type;

ALTER TABLE integration_profile
    ADD CONSTRAINT ck_integration_profile_type
        CHECK (integration_type IN ('APPROVAL_ITSM','GATEWAY_IAM'));

ALTER TABLE integration_operation
    DROP CONSTRAINT ck_integration_operation_type;

ALTER TABLE integration_operation
    ADD CONSTRAINT ck_integration_operation_type
        CHECK (operation_type IN (
            'APPROVAL_CASE_CREATE',
            'APPROVAL_STATUS_QUERY',
            'GATEWAY_PROVISION',
            'GATEWAY_DEPROVISION',
            'GATEWAY_STATUS_QUERY'
        ));

CREATE TABLE api_product_localized_content (
    localized_content_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NOT NULL,
    api_product_id CHAR(36) NOT NULL,
    locale VARCHAR(35) NOT NULL,
    status VARCHAR(20) NOT NULL,
    content_revision BIGINT NOT NULL,
    source_localization_revision BIGINT NOT NULL,
    localized_name VARCHAR(200) NOT NULL,
    localized_description TEXT NULL,
    published_at DATETIME(6) NULL,
    published_by VARCHAR(200) NULL,
    row_version BIGINT NOT NULL DEFAULT 0,
    created_at DATETIME(6) NOT NULL,
    created_by VARCHAR(200) NOT NULL,
    updated_at DATETIME(6) NOT NULL,
    updated_by VARCHAR(200) NOT NULL,
    CONSTRAINT pk_api_product_localized_content PRIMARY KEY (localized_content_id),
    CONSTRAINT fk_localized_content_tenant FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id),
    CONSTRAINT fk_localized_content_product_tenant FOREIGN KEY (tenant_id, api_product_id)
        REFERENCES api_product(tenant_id, api_product_id),
    CONSTRAINT uq_localized_content_product_locale UNIQUE (tenant_id, api_product_id, locale),
    CONSTRAINT ck_localized_content_status CHECK (status IN ('DRAFT', 'REVIEW', 'PUBLISHED', 'STALE')),
    CONSTRAINT ck_localized_content_revision CHECK (content_revision >= 1),
    CONSTRAINT ck_localized_content_source_revision CHECK (source_localization_revision >= 1)
);

CREATE INDEX ix_localized_content_tenant_product_status
    ON api_product_localized_content(tenant_id, api_product_id, status);

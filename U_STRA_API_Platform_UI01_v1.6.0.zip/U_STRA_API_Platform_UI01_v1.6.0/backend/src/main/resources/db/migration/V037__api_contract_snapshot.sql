CREATE TABLE api_contract_snapshot (
    api_contract_snapshot_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NOT NULL,
    api_version_id CHAR(36) NOT NULL,
    source_content_hash CHAR(64) NOT NULL,
    snapshot_schema_version VARCHAR(30) NOT NULL,
    structural_hash CHAR(64) NOT NULL,
    created_at DATETIME(6) NOT NULL,
    created_by VARCHAR(200) NOT NULL,
    CONSTRAINT pk_api_contract_snapshot PRIMARY KEY (api_contract_snapshot_id),
    CONSTRAINT fk_contract_snapshot_tenant FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id),
    CONSTRAINT uq_contract_snapshot_tenant_id UNIQUE (tenant_id, api_contract_snapshot_id),
    CONSTRAINT fk_contract_snapshot_api_version_tenant FOREIGN KEY (tenant_id, api_version_id)
        REFERENCES api_version(tenant_id, api_version_id),
    CONSTRAINT uq_contract_snapshot_api_version UNIQUE (tenant_id, api_version_id)
);
CREATE INDEX ix_contract_snapshot_hash ON api_contract_snapshot(tenant_id, structural_hash);

CREATE TABLE api_contract_operation_snapshot (
    api_contract_operation_snapshot_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NOT NULL,
    api_contract_snapshot_id CHAR(36) NOT NULL,
    method VARCHAR(20) NOT NULL,
    normalized_path VARCHAR(1000) NOT NULL,
    operation_fingerprint CHAR(64) NOT NULL,
    CONSTRAINT pk_contract_operation_snapshot PRIMARY KEY (api_contract_operation_snapshot_id),
    CONSTRAINT fk_contract_operation_tenant FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id),
    CONSTRAINT uq_contract_operation_tenant_id UNIQUE (tenant_id, api_contract_operation_snapshot_id),
    CONSTRAINT fk_contract_operation_parent_tenant FOREIGN KEY (tenant_id, api_contract_snapshot_id)
        REFERENCES api_contract_snapshot(tenant_id, api_contract_snapshot_id),
    CONSTRAINT uq_contract_operation_identity UNIQUE (tenant_id, api_contract_snapshot_id, method, normalized_path)
);
CREATE INDEX ix_contract_operation_parent ON api_contract_operation_snapshot(tenant_id, api_contract_snapshot_id);

CREATE TABLE api_contract_parameter_snapshot (
    api_contract_parameter_snapshot_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NOT NULL,
    api_contract_operation_snapshot_id CHAR(36) NOT NULL,
    parameter_location VARCHAR(20) NOT NULL,
    parameter_name VARCHAR(300) NOT NULL,
    required_flag BOOLEAN NOT NULL,
    schema_fingerprint CHAR(64) NOT NULL,
    parameter_fingerprint CHAR(64) NOT NULL,
    CONSTRAINT pk_contract_parameter_snapshot PRIMARY KEY (api_contract_parameter_snapshot_id),
    CONSTRAINT fk_contract_parameter_tenant FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id),
    CONSTRAINT fk_contract_parameter_operation_tenant FOREIGN KEY (tenant_id, api_contract_operation_snapshot_id)
        REFERENCES api_contract_operation_snapshot(tenant_id, api_contract_operation_snapshot_id),
    CONSTRAINT uq_contract_parameter_identity UNIQUE (
        tenant_id, api_contract_operation_snapshot_id, parameter_location, parameter_name)
);

CREATE TABLE api_contract_body_snapshot (
    api_contract_body_snapshot_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NOT NULL,
    api_contract_operation_snapshot_id CHAR(36) NOT NULL,
    required_flag BOOLEAN NOT NULL,
    media_type VARCHAR(200) NOT NULL,
    schema_fingerprint CHAR(64) NOT NULL,
    body_fingerprint CHAR(64) NOT NULL,
    CONSTRAINT pk_contract_body_snapshot PRIMARY KEY (api_contract_body_snapshot_id),
    CONSTRAINT fk_contract_body_tenant FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id),
    CONSTRAINT fk_contract_body_operation_tenant FOREIGN KEY (tenant_id, api_contract_operation_snapshot_id)
        REFERENCES api_contract_operation_snapshot(tenant_id, api_contract_operation_snapshot_id),
    CONSTRAINT uq_contract_body_media UNIQUE (tenant_id, api_contract_operation_snapshot_id, media_type)
);

CREATE TABLE api_contract_response_snapshot (
    api_contract_response_snapshot_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NOT NULL,
    api_contract_operation_snapshot_id CHAR(36) NOT NULL,
    response_code VARCHAR(20) NOT NULL,
    media_type VARCHAR(200) NOT NULL,
    schema_fingerprint CHAR(64) NOT NULL,
    response_fingerprint CHAR(64) NOT NULL,
    CONSTRAINT pk_contract_response_snapshot PRIMARY KEY (api_contract_response_snapshot_id),
    CONSTRAINT fk_contract_response_tenant FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id),
    CONSTRAINT fk_contract_response_operation_tenant FOREIGN KEY (tenant_id, api_contract_operation_snapshot_id)
        REFERENCES api_contract_operation_snapshot(tenant_id, api_contract_operation_snapshot_id),
    CONSTRAINT uq_contract_response_identity UNIQUE (
        tenant_id, api_contract_operation_snapshot_id, response_code, media_type)
);

CREATE TABLE api_contract_security_snapshot (
    api_contract_security_snapshot_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NOT NULL,
    api_contract_operation_snapshot_id CHAR(36) NOT NULL,
    requirement_index INT NOT NULL,
    requirement_fingerprint CHAR(64) NOT NULL,
    CONSTRAINT pk_contract_security_snapshot PRIMARY KEY (api_contract_security_snapshot_id),
    CONSTRAINT fk_contract_security_tenant FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id),
    CONSTRAINT fk_contract_security_operation_tenant FOREIGN KEY (tenant_id, api_contract_operation_snapshot_id)
        REFERENCES api_contract_operation_snapshot(tenant_id, api_contract_operation_snapshot_id),
    CONSTRAINT uq_contract_security_index UNIQUE (
        tenant_id, api_contract_operation_snapshot_id, requirement_index)
);

ALTER TABLE api_product_version
    ADD COLUMN approved_review_id CHAR(36) NULL,
    ADD CONSTRAINT fk_product_version_approved_review_tenant
        FOREIGN KEY (tenant_id, approved_review_id)
        REFERENCES publication_review(tenant_id, publication_review_id);

CREATE INDEX ix_product_version_approved_review
    ON api_product_version(tenant_id, approved_review_id);

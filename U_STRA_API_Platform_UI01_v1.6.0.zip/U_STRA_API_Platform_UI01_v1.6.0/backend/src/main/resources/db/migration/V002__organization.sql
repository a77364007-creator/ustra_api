CREATE TABLE organization (
    organization_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NOT NULL,
    organization_code VARCHAR(80) NOT NULL,
    display_name VARCHAR(200) NOT NULL,
    parent_organization_id CHAR(36) NULL,
    status VARCHAR(30) NOT NULL,
    row_version BIGINT NOT NULL DEFAULT 0,
    created_at DATETIME(6) NOT NULL,
    updated_at DATETIME(6) NOT NULL,
    CONSTRAINT pk_organization PRIMARY KEY (organization_id),
    CONSTRAINT fk_organization_tenant FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id),
    CONSTRAINT uq_organization_tenant_id UNIQUE (tenant_id, organization_id),
    CONSTRAINT fk_organization_parent_tenant FOREIGN KEY (tenant_id, parent_organization_id) REFERENCES organization(tenant_id, organization_id),
    CONSTRAINT uq_organization_tenant_code UNIQUE (tenant_id, organization_code),
    CONSTRAINT ck_organization_status CHECK (status IN ('ACTIVE', 'INACTIVE')),
    CONSTRAINT ck_organization_not_self_parent CHECK (parent_organization_id IS NULL OR parent_organization_id <> organization_id)
);

CREATE INDEX ix_organization_tenant_parent ON organization(tenant_id, parent_organization_id);

CREATE TABLE role_assignment (
    role_assignment_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NULL,
    membership_id CHAR(36) NULL,
    principal_id VARCHAR(200) NULL,
    role_id CHAR(36) NOT NULL,
    organization_scope_id CHAR(36) NULL,
    effective_from DATETIME(6) NOT NULL,
    effective_to DATETIME(6) NULL,
    status VARCHAR(30) NOT NULL,
    assigned_by VARCHAR(200) NOT NULL,
    assigned_at DATETIME(6) NOT NULL,
    revoked_by VARCHAR(200) NULL,
    revoked_at DATETIME(6) NULL,
    row_version BIGINT NOT NULL DEFAULT 0,
    CONSTRAINT pk_role_assignment PRIMARY KEY (role_assignment_id),
    CONSTRAINT fk_role_assignment_tenant FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id),
    CONSTRAINT fk_role_assignment_membership_tenant FOREIGN KEY (tenant_id, membership_id) REFERENCES membership(tenant_id, membership_id),
    CONSTRAINT fk_role_assignment_role FOREIGN KEY (role_id) REFERENCES role_definition(role_id),
    CONSTRAINT fk_role_assignment_org_scope_tenant FOREIGN KEY (tenant_id, organization_scope_id) REFERENCES organization(tenant_id, organization_id),
    CONSTRAINT ck_role_assignment_subject CHECK (
        (membership_id IS NOT NULL AND principal_id IS NULL AND tenant_id IS NOT NULL)
        OR (membership_id IS NULL AND principal_id IS NOT NULL AND tenant_id IS NULL AND organization_scope_id IS NULL)
    ),
    CONSTRAINT ck_role_assignment_status CHECK (status IN ('ACTIVE', 'REVOKED', 'EXPIRED')),
    CONSTRAINT ck_role_assignment_effective_period CHECK (effective_to IS NULL OR effective_to > effective_from)
);

CREATE INDEX ix_role_assignment_membership_status ON role_assignment(membership_id, status);
CREATE INDEX ix_role_assignment_tenant_status ON role_assignment(tenant_id, status);
CREATE INDEX ix_role_assignment_platform_principal ON role_assignment(principal_id, status);

CREATE TABLE api_product_version (
    api_product_version_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NOT NULL,
    api_product_id CHAR(36) NOT NULL,
    version_value VARCHAR(100) NOT NULL,
    lifecycle_state VARCHAR(30) NOT NULL,
    row_version BIGINT NOT NULL DEFAULT 0,
    created_at DATETIME(6) NOT NULL,
    created_by VARCHAR(200) NOT NULL,
    updated_at DATETIME(6) NOT NULL,
    updated_by VARCHAR(200) NOT NULL,
    CONSTRAINT pk_api_product_version PRIMARY KEY (api_product_version_id),
    CONSTRAINT fk_product_version_tenant FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id),
    CONSTRAINT uq_product_version_tenant_id UNIQUE (tenant_id, api_product_version_id),
    CONSTRAINT fk_product_version_product_tenant FOREIGN KEY (tenant_id, api_product_id)
        REFERENCES api_product(tenant_id, api_product_id),
    CONSTRAINT uq_product_version_value UNIQUE (api_product_id, version_value),
    CONSTRAINT ck_product_version_state CHECK (lifecycle_state IN
        ('DRAFT', 'VALIDATING', 'APPROVED', 'RELEASED', 'DEPRECATED', 'RETIRED'))
);

CREATE INDEX ix_product_version_tenant_product ON api_product_version(tenant_id, api_product_id);
CREATE INDEX ix_product_version_tenant_state ON api_product_version(tenant_id, lifecycle_state);

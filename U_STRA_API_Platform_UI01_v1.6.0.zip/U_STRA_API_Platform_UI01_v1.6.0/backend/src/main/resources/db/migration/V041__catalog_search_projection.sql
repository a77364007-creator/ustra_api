CREATE TABLE catalog_search_document (
    search_document_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NOT NULL,
    api_product_id CHAR(36) NOT NULL,
    locale_key VARCHAR(35) NOT NULL,
    product_code VARCHAR(100) NOT NULL,
    display_name VARCHAR(200) NOT NULL,
    description TEXT NULL,
    provider_id CHAR(36) NULL,
    provider_code VARCHAR(100) NULL,
    provider_display_name VARCHAR(200) NULL,
    product_lifecycle_state VARCHAR(30) NOT NULL,
    source_product_row_version BIGINT NOT NULL,
    source_localization_revision BIGINT NOT NULL,
    source_localized_content_revision BIGINT NULL,
    projection_hash CHAR(64) NOT NULL,
    projected_at DATETIME(6) NOT NULL,
    CONSTRAINT pk_catalog_search_document PRIMARY KEY (search_document_id),
    CONSTRAINT fk_search_document_tenant FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id),
    CONSTRAINT fk_search_document_product_tenant FOREIGN KEY (tenant_id, api_product_id)
        REFERENCES api_product(tenant_id, api_product_id) ON DELETE CASCADE,
    CONSTRAINT uq_search_document_locale UNIQUE (tenant_id, api_product_id, locale_key)
);
CREATE INDEX ix_search_document_tenant_product ON catalog_search_document(tenant_id, api_product_id);
CREATE INDEX ix_search_document_provider ON catalog_search_document(tenant_id, provider_id);
CREATE INDEX ix_search_document_product_code ON catalog_search_document(tenant_id, product_code);

CREATE TABLE catalog_search_visibility (
    search_visibility_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NOT NULL,
    api_product_id CHAR(36) NOT NULL,
    catalog_publication_id CHAR(36) NOT NULL,
    api_product_version_id CHAR(36) NOT NULL,
    version_value VARCHAR(100) NOT NULL,
    publication_state VARCHAR(30) NOT NULL,
    product_version_state VARCHAR(30) NOT NULL,
    audience_scope_type VARCHAR(30) NOT NULL,
    organization_id CHAR(36) NULL,
    source_publication_row_version BIGINT NOT NULL,
    source_product_version_row_version BIGINT NOT NULL,
    projection_hash CHAR(64) NOT NULL,
    projected_at DATETIME(6) NOT NULL,
    CONSTRAINT pk_catalog_search_visibility PRIMARY KEY (search_visibility_id),
    CONSTRAINT fk_search_visibility_tenant FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id),
    CONSTRAINT fk_search_visibility_product_tenant FOREIGN KEY (tenant_id, api_product_id)
        REFERENCES api_product(tenant_id, api_product_id) ON DELETE CASCADE,
    CONSTRAINT fk_search_visibility_publication_tenant FOREIGN KEY (tenant_id, catalog_publication_id)
        REFERENCES catalog_publication(tenant_id, catalog_publication_id) ON DELETE CASCADE,
    CONSTRAINT fk_search_visibility_product_version_tenant FOREIGN KEY (tenant_id, api_product_version_id)
        REFERENCES api_product_version(tenant_id, api_product_version_id) ON DELETE CASCADE,
    CONSTRAINT uq_search_visibility_scope UNIQUE (
        tenant_id, catalog_publication_id, audience_scope_type, organization_id)
);
CREATE INDEX ix_search_visibility_product ON catalog_search_visibility(tenant_id, api_product_id);
CREATE INDEX ix_search_visibility_lifecycle ON catalog_search_visibility(
    tenant_id, publication_state, product_version_state, api_product_id);
CREATE INDEX ix_search_visibility_org ON catalog_search_visibility(tenant_id, organization_id, api_product_id);

CREATE TABLE consumer_app (
    consumer_app_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NOT NULL,
    app_code VARCHAR(100) NOT NULL,
    app_code_normalized VARCHAR(100) NOT NULL,
    name VARCHAR(200) NOT NULL,
    description TEXT NULL,
    owner_membership_id CHAR(36) NOT NULL,
    organization_id CHAR(36) NULL,
    lifecycle_state VARCHAR(30) NOT NULL,
    row_version BIGINT NOT NULL DEFAULT 0,
    created_at DATETIME(6) NOT NULL,
    created_by VARCHAR(200) NOT NULL,
    updated_at DATETIME(6) NOT NULL,
    updated_by VARCHAR(200) NOT NULL,
    CONSTRAINT pk_consumer_app PRIMARY KEY (consumer_app_id),
    CONSTRAINT fk_consumer_app_tenant FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id),
    CONSTRAINT uq_consumer_app_tenant_id UNIQUE (tenant_id, consumer_app_id),
    CONSTRAINT uq_consumer_app_tenant_code UNIQUE (tenant_id, app_code_normalized),
    CONSTRAINT fk_consumer_app_owner_tenant FOREIGN KEY (tenant_id, owner_membership_id)
        REFERENCES membership(tenant_id, membership_id),
    CONSTRAINT fk_consumer_app_org_tenant FOREIGN KEY (tenant_id, organization_id)
        REFERENCES organization(tenant_id, organization_id),
    CONSTRAINT ck_consumer_app_state CHECK (lifecycle_state IN ('DRAFT', 'ACTIVE', 'SUSPENDED', 'RETIRED'))
);

CREATE INDEX ix_consumer_app_tenant_owner ON consumer_app(tenant_id, owner_membership_id);
CREATE INDEX ix_consumer_app_tenant_org ON consumer_app(tenant_id, organization_id);
CREATE INDEX ix_consumer_app_tenant_state ON consumer_app(tenant_id, lifecycle_state);

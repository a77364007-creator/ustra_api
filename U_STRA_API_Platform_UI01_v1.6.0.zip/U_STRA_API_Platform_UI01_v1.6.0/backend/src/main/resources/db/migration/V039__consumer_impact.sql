CREATE TABLE consumer_impact_analysis (
    consumer_impact_analysis_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NOT NULL,
    api_change_id CHAR(36) NOT NULL,
    impact_basis_hash CHAR(64) NOT NULL,
    materialized_row_count INT NOT NULL,
    analyzed_at DATETIME(6) NOT NULL,
    analyzed_by VARCHAR(200) NOT NULL,
    created_at DATETIME(6) NOT NULL,
    created_by VARCHAR(200) NOT NULL,
    CONSTRAINT pk_consumer_impact_analysis PRIMARY KEY (consumer_impact_analysis_id),
    CONSTRAINT fk_consumer_impact_analysis_tenant FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id),
    CONSTRAINT uq_consumer_impact_analysis_tenant_id UNIQUE (tenant_id, consumer_impact_analysis_id),
    CONSTRAINT fk_consumer_impact_analysis_change_tenant FOREIGN KEY (tenant_id, api_change_id)
        REFERENCES api_change(tenant_id, api_change_id),
    CONSTRAINT uq_consumer_impact_basis UNIQUE (tenant_id, api_change_id, impact_basis_hash)
);
CREATE INDEX ix_consumer_impact_analysis_change ON consumer_impact_analysis(tenant_id, api_change_id, analyzed_at);

CREATE TABLE consumer_impact (
    consumer_impact_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NOT NULL,
    consumer_impact_analysis_id CHAR(36) NOT NULL,
    api_change_id CHAR(36) NOT NULL,
    api_product_version_id CHAR(36) NOT NULL,
    subscription_id CHAR(36) NOT NULL,
    entitlement_id CHAR(36) NULL,
    consumer_app_environment_id CHAR(36) NOT NULL,
    consumer_app_id CHAR(36) NOT NULL,
    subscription_status VARCHAR(30) NOT NULL,
    entitlement_status VARCHAR(30) NULL,
    consumer_app_state VARCHAR(30) NOT NULL,
    impacted_operation_count INT NOT NULL,
    impact_row_hash CHAR(64) NOT NULL,
    analyzed_at DATETIME(6) NOT NULL,
    CONSTRAINT pk_consumer_impact PRIMARY KEY (consumer_impact_id),
    CONSTRAINT fk_consumer_impact_tenant FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id),
    CONSTRAINT fk_consumer_impact_analysis_parent_tenant FOREIGN KEY (tenant_id, consumer_impact_analysis_id)
        REFERENCES consumer_impact_analysis(tenant_id, consumer_impact_analysis_id),
    CONSTRAINT fk_consumer_impact_change_tenant FOREIGN KEY (tenant_id, api_change_id)
        REFERENCES api_change(tenant_id, api_change_id),
    CONSTRAINT fk_consumer_impact_product_version_tenant FOREIGN KEY (tenant_id, api_product_version_id)
        REFERENCES api_product_version(tenant_id, api_product_version_id),
    CONSTRAINT fk_consumer_impact_subscription_tenant FOREIGN KEY (tenant_id, subscription_id)
        REFERENCES subscription(tenant_id, subscription_id),
    CONSTRAINT fk_consumer_impact_entitlement_tenant FOREIGN KEY (tenant_id, entitlement_id)
        REFERENCES entitlement(tenant_id, entitlement_id),
    CONSTRAINT fk_consumer_impact_environment_tenant FOREIGN KEY (tenant_id, consumer_app_environment_id)
        REFERENCES consumer_app_environment(tenant_id, consumer_app_environment_id),
    CONSTRAINT fk_consumer_impact_app_tenant FOREIGN KEY (tenant_id, consumer_app_id)
        REFERENCES consumer_app(tenant_id, consumer_app_id),
    CONSTRAINT uq_consumer_impact_row UNIQUE (
        tenant_id, consumer_impact_analysis_id, subscription_id, entitlement_id),
    CONSTRAINT ck_consumer_impact_operation_count CHECK (impacted_operation_count >= 0)
);
CREATE INDEX ix_consumer_impact_change ON consumer_impact(tenant_id, api_change_id);
CREATE INDEX ix_consumer_impact_product_version ON consumer_impact(tenant_id, api_product_version_id);
CREATE INDEX ix_consumer_impact_subscription ON consumer_impact(tenant_id, subscription_id);

CREATE TABLE approval_quota_limit (
    approval_quota_limit_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NOT NULL,
    approval_reference_id CHAR(36) NOT NULL,
    metric_code VARCHAR(100) NOT NULL,
    limit_value DECIMAL(24,6) NOT NULL,
    window_seconds BIGINT NOT NULL,
    unit_code VARCHAR(100) NOT NULL,
    created_at DATETIME(6) NOT NULL,
    created_by VARCHAR(200) NOT NULL,
    CONSTRAINT pk_approval_quota_limit PRIMARY KEY (approval_quota_limit_id),
    CONSTRAINT fk_approval_quota_tenant FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id),
    CONSTRAINT fk_approval_quota_reference_tenant FOREIGN KEY (tenant_id, approval_reference_id)
        REFERENCES approval_reference(tenant_id, approval_reference_id),
    CONSTRAINT uq_approval_quota_limit UNIQUE (tenant_id, approval_reference_id, metric_code, window_seconds, unit_code),
    CONSTRAINT ck_approval_quota_positive CHECK (limit_value > 0 AND window_seconds > 0)
);

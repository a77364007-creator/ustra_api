CREATE TABLE approval_reference (
    approval_reference_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NOT NULL,
    subscription_request_id CHAR(36) NOT NULL,
    request_revision_no INT NOT NULL,
    snapshot_hash CHAR(64) NOT NULL,
    authority_code VARCHAR(80) NOT NULL,
    external_case_ref VARCHAR(300) NOT NULL,
    canonical_status VARCHAR(30) NOT NULL,
    decision_evidence_ref VARCHAR(500) NULL,
    reviewer_reference VARCHAR(300) NULL,
    workflow_version VARCHAR(100) NULL,
    decided_at DATETIME(6) NULL,
    effective_from DATETIME(6) NULL,
    effective_to DATETIME(6) NULL,
    row_version BIGINT NOT NULL DEFAULT 0,
    created_at DATETIME(6) NOT NULL,
    created_by VARCHAR(200) NOT NULL,
    updated_at DATETIME(6) NOT NULL,
    updated_by VARCHAR(200) NOT NULL,
    CONSTRAINT pk_approval_reference PRIMARY KEY (approval_reference_id),
    CONSTRAINT fk_approval_reference_tenant FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id),
    CONSTRAINT uq_approval_reference_tenant_id UNIQUE (tenant_id, approval_reference_id),
    CONSTRAINT uq_approval_reference_request_revision UNIQUE (tenant_id, subscription_request_id, request_revision_no),
    CONSTRAINT uq_approval_reference_external_case UNIQUE (tenant_id, authority_code, external_case_ref),
    CONSTRAINT fk_approval_reference_request_tenant FOREIGN KEY (tenant_id, subscription_request_id)
        REFERENCES subscription_request(tenant_id, subscription_request_id),
    CONSTRAINT ck_approval_reference_status CHECK (canonical_status IN ('PENDING','APPROVED','REJECTED','CANCELLED','UNKNOWN')),
    CONSTRAINT ck_approval_reference_revision CHECK (request_revision_no >= 1),
    CONSTRAINT ck_approval_reference_effective_period CHECK (effective_from IS NULL OR effective_to IS NULL OR effective_from < effective_to)
);
CREATE INDEX ix_approval_reference_request ON approval_reference(tenant_id, subscription_request_id, request_revision_no);

CREATE TABLE approval_operation_scope (
    approval_operation_scope_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NOT NULL,
    approval_reference_id CHAR(36) NOT NULL,
    api_operation_id CHAR(36) NOT NULL,
    created_at DATETIME(6) NOT NULL,
    created_by VARCHAR(200) NOT NULL,
    CONSTRAINT pk_approval_operation_scope PRIMARY KEY (approval_operation_scope_id),
    CONSTRAINT fk_approval_scope_tenant FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id),
    CONSTRAINT fk_approval_scope_reference_tenant FOREIGN KEY (tenant_id, approval_reference_id)
        REFERENCES approval_reference(tenant_id, approval_reference_id),
    CONSTRAINT fk_approval_scope_operation_tenant FOREIGN KEY (tenant_id, api_operation_id)
        REFERENCES api_operation(tenant_id, api_operation_id),
    CONSTRAINT uq_approval_operation_scope UNIQUE (tenant_id, approval_reference_id, api_operation_id)
);

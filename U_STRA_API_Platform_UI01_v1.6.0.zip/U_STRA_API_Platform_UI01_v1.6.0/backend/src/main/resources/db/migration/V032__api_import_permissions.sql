INSERT INTO permission (permission_id, permission_code, resource_type, action, status) VALUES
('15000000-0000-0000-0000-000000000001', 'API_IMPORT:READ', 'API_IMPORT', 'READ', 'ACTIVE'),
('15000000-0000-0000-0000-000000000002', 'API_IMPORT:CREATE', 'API_IMPORT', 'CREATE', 'ACTIVE');

-- Deliberately no role_permission rows. Role -> Permission mapping remains tenant administration policy.

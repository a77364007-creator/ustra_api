CREATE TABLE consumer_app_environment (
    consumer_app_environment_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NOT NULL,
    consumer_app_id CHAR(36) NOT NULL,
    environment_type VARCHAR(20) NOT NULL,
    gateway_client_reference VARCHAR(300) NULL,
    iam_application_reference VARCHAR(300) NULL,
    authentication_method VARCHAR(100) NULL,
    row_version BIGINT NOT NULL DEFAULT 0,
    created_at DATETIME(6) NOT NULL,
    created_by VARCHAR(200) NOT NULL,
    updated_at DATETIME(6) NOT NULL,
    updated_by VARCHAR(200) NOT NULL,
    CONSTRAINT pk_consumer_app_environment PRIMARY KEY (consumer_app_environment_id),
    CONSTRAINT fk_consumer_app_environment_tenant FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id),
    CONSTRAINT uq_consumer_app_environment_tenant_id UNIQUE (tenant_id, consumer_app_environment_id),
    CONSTRAINT fk_consumer_app_environment_parent_tenant FOREIGN KEY (tenant_id, consumer_app_id)
        REFERENCES consumer_app(tenant_id, consumer_app_id),
    CONSTRAINT uq_consumer_app_environment_type UNIQUE (tenant_id, consumer_app_id, environment_type),
    CONSTRAINT ck_consumer_app_environment_type CHECK (environment_type IN ('DEV', 'TEST', 'PROD'))
);

CREATE INDEX ix_consumer_app_environment_parent ON consumer_app_environment(tenant_id, consumer_app_id);

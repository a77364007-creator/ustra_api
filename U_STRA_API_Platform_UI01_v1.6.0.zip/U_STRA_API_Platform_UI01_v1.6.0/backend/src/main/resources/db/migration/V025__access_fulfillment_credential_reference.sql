CREATE TABLE access_fulfillment (
    access_fulfillment_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NOT NULL,
    entitlement_id CHAR(36) NOT NULL,
    fulfillment_revision INT NOT NULL,
    fulfillment_type VARCHAR(20) NOT NULL,
    status VARCHAR(30) NOT NULL,
    idempotency_key VARCHAR(200) NOT NULL,
    request_fingerprint CHAR(64) NOT NULL,
    external_operation_ref VARCHAR(500) NULL,
    last_error_code VARCHAR(100) NULL,
    row_version BIGINT NOT NULL DEFAULT 0,
    created_at DATETIME(6) NOT NULL,
    created_by VARCHAR(200) NOT NULL,
    updated_at DATETIME(6) NOT NULL,
    updated_by VARCHAR(200) NOT NULL,
    CONSTRAINT pk_access_fulfillment PRIMARY KEY (access_fulfillment_id),
    CONSTRAINT fk_access_fulfillment_tenant FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id),
    CONSTRAINT uq_access_fulfillment_tenant_id UNIQUE (tenant_id, access_fulfillment_id),
    CONSTRAINT fk_access_fulfillment_entitlement_tenant FOREIGN KEY (tenant_id, entitlement_id)
        REFERENCES entitlement(tenant_id, entitlement_id),
    CONSTRAINT uq_access_fulfillment_revision UNIQUE (tenant_id, entitlement_id, fulfillment_type, fulfillment_revision),
    CONSTRAINT uq_access_fulfillment_idempotency UNIQUE (tenant_id, idempotency_key),
    CONSTRAINT ck_access_fulfillment_revision CHECK (fulfillment_revision >= 1),
    CONSTRAINT ck_access_fulfillment_type CHECK (fulfillment_type IN ('PROVISION','DEPROVISION')),
    CONSTRAINT ck_access_fulfillment_status CHECK (status IN ('PENDING','PROCESSING','SUCCEEDED','FAILED','UNKNOWN','RECONCILING'))
);
CREATE INDEX ix_access_fulfillment_entitlement ON access_fulfillment(tenant_id, entitlement_id, fulfillment_type, fulfillment_revision);
CREATE INDEX ix_access_fulfillment_status ON access_fulfillment(tenant_id, status, updated_at);

CREATE TABLE credential_reference (
    credential_reference_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NOT NULL,
    entitlement_id CHAR(36) NOT NULL,
    access_fulfillment_id CHAR(36) NULL,
    provider_type VARCHAR(100) NOT NULL,
    external_reference VARCHAR(500) NOT NULL,
    status VARCHAR(30) NOT NULL,
    expires_at DATETIME(6) NULL,
    last_synced_at DATETIME(6) NOT NULL,
    created_at DATETIME(6) NOT NULL,
    created_by VARCHAR(200) NOT NULL,
    updated_at DATETIME(6) NOT NULL,
    updated_by VARCHAR(200) NOT NULL,
    CONSTRAINT pk_credential_reference PRIMARY KEY (credential_reference_id),
    CONSTRAINT fk_credential_reference_tenant FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id),
    CONSTRAINT uq_credential_reference_tenant_id UNIQUE (tenant_id, credential_reference_id),
    CONSTRAINT uq_credential_reference_entitlement UNIQUE (tenant_id, entitlement_id),
    CONSTRAINT fk_credential_reference_entitlement_tenant FOREIGN KEY (tenant_id, entitlement_id)
        REFERENCES entitlement(tenant_id, entitlement_id),
    CONSTRAINT fk_credential_reference_fulfillment_tenant FOREIGN KEY (tenant_id, access_fulfillment_id)
        REFERENCES access_fulfillment(tenant_id, access_fulfillment_id),
    CONSTRAINT ck_credential_reference_status CHECK (status IN ('NOT_ISSUED','ACTIVE','ROTATION_REQUIRED','EXPIRED','REVOKED','UNKNOWN'))
);

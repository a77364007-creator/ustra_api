CREATE TABLE membership (
    membership_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NOT NULL,
    organization_id CHAR(36) NULL,
    principal_id VARCHAR(200) NOT NULL,
    issuer VARCHAR(300) NOT NULL,
    status VARCHAR(30) NOT NULL,
    effective_from DATETIME(6) NOT NULL,
    effective_to DATETIME(6) NULL,
    created_at DATETIME(6) NOT NULL,
    updated_at DATETIME(6) NOT NULL,
    CONSTRAINT pk_membership PRIMARY KEY (membership_id),
    CONSTRAINT fk_membership_tenant FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id),
    CONSTRAINT uq_membership_tenant_id UNIQUE (tenant_id, membership_id),
    CONSTRAINT fk_membership_organization_tenant FOREIGN KEY (tenant_id, organization_id) REFERENCES organization(tenant_id, organization_id),
    CONSTRAINT ck_membership_status CHECK (status IN ('ACTIVE', 'INACTIVE', 'EXPIRED')),
    CONSTRAINT ck_membership_effective_period CHECK (effective_to IS NULL OR effective_to > effective_from)
);

CREATE INDEX ix_membership_tenant_principal_status ON membership(tenant_id, principal_id, status);
CREATE INDEX ix_membership_tenant_org_status ON membership(tenant_id, organization_id, status);
CREATE INDEX ix_membership_principal_issuer_status ON membership(principal_id, issuer, status);

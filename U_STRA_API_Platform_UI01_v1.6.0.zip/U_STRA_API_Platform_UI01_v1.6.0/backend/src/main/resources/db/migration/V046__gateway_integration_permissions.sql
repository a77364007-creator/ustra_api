INSERT INTO permission (permission_id, permission_code, resource_type, action, status) VALUES
('1a000000-0000-0000-0000-000000000001', 'GATEWAY_INTEGRATION:READ', 'GATEWAY_INTEGRATION', 'READ', 'ACTIVE'),
('1a000000-0000-0000-0000-000000000002', 'GATEWAY_INTEGRATION:RECONCILE', 'GATEWAY_INTEGRATION', 'RECONCILE', 'ACTIVE');

-- Deliberately no role_permission rows. Operator authority remains tenant administration policy.

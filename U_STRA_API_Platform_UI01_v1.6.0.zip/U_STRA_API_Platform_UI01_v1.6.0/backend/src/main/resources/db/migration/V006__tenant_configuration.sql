CREATE TABLE tenant_configuration (
    tenant_configuration_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NOT NULL,
    config_revision BIGINT NOT NULL DEFAULT 1,
    default_locale VARCHAR(35) NOT NULL,
    timezone VARCHAR(80) NOT NULL,
    row_version BIGINT NOT NULL DEFAULT 0,
    created_at DATETIME(6) NOT NULL,
    updated_at DATETIME(6) NOT NULL,
    CONSTRAINT pk_tenant_configuration PRIMARY KEY (tenant_configuration_id),
    CONSTRAINT uq_tenant_configuration_tenant UNIQUE (tenant_id),
    CONSTRAINT fk_tenant_configuration_tenant FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id)
);

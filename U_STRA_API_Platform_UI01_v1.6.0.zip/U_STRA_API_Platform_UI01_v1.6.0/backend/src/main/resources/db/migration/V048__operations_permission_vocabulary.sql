INSERT INTO permission(permission_id,permission_code,resource_type,action,status)
SELECT '1b000000-0000-0000-0000-000000000001','OPERATIONS:READ','OPERATIONS','READ','ACTIVE'
WHERE NOT EXISTS (SELECT 1 FROM permission WHERE permission_code='OPERATIONS:READ');
INSERT INTO permission(permission_id,permission_code,resource_type,action,status)
SELECT '1b000000-0000-0000-0000-000000000002','AUDIT:READ','AUDIT','READ','ACTIVE'
WHERE NOT EXISTS (SELECT 1 FROM permission WHERE permission_code='AUDIT:READ');
-- No Role -> Permission grants. Existing authorization administration remains the authority.

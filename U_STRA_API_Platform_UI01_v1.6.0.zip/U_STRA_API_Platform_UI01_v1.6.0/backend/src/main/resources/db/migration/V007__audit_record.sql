CREATE TABLE audit_record (
    audit_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NULL,
    occurred_at DATETIME(6) NOT NULL,
    actor_principal_id VARCHAR(200) NOT NULL,
    actor_type VARCHAR(40) NOT NULL,
    action VARCHAR(120) NOT NULL,
    resource_type VARCHAR(80) NOT NULL,
    resource_id VARCHAR(200) NOT NULL,
    outcome VARCHAR(40) NOT NULL,
    reason_code VARCHAR(120) NULL,
    correlation_id VARCHAR(100) NOT NULL,
    privileged_flag BOOLEAN NOT NULL,
    safe_diff LONGTEXT NULL,
    before_hash VARCHAR(128) NULL,
    after_hash VARCHAR(128) NULL,
    CONSTRAINT pk_audit_record PRIMARY KEY (audit_id)
);

CREATE INDEX ix_audit_tenant_time ON audit_record(tenant_id, occurred_at);
CREATE INDEX ix_audit_correlation ON audit_record(correlation_id);

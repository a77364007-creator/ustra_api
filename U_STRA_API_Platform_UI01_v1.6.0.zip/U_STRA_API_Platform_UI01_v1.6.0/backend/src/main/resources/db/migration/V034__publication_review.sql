CREATE TABLE publication_review (
    publication_review_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NOT NULL,
    api_product_id CHAR(36) NOT NULL,
    api_product_version_id CHAR(36) NOT NULL,
    state VARCHAR(30) NOT NULL,
    submitted_snapshot_hash CHAR(64) NOT NULL,
    submitted_snapshot_json LONGTEXT NOT NULL,
    approved_snapshot_hash CHAR(64) NULL,
    approved_snapshot_json LONGTEXT NULL,
    submitted_product_row_version BIGINT NOT NULL,
    submitted_product_localization_revision BIGINT NOT NULL,
    submitted_product_version_row_version BIGINT NOT NULL,
    submitted_at DATETIME(6) NOT NULL,
    submitted_by VARCHAR(200) NOT NULL,
    decided_at DATETIME(6) NULL,
    decided_by VARCHAR(200) NULL,
    decision_reason_code VARCHAR(100) NULL,
    decision_summary VARCHAR(500) NULL,
    row_version BIGINT NOT NULL DEFAULT 0,
    created_at DATETIME(6) NOT NULL,
    created_by VARCHAR(200) NOT NULL,
    updated_at DATETIME(6) NOT NULL,
    updated_by VARCHAR(200) NOT NULL,
    CONSTRAINT pk_publication_review PRIMARY KEY (publication_review_id),
    CONSTRAINT fk_publication_review_tenant
        FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id),
    CONSTRAINT uq_publication_review_tenant_id
        UNIQUE (tenant_id, publication_review_id),
    CONSTRAINT fk_publication_review_product_tenant
        FOREIGN KEY (tenant_id, api_product_id)
        REFERENCES api_product(tenant_id, api_product_id),
    CONSTRAINT fk_publication_review_product_version_tenant
        FOREIGN KEY (tenant_id, api_product_version_id)
        REFERENCES api_product_version(tenant_id, api_product_version_id),
    CONSTRAINT ck_publication_review_state
        CHECK (state IN ('SUBMITTED','IN_REVIEW','CHANGES_REQUESTED','APPROVED','REJECTED','CANCELLED'))
);

CREATE INDEX ix_publication_review_version_state
    ON publication_review(tenant_id, api_product_version_id, state, created_at);

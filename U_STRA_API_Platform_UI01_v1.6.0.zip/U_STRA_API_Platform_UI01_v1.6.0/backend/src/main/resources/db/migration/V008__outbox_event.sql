CREATE TABLE outbox_event (
    outbox_id CHAR(36) NOT NULL,
    event_id CHAR(36) NOT NULL,
    event_type VARCHAR(120) NOT NULL,
    event_version INT NOT NULL,
    aggregate_type VARCHAR(80) NOT NULL,
    aggregate_id VARCHAR(200) NOT NULL,
    tenant_id CHAR(36) NULL,
    payload LONGTEXT NOT NULL,
    correlation_id VARCHAR(100) NOT NULL,
    created_at DATETIME(6) NOT NULL,
    published_at DATETIME(6) NULL,
    publish_attempts INT NOT NULL DEFAULT 0,
    status VARCHAR(30) NOT NULL,
    CONSTRAINT pk_outbox_event PRIMARY KEY (outbox_id),
    CONSTRAINT uq_outbox_event_event_id UNIQUE (event_id),
    CONSTRAINT ck_outbox_status CHECK (status IN ('PENDING', 'PUBLISHED', 'FAILED'))
);

CREATE INDEX ix_outbox_status_created ON outbox_event(status, created_at);
CREATE INDEX ix_outbox_tenant_created ON outbox_event(tenant_id, created_at);

ALTER TABLE api ADD CONSTRAINT uq_api_tenant_code UNIQUE (tenant_id, api_code_normalized);

CREATE TABLE api_candidate (
    api_candidate_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NOT NULL,
    provider_id CHAR(36) NOT NULL,
    source_type VARCHAR(40) NOT NULL,
    state VARCHAR(30) NOT NULL,
    current_import_id CHAR(36) NULL,
    row_version BIGINT NOT NULL DEFAULT 0,
    created_at DATETIME(6) NOT NULL,
    created_by VARCHAR(200) NOT NULL,
    updated_at DATETIME(6) NOT NULL,
    updated_by VARCHAR(200) NOT NULL,
    CONSTRAINT pk_api_candidate PRIMARY KEY (api_candidate_id),
    CONSTRAINT fk_api_candidate_tenant FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id),
    CONSTRAINT uq_api_candidate_tenant_id UNIQUE (tenant_id, api_candidate_id),
    CONSTRAINT fk_api_candidate_provider_tenant FOREIGN KEY (tenant_id, provider_id)
        REFERENCES provider(tenant_id, provider_id),
    CONSTRAINT ck_api_candidate_source_type CHECK (source_type IN ('OPENAPI_UPLOAD')),
    CONSTRAINT ck_api_candidate_state CHECK (state IN ('DETECTED','ASSESSING','ACCEPTED','REJECTED'))
);
CREATE INDEX ix_api_candidate_provider_state ON api_candidate(tenant_id, provider_id, state);

CREATE TABLE api_import (
    api_import_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NOT NULL,
    api_candidate_id CHAR(36) NOT NULL,
    provider_id CHAR(36) NOT NULL,
    source_type VARCHAR(40) NOT NULL,
    original_filename VARCHAR(255) NULL,
    source_content_hash CHAR(64) NOT NULL,
    idempotency_key VARCHAR(200) NOT NULL,
    request_fingerprint CHAR(64) NOT NULL,
    status VARCHAR(30) NOT NULL,
    failure_code VARCHAR(100) NULL,
    failure_summary VARCHAR(500) NULL,
    api_code_normalized VARCHAR(100) NOT NULL,
    source_version VARCHAR(100) NULL,
    result_api_id CHAR(36) NULL,
    result_api_version_id CHAR(36) NULL,
    created_at DATETIME(6) NOT NULL,
    created_by VARCHAR(200) NOT NULL,
    updated_at DATETIME(6) NOT NULL,
    updated_by VARCHAR(200) NOT NULL,
    CONSTRAINT pk_api_import PRIMARY KEY (api_import_id),
    CONSTRAINT fk_api_import_tenant FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id),
    CONSTRAINT uq_api_import_tenant_id UNIQUE (tenant_id, api_import_id),
    CONSTRAINT fk_api_import_candidate_tenant FOREIGN KEY (tenant_id, api_candidate_id)
        REFERENCES api_candidate(tenant_id, api_candidate_id),
    CONSTRAINT fk_api_import_provider_tenant FOREIGN KEY (tenant_id, provider_id)
        REFERENCES provider(tenant_id, provider_id),
    CONSTRAINT uq_api_import_idempotency UNIQUE (tenant_id, idempotency_key),
    CONSTRAINT ck_api_import_source_type CHECK (source_type IN ('OPENAPI_UPLOAD')),
    CONSTRAINT ck_api_import_status CHECK (status IN ('RECEIVED','VALIDATING','SUCCEEDED','FAILED'))
);
CREATE INDEX ix_api_import_candidate_created ON api_import(tenant_id, api_candidate_id, created_at);

CREATE TABLE api_candidate_state_history (
    api_candidate_state_history_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NOT NULL,
    api_candidate_id CHAR(36) NOT NULL,
    from_state VARCHAR(30) NULL,
    to_state VARCHAR(30) NOT NULL,
    reason_code VARCHAR(100) NULL,
    changed_at DATETIME(6) NOT NULL,
    changed_by VARCHAR(200) NOT NULL,
    CONSTRAINT pk_api_candidate_state_history PRIMARY KEY (api_candidate_state_history_id),
    CONSTRAINT fk_api_candidate_history_tenant FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id),
    CONSTRAINT fk_api_candidate_history_candidate_tenant FOREIGN KEY (tenant_id, api_candidate_id)
        REFERENCES api_candidate(tenant_id, api_candidate_id)
);

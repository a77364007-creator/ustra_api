ALTER TABLE subscription_request_revision ADD CONSTRAINT uq_subscription_request_revision_tenant_id UNIQUE (tenant_id, subscription_request_revision_id);

CREATE TABLE subscription_request_revision_operation_scope (
    subscription_request_revision_operation_scope_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NOT NULL,
    subscription_request_revision_id CHAR(36) NOT NULL,
    api_operation_id CHAR(36) NOT NULL,
    created_at DATETIME(6) NOT NULL,
    created_by VARCHAR(200) NOT NULL,
    CONSTRAINT pk_subscription_request_revision_operation_scope PRIMARY KEY (subscription_request_revision_operation_scope_id),
    CONSTRAINT fk_request_revision_scope_tenant FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id),
    CONSTRAINT uq_subscription_request_revision_tenant_id UNIQUE (tenant_id, subscription_request_revision_id),
    CONSTRAINT fk_request_revision_scope_revision_tenant FOREIGN KEY (tenant_id, subscription_request_revision_id)
        REFERENCES subscription_request_revision(tenant_id, subscription_request_revision_id),
    CONSTRAINT fk_request_revision_scope_operation_tenant FOREIGN KEY (tenant_id, api_operation_id)
        REFERENCES api_operation(tenant_id, api_operation_id),
    CONSTRAINT uq_request_revision_operation_scope
        UNIQUE (tenant_id, subscription_request_revision_id, api_operation_id)
);
CREATE INDEX ix_request_revision_operation_scope_revision
    ON subscription_request_revision_operation_scope(tenant_id, subscription_request_revision_id);

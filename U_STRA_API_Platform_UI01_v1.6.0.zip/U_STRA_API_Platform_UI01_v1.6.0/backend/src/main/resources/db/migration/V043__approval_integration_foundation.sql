CREATE TABLE integration_profile (
    integration_profile_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NOT NULL,
    profile_code VARCHAR(100) NOT NULL,
    integration_type VARCHAR(40) NOT NULL,
    display_name VARCHAR(200) NOT NULL,
    enabled BOOLEAN NOT NULL DEFAULT TRUE,
    row_version BIGINT NOT NULL DEFAULT 0,
    created_at DATETIME(6) NOT NULL,
    created_by VARCHAR(200) NOT NULL,
    updated_at DATETIME(6) NOT NULL,
    updated_by VARCHAR(200) NOT NULL,
    CONSTRAINT pk_integration_profile PRIMARY KEY (integration_profile_id),
    CONSTRAINT fk_integration_profile_tenant FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id),
    CONSTRAINT uq_integration_profile_tenant_id UNIQUE (tenant_id, integration_profile_id),
    CONSTRAINT uq_integration_profile_code UNIQUE (tenant_id, profile_code),
    CONSTRAINT ck_integration_profile_type CHECK (integration_type IN ('APPROVAL_ITSM'))
);
CREATE INDEX ix_integration_profile_type ON integration_profile(tenant_id, integration_type, enabled);

CREATE TABLE connector_instance (
    connector_instance_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NOT NULL,
    integration_profile_id CHAR(36) NOT NULL,
    connector_code VARCHAR(100) NOT NULL,
    adapter_code VARCHAR(100) NOT NULL,
    authority_code VARCHAR(80) NOT NULL,
    secret_reference VARCHAR(500) NULL,
    enabled BOOLEAN NOT NULL DEFAULT TRUE,
    row_version BIGINT NOT NULL DEFAULT 0,
    created_at DATETIME(6) NOT NULL,
    created_by VARCHAR(200) NOT NULL,
    updated_at DATETIME(6) NOT NULL,
    updated_by VARCHAR(200) NOT NULL,
    CONSTRAINT pk_connector_instance PRIMARY KEY (connector_instance_id),
    CONSTRAINT fk_connector_instance_tenant FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id),
    CONSTRAINT uq_connector_instance_tenant_id UNIQUE (tenant_id, connector_instance_id),
    CONSTRAINT uq_connector_instance_code UNIQUE (tenant_id, connector_code),
    CONSTRAINT fk_connector_profile_tenant FOREIGN KEY (tenant_id, integration_profile_id)
        REFERENCES integration_profile(tenant_id, integration_profile_id)
);
CREATE INDEX ix_connector_instance_profile ON connector_instance(tenant_id, integration_profile_id, enabled);

CREATE TABLE integration_operation (
    integration_operation_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NOT NULL,
    connector_instance_id CHAR(36) NOT NULL,
    operation_type VARCHAR(50) NOT NULL,
    aggregate_type VARCHAR(60) NOT NULL,
    aggregate_id CHAR(36) NOT NULL,
    aggregate_revision INT NULL,
    source_snapshot_hash CHAR(64) NULL,
    local_correlation_key VARCHAR(200) NOT NULL,
    external_reference VARCHAR(300) NULL,
    workflow_version VARCHAR(100) NULL,
    status VARCHAR(30) NOT NULL,
    attempt_count INT NOT NULL DEFAULT 0,
    safe_error_category VARCHAR(80) NULL,
    safe_error_code VARCHAR(120) NULL,
    causation_id VARCHAR(200) NULL,
    row_version BIGINT NOT NULL DEFAULT 0,
    created_at DATETIME(6) NOT NULL,
    created_by VARCHAR(200) NOT NULL,
    updated_at DATETIME(6) NOT NULL,
    updated_by VARCHAR(200) NOT NULL,
    last_attempt_at DATETIME(6) NULL,
    CONSTRAINT pk_integration_operation PRIMARY KEY (integration_operation_id),
    CONSTRAINT fk_integration_operation_tenant FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id),
    CONSTRAINT uq_integration_operation_tenant_id UNIQUE (tenant_id, integration_operation_id),
    CONSTRAINT fk_integration_operation_connector_tenant FOREIGN KEY (tenant_id, connector_instance_id)
        REFERENCES connector_instance(tenant_id, connector_instance_id),
    CONSTRAINT uq_integration_operation_create UNIQUE (tenant_id, operation_type, aggregate_id, aggregate_revision),
    CONSTRAINT uq_integration_operation_local_key UNIQUE (tenant_id, local_correlation_key),
    CONSTRAINT ck_integration_operation_type CHECK (operation_type IN ('APPROVAL_CASE_CREATE','APPROVAL_STATUS_QUERY')),
    CONSTRAINT ck_integration_operation_status CHECK (status IN ('REQUESTED','IN_PROGRESS','SUCCEEDED','FAILED','UNKNOWN','CANCELLED')),
    CONSTRAINT ck_integration_operation_attempt CHECK (attempt_count >= 0)
);
CREATE INDEX ix_integration_operation_status ON integration_operation(tenant_id, status, updated_at);
CREATE INDEX ix_integration_operation_aggregate ON integration_operation(tenant_id, aggregate_type, aggregate_id, aggregate_revision);
CREATE INDEX ix_integration_operation_external_ref ON integration_operation(tenant_id, connector_instance_id, external_reference);

CREATE TABLE processed_external_event (
    processed_external_event_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NOT NULL,
    connector_instance_id CHAR(36) NOT NULL,
    external_event_id VARCHAR(300) NOT NULL,
    payload_fingerprint CHAR(64) NOT NULL,
    integration_operation_id CHAR(36) NULL,
    outcome_code VARCHAR(100) NOT NULL,
    received_at DATETIME(6) NOT NULL,
    processed_at DATETIME(6) NOT NULL,
    CONSTRAINT pk_processed_external_event PRIMARY KEY (processed_external_event_id),
    CONSTRAINT fk_external_event_tenant FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id),
    CONSTRAINT fk_external_event_connector_tenant FOREIGN KEY (tenant_id, connector_instance_id)
        REFERENCES connector_instance(tenant_id, connector_instance_id),
    CONSTRAINT fk_external_event_operation_tenant FOREIGN KEY (tenant_id, integration_operation_id)
        REFERENCES integration_operation(tenant_id, integration_operation_id),
    CONSTRAINT uq_external_event_identity UNIQUE (tenant_id, connector_instance_id, external_event_id)
);
CREATE INDEX ix_external_event_operation ON processed_external_event(tenant_id, integration_operation_id);

CREATE TABLE reconciliation_issue (
    reconciliation_issue_id CHAR(36) NOT NULL,
    tenant_id CHAR(36) NOT NULL,
    integration_operation_id CHAR(36) NOT NULL,
    issue_type VARCHAR(80) NOT NULL,
    status VARCHAR(30) NOT NULL,
    safe_detail_code VARCHAR(120) NULL,
    opened_at DATETIME(6) NOT NULL,
    last_checked_at DATETIME(6) NULL,
    resolved_at DATETIME(6) NULL,
    row_version BIGINT NOT NULL DEFAULT 0,
    created_at DATETIME(6) NOT NULL,
    created_by VARCHAR(200) NOT NULL,
    updated_at DATETIME(6) NOT NULL,
    updated_by VARCHAR(200) NOT NULL,
    CONSTRAINT pk_reconciliation_issue PRIMARY KEY (reconciliation_issue_id),
    CONSTRAINT fk_reconciliation_issue_tenant FOREIGN KEY (tenant_id) REFERENCES tenant(tenant_id),
    CONSTRAINT uq_reconciliation_issue_tenant_id UNIQUE (tenant_id, reconciliation_issue_id),
    CONSTRAINT fk_reconciliation_issue_operation_tenant FOREIGN KEY (tenant_id, integration_operation_id)
        REFERENCES integration_operation(tenant_id, integration_operation_id),
    CONSTRAINT uq_reconciliation_issue_open UNIQUE (tenant_id, integration_operation_id, issue_type),
    CONSTRAINT ck_reconciliation_issue_status CHECK (status IN ('OPEN','RESOLVED'))
);
CREATE INDEX ix_reconciliation_issue_status ON reconciliation_issue(tenant_id, status, opened_at);

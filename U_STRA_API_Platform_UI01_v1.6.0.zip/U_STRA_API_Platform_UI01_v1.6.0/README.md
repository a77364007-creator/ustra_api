# U.STRA API Platform — UI01 v1.6.0

**첨부 HR UI 스타일을 적용한 실행형 화면 + 기존 CP15 v1.5.2 누적 backend**

## 가장 먼저 화면 열기

ZIP을 **전체 압축 해제**하고 최상위 **`START_UI_PREVIEW.html`**을 브라우저로 연다. Windows는 `OPEN_UI_PREVIEW.cmd`를 더블클릭해도 된다. 인터넷/CDN/Node/Maven/DB 없이 예시 데이터 화면을 볼 수 있다.

기본 모드는 항상 **예시 데이터**다. 검색·탭·등록·신청·취소·환경 관리·복구 결과를 메모리에서 체험한다. 브라우저 새로고침 시 변경이 초기화된다. 실제 서버 저장·승인·발급이나 OpenAPI parser 성공으로 해석하지 않는다.

## 이번 화면

워크스페이스, API 카탈로그·상세, Product 관리·DRAFT 버전·준비조건, OpenAPI Import, 앱·환경·활성화, 구독 신청·현황, 접근권한·사용 준비, 연계 운영·복구, 감사 이력, 연결·실행 안내 — **10개 메뉴**.

흰색 상단 내비게이션, 네이비 선택 메뉴, 청색·민트·라벤더 배경, 좌측 메뉴, 흰 라운드 카드, 회색 조회조건, 탭·표·입력 폼을 구현했다. HR 사진/개인정보/급여 데이터는 복사하지 않았다.

## 서버 연결은 선택 사항

백엔드가 별도로 127.0.0.1:8080에서 기동한 개발환경에서:

```bash
python3 scripts/start_ui_preview.py --api-proxy
# Windows Python Launcher:
# py scripts/start_ui_preview.py --api-proxy
```

열린 로컬 UI의 **연결 · 실행 안내 → 서버 인증 → 서버 연결 확인**을 사용한다. 이 proxy는 같은 PC의 127.0.0.1:8080 고정이며 production reverse proxy가 아니다. 서버 기동/DB 생성/로그인/권한 부여를 자동 수행하지 않는다. file:// 상태에서는 실제 API 연결을 허용하지 않는다.

## 소스 구성과 검증 구분

`web/src/App.tsx`의 React host가 공통 TypeScript UI를 mount/cleanup한다. 단일 HTML도 **동일 UI 모듈**에서 생성하므로 별도 그림용 구현이 아니다. 추가 runtime library는 없다. 기존 React/Vite/POM dependency 버전은 바꾸지 않았다.

실제 실행한 검증은 `docs/ui01/UI01_TEST_REPORT.md`를 따른다. standalone UI TypeScript 빌드와 DOM/JS/경계 테스트는 수행했다. 전체 React/Vite build, Spring/MariaDB/OIDC/vendor E2E는 별도이며 이 패키지를 운영배포 완성본으로 보지 않는다.

## 개발자 읽는 순서

1. `00_화면_실행_안내.md`
2. `docs/ui01/UI01_HANDOFF.md`
3. `docs/ui01/UI01_AS_BUILT.md`
4. `docs/ui01/UI01_API_COVERAGE.md`
5. `docs/ui01/UI01_TEST_REPORT.md` / `UI01_DESIGN_FEEDBACK.md`

Backend의 이전 상태는 `docs/CP15_BUILD_RUNTIME_VALIDATION_02_REPORT.md`에 있다. 이전 root README는 `docs/ui01/BASELINE_CP15_README.md`에 보존했다. 과거 문서의 PASS/차단 수치는 **그 단계의 역사적 결과**이며 이번 UI 실행 증적과 합산하지 않는다.

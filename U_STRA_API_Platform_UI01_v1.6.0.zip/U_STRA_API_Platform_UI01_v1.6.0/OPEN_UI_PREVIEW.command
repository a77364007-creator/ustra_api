#!/bin/sh
cd "$(dirname "$0")" || exit 1
open "START_UI_PREVIEW.html"

# CP-15 v1.5.1 — Build & Runtime Validation 01

**작성일:** 2026-09-22  
**입력 Source Baseline:** `U_STRA_API_Platform_CP15_v1.5.zip`  
**입력 ZIP SHA-256:** `33d506a65ce770f5e18ef2386904239ea9127013ebbb34b4adbfa0151cb7c467`  
**산출물:** `U_STRA_API_Platform_CP15_v1.5.1.zip`

> **검증 경로 보강·추가 테스트 작성 완료 / BACKEND COMPILE + JUNIT + MARIADB BLOCKED / NOT RELEASE-READY**

## 1. 이번 작업의 결과

요청한 실제 빌드·런타임 검증을 시도했지만 Maven 실행 환경을 확보하지 못했다. 따라서 Spring 컴파일 오류나 실제 업무 결함을 수정·해소했다고 보고하지 않는다. 대신 기존 검증 스크립트에서 확인한 두 가지 공백을 보완하고, 이전 추적표의 부분 커버리지에 대응하는 DB/HTTP 행위검사 15개를 작성했다. 새로운 CP나 운영정책을 추가하지 않았다.

기준 ZIP의 내부 789개 파일 해시와 압축 무결성을 확인했다. 새 누적 소스에서도 운영 Java 318개, V001~V049 migration 49개, POM 1개, Web 11개, backend 기본 설정 3개는 원본과 바이트 단위로 동일하다. 전체 누적 코드가 컴파일된다는 의미는 아니다.

## 2. 실제 실행 시도와 차단 지점

| 항목 | 실제 확인 결과 | 의미 |
|---|---|---|
| Java / javac | 21.0.11 사용 가능 | JDK 파싱·순수 Java 검사 실행 가능 |
| Maven 실행 | 명령 없음, 직접 실행 시 127 | 의존성 다운로드·backend 컴파일·JUnit 시작 불가 |
| Maven Central 직접 접속 | curl exit 6 / 이름 해석 실패 | 이 실행 환경에서 직접 다운로드 불가. 저장소의 패키지 부재를 뜻하지 않음 |
| 별도 Maven binary 다운로드 시도 | 파일 확보 실패 | Maven 설치·체크섬/서명 검증을 수행했다고 보고하지 않음 |
| Docker / Podman / MariaDB 실행도구 | 없음 | Testcontainers 및 MariaDB 적용 미실행 |
| Node | 22.16.0 | 목표 Node24/Web lockfile Gate는 그대로이나 신규 backend 경로는 이에 의존하지 않음 |
| 신규 backend `no-db` 경로 | exit2, BLOCKED | Maven preflight에서 종료; 테스트 실행0 |
| 신규 backend `full` 경로 | exit2, BLOCKED | Maven preflight에서 종료; 테스트 실행0 |

최종 소스 기준 실행 증적은 `build-runtime-validation-01/evidence/final-no-db-attempt/summary.json`과 `final-full-attempt/summary.json`이다. 앞선 `backend-*-attempt`는 중간 시도의 이력이다. 실제 Surefire XML은 생성되지 않았다.

## 3. 검증 경로의 변경

### 3.1 프론트엔드 전제조건을 백엔드 검증에서 분리

기존 통합 preflight는 Maven 이후 Node24, 프론트엔드 lockfile과 Docker를 한 번에 요구했다. `backend_runtime_verify.py`에 `compile / no-db / mariadb / full` 모드를 추가하여 backend 컴파일을 별도로 실행하도록 했다. 기존 `runtime-verify.sh`, `test-all.sh`도 backend를 먼저 실행하고 frontend 전제조건을 나중에 검사한다. 종전 frontend 검증을 제거한 것은 아니다.

`no-db`는 **외부 MariaDB/Testcontainers를 제외한 JUnit**이라는 뜻이다. 기존 H2 기반 Spring/JPA 검사와 소스 계약검사를 포함한다. H2 결과를 MariaDB 검증으로 대체하지 않는다. 모든 backend 테스트 클래스는 이 모드에서도 먼저 실제 Maven으로 컴파일한다.

### 3.2 결과 파일 누락·실패·잘못된 skip을 엄격히 검사

기존 `verify_runtime_evidence.py`는 지정 목록만 검사했다. 합성 XML을 사용한 검증기 회귀 실험에서, 기존 목록의 정상 보고서와 **목록 밖의 실패 보고서**를 함께 제공했을 때 종전 검사기는 exit0을 반환했다. 보강한 검사기는 동일 조건을 FAIL로 분류했다. 이는 **보고서 검사기의 결함 재현**이며 backend JUnit을 실행한 결과가 아니다.

새 경로는 JDK AST에서 실제 @Test 메서드·@Disabled·@Testcontainers와 소스 해시를 수집한다. 모든 Surefire XML을 읽고 다음을 확인한다.

- 누락/예상 밖 suite, method, classname, 중복 보고서와 중복 testcase.
- testcase와 보고서 헤더의 tests/failures/errors/skipped 수 일치.
- 모든 보고서의 실패·오류 및 disabled 메서드의 정확한 식별관계.
- 실행 시작 이후 생성된 보고서와 실행 전후 backend 소스 불변성.
- 기존 최소 suite 수용조건과 현재 소스 인벤토리를 함께 유지.

파라미터화·반복·동적·중첩 테스트를 나중에 도입하면 인벤토리 생성기가 이를 조용히 누락하지 않고 오류로 차단한다. 그때 실제 JUnit 보고서 규칙에 맞춰 생성기·검사기를 함께 확장해야 한다. `REPORT_CHECKS_PASSED`는 실행 증적 구조 확인이며 설계 수용조건이나 운영 출시 승인이 아니다.

### 3.3 재현 가능한 실행 증적

각 실행은 새 디렉터리만 사용한다. 기존 디렉터리는 덮어쓰지 않는다. 실제 Maven 종료코드, 컴파일 로그, 현재 소스 해시, fresh Surefire XML, exact report gate와 요약을 보관한다. Maven settings 파일은 기존 승인 파일 경로만 받으며 내용을 복제하지 않는다. 실제 의존성 또는 Maven을 가짜 구현으로 대체하지 않았다.

## 4. 추가한 행위검사 — 작성했으나 미실행

| 신규 suite | 메서드 수 | 주요 범위 | 실행상태 |
|---|---:|---|---|
| `Cp15RuntimeClosureMariaDbTest` | 7 | 실제 서비스 동시 복구, 외부 handler 전 journal/audit commit 관측, journal rollback, 이슈 재발 경쟁, after-commit 검색 실패, 새로운 실패관측과 과거 성공의 경쟁 | JUNIT NOT_EXECUTED |
| `Cp15AuthenticatedOperationsMariaDbTest` | 8 | 인증된 테스트 사용자, 실제 Tenant/권한 조회, 유형별 SQL count/paging, audit 분리, 타 Tenant 복구 차단, unknown body 거절, Connector DTO와 기존 API 범위 | JUNIT NOT_EXECUTED |

첫 suite는 외부 Projection/ITSM/Gateway와 권한 문맥을 test double로 격리하고 실제 JPA·transaction·journal·audit 서비스를 검사한다. 두 번째 suite는 전체 Spring context와 실제 security/permission DB를 사용하지만 인증 방식은 기존 명시적 test profile의 header fixture다. **Production OIDC와 실 벤더 연동 검증은 아니다.**

자세한 조건/메서드 대응과 한계는 `CP15_BUILD_RUNTIME_COVERAGE.md`에 기록했다. 테스트를 작성한 사실과 요구사항 검증을 완료한 사실을 구분한다.

## 5. 이번에 실제 실행한 검사

| 검사 | 실제 결과 | 해석 |
|---|---:|---|
| 기존 누적 source guard | 1,146 / 1,146 PASS | 소스 구조·문자열 계약 검사 |
| CP15 구조 guard | 93 / 93 PASS | 테스트 파일 2개 추가로 기존91에서 증가; 행위검사 PASS 아님 |
| JDK backend Java 파싱 | 351개 / syntax 오류0 | backend dependency 타입검사·전체 compile 아님 |
| 실제 순수 Java probe | 29 / 29 PASS | 기존 요청·키·hash·enum 코드의 컴파일/실행 한정 |
| 검증 도구 Python unittest | 16 / 16 PASS | 합성 보고서, 실패·누락·skip·stale 처리와 runner 차단 검증; backend 테스트 아님 |
| OpenAPI YAML | 15개 parse PASS | YAML 문법 한정 |
| Python / Shell / POM / backend config | 10개 AST / 10개 bash-n / POM1 / YAML4 parse PASS | 문법 한정 |
| backend Maven compile | BLOCKED | 실행되지 않음 |
| Spring/JPA/JUnit/MariaDB/Flyway/Testcontainers | NOT_EXECUTED | PASS 없음 |
| 실제 ITSM/Gateway, UI E2E, restore, SAST, 부하 | NOT_EXECUTED | 별도 환경·계약·범위 필요 |

JDK가 추출한 현재 **작성 인벤토리**는 33 suites / @Test 714개 / @Disabled 76개다. 이 수는 실행 결과가 아니다. 선택 모드별 선언 수는 `no-db=29 suites/692개/disabled76`, `mariadb=4 suites/22개/disabled0`, `full=33 suites/714개/disabled76`이다. 기존 CP15 16개 Gate 외에 이전 CP의 disabled 조건도 남아 있다.

## 6. 미해소 항목

실제 컴파일·기동·테스트가 막혀 있으므로 새로운 테스트의 의존성 타입·Spring context 구성·SQL 동작도 미확인이다. 실행 가능 환경에서 첫 실패부터 최소 Diff로 보완해야 한다. 소스 해시 또는 파싱 성공을 런타임 정상으로 해석하지 않는다.

또한 다음은 이번 테스트 작성으로도 완료되지 않았다.

- 기존 legacy 복구 API와 새 journal 경로 사이의 공통 mutex·동시 호출 계약.
- 실제 Production Catalog projection 트랜잭션끼리의 경쟁과 전체 Product/Publication 쓰기 API fault injection.
- 다중 조직 권한 전체 행렬, Production OIDC, 실제 벤더 callback/status/timeout 복구.
- CP14→CP15 전체 업무 데이터 업그레이드·복원훈련·성능/SAST/운영 전달 정책.
- 실제 Gateway/ITSM Adapter, Production Outbox·자동운영, UI 및 남은 policy Gate.

## 7. 산출물과 다음 실행

- `CP15_BUILD_RUNTIME_RUNBOOK.md`: backend 독립 실행 절차와 결과 해석.
- `CP15_BUILD_RUNTIME_COVERAGE.md`: 추가 15개 검사와 수용조건 추적.
- `CP15_BUILD_RUNTIME_DESIGN_FEEDBACK.md`: 보완한 검증 경로와 미해소 Gate.
- `CP15_v1.5_TO_v1.5.1_DIFF.patch`, `CP15_v1.5_TO_v1.5.1_CHANGED_FILES.json`: 코드·스크립트 최소 변경과 전체 파일 변경 목록.
- `build-runtime-validation-01/evidence/`: 실제 명령/차단/정적/도구 검사 결과.

다음 작업은 이 v1.5.1을 그대로 사용해 Java21+Maven3.9+와 승인된 저장소 접근 환경에서 `--mode no-db`를 실행하는 것이다. Docker가 준비되면 `--mode full`을 실행한다. 결과가 실패하면 현행 summary/log/XML을 기준으로 수정하며, 기존 구현을 처음부터 다시 만들지 않는다.

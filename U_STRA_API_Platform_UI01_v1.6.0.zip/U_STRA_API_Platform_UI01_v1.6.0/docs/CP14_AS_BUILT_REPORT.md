# U.STRA API Platform CP-14 v1.4 — As-Built

## 1. Input sufficiency / implementation status
- Source baseline: `U_STRA_API_Platform_CP13_v1.3`.
- Design/readiness basis: `U_STRA_API_CP14_Actual_Gateway_Readiness_v0.1`.
- User continuation after readiness is treated as approval of the recommended contract-neutral foundation.
- Vendor-specific Gateway/IAM/Vault contract remains unavailable; no fake production adapter was created.

**Status:** `SOURCE IMPLEMENTED / STATIC VERIFIED / VENDOR-CONTRACT+RUNTIME BLOCKED / NOT RELEASE-READY`.

## 2. Implemented scope

### DB V045–V046
- Reuse CP-13 `integration_profile` / `connector_instance` / `integration_operation`.
- Add `GATEWAY_IAM`.
- Add `GATEWAY_PROVISION`, `GATEWAY_DEPROVISION`, `GATEWAY_STATUS_QUERY`.
- Add `GATEWAY_INTEGRATION:READ` / `GATEWAY_INTEGRATION:RECONCILE`.
- No Role→Permission auto mapping.

### Gateway integration foundation
- `GatewayConnectorRegistration` / `GatewayConnectorRegistry`.
- `TenantGatewayConnectorResolver` with missing/ambiguous/disabled fail-closed behavior.
- `GatewayIntegrationStateService`.
- `GatewayIntegrationOrchestrator`.
- `GatewayIntegrationOperatorService` / admin read-reconcile API.
- Mock registration limited to local/test/mock-integration profiles.
- Durable IntegrationOperation is written before an external effect.
- Gateway call is outside the DB transaction.
- Exception/uncertain outcome after call-start → `UNKNOWN`.
- Reconciliation performs `queryStatus` before any retry.
- ReconciliationIssue reuses the CP-13 generic persistence foundation.
- No direct UI-driven provision endpoint is exposed.

### Existing domain boundary preserved
- `GatewayPort` remains the anti-corruption boundary.
- Provision command is derived from server-side Entitlement scope/quota/ProductVersion/ConsumerAppEnvironment.
- `AccessFulfillment` state machine remains canonical.
- `ReadyToUse` remains derived.
- Entitlement revoke remains immediately business-authoritative.
- Credential material is never persisted; `CredentialReference` remains opaque.

### CP-08 compatibility / CP-14 production-path correction
`GatewayFulfillmentStateService.apply(tenant, fulfillment, result)` remains as a CP-08 mock-compatible overload.
The CP-14 production-capable path calls the overload that receives the resolved Connector `authorityCode`; it no longer relies on hard-coded `MOCK_GATEWAY` provider metadata.

### Contract-neutral drift vocabulary
Represented, but not live-detected:
- MISSING_RUNTIME_POLICY
- UNEXPECTED_RUNTIME_POLICY
- SCOPE_MISMATCH
- QUOTA_MISMATCH
- VERSION_MISMATCH
- EXPIRED_ENTITLEMENT_ACTIVE
- CREDENTIAL_STATE_MISMATCH
- TENANT_SCOPE_MISMATCH

## 3. Explicitly not implemented
- Actual Gateway endpoint or authentication.
- Vendor runtime-policy payload/DTO.
- Quota/unit conversion.
- Credential issue/rotation/revoke contract.
- Vendor async/status mapping.
- Blind retry after timeout.
- Live Gateway drift evidence query.
- Numeric timeout/retry/backoff/SLA values.
- Production Vault/secret-provider adapter.
- Real Gateway sandbox/E2E.
- Automatic EntitlementGranted → production Gateway trigger/worker wiring.
- Broad connector administration UI/CRUD (CP-15).

## 4. Verification actually executed
- CP-14 source contract verifier: **61 active PASS + 9 explicit contract gates / 0 FAIL**.
- Cumulative static verifier: **1146/1146 PASS**.
- OpenAPI YAML parse: **14/14 PASS** (YAML parse only).
- Full dependency-less Java diagnostic: only missing external dependency/symbol categories plus dependency-caused override diagnostics; no syntax/type-mismatch category found.
- Focused CP-14 new/changed Java diagnostic: only missing external dependency/symbol categories; no syntax/type-mismatch category found.
- Python verifier syntax: PASS.
- Shell script `bash -n`: PASS.
- Environment: Java/Javac 21.0.11 available; Maven unavailable; Docker unavailable; Node 22.16.0 (target Node 24).

## 5. Verification NOT executed
- Maven compile/test.
- Spring bean graph startup.
- JPA repository/runtime transaction behavior.
- Flyway V001–V046 against MariaDB 11.8.
- Testcontainers.
- CP01–CP14 JUnit runtime regression.
- Real Gateway/IAM/Vault sandbox/E2E.

No unexecuted test is reported as PASS.

## 6. Source-preservation decisions
- CP-13 generic integration tables are reused instead of copied.
- CP-08 MockGateway path remains explicitly non-production.
- No automatic production provisioning trigger is invented.
- No raw vendor request/response or secret material is persisted.
- Operator reconcile can query an existing uncertain/failed fulfillment but cannot manually force SUCCEEDED.
- Missing connector registration fails before Fulfillment is moved to PROCESSING.
- An exception after outbound effect begins is treated as uncertain and stored as `UNKNOWN`.

## 7. Design feedback / release blockers
See `DESIGN_FEEDBACK_CP14.md`.

## 8. Next baseline
If accepted, this package becomes the cumulative source baseline for **CP-15 Operations / Recovery Readiness**.
Actual Gateway Stage B must return to CP-14 when a real Gateway/IAM/Vault contract is supplied.

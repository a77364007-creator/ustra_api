# CP-15 v1.5.1 — Backend 독립 검증 Runbook

## 범위

개발 PC/격리 CI용이다. 운영 DB·실 벤더에 적용하는 배포 명령이 아니다. 현재 패키지에는 실제 backend 컴파일/JUnit 성공 증거가 없다. 아래 명령의 성공을 미리 가정하지 않는다.

## 전제조건

Linux 또는 현재 프로젝트 bash 실행이 가능한 개발 환경, Python3.10+, Java/JDK21, Maven3.9+, 승인된 Maven 저장소 접근이 필요하다. `mariadb/full`은 Docker 호환 CLI·daemon과 기존 `mariadb:11.8.9` 테스트 이미지 확보도 필요하다. 새 이미지/라이브러리 버전을 임의로 바꾸지 않는다.

프론트엔드 Node24와 lockfile은 **backend 독립 명령의 전제조건이 아니다.** Podman 등을 사용하려면 기존 Docker 호환 CLI/API 및 Testcontainers 연결을 담당자가 설정해야 하며 자동 구성을 제공하지 않는다. 실제 DB 대신 H2로 MariaDB 전용 테스트를 바꾸지 않는다.

## 권장 실행 순서

ZIP을 풀어 최상위 README와 backend 디렉터리가 있는 위치에서 실행한다.

```bash
# 1. 의존성 resolve 및 main+test 전체 실제 컴파일. 테스트는 실행하지 않는다.
python3 scripts/backend_runtime_verify.py --mode compile

# 2. Docker 없이 가능한 전체 non-container JUnit. 기존 H2 tests 포함.
python3 scripts/backend_runtime_verify.py --mode no-db

# 3. MariaDB 전용 네 suite: clean/install, upgrade, 실제 서비스·HTTP 검사.
python3 scripts/backend_runtime_verify.py --mode mariadb

# 4. 전체 backend 누적 회귀: 모든 suite와 기존 disabled Gate를 함께 검증.
python3 scripts/backend_runtime_verify.py --mode full
```

각 명령은 `clean test-compile`을 먼저 수행한다. `full/mariadb`도 컴파일 성공 뒤 Docker 전제조건을 검사한다. `no-db`도 모든 테스트 클래스의 컴파일은 필요하므로 Maven dependencies가 없으면 실행할 수 없다.

기존에 승인된 Maven settings가 필요하면 해당 경로를 명시한다. 파일을 생성하거나 비밀값을 전달하는 예시는 제공하지 않는다.

```bash
python3 scripts/backend_runtime_verify.py --mode no-db --settings /approved/maven/settings.xml
```

실행 가능한 Maven이 PATH에 없지만 설치되어 있으면 `--maven /approved/apache-maven/bin/mvn`을 사용할 수 있다. shell 명령 문자열을 넘기지 않는다. `--timeout-seconds`는 검증 명령 중단 한계이며 제품의 retry/SLA 정책이 아니다. POSIX에서는 시간 초과 시 해당 검증 자식 프로세스 그룹을 종료한다.

## 결과 보관 및 판정

기본 결과 디렉터리는 `docs/as-built/runtime-builds/<UTC>-<mode>-<unique-id>/`다. 지정하려면 `--evidence`에 존재하지 않는 새 디렉터리를 준다. 기존 디렉터리는 덮어쓰지 않는다.

| 결과 | 의미 |
|---|---|
| `BLOCKED`, exit2 | 필요한 도구/환경 미확보. summary의 test_execution과 step 로그를 확인한다. |
| `FAIL`, exit1 | 실제 컴파일/명령/보고서 검사 실패. 컴파일 전 실패인지, JUnit 실패인지 구분한다. |
| `COMPILE_PASSED_TESTS_NOT_RUN`, exit0 | compile 모드에서 실제 컴파일만 성공. 테스트 PASS 아님. |
| `COMMAND_AND_REPORT_GATES_PASSED`, exit0 | 해당 모드의 실제 명령·보고서 검사 성공. 제품/출시 승인 아님. |

각 실행의 `summary.json`과 `*-backend-test-compile.log`를 먼저 확인한다. 테스트 단계까지 갔다면 `test-inventory.json`, `surefire-reports/TEST-*.xml`, `report-gate.json`을 함께 보관한다. XML이 없는데 테스트가 통과한 것으로 기록하지 않는다.

새 runner는 현재 소스에서 인벤토리를 생성하고 모든 XML을 검사한다. @Disabled는 정확한 메서드별로 일치해야 한다. 예상 밖의 suite, 누락, 실패, 오래된 파일, 소스 변경을 무시하지 않는다. 기존 `verify_runtime_evidence.py`를 단독 실행할 경우 기본 호출은 freshness를 증명하지 못한다는 안내가 출력되므로, 현재 실행 증거는 runner의 결과를 사용한다.

## 첫 실패 처리

의존성 resolve가 실패하면 저장소 접근/실제 artifact 해석 결과를 확인하고 원본 POM을 임의로 낮추지 않는다. 컴파일 오류면 실패한 파일·행·진단을 기준으로 최소 Diff를 작성한다. Spring context 실패는 root cause부터, MariaDB 실패는 실제 V001~V049 적용/제약/트랜잭션 로그를 기준으로 분류한다. 정책 미확정으로 disabled인 검사를 무조건 활성화하지 않는다.

전체 사용자 화면/Production OIDC/실 ITSM·Gateway/운영 Outbox는 이 backend test 명령의 통과만으로 완료되지 않는다. 테스트 fixture의 사용자·권한·비밀번호는 격리된 테스트용이며 운영 설정으로 사용하지 않는다.

## 전달 자료

실행한 v1.5.1 소스의 ZIP 해시, 실행별 summary, 컴파일 로그, 생성된 Surefire XML, report gate를 함께 전달한다. 승인된 settings/실제 Secret/token을 전달하지 않는다. 로그에 사내 저장소 주소나 민감정보가 포함되면 보안규정에 맞게 제거한다. 현재 패키지에 포함된 합성 XML 검사기 실험은 backend 실실행 증거로 재사용하지 않는다.

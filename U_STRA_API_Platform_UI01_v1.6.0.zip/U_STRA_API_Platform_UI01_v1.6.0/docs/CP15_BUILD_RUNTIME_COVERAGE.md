# CP-15 v1.5.1 — 추가 행위검사 추적표

**공통 상태: AUTHORED / JUNIT NOT_EXECUTED.** 아래 항목은 검사 작성 진전이며 runtime 수용조건 해소 판정이 아니다.

기존 TRACEABILITY_CP15.md는 원본 이력으로 유지했다. 새 15개는 기존 67개 CP15 행위검사를 제거하지 않고 추가했다. 두 suite 모두 기존 MariaDB11.8.9 Testcontainers 환경을 사용하도록 작성했다.

| Suite / Method | CP15 조건 | 추가한 검사 | 범위 한계 |
|---|---|---|---|
| `Cp15AuthenticatedOperationsMariaDbTest`<br>`cp15T02T04T06_approvalOnlyScopeAndCountIgnoreForgedTenantHeader` | T02/T04/T06/T08 | 인증된 Approval-only 사용자, forged Tenant 무시, SQL count·2page tie-break | test-profile header auth. Production OIDC 아님. |
| `Cp15AuthenticatedOperationsMariaDbTest`<br>`cp15T02T56_authenticatedBodyCannotSupplyTenantAuthority` | T02/T56 | 인증 후 body Tenant 주입을 HTTP에서 거절 | 임의 URL/secret 모든 입력 행렬 아님. |
| `Cp15AuthenticatedOperationsMariaDbTest`<br>`cp15T03T37_recoveryCannotTargetAnotherTenantAndDoesNotInsertJournal` | T03/T37 | 타 Tenant Product 복구 차단, journal 미생성 | 모든 action/조직/권한 조합 아님. |
| `Cp15AuthenticatedOperationsMariaDbTest`<br>`cp15T05T06_gatewayIssueScopeAndCountUseRealParentOwnership` | T05/T06 | Gateway issue 부모 operation 기반 소유·count 검증 | 모든 paging 조건/대규모 실행계획 아님. |
| `Cp15AuthenticatedOperationsMariaDbTest`<br>`cp15T09_operationsReadDoesNotGrantSourceOrAuditRead` | T09 | Operations READ가 source/Audit 권한을 대체하지 않음 | 전체 조직 권한 정책 검증 아님. |
| `Cp15AuthenticatedOperationsMariaDbTest`<br>`cp15T10T11T12_auditReadIsTenantBoundAndOmitsPrivateDiff` | T10/T11/T12 | 현재 Tenant audit만, NULL/다른Tenant 제외, private diff 비노출 | 전체 log/SAST/retention/export 아님. |
| `Cp15AuthenticatedOperationsMariaDbTest`<br>`cp15T54T57_connectorReadDoesNotExposeSecretReferenceOrGrantWrite` | T54/T57 | safe Connector DTO, health NOT_MEASURED, write 금지 | 실제 connector health/관리변경 계약 아님. |
| `Cp15AuthenticatedOperationsMariaDbTest`<br>`cp15T60_legacyListShapePreservedWithSourceIsolation` | T60 | 기존 승인/Gateway 목록 shape·type isolation | legacy/new 동시 recovery mutex 아님. |
| `Cp15RuntimeClosureMariaDbTest`<br>`cp15T15T40T41_realConcurrentOrchestratorsSeeCommittedJournalBeforeSingleHandler` | T15/T40/T41 | 실제 orchestrator·journal·audit, 별도 DB connection의 commit 관측, 같은 key 처리1회 | 권한/context와 외부 projection은 fixture. legacy 경로 동시 호출 아님. |
| `Cp15RuntimeClosureMariaDbTest`<br>`cp15T15_failedAuditPreparationRollsBackTheInsertedJournal` | T15 | 인증 문맥 부재로 audit 실패 시 journal DB rollback | 실제 DB 장애 및 전체 audit failure matrix 아님. |
| `Cp15RuntimeClosureMariaDbTest`<br>`cp15T34_concurrentIssueInsertThenReopenUsesOnePersistentIdentity` | T34 | 실제 issue service 최초 동시 insert·resolve 후 동시 reopen | 여러 JVM 프로세스/장시간 fault injection 아님. |
| `Cp15RuntimeClosureMariaDbTest`<br>`cp15T40_differentKeysOnSameTargetCannotStartASecondHandler` | T40 | 서로 다른 key가 같은 target handler 중복실행을 막는지 | legacy/new API 간 공통 mutex 검증 아님. |
| `Cp15RuntimeClosureMariaDbTest`<br>`cp15T45_canonicalCommitSurvivesAfterCommitProjectionFailureAndObservationPersists` | T45 | 실제 Product entity commit 후 event listener 실패와 observation 독립 저장 | 전체 Product/Publication 서비스/REST write 경로 아님. |
| `Cp15RuntimeClosureMariaDbTest`<br>`cp15T45_rollbackDoesNotDispatchAfterCommitListener` | T45 | 원 업무 rollback 시 after-commit listener 미실행 | 모든 publication transition 회귀 아님. |
| `Cp15RuntimeClosureMariaDbTest`<br>`cp15T49_newObservationWinsOverEarlierSuccessfulReindex` | T49 | 실제 관측 서비스에서 새 failure가 과거 작업 success보다 우선 | 실제 production projection port의 동시 transaction race는 추가 필요. |

## 검증 도구 자체 테스트는 별도

`scripts/tests/test_runtime_validation.py`의 16개 Python unittest는 실제 실행했다. 합성 XML fixture 및 tool-not-found 모의를 통해 검사기의 정확성을 점검했으며 backend service/JUnit/DB를 실행한 것이 아니다. 합성 보고서는 임시 디렉터리에만 생성했고 실제 backend/target/surefire-reports에 결과를 만들지 않았다.

## 계속 남는 검증

실제 Maven compile, Spring context, MariaDB migration 신규설치/업그레이드, 모든 누적 JUnit 실행, 실패 후 최소 수정이 우선이다. 이후 legacy/new 경로 공통 조정, 실제 projection/업무 전체경로, Production OIDC·조직 권한, 실 벤더 및 restore/UI/policy Gate를 별도 관리한다.

# CP-05 Runtime Verification Runbook

## Required environment
- Java 21
- Maven 3.9+
- Docker/Podman compatible with Testcontainers
- Node 24+
- reviewed `web/package-lock.json`

## Execute
```bash
python3 scripts/verify_source.py
bash scripts/runtime-preflight.sh
bash scripts/runtime-verify.sh
```

## Mandatory backend evidence
- CP01 Acceptance: no unexpected failure/skip
- CP02 Acceptance: only its two documented deferred tests may remain skipped
- CP03 Acceptance: no skip
- CP04 Acceptance: no skip
- CP05 Acceptance: only CP05-T24 may remain skipped until DF-05-01 is approved
- MariaDB Testcontainers migration: V001..V019 = 19 migrations

## Release rule
Even if runtime tests pass, CP-05 remains **NOT RELEASE-READY** while DF-05-01 object-scope authorization is unresolved. After approval, implement the policy, enable CP05-T24, update expected skip count to 0, and rerun the complete gate.

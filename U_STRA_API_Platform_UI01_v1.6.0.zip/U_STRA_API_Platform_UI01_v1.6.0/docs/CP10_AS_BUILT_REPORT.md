# CP-10 As-Built Report — Provider Publishing

## Status
`SOURCE IMPLEMENTED / STATIC VERIFIED / POLICY+RUNTIME BLOCKED / NOT RELEASE-READY`

## Baseline
- cumulative source baseline: `U_STRA_API_Platform_CP09_v0.9`.
- CP-10 Readiness package: `U_STRA_API_CP10_Provider_Publishing_Readiness_v0.1`.
- no CP01~09 implementation restart was performed.

## Implemented
### Database
- V033 Candidate Productization linkage and states.
- V034 PublicationReview with immutable submitted/approved snapshot evidence.
- V035 ProductVersion → approved PublicationReview linkage.
- V036 granular Productization/Review permission vocabulary; no Role mapping.

### Application
- explicit Candidate Productization against existing APIProduct/ProductVersion.
- server-derived Publish Readiness.
- internal PublicationReview submission/start/approve/request-changes/reject/cancel.
- deterministic review snapshot + SHA-256 hash.
- ProductVersion review path DRAFT → VALIDATING → APPROVED.
- approved-snapshot Release gate added to existing ProductVersion Release path.
- APIVersion DRAFT → VALIDATED → RELEASED coordination.
- APIProduct DRAFT → REVIEWING → ACTIVE coordination.
- safe audit/state-history evidence.
- CP-10 OpenAPI contract.

## Boundaries preserved
- no automatic APIProduct/ProductVersion creation from OpenAPI Candidate.
- no automatic CatalogPublication activation.
- no Breaking Change or ConsumerImpact.
- no actual ITSM integration.
- no production Gateway integration.
- no raw OpenAPI body in review snapshot/audit/outbox.
- no Role → Permission mapping invented.

## Fail-closed design authorities
Approval/Release remains blocked while any of the following is unresolved:
- Classification authority.
- AccessPolicy authority.
- required-locale authority.
- Terms version authority.
- critical-finding authority.
- reconstructable immutable source provenance for direct upload.

See `DESIGN_FEEDBACK_CP10.md` for details.

## Verification actually executed
1. `python3 scripts/verify_source.py`: **706/706 static checks PASS**.
2. CP10 source-contract test runner: **46 PASS / 7 explicit design-gated SKIP / 0 FAIL**.
3. OpenAPI YAML parse: all 10 cumulative YAML files parsed successfully with available PyYAML.
4. dependency-less `javac -proc:none` scan after fixing one generated-test leading-character defect: **0 syntax-like diagnostics**. Missing Spring/JPA/JUnit/Jackson dependencies generated unresolved-symbol diagnostics; therefore this is **not compile PASS**.
5. Java runtime: OpenJDK 21.0.11 available.
6. Maven: unavailable.
7. Docker/Testcontainers: unavailable.
8. Node: v22.16.0; web target baseline remains Node 24.

## Runtime tests not executed
- Maven compile/test.
- Spring context / MockMvc.
- JPA behavior.
- Flyway V001..V036 against MariaDB.
- Testcontainers.
- CP01~09 runtime regression.

These are not reported as PASS.

## Result
CP-10 source foundation is implemented and statically verified, but operational approval/release is intentionally fail-closed until the remaining publish authorities are designed and runtime verification can be executed.

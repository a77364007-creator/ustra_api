# CP-02 Catalog Core — Implementation Plan

## Scope baseline

Approved working boundary for this implementation snapshot:

- Provider: minimal tenant-scoped reference master, no public CRUD
- APIProduct: public management list/detail/create/update
- API / APIVersion / APIOperation: domain/persistence + DB integrity only
- Product lifecycle review/publish transition: deferred to CP-10
- Consumer Catalog publication/audience semantics: deferred to CP-03/CP-12
- OpenAPI import/provenance: deferred to CP-09

## Reused CP-01 foundation

- `TenantContextResolver`
- `TenantPermissionGuard`
- request/correlation context
- canonical error envelope
- `If-Match` / ETag version pattern
- tenant-qualified repository access
- DB-level tenant composite FK defense

## Implementation order

1. V010 Catalog Core physical schema
2. V011 API Product permission vocabulary
3. Catalog entities/repositories
4. APIProduct application service
5. APIProduct REST controller
6. CP02-T01~T24 acceptance/security/constraint test source
7. static source/security checks
8. OpenAPI + traceability + As-Built
9. runtime verification when Maven/Docker/Node24/lockfile are available

## Explicit non-goals

- no new business lifecycle transitions
- no Provider public CRUD
- no public API/APIVersion/APIOperation CRUD
- no operation-path normalizer algorithm until approved
- no role-to-permission production mapping
- no taxonomy/classification policy
- no Product publication/search/entitlement fields

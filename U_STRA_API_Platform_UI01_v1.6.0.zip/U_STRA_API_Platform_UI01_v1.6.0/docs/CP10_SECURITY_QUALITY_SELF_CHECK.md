# CP-10 Security / Quality Self-Check

## Functional boundary
- [x] Productization is explicit and links existing business product structures.
- [x] Review approval does not auto-Release ProductVersion.
- [x] ProductVersion Release does not auto-activate CatalogPublication.
- [x] CP-11 Breaking Change / ConsumerImpact not implemented.
- [x] CP-13 actual ITSM and CP-14 production Gateway not implemented.

## Tenant / authorization
- [x] Tenant is resolved from server-side `TenantContext`.
- [x] Candidate/Product/ProductVersion/Review direct lookups are tenant-qualified.
- [x] Candidate Provider must equal Product Provider.
- [x] Granular permissions are checked in Service layer.
- [x] No Role name is treated as authorization policy.
- [x] No Role → Permission rows are seeded in V036.
- [ ] Exact reviewer separation-of-duties is not defined; Design Feedback remains open.

## Data integrity / transaction
- [x] Tenant-qualified FKs added for Candidate→Product/ProductVersion and Review→Product/ProductVersion.
- [x] ProductVersion→approved Review uses tenant-qualified FK.
- [x] optimistic `@Version` retained for mutable entities.
- [x] review/version/product/api-version coordination is transactional through Service boundaries.
- [x] release snapshot mismatch fails closed.
- [ ] V033~V036 must still be executed on MariaDB; no runtime migration PASS claimed.

## Source / secrets / logs
- [x] raw OpenAPI source is not stored in PublicationReview snapshot/audit/outbox.
- [x] no credential secret/token/private key fields added.
- [x] audit uses IDs, decision metadata and snapshot hashes.
- [x] approved/submitted snapshot JSON contains technical evidence only, not raw OpenAPI.

## Undefined policy handling
- [x] Classification not invented.
- [x] AccessPolicy not invented.
- [x] required locale list not invented.
- [x] Terms version and critical-finding SoT not invented.
- [x] unresolved authorities map to explicit readiness blockers.
- [x] direct-upload hash alone is not treated as reconstructable Release provenance.

## Verification
- [x] 706 cumulative static checks PASS.
- [x] CP10 source-contract active tests: 46 PASS.
- [x] 7 authority-dependent CP10 tests explicitly disabled, not hidden.
- [x] OpenAPI YAML syntax parsed.
- [x] dependency-less Java diagnostic scan has zero syntax-like diagnostics.
- [ ] Maven compile/test not executed — Maven unavailable.
- [ ] Testcontainers/MariaDB not executed — Docker unavailable.
- [ ] Full CP01~09 runtime regression not executed.

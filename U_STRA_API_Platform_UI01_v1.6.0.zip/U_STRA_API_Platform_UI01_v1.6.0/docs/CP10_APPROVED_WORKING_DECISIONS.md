# CP-10 Approved Working Decisions — Provider Publishing

The user continued with **“다음”** after the CP-10 Readiness recommendation. The following recommended items are used as working decisions for source implementation. Items whose source-of-truth is still absent remain fail-closed and are not fabricated.

## Implemented working decisions
1. Productization is explicit; Candidate does not silently create/release/publish a Product.
2. Candidate Provider must equal the target APIProduct Provider.
3. Candidate lifecycle continues `ACCEPTED → PRODUCTIZING → COMPLETED`.
4. Review submission coordinates ProductVersion `DRAFT → VALIDATING`.
5. Review approval coordinates `VALIDATING → APPROVED`.
6. Changes requested / rejected / cancelled return ProductVersion `VALIDATING → DRAFT`.
7. First review submission may move APIProduct `DRAFT → REVIEWING`.
8. ProductVersion Release may move APIProduct `DRAFT/REVIEWING → ACTIVE`.
9. Referenced APIVersion is validated in the approved review transaction and released with ProductVersion Release.
10. PublicationReview approval binds a deterministic snapshot hash; Release recomputes and rejects mismatch.
11. ProductVersion Release remains distinct from CatalogPublication activation.
12. CP-10 uses internal review evidence only; actual ITSM integration remains CP-13.
13. CP-10 does not implement Breaking Change / ConsumerImpact (CP-11).

## Deliberately unresolved / fail-closed
- Classification vocabulary/model/authority.
- AccessPolicy model/revision authority.
- required locale policy and localization-review ownership.
- Terms version authority.
- critical-finding source of truth.
- reconstructable immutable source reference for direct-upload OpenAPI.
- exact reviewer role/SoD mapping.

## Permission scaffolding
CP-10 introduces granular permission vocabulary (`API_CANDIDATE:PRODUCTIZE`, `PUBLICATION_REVIEW:READ/SUBMIT/DECIDE`) only as technical authorization hooks. No Role → Permission mapping is seeded. Exact reviewer SoD/role binding remains Design Feedback and operational authority is not claimed.

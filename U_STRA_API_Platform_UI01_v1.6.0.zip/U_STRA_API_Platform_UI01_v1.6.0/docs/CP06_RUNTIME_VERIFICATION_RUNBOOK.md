# CP-06 Runtime Verification Runbook

## Required environment
- Java 21
- Maven 3.9+
- Docker/Podman compatible with Testcontainers
- Node 24+
- reviewed `web/package-lock.json`

## Execute
```bash
python3 scripts/verify_source.py
bash scripts/runtime-preflight.sh
bash scripts/runtime-verify.sh
```

## Mandatory backend evidence
- CP01 Acceptance: no unexpected failure/skip
- CP02 Acceptance: only its two documented deferred tests may remain skipped
- CP03 Acceptance: no skip
- CP04 Acceptance: no skip
- CP05 Acceptance: only CP05-T24 may remain skipped while DF-05-01 is unresolved
- CP06 Acceptance: only CP06-T13 may remain skipped while DF-06-01 is unresolved
- MariaDB Testcontainers migration: **V001..V022 = 22 migrations**

## CP-06 mandatory checks
- tenant-qualified ConsumerAppEnvironment / Publication / ProductVersion / requester references
- exact ProductVersion pinning
- immutable revision 1 + snapshot hash
- `SUBSCRIPTION:REQUEST` backend permission
- idempotency same-key/same-payload no duplicate effect
- same-key/changed-payload conflict
- `SubscriptionRequested` safe event payload
- SUBMITTED-only CP-06 cancellation
- no Subscription/Entitlement/Credential/Gateway authority creation

## Release rule
Runtime PASS alone is not enough. CP-06 remains **NOT RELEASE-READY** until DF-06-01 object-scope authorization is approved, implemented, CP06-T13 is enabled, and the full regression gate is rerun.

# CP-05 Implementation Plan

1. Preserve CP-04 baseline and prior public contracts.
2. Add V017 ConsumerApp, V018 ConsumerAppEnvironment, V019 permissions.
3. Add ConsumerApp/Environment domain, JPA repositories, services and REST APIs.
4. Reuse TenantContextResolver, TenantPermissionGuard, AuditService, VersionHeaderParser and existing state-transition history.
5. Enforce same-tenant/effective owner, same-tenant optional Organization, canonical appCode and environment cardinality.
6. Keep raw secrets, Subscription, Entitlement, Credential, Usage and Incident outside CP-05.
7. Add CP05-T01..T28 + negative security coverage.
8. Extend runtime evidence gate to CP-05 and V001..V019.
9. Produce As-Built, traceability and Design Feedback; do not report runtime PASS unless Maven/Testcontainers actually run.

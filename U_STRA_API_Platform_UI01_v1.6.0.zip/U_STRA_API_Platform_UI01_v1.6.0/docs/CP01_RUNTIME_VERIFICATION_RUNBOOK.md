# CP-01 Runtime Verification Runbook

## Purpose

This runbook closes the remaining CP-01 verification gate. It does **not** extend scope into CP-02.

## Required environment

- Java 21
- Maven 3.9+
- Docker or compatible Testcontainers runtime
- Node 24 LTS and npm
- Network access to Maven Central and npm registry, or equivalent approved internal mirrors

## 0. Fail-closed runtime preflight

Run first:

```bash
bash scripts/runtime-preflight.sh
```

It must confirm Java 21, Maven 3.9+, Node 24+, a verified frontend `package-lock.json`, and a Testcontainers-compatible container runtime.

For evidence capture use:

```bash
bash scripts/runtime-verify.sh
```

The script writes `docs/as-built/evidence/runtime-verification.txt` and stops on the first blocked/failed gate.

Security note: local/test header authentication is available only when the `local` or `test` profile is explicitly active. Production must explicitly use `prod`.

## 1. Backend build and unit/integration tests

```bash
cd backend
mvn clean verify
```

Acceptance:
- Maven build success
- CP01-T01~T16 pass
- domain unit tests pass
- `MariaDbMigrationIntegrationTest` applies V001..V009 on MariaDB Testcontainers

## 2. Local MariaDB smoke

```bash
cd ..
docker compose up -d mariadb
cd backend
mvn spring-boot:run -Dspring-boot.run.profiles=local
```

Verify:
- application starts
- Flyway V001..V009 succeeds
- no migration checksum/order errors
- correlation/request headers appear as designed

Optional local-only fixture:

```bash
mariadb < ../scripts/local-fixture.sql
```

Do not use the local fixture in production.

## 3. Frontend dependency lock and build

The current snapshot intentionally does not fabricate a lockfile.

```bash
cd ../web
nvm use
npm install
npm run typecheck
npm run build
```

After the first **verified** install/build, commit the generated `package-lock.json`. From then on CI must use:

```bash
npm ci
npm run typecheck
npm run build
```

## 4. Full helper

After a verified frontend lockfile exists:

```bash
cd ..
bash scripts/test-all.sh
```

## 5. Required regression/security checks

Confirm at minimum:

- client-supplied tenant header does not switch authority context
- no-membership and inactive-membership are differentiated
- cross-tenant resource IDs do not leak resource existence
- organization parent cannot cross tenant
- tenant administrator cannot grant platform administrator authority
- duplicate/effective-period role assignments are rejected correctly
- stale `If-Match` / configuration revision is rejected
- privileged successful changes create audit records
- denied privilege escalation audit survives rejected business command
- state change and outbox insert are atomic
- outbox eventId uniqueness/retry behavior passes
- error response contains correlationId

## 6. Design Feedback gates before production readiness

Do not invent policy for the following. Close them through approved design decisions:

1. DF-CP01-01 tenant_code uniqueness scope
2. DF-CP01-02 Customer provisioning owner/API
3. DF-CP01-03 multi-active-membership tenant selection protocol
4. DF-CP01-04 production IdP authority/deprovisioning contract
5. DF-CP01-05 initial Platform Admin bootstrap/recovery
6. DF-CP01-06 final CP-01 administration UI/UX

## 7. Completion rule

Only after the required backend, migration, frontend and security regression tests pass may `docs/as-built/CP01_AS_BUILT_REPORT.md` be changed from **BLOCKED / NOT COMPLETE** to a completed result.

Do not begin CP-02 on the assumption that CP-01 runtime behavior is verified until this gate is closed.

# CP-09 Runtime Verification Runbook

Required release-gate environment:
- Java 21
- Maven capable of resolving the pinned parser dependency
- Docker/Testcontainers
- MariaDB 11.8-compatible runtime

Commands when the environment is available:

```bash
cd backend
mvn -B -ntp clean verify
cd ..
python3 scripts/verify_source.py
```

Runtime gate must prove:
1. V001..V032 clean migration on MariaDB.
2. CP01~CP09 acceptance/regression suites.
3. OpenAPI 3.0 JSON/YAML and 3.1 parser behavior.
4. remote/file/external `$ref` rejection.
5. transaction rollback/no partial technical tree on invalid/duplicate import.
6. same-key/same-fingerprint replay and conflict behavior.
7. concurrent duplicate defense.

Do not promote static verification to runtime PASS.

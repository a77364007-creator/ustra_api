# CP-07 Approved Working Decisions

These decisions are the implementation baseline accepted by continuation from the CP-07 Readiness recommendation. Items still listed in `DESIGN_FEEDBACK_CP07.md` are not treated as final product policy.

1. CP-07 owns Subscription, Entitlement, explicit approved operation scope, vendor-neutral quota snapshot, AccessFulfillment state foundation and CredentialReference metadata boundary.
2. Approval is not Entitlement. There is no public grant/approve endpoint in CP-07.
3. CP-08 will supply a typed internal `ApprovedSubscriptionDecision`; CP-07 validates exact request revision/hash/environment/ProductVersion.
4. One source SubscriptionRequest creates at most one Subscription. Replay must reuse the same effect and reject a changed approval decision.
5. Entitlement subject is the exact ConsumerAppEnvironment approved by the source request.
6. Entitlement operation scope is explicit. Empty scope is never treated as all operations.
7. Approved operations must belong to the pinned ProductVersion composition, directly or through an API_VERSION component.
8. Quota is persisted as vendor-neutral `QuotaProfile + QuotaLimit(metric,value,window,unit)` without inventing a Gateway-specific vocabulary.
9. Effective period is supplied by approval; CP-07 does not invent 30/90/365-day defaults.
10. Platform-side materialization is atomic: Subscription + Entitlement + Scope/Quota + PENDING PROVISION fulfillment + history/audit/outbox.
11. Subscription becomes ACTIVE when platform-side grant records succeed; Gateway success is not required for Subscription ACTIVE.
12. Entitlement revoke immediately removes business authority, records a PENDING DEPROVISION fulfillment, and emits `EntitlementRevoked`; external deprovision happens later.
13. Gateway timeout/ambiguous effect is `UNKNOWN`, not automatically `FAILED`.
14. CredentialReference stores opaque reference/status metadata only. Raw key/token/private-key material is forbidden.
15. ReadyToUse is derived internally and is not exposed as a finalized public response shape until CP-08.
16. Read/revoke authorization uses permissions, not Role-name predicates.
17. Automatic expiry/renewal, quota mutation, Subscription suspend/terminate and actual Gateway integration are deferred until approved rules/packages.

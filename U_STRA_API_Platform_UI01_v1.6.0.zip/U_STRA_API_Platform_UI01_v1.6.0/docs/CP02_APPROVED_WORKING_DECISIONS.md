# CP-02 Approved Working Decisions for This Implementation Snapshot

This file records the working decisions used after the design-candidate approval step in this conversation. It is not a replacement for a formal enterprise ADR if the project later introduces one.

1. CP-02 object boundary: `Provider + APIProduct + API + APIVersion + APIOperation`.
2. APIProduct code: tenant-scoped uniqueness, trim + uppercase canonical form, immutable after create.
3. Provider: minimal tenant-scoped reference master; no public Provider CRUD in CP-02.
4. Product owner: single primary Membership reference for MVP; ACTIVE/effective requirement remains TBD.
5. Product lifecycle: CP-02 creates/updates core DRAFT metadata; CP-10 owns review/publish lifecycle commands.
6. APIOperation path normalization: one shared contract is required, but the exact algorithm remains unapproved; therefore CP-02 exposes no public operation-write API.
7. Authorization: code checks Permission, not Role names. Production Role→Permission mapping remains configuration/admin policy.
8. Consumer Catalog: CP-02 list/detail are management views, not Publication/Audience discoverability.

Any remaining open item is tracked in `DESIGN_FEEDBACK_CP02.md` rather than being silently converted into business policy.

# 개발 담당자 실행 요청서 — CP15 v1.5.2

## 목적

U.STRA API Platform의 누적 backend가 실제 컴파일·테스트·DB 적용되는지 확인하기 위한 개발/격리 CI 실행이다. 운영 배포 요청이 아니다.

## 준비 환경

Java/JDK21, Maven3.9+, Python3.10+, 승인된 Maven 저장소 접근. `full`은 Docker-compatible daemon 및 기존 `mariadb:11.8.9` 테스트 이미지가 필요하다. Node/Web lockfile은 backend-only runner의 전제조건이 아니다. 버전과 의존성을 임의로 낮추지 않는다.

## 실행

ZIP의 README와 backend가 있는 프로젝트 최상위에서:

```bash
python3 scripts/backend_runtime_verify.py --mode no-db
# 사내 승인 Maven settings가 필요한 경우:
# python3 scripts/backend_runtime_verify.py --mode no-db --settings /approved/maven/settings.xml
# Docker를 사용할 수 있는 경우:
python3 scripts/backend_runtime_verify.py --mode full
```

## 반환 자료

실행 source ZIP SHA256과 해당 invocation 디렉터리의 summary.json, compiler log, 생성된 Surefire XML, report-gate.json을 제공한다. 성공한 테스트뿐 아니라 실패 로그를 포함한다. 승인 settings 파일 자체나 Secret/token/실제 vendor credential은 전달하지 않는다. 저장소 주소나 로그에 고객정보가 있으면 규정에 따라 마스킹한다.

현재 제공 패키지의 JDK 실행검사 22/22 결과는 Port snapshot 검사일 뿐 전체 backend/JUnit/DB 성공 결과가 아니다.

# CP-05 Approved Working Decisions

The user's continuation instruction is treated as approval of the CP-05 Decision Brief recommendations for implementation, except where the Decision Brief itself explicitly left a rule unresolved.

1. CP-05 owns `ConsumerApp + ConsumerAppEnvironment` only.
2. `appCode`: trim + uppercase, tenant-scoped unique, immutable after creation.
3. `ownerMembershipId`: required; create/transfer requires same-tenant currently effective Membership.
4. `organizationId`: optional; when present must resolve in same tenant.
5. Environment types: `DEV / TEST / PROD`; at most one per App+type.
6. External identifiers are non-secret references only; raw key/secret/token/private-key material is not stored.
7. Lifecycle: `DRAFT -> ACTIVE -> SUSPENDED -> ACTIVE`; `ACTIVE/SUSPENDED -> RETIRED`; RETIRED has no outgoing lifecycle transition.
8. Permission codes use `CONSUMER_APP:*`; Role names are not authorization predicates.
9. Lifecycle/ownership/external-reference changes are audited; no new Integration Event is invented.
10. SCREEN 05 remains a composite view; Subscription/Entitlement/Credential/Usage are later-package data.

## Still not approved

The exact owner/organization **object-scope authorization policy** remains unresolved. CP-05 therefore implements tenant isolation + permission enforcement but is not release-ready until this policy is approved and CP05-T24 is enabled.

# CP-03 Implementation Changelog

## H-01 Product Version separation
Added `api_product_version` as a business-version object independent from technical `api_version`.

## H-02 Composition boundary
Added `api_product_component` with exactly-one target enforcement for APIVersion/APIOperation and tenant-qualified FKs.

## H-03 Publication separation
Added `catalog_publication` and `audience_scope`; Publication does not contain Entitlement authority.

## H-04 Semantic lifecycle actions
Added release/activate/suspend/withdraw commands instead of generic state mutation.

## H-05 Transactional evidence
Release and activation write lifecycle history + immutable audit + approved named Outbox event in the same transaction.

## H-06 Derived visibility
Added internal visibility evaluation that requires ACTIVE Publication + RELEASED ProductVersion + non-RETIRED Product + matching AudienceScope.

## H-07 Runtime gate
MariaDB migration count raised to 14; CP03 Acceptance evidence added to fail-closed runtime verification and reference CI template.

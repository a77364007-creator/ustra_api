# Validation 02 — Design Feedback / Security Review

## DF-BRV02-01 — Port 리스트의 불변성 보완 [수정 / 단위범위 검증]

Java record의 scalar reference를 final로 보관하는 것만으로 List 내용이 불변인 것은 아니었다. source와 테스트 모두 확인한 boundary에 defensive copy를 넣었다. snapshot/hash/정확한 scope 전달 취지에 따른 기술 보완이며 신규 승인·권한 정책이 아니다. 기준선의 public signature는 동일하다. 변경 가능한 accessor에 의존한 외부 custom adapter는 미확인이다.

## DF-BRV02-02 — Approval quota null 소비 비일관성 [OPEN / SOURCE FINDING]

`ApprovalStateService.validateQuota`는 null이면 return하고 `sameQuota`는 null을 빈 목록으로 보지만, `synchronizeDecision`에는 그 뒤 `for(var q:d.quotaLimits())`가 존재한다. 실제 승인 API/DB flow를 실행해 재현한 결과는 아니다. nullable quota의 명시 계약과 기존 회귀를 확인한 뒤 service 경계에서 정리해야 한다. 이번 Port 수정은 null을 빈 목록으로 바꾸지 않아 이 차이를 숨기지 않았다.

## DF-BRV02-03 — Framework 지원 유지방안 [OPEN / RELEASE DECISION]

POM은 기존 `spring-boot-starter-parent:3.5.16` 그대로다. Spring 공식 2026-06-25 릴리스 공지는 3.5.16 배포와 3.5.x의 마지막 OSS 릴리스임을 명시한다. 이는 현재 소스가 빌드되지 않는다거나 특정 취약점이 있다고 증명하는 자료가 아니다. 상용지원 적용/지원 버전으로의 별도 전환 중 어떤 방안을 택할지 출시 전 결정해야 한다. 이번 작업에서는 메이저 업그레이드나 라이브러리 변경을 수행하지 않았다.

외부 확인 근거(2026-09-22 조회):
- Spring 공식 릴리스: https://spring.io/blog/2026/06/25/spring-boot-3-5-16-available-now/
- Apache 공식 Maven archive metadata: https://archive.apache.org/dist/maven/maven-3/3.9.11/binaries/

웹에서 artifact 공개 사실을 확인한 것과 현재 컨테이너에서 다운로드/의존성 resolve를 성공한 것은 다르다. 후자는 실패했다.

## 품질·보안 자체점검

- 공개 route/생성자/접근자, Tenant/범위/상태/금액/기간 계산은 유지했다.
- Secret/token/raw payload를 새로 저장하거나 출력하지 않는다. 테스트는 synthetic identifier만 쓴다.
- defensive copy는 원소를 deep-copy하지 않는다. 여기의 원소는 String 또는 BigDecimal/String/primitive만 가진 quota record다.
- null/빈목록/순서/중복의 의미를 변경하지 않는다. 잘못된 데이터가 유효하다고 승인하지 않고 기존 validator에 그대로 전달한다.
- 운영 Java2개 외에 migration/POM/Web/config 변경 없음.
- SAST/전체 로그 스캔/실제 dependency compatibility는 미실행. 안전성 또는 배포가능성을 보증하지 않는다.

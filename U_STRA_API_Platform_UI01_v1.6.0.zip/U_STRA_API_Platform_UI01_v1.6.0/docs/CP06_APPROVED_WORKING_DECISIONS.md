# CP-06 Approved Working Decisions

This document records the working baseline applied after the CP-06 Readiness recommendation was accepted for coding.

## WD-06-01 Scope
CP-06 owns `SubscriptionRequest`, immutable `SubscriptionRequestRevision`, create/get, conservative pre-approval cancel, idempotency, audit/history and the confirmed `SubscriptionRequested` outbox event.

CP-06 does not own ApprovalReference, Subscription, Entitlement, AccessFulfillment, Gateway policy or Credential.

## WD-06-02 Target selection and pinning
The client supplies `consumerAppEnvironmentId + catalogPublicationId`.
The server resolves the exact API Product Version from the selected Publication and pins it into the request.

## WD-06-03 Immutable request revision
Revision 1 is insert-only and stores purpose, descriptive expected-call-volume and a SHA-256 snapshot hash. Approval later must bind the exact request revision/snapshot, not mutable request text.

## WD-06-04 Initial state
Create ends in `SUBMITTED`. CP-06 does not fabricate VALIDATING/PENDING_APPROVAL/APPROVED/COMPLETED.

## WD-06-05 Eligibility
Create requires same Tenant, ACTIVE ConsumerApp, tenant-qualified Environment, ACTIVE Publication, RELEASED ProductVersion and a matching AudienceScope.

## WD-06-06 Expected call volume
Stored as descriptive request information only. It is not an enforceable quota in CP-06.

## WD-06-07 Permission
Backend authorization uses `SUBSCRIPTION:REQUEST`. Role names are not authorization predicates.

## WD-06-08 Idempotency
`Idempotency-Key` is mandatory for create. The implemented uniqueness key is `(tenant, operation, idempotency-key)` and the normalized request fingerprint is checked.
No automatic retention/purge policy is invented; retention remains Design Feedback.

## WD-06-09 Transaction/Event
Request + Revision + History + Audit + `SubscriptionRequested` Outbox + Idempotency record commit in one local DB transaction. No external ITSM/approval call is made in that transaction.

## WD-06-10 Cancellation
CP-06 implements only `SUBMITTED -> CANCELLED`. Cancellation after an external approval case exists remains a later orchestration concern.

## Blocking inherited decision
ConsumerApp owner/organization object-scope authorization remains unresolved from CP-05 and therefore blocks CP-06 release as well.

# CP-04 Localization Implementation Plan

## 1. Source baseline

- CP-03 source: `U_STRA_API_Platform_CP03_v0.3`
- CP-04 readiness: `docs/reference/cp04/*`
- 기존 TenantContext / Permission / ETag / Outbox 패턴 재사용

## 2. Implementation order

1. V015 `api_product_localized_content`
2. V016 `api_product.localization_revision`
3. LocalizationStatus / Entity / Repository
4. APIProduct translatable revision + STALE hook
5. list / save-draft API
6. internal fallback resolver
7. `LocalizationUpdated` STALE event
8. CP04 acceptance and CP01..03 regression gate
9. Runtime verification / As-Built

## 3. Security/transaction rules

- client tenant selector를 authorization source로 사용하지 않는다.
- APIProduct는 항상 `tenant_id + api_product_id`로 확인한다.
- LocalizedContent DB FK도 `(tenant_id, api_product_id)`를 사용한다.
- 기존 row 변경 시 If-Match를 요구한다.
- canonical name/description change + STALE marking + Outbox enqueue는 하나의 DB Transaction이다.
- Search/Entitlement/Review policy를 CP-04에서 선행 구현하지 않는다.

# CP-04 Runtime Verification Runbook

## Completion gate

CP-04 is runtime-complete only when all of the following pass in one revision:

1. `python3 scripts/verify_source.py`
2. `bash scripts/runtime-preflight.sh`
3. `cd backend && mvn -B -ntp clean verify`
4. `python3 scripts/verify_runtime_evidence.py`
5. `cd web && npm ci`
6. `npm run typecheck`
7. `npm run build`

## Environment

- Java 21
- Maven 3.9+
- Docker-compatible Testcontainers runtime
- MariaDB image `11.8.9`
- Node 24+
- committed/reviewed `web/package-lock.json`

## Backend evidence required

- CP01 Acceptance: >=16, skipped=0
- CP02 Acceptance: >=25, skipped=2 (existing explicit T15/T24 deferrals only)
- CP03 Acceptance: >=27, skipped=0
- CP04 Acceptance: >=25, skipped=0
- MariaDB migration test: >=1, skipped=0
- Flyway migrations executed: exactly V001..V016 = 16

## Hard failures

- cross-tenant localization reference/access
- missing server-side permission
- false-green Testcontainers skip
- unexpected test skip
- stale If-Match accepted
- Product name/description changed without stale marking of PUBLISHED localization
- stale transition committed when outbox enqueue fails

## Current sandbox result

`runtime-preflight.sh` returns BLOCKED because Maven is unavailable. This is not a PASS.

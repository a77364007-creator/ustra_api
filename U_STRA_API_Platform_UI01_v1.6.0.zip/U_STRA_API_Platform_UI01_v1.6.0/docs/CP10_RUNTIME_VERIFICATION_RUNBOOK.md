# CP-10 Runtime Verification Runbook

## Required environment
- Java 21
- Maven compatible with project wrapper/build policy (no wrapper is currently committed)
- Docker runtime available to Testcontainers
- MariaDB Testcontainers image already used by the project: `mariadb:11.8.9`

## Required commands
From `backend/`:

```bash
mvn -U test
```

At minimum verify:
1. Spring context loads with CP-10 beans.
2. Flyway clean MariaDB applies V001..V036 and validates.
3. CP01..CP09 regression suites still pass.
4. CP10-T01..T53 compile and run; authority-gated T16~20/T27~28 remain explicitly disabled until design authority exists.
5. Productization tenant/provider/object checks behave as designed.
6. Review state transitions and optimistic locking work against MariaDB.
7. Snapshot hash remains deterministic across repeated reads.
8. Review snapshot mismatch blocks approval/release.
9. Release transaction rolls back atomically if APIVersion/APIProduct coordination fails.
10. CatalogPublication remains inactive until separately commanded.
11. Audit/history/outbox contain identifiers/hashes only and do not contain raw OpenAPI or credentials.

## Current environment observation — 2026-09-20
- Java: OpenJDK 21.0.11 available.
- Maven: unavailable (`mvn: command not found`).
- Docker: unavailable (`docker: command not found`).
- Node: v22.16.0 (web target baseline remains Node 24).

Therefore Maven/Spring/JPA/Testcontainers/MariaDB runtime tests were **not executed** in this environment.

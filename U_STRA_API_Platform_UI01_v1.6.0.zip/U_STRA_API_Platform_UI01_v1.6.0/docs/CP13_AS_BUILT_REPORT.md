# U.STRA API Platform CP-13 v1.3 — As-Built

## 1. Input sufficiency / implementation status
- Source baseline: `U_STRA_API_Platform_CP12_v1.2`.
- Design/readiness basis: `U_STRA_API_CP13_Actual_ITSM_Readiness_v0.1`.
- User continuation after readiness is treated as approval of the recommended contract-neutral foundation.
- Vendor-specific Actual ITSM contract remains unavailable; no production vendor adapter/callback was fabricated.

**Status:** `SOURCE IMPLEMENTED / STATIC VERIFIED / VENDOR-CONTRACT+RUNTIME BLOCKED / NOT RELEASE-READY`.

## 2. Implemented scope
### DB V043–V044
- IntegrationProfile
- ConnectorInstance
- IntegrationOperation
- ProcessedExternalEvent
- ReconciliationIssue
- operator permission vocabulary (`READ`, `RECONCILE`), no role mappings

### Application / integration
- Tenant-aware connector resolution with ambiguous/disabled fail-closed behavior.
- Adapter registry that can be empty in production; no fake ActualITSMAdapter.
- Mock adapter registration only under existing local/test/mock-integration profiles.
- Durable create/query operation state.
- Outbound call orchestration outside DB transaction.
- Explicit uncertain-effect exception → `UNKNOWN` + reconciliation issue.
- Definitive connector failure → `FAILED` with safe code only.
- Approval decision synchronization reuses `ApprovalStateService` and exact CP-08 validation/materialization.
- Status-query reconciliation for persisted ApprovalReference.
- Normalized authenticated external-event inbox/dedupe service (no public callback receiver yet).
- Tenant operator list/reconcile API.
- Fail-closed subscription cancellation after unresolved approval-case creation starts.

## 3. Explicitly not implemented
- Actual ITSM endpoint/auth/DTO mapping.
- Public webhook/callback endpoint and authentication.
- Vendor status mapping.
- Vendor idempotency/correlation lookup after create timeout.
- External case cancellation.
- Numeric retry/backoff/reconciliation schedule/SLA.
- Classification/risk outbound mapping.
- Production Vault/secret-provider binding.
- Full connector administration UI/CRUD.
- Actual Gateway integration (CP-14).

## 4. Verification actually executed
- CP-13 source contract verifier: **50 active PASS + 14 explicit contract gates / 0 FAIL**.
- Cumulative static verifier: **1032/1032 PASS**.
- OpenAPI YAML parse: **13/13 PASS** (YAML parse only).
- Dependency-less full Java scan: dependency/classpath errors expected because Maven dependencies are unavailable.
- Focused CP-13 new/changed Java scan: **0 non-dependency-like diagnostics**.
- Environment: Java/Javac 21 available; Maven unavailable; Docker unavailable; Node 22.16.0 (target Node 24).

## 5. Verification NOT executed
- Maven compile/test.
- Spring context startup.
- JPA derived-query validation.
- Flyway V001–V044 on MariaDB.
- Testcontainers.
- CP01–CP13 JUnit runtime regression.
- Real ITSM sandbox/E2E.

No unexecuted test is reported as PASS.

## 6. Key source-preservation decisions
- `ApprovalPort` and `ApprovalStateService` remain domain authority.
- Existing `MockApprovalOrchestrator` remains available only in its existing non-production profiles.
- CP-13 adds a separate integration foundation; it does not replace working CP-08 mock flow.
- No automatic `SubscriptionRequested` → ITSM trigger was invented because trigger authority is unresolved.
- No raw vendor payload is stored in canonical tables/audit/outbox.

## 7. Design feedback / release blockers
See `DESIGN_FEEDBACK_CP13.md`. The most important blocker is the absence of the real ITSM contract and safe lookup-after-timeout behavior.

## 8. Next baseline
If accepted, this package becomes the cumulative source baseline for **CP-14 Actual Gateway Integration Readiness**. Actual ITSM Stage B must return to CP-13 when the vendor contract is supplied; CP-14 must not assume CP-13 is production-complete.

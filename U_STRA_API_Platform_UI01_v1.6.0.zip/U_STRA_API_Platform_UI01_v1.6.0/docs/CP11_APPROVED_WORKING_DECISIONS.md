# CP-11 Approved Working Decisions

CP-11 implementation proceeds from the CP-10 v1.0 cumulative source baseline and the authorized CP-11 Readiness recommendations.

## Implemented decisions

1. CP-11 owns Change Assessment, Consumer Impact, and explicit APIVersion deprecation coordination; it does not execute deployment/Gateway shutdown.
2. OpenAPI source remains prohibited in canonical relational tables, Audit and Outbox. A sanitized immutable structural Contract Snapshot is persisted instead.
3. `APIChange` and `APIChangeItem` are tenant-owned evidence records.
4. Assessment is allowed only between two APIVersions of the same tenant-owned API.
5. Compatibility logic is versioned (`CP11-OPERATION-V1`).
6. Source-content hash difference alone never creates a Breaking Change verdict.
7. Operation removal is deterministic `BREAKING`; incomplete structural rule coverage is `REVIEW_REQUIRED`; exact structural equality is `NO_CONTRACT_CHANGE`.
8. Historical APIVersions without a CP-11 Contract Snapshot remain `REVIEW_REQUIRED`; CP-11 does not silently backfill evidence from an unapproved source.
9. Consumer Impact is derived from ProductVersion composition and pinned Subscription/Entitlement references.
10. CP-11 never auto-switches consumers to latest/recommended/target versions.
11. APIVersion deprecation is explicit and does not revoke Subscription/Entitlement, withdraw CatalogPublication, or call Gateway.
12. CP-11 adds permission vocabulary only; it does not seed Role-to-Permission mappings.

## Deliberately not implemented because design authority is still open

- full parameter/body/response/security Breaking Change rule catalog
- request-only/pending-request consumer inclusion policy
- first-class MigrationPlan physical model and mutation commands
- notification target/channel model
- retirement notice/grace/force/waiver policy and retirement endpoint
- ProductVersion/APIVersion automatic lifecycle cascade
- CatalogPublication auto-suspend/withdraw on deprecation/retirement
- actual ITSM/Gateway/Operations execution

These remain Design Feedback items and release gates rather than inferred business rules.

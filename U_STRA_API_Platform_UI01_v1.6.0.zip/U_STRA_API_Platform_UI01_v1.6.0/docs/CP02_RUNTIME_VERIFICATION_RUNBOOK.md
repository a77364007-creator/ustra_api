# CP-02 Runtime Verification Runbook

## 1. 목적

CP-02 Catalog Core의 Source 구현과 실제 Runtime 검증을 분리한다. CP-02는 이 Runbook의 Gate가 모두 통과하기 전까지 Release-Ready 또는 Done으로 판정하지 않는다.

## 2. 필수 환경

- Java 21
- Maven 3.9+
- Node 24+
- npm
- Docker 또는 Testcontainers 호환 Runtime
- `web/package-lock.json`

## 3. 단일 실행 명령

```bash
./scripts/runtime-verify.sh
```

## 4. Gate

| Gate | 검증 | 실패 시 |
|---|---|---|
| G0 | `verify_source.py` 정적/보안/설계 경계 | BLOCKED |
| G1 | Java 21 / Maven / Node / Docker / lockfile preflight | BLOCKED |
| G2 | `mvn -B -ntp clean verify` | BLOCKED |
| G3 | Surefire Evidence Gate | BLOCKED |
| G4 | `npm ci` + typecheck + production build | BLOCKED |

## 5. MariaDB Migration Hard Gate

`MariaDbMigrationIntegrationTest`는 실제 `mariadb:11.8.9` Testcontainers에서 **V001~V011 총 11개 migration**을 clean DB에 적용하고 Flyway validate까지 수행한다.

Docker가 없을 때 이 테스트를 SKIP해서는 안 된다. Testcontainers 실행 불가 자체가 Runtime Gate 실패이다.

## 6. Acceptance Evidence Hard Gate

`scripts/verify_runtime_evidence.py`는 Maven 실행 후 Surefire XML을 검사한다.

필수 증적:

- `Cp01AcceptanceIntegrationTest`: 최소 16 test, skip 0
- `Cp02AcceptanceIntegrationTest`: 최소 25 test, **skip 2만 허용**
  - CP02-T15: Owner ACTIVE/effective 정책 TBD
  - CP02-T24: Consumer Catalog는 CP-03/CP-12로 이관
- `MariaDbMigrationIntegrationTest`: 1 test, skip 0
- failures/errors: 모두 0

예상된 2건보다 skip이 증가하면 false-green으로 보고 Gate 실패 처리한다.

## 7. Frontend Gate

CP-02는 아직 Catalog UI를 구현하지 않았지만 CP-01 Web Shell의 reproducible build를 회귀검증한다.

- `package-lock.json` 필수
- `npm ci`
- `npm run typecheck`
- `npm run build`

## 8. 증적

실행 로그:

`docs/as-built/evidence/runtime-verification-cp02.txt`

CI에서는 Surefire XML도 artifact로 보존한다.

## 9. 현재 설계상 허용된 미완료

아래는 테스트 실패가 아니라 명시적인 Design Pending이다.

1. CP02-T15 — 비활성/기간만료 Membership을 APIProduct Owner로 허용할지 여부
2. CP02-T24 — Consumer Catalog의 Publication/AudienceScope 정책

단, Runtime Gate에서 이 두 항목 이외의 자동 테스트가 추가로 skip되는 것은 허용하지 않는다.

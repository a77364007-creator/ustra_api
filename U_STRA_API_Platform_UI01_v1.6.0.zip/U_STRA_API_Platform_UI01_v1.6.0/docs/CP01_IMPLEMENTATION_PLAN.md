# CP-01 Tenant Foundation — Implementation Plan

## 1. Baseline

- Development mode: Greenfield; no pre-existing Repository/Schema/Build convention was supplied.
- Scope: CP-01 Tenant Foundation only.
- Reference priority: CP-01 implementation package → approved platform design baseline → mockup baseline.
- Technology baseline: Java 21, Spring Boot 3.5.16, Maven, MariaDB 11.8.9 (11.8 LTS series), Flyway, Spring Data JPA, Spring Security, React + TypeScript + Vite.
- Architecture: modular monolith for the first platform baseline. Domain boundaries remain explicit so later extraction is possible without introducing distributed-system overhead in CP-01.

## 2. Implementation Units

1. Request/correlation context and canonical error response.
2. Customer/Tenant/Organization persistence and lifecycle foundation.
3. Membership and identity-authority boundary.
4. Role/Permission/RoleAssignment foundation.
5. Server-side TenantContextResolver.
6. Tenant and platform authorization guards.
7. TenantConfiguration with optimistic concurrency.
8. Append-oriented Audit foundation.
9. Transactional Outbox and publisher boundary.
10. REST API surface for CP-01 operations.
11. Flyway migrations and reference security data.
12. CP01-T01~T16 automated acceptance/security/concurrency/outbox tests.
13. Technical web shell/API client only; detailed CP-01 admin UX is deferred because the mockup baseline does not define it sufficiently.

## 3. Security / Transaction Rules

- Ordinary tenant APIs never accept a client-selected owning tenant as authorization evidence.
- Authenticated identity is resolved to current effective membership server-side.
- Tenant-owned direct-ID queries include the current tenant in the lookup predicate.
- Inactive/expired membership and role assignment cannot authorize.
- Tenant admin cannot assign platform-global authority.
- Privileged state change, success audit, and outbox event participate in the same database transaction.
- External outbox publishing occurs outside the domain transaction; publish success/failure state is recorded in short independent transactions.
- Secrets/tokens/private keys are not modeled as TenantConfiguration fields.

## 4. Migrations

- V001 Customer/Tenant
- V002 Organization
- V003 Membership
- V004 Role/Permission
- V005 RoleAssignment
- V006 TenantConfiguration
- V007 AuditRecord
- V008 OutboxEvent
- V009 CP-01 reference roles/permissions

## 5. API Scope

- `/api/v1/admin/tenants`
- `/api/v1/admin/tenants/{id}/activate|suspend|retire`
- `/api/v1/me/tenant-context`
- `/api/v1/organizations`
- `/api/v1/memberships`
- `/api/v1/role-assignments`
- `/api/v1/tenant-config`

## 6. Known Unknowns / Design Feedback

- Tenant code uniqueness scope is not confirmed.
- Customer provisioning API/process is not defined even though Tenant creation requires `customerId`.
- Tenant selection for identities with more than one simultaneously effective Membership is not defined.
- Production IdP identity-authority lookup contract is not defined.
- Platform Admin bootstrap is not defined.
- Detailed Tenant/Organization/Membership/Role administration UX is not explicit in the mockup baseline.

These are not silently decided in CP-01 implementation.

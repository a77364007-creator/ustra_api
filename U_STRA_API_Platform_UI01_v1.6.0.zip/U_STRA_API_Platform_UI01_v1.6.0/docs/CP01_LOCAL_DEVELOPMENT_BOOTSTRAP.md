# CP-01 Local Development Auto-Start

> 여기서 **bootstrap**은 Bootstrap CSS/UI framework를 의미하지 않는다. 이 문서는 CP-01 개발환경의 자동 기동/종료 절차를 정의한다.

## 1. 목적

CP-01 소스를 인계받은 개발자가 업무정책을 새로 결정하지 않고 아래 기술환경을 반복 재현할 수 있게 한다.

1. MariaDB 11.8.9 시작
2. Flyway migration을 포함한 Spring Boot `local` profile 시작
3. idempotent local-only Customer fixture 적용
4. 인증/권한/DB 연결 smoke test 수행
5. React/TypeScript Vite shell 시작
6. 상태확인 및 안전한 종료

운영 IdP, 운영 Platform Admin bootstrap, 실고객 데이터는 이 절차의 범위가 아니다.

## 2. 사전 조건

전체 개발환경:

- Java 21
- Maven 3.9+
- Docker + Docker Compose v2
- Node 24+
- npm
- curl
- `web/package-lock.json`

현재 생성 snapshot에는 외부 npm registry에 접근할 수 없어 `package-lock.json`이 포함되지 않았다. 따라서 **최초 1회** 네트워크가 허용된 검증 개발환경에서 다음을 수행한다.

```bash
./scripts/dev-init-web.sh
```

이 명령은 lockfile을 새로 만들거나 기존 lockfile을 `npm ci`로 검증하고, `typecheck`와 `build`까지 수행한다. 생성된 `web/package-lock.json`은 리뷰 후 Repository에 commit해야 한다.

## 3. 한 명령 기동

```bash
./scripts/dev-up.sh
```

성공 시:

- Backend: `http://127.0.0.1:8080`
- Web: `http://127.0.0.1:5173`
- Backend log: `.local/logs/backend.log`
- Web log: `.local/logs/web.log`

Frontend 준비 전 Backend/DB만 확인하려면:

```bash
./scripts/dev-up.sh --backend-only
```

Smoke Test를 의도적으로 생략해야 하는 진단 상황에만:

```bash
./scripts/dev-up.sh --skip-smoke
```

정상 개발 흐름에서는 smoke 생략을 권장하지 않는다.

## 4. 자동 Smoke Test

`dev-up.sh`는 `scripts/dev-smoke.sh`를 호출하여 최소 다음을 확인한다.

1. `/actuator/health` -> HTTP 200
2. 미인증 Platform Admin API -> HTTP 401
3. 인증되었지만 Platform permission이 없는 사용자 -> HTTP 403
4. `PLATFORM_ADMIN` test role을 가진 local principal -> HTTP 200

이 test header 인증은 `local`/`test` profile에서만 존재한다. 운영 `prod` profile에는 적용되지 않는다.

## 5. 상태/종료

```bash
./scripts/dev-status.sh
./scripts/dev-down.sh
```

DB 데이터를 포함한 로컬 volume까지 완전히 삭제하려는 경우에만:

```bash
./scripts/dev-down.sh --purge
```

`--purge`는 로컬 개발 DB를 삭제하므로 일반 종료에는 사용하지 않는다.

## 6. Local fixture

`scripts/local-fixture.sql`은 Flyway migration이 아니며 운영/reference business data도 아니다.

현재 포함 범위:

- `LOCAL_DEMO` Customer 1건을 idempotent upsert

Tenant code uniqueness 범위, 운영 Customer provisioning 주체, Platform Admin bootstrap 방식은 Design Feedback 미결정 항목이므로 local fixture가 이를 업무정책으로 확정하지 않는다.

## 7. Fail-closed 원칙

- `dev-up.sh`는 Spring `local` profile을 명시적으로 지정한다.
- 전체 기동은 `web/package-lock.json` 없이는 차단된다.
- Java/Node major version이 기준보다 낮으면 차단된다.
- Docker daemon 또는 Backend health가 준비되지 않으면 실패한다.
- smoke test 실패 시 성공 메시지를 출력하지 않는다.
- 운영용 IdP/JWT 설정을 local test header로 대체하지 않는다.

## 8. CI와의 관계

로컬 자동기동은 개발 편의 기능이며 CP-01 완료 판정 자체가 아니다.

공식 Runtime Gate는 계속 다음이다.

```bash
bash scripts/runtime-verify.sh
```

CI에서는 `mvn clean verify`, Testcontainers MariaDB migration, CP01-T01~T16, frontend `npm ci/typecheck/build`를 모두 통과해야 한다.

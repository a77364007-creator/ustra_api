# CP-14 Approved Working Decisions

The user continued with “다음” after the CP-14 readiness package. The readiness recommendations are therefore used as working decisions for this coding step.

1. Preserve existing `GatewayPort`, `GatewayFulfillmentStateService`, `AccessFulfillment`, `CredentialReference` and `ReadyToUseService`.
2. Implement only the contract-neutral Actual Gateway integration foundation.
3. Reuse the CP-13 generic IntegrationProfile / ConnectorInstance / IntegrationOperation / ReconciliationIssue tables.
4. Add `GATEWAY_IAM`, `GATEWAY_PROVISION`, `GATEWAY_DEPROVISION`, `GATEWAY_STATUS_QUERY`.
5. External effects stay outside DB transactions.
6. Timeout/uncertain outbound effects become `UNKNOWN`; no blind duplicate provision/deprovision.
7. Reconciliation queries the existing effect first.
8. Runtime policy input is server-derived from Entitlement; UI/client cannot widen scope/quota/version/environment.
9. Entitlement revoke remains business-authoritative even while external cleanup is pending/UNKNOWN.
10. Only opaque runtime-policy / credential / external-operation references may cross the boundary.
11. Production-capable credential provider metadata comes from resolved connector authority, not hard-coded `MOCK_GATEWAY`.
12. No vendor endpoint/auth/runtime-policy DTO/quota conversion/credential rotation/status mapping/live drift query/SLA/Vault binding is fabricated.
13. Broad integration administration and production operations UX remains CP-15.
14. Real Gateway sandbox and Maven/MariaDB/Testcontainers verification remain release gates.

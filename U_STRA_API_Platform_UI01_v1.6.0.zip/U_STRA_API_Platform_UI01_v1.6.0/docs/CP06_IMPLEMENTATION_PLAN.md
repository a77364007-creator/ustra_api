# CP-06 Subscription Request Implementation Plan

1. Preserve CP-05 v0.5 source and conventions.
2. Add V020 SubscriptionRequest with tenant-qualified target/requester FKs.
3. Add V021 immutable SubscriptionRequestRevision.
4. Add V022 `SUBSCRIPTION:REQUEST` + tenant/operation scoped idempotency record.
5. Implement server-derived Tenant/requester/ProductVersion pinning.
6. Validate ACTIVE App, ACTIVE Publication, RELEASED ProductVersion and AudienceScope.
7. Persist request/revision/history/audit/outbox/idempotency atomically.
8. Expose create/get and semantic pre-approval cancel only.
9. Keep Approval/Subscription/Entitlement/Gateway/Credential out of CP-06.
10. Automate CP06-T01..T31 and retain only object-scope test T13 as explicitly deferred.
11. Run CP01..05 regression and clean MariaDB V001..V022 Runtime Gate.
12. Produce traceability, Design Feedback and As-Built evidence.

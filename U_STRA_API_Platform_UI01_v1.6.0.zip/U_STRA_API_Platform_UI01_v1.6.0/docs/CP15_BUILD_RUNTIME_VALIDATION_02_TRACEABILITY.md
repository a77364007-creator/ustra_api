# Validation 02 — Traceability

이번 변경은 CP08/13/14의 scope·snapshot·idempotency handoff 불변성을 보강한다. CP15 이후 신규 업무정책은 없다.

| 근거/보호조건 | 변경 지점 | assertion | 실제 확인 |
|---|---|---|---|
| Gateway command scope/quota는 생성 시 캡처된 내용 보존 | GatewayPort.Command compact constructor | G01~G04, G08 | 원본FAIL → 수정PASS |
| Tenant/Env/pinned version/key/fingerprint 보존 | GatewayPort.Command | G05~G07 | 원본/수정PASS |
| 승인 신청 revision/hash/scope 고정 | ApprovalPort.CaseCommand | A01~A04 | 변이2FAIL→PASS; 값보존PASS |
| 승인 Decision scope/quota가 후속 단계 전에 변경되지 않음 | ApprovalPort.Decision | D01~D04,D08 | 원본FAIL → 수정PASS |
| null/PENDING/effective dates/evidence 등 기존 검증 계약 유지 | ApprovalPort.Decision | D05~D07 | 원본/수정PASS |
| 기존 ApprovedSubscriptionDecision 방어적 복사 보존 | 변경 없음 | R01~R02 | 원본/수정PASS |
| 공개 Java 호출 signature 보존 | 세 record | actual javap 비교 | 동일 |
| 전체 Spring/JPA/HTTP/DB 회귀 | 기존 suites+신규 PortSnapshotIsolationTest | @Test22 작성 | 엔진 NOT_EXECUTED |

`PortSnapshotAssertions.java`의 22개 실행식과 `PortSnapshotIsolationTest.java`의 @Test22는 같은 검증 논리를 공유한다. JDK helper PASS를 JUnit engine PASS로 중복 집계하지 않는다.

## 범위 밖

scope 확장 권한 검증, 승인 hash 진위 검증, SQL transaction, 외부 vendor network effect, Jackson 바인딩, actual adapter compatibility는 이 isolated probe의 통과 범위가 아니다. 기존 CP15 traceability의 미확인 조건은 그대로 남는다.

# CP-07 Runtime Verification Runbook

## Required environment
- Java 21
- Maven 3.9+
- Docker or compatible Testcontainers runtime
- Node 24+
- reviewed/committed `web/package-lock.json`
- MariaDB Testcontainers image `mariadb:11.8.9`

## One-command gate
```bash
bash scripts/runtime-verify.sh
```

## Gate order
1. `python3 scripts/verify_source.py`
2. `bash scripts/runtime-preflight.sh`
3. `cd backend && mvn -B -ntp clean verify`
4. `python3 scripts/verify_runtime_evidence.py`
5. `cd web && npm ci`
6. `npm run typecheck`
7. `npm run build`

## Backend evidence requirements
The Surefire gate requires successful reports for CP01..CP07 acceptance suites plus `MariaDbMigrationIntegrationTest`.

Allowed skips are only the already documented policy-dependent tests:
- CP02: 2
- CP05: 1
- CP06: 1
- CP07: 1 (`CP07-T34`)

Any additional skip/failure/error blocks completion.

## Database gate
A clean MariaDB must apply **V001..V026 = 26 migrations** and Flyway validation must pass.

## CP-07 hard blockers
- cross-tenant access
- approval revision/hash mismatch accepted
- implicit empty-scope full grant
- scope outside pinned ProductVersion
- changed approval replay silently expanding scope/quota
- Entitlement revoke not immediately removing platform authority
- Gateway call inside materialization/revoke DB transaction
- timeout incorrectly collapsed into FAILED
- raw credential material persisted/logged
- undocumented disabled tests

## Current sandbox status
This package's runtime preflight is expected to report BLOCKED when Maven/Docker/Node 24/lockfile prerequisites are absent. Do not convert that to PASS.

# CP-10 Implementation Plan — Executed

1. Baseline from cumulative CP-09 v0.9.
2. V033 Candidate productization continuation.
3. V034 PublicationReview persistence and snapshot evidence.
4. V035 ProductVersion approved-review linkage.
5. V036 granular permission vocabulary, no role mapping.
6. Add `provider.publishing` application/API/persistence/snapshot boundary.
7. Reuse existing APIProduct/ProductVersion/component structures rather than inventing parallel product models.
8. Add Publish Readiness with explicit fail-closed unresolved-authority blockers.
9. Add PublicationReview lifecycle and snapshot binding.
10. Insert PublicationReleaseGate before existing ProductVersion Release and coordinate APIVersion/APIProduct after Release.
11. Keep CatalogPublication separate.
12. Add CP-10 OpenAPI contract and CP10-T01~T53 traceability.
13. Extend cumulative static verifier and migration runtime gate to V036.
14. Execute available static/source-contract checks; do not claim Maven/Testcontainers runtime PASS when unavailable.

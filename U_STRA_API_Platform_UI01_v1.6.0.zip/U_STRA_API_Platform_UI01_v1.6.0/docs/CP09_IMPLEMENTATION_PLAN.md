# CP-09 Implementation Plan

1. Start from cumulative CP-08 v0.8 baseline.
2. Add V030 API identity/import foundation, V031 version provenance, V032 permission vocabulary.
3. Add `provider.importing` module with parser port/adapter, external-ref guard, SHA-256, conservative path normalizer.
4. Record import attempt metadata separately from technical materialization so invalid input leaves no partial API tree while safe failure metadata remains.
5. Materialize tenant-qualified API -> APIVersion(DRAFT) -> APIOperation atomically.
6. Apply hash/idempotency conflict rules without Product/Publication side effects.
7. Add CP-09 OpenAPI contract and CP09-T01~T46 traceability.
8. Extend migration/static verification from V001..V029 to V001..V032.

# CP-12 Runtime Verification Runbook

Run this only in an approved environment with Java 21, Maven, Docker/Testcontainers and MariaDB container access.

```bash
cd backend
mvn -B -ntp clean verify
cd ..
python3 scripts/verify_runtime_evidence.py
```

Required evidence:
1. Spring/JPA compilation succeeds with the project dependencies.
2. `MariaDbMigrationIntegrationTest` applies and validates V001~V042 against MariaDB 11.8.x.
3. CP01~CP12 acceptance suites execute; CP12 must report exactly 60 tests with exactly 8 documented design-gated skips and no failures/errors.
4. `Cp12SearchProjectionHashUnitTest` passes.
5. Search/rebuild integration fixtures verify Tenant/Organization isolation, Publication lifecycle, PUBLISHED localization and provider filters against real repositories.
6. Representative data + `EXPLAIN`/latency measurement is required before any production performance/index claim.

Until the above evidence exists, status remains `RUNTIME BLOCKED / NOT RELEASE-READY`.

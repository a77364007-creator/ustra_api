# CP-11 Runtime Verification Runbook

Run in an approved environment with Java 21, Maven, Docker/Testcontainers and MariaDB 11.8 available.

```bash
python3 scripts/verify_source.py
python3 scripts/verify_cp11_source_contract.py
bash scripts/runtime-preflight.sh
cd backend
mvn -B -ntp clean verify
cd ..
python3 scripts/verify_runtime_evidence.py
```

The runtime gate must prove at minimum:
1. Maven dependency resolution and compilation, including `swagger-parser:2.1.48` APIs.
2. CP01~CP11 JUnit/Spring regression reports with only documented disabled tests.
3. `MariaDbMigrationIntegrationTest` applies exactly V001~V040 and `flyway.validate()` succeeds on MariaDB 11.8.
4. CP-09 OpenAPI 3.0/3.1 parser behavior still passes after the CP-11 structural extraction extension.
5. `Cp11ContractFingerprintUnitTest` and `Cp11OpenApiParserUnitTest` pass.
6. CP-11 APIChange/ConsumerImpact/deprecation HTTP + persistence behavior is exercised with real Spring/JPA transactions before release.

Expected source-level disabled CP-11 tests until design decisions are approved:
`T16,T17,T18,T19,T20,T34,T40,T42,T45,T46,T47,T48,T49,T50` (14 tests).

Do not release if Maven/Testcontainers/MariaDB evidence is missing even when static verification is green.

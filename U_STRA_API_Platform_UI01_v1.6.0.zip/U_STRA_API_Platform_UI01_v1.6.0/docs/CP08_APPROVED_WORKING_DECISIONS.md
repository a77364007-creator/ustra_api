# CP-08 Approved Working Decisions

## Scope
CP-08 closes the first backend vertical slice from a scoped SubscriptionRequest through mock approval, CP-07 materialization, mock Gateway fulfillment, opaque CredentialReference, and derived ReadyToUse.

## Decisions applied
1. A CP-08-capable request carries explicit immutable requested APIOperation scope. Legacy scope-less requests remain readable/cancellable but fail closed at approval entry.
2. Approved operation scope must be a non-empty subset of requested scope.
3. `expectedCallVolume` is descriptive only; no enforceable quota is inferred from text.
4. One ApprovalReference per exact request revision in this MVP slice.
5. Mock Approval supports explicit APPROVED/REJECTED decisions only; no auto-approval.
6. Mock Approval and Mock Gateway are active only in `local`, `test`, or `mock-integration` profiles.
7. Approval synchronization commits before CP-07 Entitlement materialization. Request becomes COMPLETED only after materialization succeeds.
8. Gateway side effect is outside the Platform DB transaction. PROCESSING is committed first.
9. Timeout-after-effect is UNKNOWN and is reconciled through status query; no blind second provision.
10. Credential storage is opaque reference/status/expiry only. No raw key/secret/token is generated or persisted.
11. ReadyToUse is derived and now additionally requires ConsumerApp ACTIVE.
12. Post-grant Publication suspension/withdrawal semantics remain unresolved and are not invented.
13. ConsumerApp owner/organization object-scope authorization remains a release blocker.

# CP-12 Approved Working Decisions

Authorized by continuation after CP-12 Readiness.

1. CP-12 is MVP keyword Search & Discovery, not semantic/vector/AI search.
2. Result identity is API Product; APIOperation is not a search result identity.
3. Search projection is disposable/rebuildable and is not a canonical source of truth.
4. `CatalogSearchPort` and `CatalogSearchProjectionPort` isolate search implementation.
5. CP-12 uses MariaDB projection foundation; no new search vendor/library is introduced.
6. Search reuses `API_PRODUCT:READ`; rebuild uses `CATALOG_SEARCH:REBUILD` with no automatic role mapping.
7. Tenant and Organization authority come only from server-resolved `TenantContext`.
8. Canonical discoverability is rechecked at query time; projection alone cannot authorize disclosure.
9. Search text sources are Product code/name/description, Provider identity and only PUBLISHED localization.
10. Multilingual matches dedupe by `apiProductId`.
11. All visible released version/publication evidence is returned; no latest/recommended version is selected.
12. Provider filter is enabled only with same-tenant validation.
13. Missing taxonomies/facets are design-gated; no synthetic values are inferred.
14. No numeric relevance/popularity score is invented; deterministic stable ordering is used.
15. Full tenant rebuild and idempotent Product reindex are required recovery foundations.
16. Projection refresh occurs after canonical commit; projection failure cannot roll back canonical business changes.
17. Raw search query text is not persisted into Audit/Outbox by CP-12.
18. Raw OpenAPI, credentials and secrets are excluded from search projection.

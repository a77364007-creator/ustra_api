# U.STRA API Platform — CP-11 As-Built Report

## 1. Baseline and scope
- Source baseline: cumulative CP-10 v1.0.
- Implemented scope: CP-11 Change Assessment + Consumer Impact foundation + explicit APIVersion deprecation.
- Deferred by design gate: full schema/security breaking rule catalog, MigrationPlan, notification target model, retirement force/grace/waiver policy, actual ITSM/Gateway/Operations.

## 2. Database changes
- `V037__api_contract_snapshot.sql`: immutable sanitized contract/evidence snapshot.
- `V038__api_change_assessment.sql`: APIChange and evidence items.
- `V039__consumer_impact.sql`: immutable impact analyses and materialized consumer rows.
- `V040__api_change_permissions.sql`: CP-11 permission vocabulary only.

## 3. Parser / contract evidence
`OpenApiParserPort` now carries sanitized parameter, request-body, response and security facts. `SanitizedContractFingerprintService` hashes contract-significant structure, excluding descriptions/examples/raw source. Newly imported APIVersions materialize a `CP11-STRUCTURE-V1` snapshot in the same import transaction.

Existing historical APIVersions are not silently reconstructed/backfilled from an unapproved source. If a baseline or target snapshot is absent, assessment returns `REVIEW_REQUIRED` evidence.

## 4. Compatibility assessment
- pair must be same Tenant and same API, different APIVersions.
- rule set: `CP11-OPERATION-V1`.
- exact structural hash match: `NO_CONTRACT_CHANGE`.
- removed operation: `BREAKING`.
- added operation: informational evidence but overall `REVIEW_REQUIRED` under current incomplete rule coverage.
- changed operation fingerprint: `REVIEW_REQUIRED`.
- source-content hash is not a verdict input.

## 5. Consumer Impact
Impact traversal uses baseline ProductVersion composition and pinned Subscriptions/Entitlements. It does not select “latest” or “recommended”. Statuses are stored as evidence snapshots and summarized by status; no unapproved active-consumer inclusion policy is applied.

## 6. Lifecycle
A RELEASED APIVersion may be explicitly moved to DEPRECATED with permission + row-version control. Repeated DEPRECATED requests are idempotent. Deprecation does not revoke Subscription/Entitlement, modify CatalogPublication, or call Gateway. Retirement remains closed pending Design Feedback.

## 7. Regression hardening
- updated CP-09 parser test helper for the new parser dependency without changing CP-09 business semantics.
- CP-10 migration acceptance no longer assumes the cumulative project must stop at V036; it verifies V001~V036 remain present.
- cumulative MariaDB runtime migration gate now requires V001~V040.
- runtime evidence verifier now requires CP09, CP10 and CP11 reports as well as prior CPs.
- CP-11 reference CI template added but not activated as a provider workflow.

## 8. Tests / verification actually executed in this environment
- source verifier: PASS (see `CP11_STATIC_VERIFICATION_RESULT.txt`).
- CP-11 source-contract verifier: PASS for implemented scope; design-gated cases are explicit SKIP (see evidence file).
- all OpenAPI YAML files parse successfully with local YAML parser.
- dependency-less `javac` diagnostic: zero syntax-like and zero non-dependency-like diagnostics after excluding expected missing-framework/dependency symbols. This is not Maven compile PASS.

Focused JUnit tests were added for contract fingerprints and parser structural extraction, but Maven/JUnit was unavailable and these tests were not executed here.

## 9. Runtime state
Environment observed:
- Java 21 available.
- Maven unavailable.
- Docker/Testcontainers unavailable.
- Node 22 available while target frontend baseline is Node 24.

Therefore final status is:

**SOURCE IMPLEMENTED / STATIC VERIFIED / POLICY+RUNTIME BLOCKED / NOT RELEASE-READY**

## 10. Open design feedback
See `DESIGN_FEEDBACK_CP11.md`. The most important remaining decisions are full compatibility semantics, Consumer inclusion, MigrationPlan, Retirement policy, ProductVersion/APIVersion/CatalogPublication coordination and notification targeting.

# CP-02 Runtime Gate Hardening Changelog

## RH-01 — MariaDB migration expected count corrected

**Before**: `MariaDbMigrationIntegrationTest` expected 9 migrations (CP-01 baseline).  
**After**: it requires all 11 migrations, V001 through V011.

Reason: CP-02 adds V010 and V011. The old assertion would make a correct CP-02 migration set fail.

## RH-02 — Docker absence may not silently skip MariaDB validation

**Before**: `@Testcontainers(disabledWithoutDocker = true)` could turn missing Docker into a skipped test.  
**After**: strict `@Testcontainers`; unavailable Testcontainers runtime is a Gate failure.

Reason: clean MariaDB migration is a CP-02 release criterion, not an optional test.

## RH-03 — Surefire evidence hard gate

Added `scripts/verify_runtime_evidence.py`.

It requires runtime evidence for:

- CP-01 acceptance tests
- CP-02 acceptance tests
- real MariaDB migration test

Only the two explicitly documented design-pending CP-02 tests may be skipped. Any additional skip fails the Gate.

## RH-04 — CP-02 CI reference template

Added `ci/templates/github-actions/cp02-verify.yml`.

The template runs:

1. static source guard
2. Java 21 + Docker verification
3. Maven clean verify
4. Surefire evidence gate
5. Node 24 + locked frontend build
6. final CP-02 Gate

It is not activated automatically because CI-provider policy remains a human/organization decision.

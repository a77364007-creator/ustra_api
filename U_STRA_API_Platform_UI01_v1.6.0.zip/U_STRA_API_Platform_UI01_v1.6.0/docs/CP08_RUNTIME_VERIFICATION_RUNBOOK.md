# CP-08 Runtime Verification Runbook

## Required environment
- Java 21
- Maven
- Docker-compatible runtime available to Testcontainers
- Node 24 target and committed `web/package-lock.json` for reproducible frontend gate

## One-command gate
```bash
./scripts/runtime-verify.sh
```

The gate executes:
1. `scripts/verify_source.py`
2. environment preflight
3. `mvn -B -ntp clean verify`
4. Surefire evidence inspection for CP01~CP08 + MariaDB migration test
5. frontend `npm ci`, typecheck and build

## MariaDB gate
`MariaDbMigrationIntegrationTest` must execute V001..V029 on a real Testcontainers MariaDB. Docker absence must fail/block; it must not silently skip.

## Expected CP-08 test evidence
- `Cp08AcceptanceIntegrationTest`: at least 57 tests
- exactly 2 skips: CP08-T37 and CP08-T47
- zero failures/errors
- CP08-E2E-01 must execute in the `test` profile with mock adapters

## Release interpretation
Static verification alone is not runtime PASS. Runtime/release remains blocked until Maven/Testcontainers evidence exists and DF-CP08-11 is resolved.

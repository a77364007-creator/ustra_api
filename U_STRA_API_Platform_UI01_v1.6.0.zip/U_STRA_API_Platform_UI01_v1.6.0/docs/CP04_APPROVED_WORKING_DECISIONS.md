# CP-04 Approved Working Decisions

이번 구현은 직전 Readiness 단계에서 제시한 권고안을 사용자가 `다음`으로 계속 진행하도록 지시한 흐름에 따라 **CP-04 작업 기준선**으로 적용했다. 단, 원 설계에서 미확정인 정책을 추가 확정하지 않는다.

## 적용 기준

1. MVP resource scope: `APIProduct` localization만 구현.
2. MVP translatable fields: `name`, `description`.
3. Storage: Product + locale당 current row 1개.
4. `MISSING`: row 부재의 derived status. DB에 저장하지 않음.
5. `REVIEW`: enum은 유지하되 public transition을 만들지 않음.
6. Publish command: REVIEW/publish policy 승인 전 public endpoint를 열지 않음.
7. Canonical source revision: `api_product.localization_revision`을 V016으로 추가하고 name/description 변경 시에만 증가.
8. Permission: `API_PRODUCT:READ`, `API_PRODUCT:UPDATE` 재사용. Role 이름 하드코딩 금지.
9. Fallback MVP: requested locale -> tenant default -> canonical text. User locale/platform default authority는 미확정으로 보류.
10. Required locale policy: CP-04에 만들지 않음.
11. `LocalizationUpdated`: 현재 구현된 consumer-visible 의미 변화인 `PUBLISHED -> STALE`에만 발행. Publish trigger는 publish 정책 확정 후 결정.

## 구현하지 않은 결정

위 기준은 다음을 확정하지 않는다.

- DRAFT/REVIEW/PUBLISHED 전체 상태전이 그래프
- Reviewer 역할/승인 주체
- User locale 저장 위치
- Platform default locale authority
- Required locale 목록 및 publication readiness 정책
- locale 대소문자/alias canonicalization 정책
- revision history entity

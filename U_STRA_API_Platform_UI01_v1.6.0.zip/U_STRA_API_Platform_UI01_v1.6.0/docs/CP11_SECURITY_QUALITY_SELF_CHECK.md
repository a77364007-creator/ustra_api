# CP-11 Security & Quality Self-Check

## Security
- Tenant ownership is resolved server-side; assessment and impact repositories use tenant-qualified lookup.
- CP-09 external/remote/file/path-traversal `$ref` guard remains active before parsing.
- Raw OpenAPI source, descriptions/examples, credentials and secret values are not stored in CP-11 canonical snapshot tables, Audit or Outbox.
- Contract Snapshot stores structural hashes/fingerprints and approved identifiers only.
- Role-to-Permission mappings are not invented.
- Deprecation cannot silently revoke consumers or call Gateway.

## Integrity / concurrency
- APIChange uses Idempotency-Key + request fingerprint and exact pair/hash/rule-set uniqueness.
- Consumer Impact analysis is immutable and keyed by an impact-basis hash; prior evidence is not rewritten.
- APIVersion deprecation requires row-version (`If-Match`) concurrency control.
- V037~V039 use tenant-qualified foreign keys for tenant-owned relationships.

## Compatibility conservatism
- source hash difference alone is ignored as a Breaking verdict.
- exact structural equality => `NO_CONTRACT_CHANGE`.
- operation removal => `BREAKING`.
- operation addition/unsupported structural change => `REVIEW_REQUIRED`, not fabricated NON_BREAKING.
- legacy version without structural evidence => `REVIEW_REQUIRED`.

## Regression boundaries
- CP-09 same-version same-hash replay and different-hash conflict retained.
- CP-10 Review approval, Release and CatalogPublication activation remain separate.
- Consumer subscription pinning remains authoritative; no “latest” auto migration.

## Verification limitation
Maven, Docker/Testcontainers and MariaDB runtime were not available. Static/source-contract/Javac syntax diagnostics are not substitutes for compile/runtime PASS.

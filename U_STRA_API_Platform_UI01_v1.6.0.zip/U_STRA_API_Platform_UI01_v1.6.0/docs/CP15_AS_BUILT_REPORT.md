# CP-15 v1.5 Stage A — As-Built

**구현일:** 2026-09-22  
**Source Baseline:** U_STRA_API_Platform_CP14_v1.4.zip  
**Baseline SHA256:** `0885b6f6e6d28c4ff6230514e5aeaa6382207f0f7acd0546bbd189c86e311f9a`  
**현재 상태:** `CP15 STAGE-A SOURCE IMPLEMENTED / TARGETED STATIC+PURE-JAVA VERIFIED / SPRING+DB+VENDOR+POLICY+UI BLOCKED / NOT RELEASE-READY`

## 1. 입력 충분성과 구현 범위
CP15 Readiness의 Stage A working decision에 따라 구현했다. Vendor 계약 없는 전체 운영기능이나 업무권한/상태정책은 만들지 않았다. 구현 소스는 생성했으나 일부 행위 수용검사의 추가 작성과 모든 JUnit/runtime 실행이 남아 있다.

Java21, 기존 Spring Boot/POM, JPA/MariaDB/Flyway, 기존 보안·Audit·Outbox·응답 패턴을 유지했다. 새 라이브러리/버전변경은 없다. Web 셸은 변경하지 않았다.

## 2. 소스 안전성 보강
- **Outbox:** LoggingOutboxSink를 explicit non-prod로 제한하고 prod+test 혼합도 제외. prod worker 기본false, enabled 시 Stage A delivery gate 오류. 실제 transport가 없는 상태에서 PENDING을 가짜 PUBLISHED로 바꾸지 않는다. prod에는 어떤 sink가 추가돼도 아직 delivery를 열지 않는다.
- **Approval:** adapter resolution을 beginOutbound 전에 수행. 외부 create/결과저장을 다른 예외경계로 분리. 원격 호출의 명시 definitive 실패만 FAILED, 포괄 호출후/DB 반영실패는 UNKNOWN. 동일 create를 무조건 재전송하지 않는다.
- **TX:** Approval/Gateway/Recovery orchestrator는 NOT_SUPPORTED로 caller TX를 suspend. journal은 별도 REQUIRES_NEW; 기존 업무 state service 재사용.
- **권한별 조회:** legacy Approval/Gateway 목록과 신규 query/count는 Tenant/type을 DB에서 제한. issue명 prefix가 아니라 부모 operation으로 source를 판별. audit는 AUDIT:READ 독립. journal GET도 허용 actionType을 조회 predicate에 적용.
- **Issue 재발:** 같은 unique row를 reopen하고 감사기록. parent operation lock으로 최초insert/재발의 경쟁을 조정한다.

## 3. 신규 구현
### Migration
|버전|내용|
|---|---|
|V047|operations_recovery_action: tenant/key unique, fingerprint, nullable active-target unique, 상태check, Tenant+operation FK, audit correlation|
|V048|OPERATIONS:READ / AUDIT:READ vocabulary; Role 매핑 자동추가 없음|
|V049|search_projection_failure: 독립 Tenant/Product identity, 실패관측/해소시각, observation_count 및 rowVersion|

**V001–V046의 실제 파일해시46개 모두 기존과 같다.** `baseline_integrity.json`에 근거를 보관했다.

### 운영·감사 API
`GET /api/v1/admin/operations/summary`  
`GET /api/v1/admin/operations/integration-operations`  
`GET /api/v1/admin/operations/reconciliation-issues`  
`GET /api/v1/admin/operations/outbox-events`  
`GET /api/v1/admin/operations/connectors`  
`GET /api/v1/admin/operations/search-failures`  
`GET /api/v1/admin/audit-records`  
`POST /api/v1/admin/operations/recovery-actions`  
`GET /api/v1/admin/operations/recovery-actions/{id}`

9개 additive HTTP endpoint다. bounded time/page/filter/sort, time+ID tie-break, safe DTO, source별 조회와 합계, asOf 및 unavailable 지표를 제공한다. stored enabled를 실제healthy로 보지 않는다.

### 통제된 수동 복구
네 action만 허용: Approval 상태조회, Gateway 상태조회, Product 재색인, 현재 Tenant 검색전체재생성. 기존 Approval/Gateway/Search handler를 호출한다.

`권한·입력 검증 → 신규 journal 저장 commit → claim commit → target 재검증 → handler (업무TX 밖) → 결과 기록 commit`.

동일 Tenant/key와 fingerprint는 기존기록만 반환하며 재실행하지 않는다. fingerprint가 다르면 conflict. UNKNOWN/IN_PROGRESS는 시간기준으로 인수/재실행하지 않는다. 새 journal 경로에서 미해결 activeTarget은 다른 키의 중복실행도 막는다.

**actionStatus=SUCCEEDED는 handler 처리 완료다.** targetStatus=PENDING/UNKNOWN 등은 그대로 유지한다. 승인/Gateway 권한상태를 직접 성공으로 바꾸는 API가 아니다.

### 검색 실패관측
Canonical 서비스/Projection 모델을 변경하지 않고 기존 AFTER_COMMIT 경계를 유지한다. 실패 기록은 독립TX, 동일Product 재관측 재사용, 같은 시각 실패도 observation_count 변경으로 rowVersion이 진행된다. 성공은 작업 전 관측한 버전과 일치하는 경우만 failure를 해소한다. 관측DB마저 실패하면 고정코드 로그를 남기고 Canonical 업무를 되돌리지 않는다.

## 4. 실제 실행 결과
|검증 분류|실제 결과|의미|
|---|---|---|
|누적 기존 source guard|1146/1146 PASS|CP01–14 정적구조검사; runtime 동작 증거 아님|
|CP15 신규 구조검사|91/91 PASS|SQL/경계/권한·테스트 존재 등 구조검사|
|JDK syntax parse|349개 Java / 구문오류0|main+test parse만 수행; dependency typing/전체compile 아님|
|순수 Java 실제 코드 probe|29/29 PASS|실제 RecoveryRequest/ActionType/Status 컴파일 및 요청/키/hash/enum 실행 한정|
|OpenAPI YAML|15개 parse PASS|계약 문법; endpoint 런타임적합성 아님|
|기타|Python 7개 AST, Shell 10개 bash -n, config YAML 3개, POM XML parse PASS|문법검사|
|신규 JUnit|행위메서드 67개 작성 / 실행0|단위/Mockito/Spring/HTTP/H2/MariaDB 범주; PASS 없음|
|후속 Gate|16개 explicit disabled|계약/정책/운영/UI 미완료|
|Maven / Spring compile / JPA / Testcontainers|NOT_EXECUTED|mvn/Docker/DB 없음|
|CP01–15 전체 runtime 회귀|NOT_EXECUTED|정적검사 결과로 대체하지 않음|
|실 Vendor / UI / restore / SAST|NOT_EXECUTED|별도 승인 환경·자료 필요|

Java21.0.11 / Node22.16.0 확인. Maven·Docker·Podman·MariaDB CLI 없음. runtime-preflight는 mvn missing으로 exit2. Node24 목표 및 검증된 frontend lockfile도 별도 Gate다.

CP11–14의 dedicated source-contract verifier도 재실행했다. 출력의 active PASS는 **source condition**일 뿐 JUnit acceptance 성공이 아니다. dependencyless javac의 외부 dependency 오류 로그는 초기 참고용이며 최종 검증은 위에 분류했다.

## 5. 변경 영향
소스/테스트/설정/스크립트/계약/CI 범위 **신규 38개, 변경 33개**. `CP15_CHANGESET.json`, `CP15_CHANGED_FILES.md`, `CP14_TO_CP15_SOURCE_DIFF.patch` 참조. 기존 runtime migration test는49개 검증으로 확장, source verifier는 annotation 부재가 아니라 NOT_SUPPORTED 의미를 검사하도록 수정했다. 기존 suite를 제거하지 않았다.

## 6. 잔여사항과 인계
- Stage A64조건은 모두 runtime 미실행. 일부는 부분 커버리지다. 실제 서비스 동시 claim, 사전 journal commit 관측, Canonical commit fault test, 전 source HTTP matrix 추가가 필요하다. 추적표에 숨기지 않았다.
- 신규 journal의 active mutex는 기존 legacy reconcile/rebuild API와 공유되지 않는다. legacy 응답/경로는 유지하며 그 경로의 전역 단일실행/통합journal을 보장하지 않는다. 원 경로 이관은 계약조정 및 경쟁검증을 전제로 한다.
- StageA의 Production Outbox는 의도적으로 닫혀 있다. actual ITSM/Gateway, 자동worker/retry/DLQ, Usage/Notification, 설정쓰기 승인, purge/복원훈련/NFR, 필수 UI와 과거정책Gate는 미완료다.
- **15개 단계번호와 제품100%완성은 다르다.** web/src/App.tsx는 CP01 기술 셸이다.
- 다음 우선순위는 Build & Runtime Closure와 부분 커버리지 보완이다. Coding Doctor/실제환경/개발자 검토 전 운영반영하지 않는다.

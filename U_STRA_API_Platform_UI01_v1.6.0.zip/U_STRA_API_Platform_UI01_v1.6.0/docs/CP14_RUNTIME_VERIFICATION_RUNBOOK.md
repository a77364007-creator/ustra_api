# CP-14 Runtime Verification Runbook

Run only in an approved environment with Java 21, Maven, Docker/Testcontainers and MariaDB 11.8 compatible image.

1. `java -version` — confirm Java 21.
2. `mvn -version` — Maven installed and bound to Java 21.
3. `docker info` — Docker available.
4. From repository root: `python3 scripts/verify_source.py`.
5. From repository root: `python3 scripts/verify_cp14_source_contract.py`.
6. From `backend/`: `mvn -B -ntp clean verify`.
7. Confirm `MariaDbMigrationIntegrationTest` sees at least V001–V046 and V045 CHECK-constraint alteration succeeds on the target MariaDB version.
8. Confirm CP01..CP14 Surefire reports exist; CP14 must have at least 70 tests with exactly **9** documented contract-gate skips and zero failures/errors.
9. Run `python3 scripts/verify_runtime_evidence.py`.
10. From `web/`: `npm ci && npm run typecheck && npm run build` using the approved Node 24 baseline.
11. For vendor-specific Stage B, resolve DF-CP14-01..10, register a real adapter and add sandbox contract tests for auth, provision, query, deprovision, idempotency after timeout, quota mapping, credential lifecycle and drift evidence.

Passing steps 1–10 validates the current contract-neutral CP-14 foundation. It does **not** validate a production Gateway adapter because none is present.

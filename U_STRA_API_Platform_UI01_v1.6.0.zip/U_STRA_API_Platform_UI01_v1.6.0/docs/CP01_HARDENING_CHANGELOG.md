# CP-01 Hardening Changelog

This note records source-level hardening performed after the first CP-01 handoff package. It does not extend scope into CP-02.

## H-01 — Test authentication profile narrowed

- Previous generated state: local test authentication components used a broad `!prod` profile expression.
- Risk: an incorrectly deployed runtime with no `prod` profile could register test-header authentication components.
- Change: `LocalSecurityConfig`, `TestHeaderAuthenticationFilter`, and `LocalIdentityAuthority` now register only under explicit `local` or `test` profiles.
- Regression guard: `scripts/verify_source.py` rejects a return to broad `!prod` test-auth configuration.

## H-02 — CP01-T15 correlation evidence strengthened

- Previous generated test: verified correlationId in the HTTP response.
- Required specification: error response correlationId and matching structured log context.
- Change: safe error-code/status logging added to `GlobalExceptionHandler`; CP01-T15 now asserts the same correlationId exists in MDC-backed log evidence.
- Secret handling: request body, token and credentials are not added to these rejection log messages.

## H-03 — CP01-T11 audit coverage completed

- Previous generated test: checked privileged role assignment audit.
- Required specification: role assignment and revoke audit.
- Change: CP01-T11 now checks both `ROLE_ASSIGN` and `ROLE_REVOKE`, including actor, correlationId and target identity.

## H-04 — CP01-T12 transaction coverage completed

- Previous generated test: checked rollback removes both state and outbox event.
- Required specification: rollback removes both; successful commit persists matching state and outbox event.
- Change: CP01-T12 now verifies both negative rollback and positive commit paths.

## H-05 — Runtime false-green prevention

Added:
- `scripts/runtime-preflight.sh`
- `scripts/runtime-verify.sh`

The preflight requires:
- Java 21
- Maven 3.9+
- Node 24+
- verified `web/package-lock.json`
- Testcontainers-compatible container runtime

This prevents a Maven run with skipped MariaDB container tests or a frontend run without a verified lockfile from being treated as a completed CP-01 runtime gate.

## Current verification state

- Static source checks: PASS 49/49.
- Runtime verification: BLOCKED at preflight in the current sandbox because Maven is unavailable. Docker/Podman are also unavailable, Node is 22 rather than the target 24, and required npm metadata is not cached.
- Completion status: **BLOCKED / NOT COMPLETE** until the runtime gate passes in an approved dev/CI environment.

## H-06 — CI verification contract added

Added:
- `docs/CP01_CI_VERIFICATION_PIPELINE.md`
- `ci/README.md`
- `ci/templates/github-actions/cp01-verify.yml`

The pipeline separates static source guards, backend/Testcontainers/MariaDB verification, frontend reproducible build, and the final CP-01 gate. The GitHub Actions file is intentionally stored as a reference template instead of an active `.github/workflows` file because the supplied baseline does not approve a CI provider, branch policy, runner policy, or action allowlist/SHA-pinning standard.

The source verifier also checks that:
- `mvn clean verify` and `npm ci` remain required;
- CP01-T01..T16 and tenant-isolation hard gates are preserved;
- lockfile/Testcontainers prerequisites are not bypassed;
- the provider-specific workflow is not silently activated.

## H-07 — Local development auto-start / reproducibility hardening

- Added `scripts/dev-up.sh`, `dev-down.sh`, `dev-status.sh`, `dev-smoke.sh`, `dev-init-web.sh` and shared local helper.
- Bound local MariaDB port to `127.0.0.1` rather than all interfaces.
- Made local DB values overrideable through uncommitted `.env` while keeping production IdP/bootstrap out of the local fixture.
- Added idempotent fixture loading after Flyway/health readiness.
- Added local negative security smoke checks: anonymous `401`, authenticated unauthorized `403`, platform-admin authorized `200`.
- Full local start blocks when the reviewed frontend lockfile is absent; it does not downgrade to non-reproducible `npm install` silently.
- Local runtime PID/log files are isolated under ignored `.local/`.
- Runtime execution remains unverified in the current generation environment because Maven/Docker/Node 24 prerequisites are unavailable.

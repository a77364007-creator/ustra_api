# CP-12 Quality / Security Self-Check

## Functional / consistency
- Product is the response identity; locale/publication matches dedupe to Product.
- blank query still requires canonical discoverability.
- multiple visible versions are evidence, not an implicit latest/default.
- Provider direct filter is same-tenant validated.
- projection loss is recoverable through canonical rebuild.

## Authorization / privacy
- Tenant is server-resolved; no X-Tenant-Id authority is introduced.
- Organization audience uses `TenantContext.organizationId()`.
- final visibility is rechecked against canonical Catalog state; projection is not authorization SoT.
- raw search terms are not stored in Audit/Outbox by CP-12.
- raw OpenAPI, secrets, credentials, approval payloads and consumer identities are absent from projection schema.
- Classification/AccessPolicy remains an explicit release blocker, not silently treated as equivalent.

## Failure / transaction behavior
- Product/Publication writes publish a local reindex event in their canonical transaction.
- actual projection refresh runs AFTER_COMMIT and catches projection failures; canonical business mutations remain authoritative.
- full rebuild deletes only current-tenant projection rows, never canonical Product/Publication data.
- projection FKs use ON DELETE CASCADE so disposable projection cannot block canonical deletion semantics if deletion is later approved.

## Performance / compatibility
- page size and query length are bounded technical safety limits.
- no dynamic SQL fragment is built from search input.
- no production search QPS/latency/index effectiveness claim is made without MariaDB runtime/EXPLAIN evidence.
- no external search dependency/vendor is added.

## Verification honesty
Static/source-contract/YAML/dependency-less diagnostics were run. Maven, Spring compile, Testcontainers and MariaDB V001~V042 were not runnable in this environment and are not reported PASS.

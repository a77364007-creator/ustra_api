# CP-11 Implementation Plan

1. Extend CP-09 parser output with sanitized structural facts without storing raw OpenAPI.
2. Add V037 immutable Contract Snapshot persistence and materialize it for newly imported APIVersions.
3. Add V038 `APIChange`/`APIChangeItem` with deterministic, versioned compatibility assessment.
4. Add V039 immutable Consumer Impact analysis derived from ProductVersion composition and pinned consumers.
5. Add V040 permission vocabulary without Role mapping.
6. Add semantic API endpoints for assessment, evidence, impact analysis/summary, and explicit deprecation.
7. Preserve CP-09 import idempotency/conflict semantics and CP-10 Review/Release/Publication separation.
8. Keep policy-dependent retirement, MigrationPlan and notification targets design-gated.
9. Add CP11-T01~T56 traceability, focused parser/fingerprint unit tests, cumulative MariaDB migration gate, runtime evidence gate and CP-11 CI reference template.
10. Run all verification available in the current environment; never report Maven/Testcontainers/MariaDB runtime PASS unless actually executed.

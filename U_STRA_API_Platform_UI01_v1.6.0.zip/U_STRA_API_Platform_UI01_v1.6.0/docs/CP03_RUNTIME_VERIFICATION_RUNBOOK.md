# CP-03 Runtime Verification Runbook

## Required environment

- Java 21
- Maven 3.9+
- Docker or compatible Testcontainers runtime
- MariaDB Testcontainers image `mariadb:11.8.9`
- Node 24+
- committed/reviewed `web/package-lock.json`

## One-command verification

```bash
bash scripts/runtime-verify.sh
```

The gate executes:

1. source/security structural verification
2. runtime prerequisite verification
3. `mvn -B -ntp clean verify`
4. Surefire evidence validation
5. `npm ci`
6. TypeScript typecheck
7. production frontend build

## Backend acceptance evidence requirements

The evidence verifier requires:

- CP01 Acceptance: at least 16, 0 skipped
- CP02 Acceptance: at least 25, exactly 2 explicitly deferred tests
- CP03 Acceptance: at least 27, 0 skipped
- MariaDB Migration: at least 1, 0 skipped
- no failures/errors

## MariaDB migration gate

A clean MariaDB 11.8.9 Testcontainer must apply and validate **V001..V014 (14 migrations)**.
Docker absence is a failure/blocker, never a silent skip.

## Expected current sandbox result

This sandbox does not provide Maven/Docker and has Node 22 rather than Node 24. Runtime verification is therefore expected to stop in preflight and must remain `BLOCKED`, not PASS.

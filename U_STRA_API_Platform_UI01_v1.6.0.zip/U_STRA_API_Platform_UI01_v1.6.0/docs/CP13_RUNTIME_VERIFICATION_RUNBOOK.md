# CP-13 Runtime Verification Runbook

Run only in an approved environment with Java 21, Maven, Docker/Testcontainers and MariaDB 11.8 compatible image.

1. `java -version` — must satisfy project Java 21 baseline.
2. `mvn -version` — Maven must be installed and use Java 21.
3. `docker info` — Docker must be available for Testcontainers.
4. From `backend/`: `mvn -B -ntp clean verify`.
5. Confirm `MariaDbMigrationIntegrationTest` reports exactly **44** migrations and zero skip/failure.
6. Confirm CP01..CP13 Surefire reports exist; CP13 must have at least 64 tests with exactly **14** documented contract-gate skips and zero failures/errors.
7. Run `python3 scripts/verify_runtime_evidence.py` from repository root.
8. For actual ITSM Stage B, do not proceed until DF-CP13-01/02/03/06/12 are resolved. Then add sandbox contract tests for auth, create, query, callback replay, timeout lookup and secret-provider behavior.

Passing steps 1–7 validates the current contract-neutral source. It does **not** validate an actual ITSM adapter because no vendor contract/adapter is present in CP-13 v1.3.

# CP-13 Approved Working Decisions

Basis: CP-13 Readiness v0.1 followed by user continuation (`다음`).

1. Preserve `ApprovalPort` and `ApprovalStateService` as the canonical approval domain boundary.
2. Implement only contract-neutral integration foundation; no fabricated vendor ITSM API.
3. Persist an `IntegrationOperation` before outbound side effect and execute connector calls outside the business DB transaction.
4. Represent uncertain create/query outcome as `UNKNOWN`; do not blindly retry create.
5. Provide reconciliation architecture before enabling a real adapter.
6. Keep callback processing behind an authenticated-normalized inbox service; no public callback endpoint until auth/payload contract exists.
7. Resolve Tenant from platform context or persisted trusted correlation, never from arbitrary callback headers.
8. Store only opaque secret references and safe metadata; do not persist raw vendor request/response payload by default.
9. Reuse CP-08 request revision/hash/scope/quota validation and entitlement materialization.
10. Keep reviewer/evidence references opaque; no external-user to Membership auto-mapping.
11. Do not implement external cancellation, numeric retry/backoff/SLA, classification/risk mapping, or production Vault binding without design authority.
12. CP-14 remains owner of actual Gateway integration; CP-15 remains owner of full integration administration/operations UX.
13. If case creation is `UNKNOWN`, subscription cancellation is fail-closed because absence of an external case cannot be proven.

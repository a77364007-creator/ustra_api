# CP-15 v1.5.1 — Validation Design Feedback

| ID | 내용 | 조치/상태 |
|---|---|---|
| BV-01 | frontend Node/lockfile 전제조건이 backend 실행을 함께 차단 | backend 독립 runner 추가, 기존 전체검증 순서 조정. 구조/도구 검사 실행; Maven 경로는 실제 미실행. |
| BV-02 | 지정 suite 밖 실패를 기존 report 검사기가 놓침 | 합성 보고서로 기존 false-pass 재현. 모든 XML·메서드·skip·현재 소스·freshness 검사로 보강. 도구 unittest16개 실행 PASS. |
| BV-03 | 실제 Maven 실행파일/저장소 접근 부재 | BLOCKED. DNS/download 실패. 설치나 의존성 호환성 성공을 보고하지 않음. |
| BV-04 | MariaDB/Testcontainers 실행 환경 부재 | BLOCKED. 테스트 이미지/daemon 확보 후 실검증 필요. |
| BV-05 | 실제 서비스 동시 claim·사전 commit·이슈 재발 경합 부족 | JUnit7개 중 해당검사 추가. AUTHORED / NOT_EXECUTED; closed 판정 아님. |
| BV-06 | 인증된 Tenant/type DB query/count/HTTP 행렬 부족 | JUnit8개 추가. AUTHORED / NOT_EXECUTED; Production OIDC/조직 전체 행렬은 여전히 미완료. |
| BV-07 | legacy/new 복구 경로의 mutex 미공유 | UNCHANGED. 기존 public contract를 이번 검증 보강에서 임의 변경하지 않음. |
| BV-08 | 검색 성공/실패 실제 projection 경쟁·전체 업무 쓰기 경로 | 부분 test double 및 실제 관측 서비스 검사를 작성. 전체 경로 동작을 보장하지 않음. |
| BV-09 | 인벤토리의 동적/중첩/반복 JUnit 지원 | 현재 소스는 일반 @Test. 새로운 형태 도입 시 fail-closed로 생성 중단; 실제 보고서 대응 확장 필요. |
| BV-10 | 제품완료/출시준비를 CP 번호·테스트 수로 판단 | 금지. 누적714 선언/disabled76은 authored inventory이며 runtime 통과 아님. |

## 유지한 업무/보안 경계

운영 Java, migration, POM, 기본 설정, Web은 원본 그대로다. 실제 ITSM/Gateway/Quota/권한 정책/자동 trigger/재시도 숫자/Production Outbox/restore 권한은 추가하지 않았다. 운영 배포는 수행하지 않았다. 도구나 소스를 외부 repository로 업로드하지 않았다.

## 자체점검 한계

확인한 것은 파일 무결성, 소스 구조, 파싱, 일부 실제 순수 Java 및 검증기 자체 동작이다. 전체 컴파일, dependency vulnerability/SAST, 다중 Tenant/조직 실제 동시운영, DB 업그레이드/복원/성능 결과는 없다. 새 테스트가 향후 실패할 수 있으며 그 결과를 그대로 보존해야 한다.

# CP-03 Product Version & Publication — Implementation Plan

## 1. Input sufficiency / development status

CP-02 source is the technical baseline. CP-03 Readiness v0.1 and Decision Brief are the business/design working baseline. The continuation instruction is treated as authorization to implement the recommended working baseline, but it does not convert unresolved items into permanent business policy.

## 2. Reused CP-01/CP-02 assets

- `TenantContextResolver`
- `TenantPermissionGuard`
- canonical error/correlation handling
- JPA `@Version` + ETag/If-Match pattern
- `AuditService`
- transactional `OutboxService`
- tenant-qualified Repository/FK pattern
- Flyway/Testcontainers/runtime evidence gates
- CP-02 `APIProduct`, `API`, `APIVersion`, `APIOperation`

## 3. CP-03 implementation order

1. V012 `api_product_version`
2. V013 `api_product_component`
3. V014 `catalog_publication`, `audience_scope`, `state_transition_history`
4. ProductVersion/Component persistence + service + REST
5. Publication/AudienceScope persistence + service + REST
6. derived visibility service
7. Release/Activation history, audit, outbox
8. CP03-T01..T27
9. OpenAPI + traceability + As-Built
10. runtime verification gate

## 4. State boundaries

### ProductVersion

`DRAFT → VALIDATING → APPROVED → RELEASED → DEPRECATED → RETIRED`

CP-03 public commands own only:
- create → DRAFT
- APPROVED → RELEASED
- DRAFT composition add/remove

CP-10 remains responsible for review/approval. CP-11 remains responsible for deprecate/retire commands.

### CatalogPublication

Implemented working state path:
- create → DRAFT
- DRAFT → ACTIVE
- ACTIVE → SUSPENDED
- SUSPENDED → ACTIVE
- SUSPENDED → WITHDRAWN

`WITHDRAWN` is terminal in CP-03.

## 5. Security / transaction model

- tenant is always derived server-side
- Role names are never authorization conditions
- ProductVersion read uses `API_PRODUCT:READ`
- create/composition uses `API_PRODUCT:UPDATE`
- release/publication actions use `API_PRODUCT:PUBLISH`
- release and activation persist state + history + audit + named outbox event in one DB transaction
- suspend/withdraw persist state + history + audit in one DB transaction

## 6. Explicit non-scope

- Review/approval command
- default/recommended/latest selector
- SemVer enforcement
- publication effective period
- duplicate/overlapping publication selection policy
- Entitlement/Subscription behavior
- Search/Discovery public API
- deprecate/retire commands

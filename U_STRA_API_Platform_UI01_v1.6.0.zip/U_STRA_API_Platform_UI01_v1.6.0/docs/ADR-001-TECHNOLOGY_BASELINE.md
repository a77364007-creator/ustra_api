# ADR-001 — CP-01 Technology Baseline

## Status
PROPOSED_AND_APPLIED_FOR_CP01_GREENFIELD_BASELINE

## Context
The design baseline explicitly leaves technology selection to a human decision when no repository standard exists. This repository is greenfield.

## Decision
- Architecture: modular monolith first
- Backend: Java 21 + Spring Boot 3.5.16, Servlet/MVC
- Build: Maven
- Persistence: Spring Data JPA; explicit tenant-aware repository methods
- DB: MariaDB 11.8.9 (11.8 LTS series)
- Migration: Flyway
- Security: Spring Security; production JWT/OIDC resource-server boundary, local/test header auth isolated by profile
- Async foundation: DB transactional outbox + scheduled worker; no broker required for CP-01
- IDs: application-generated UUID text (`CHAR(36)`) for transparent cross-system identity
- Time: UTC `Instant` in persistence; tenant timezone retained as configuration
- Frontend baseline: Node 24.21 LTS + React 19.3.0 + TypeScript 5.9.3 + Vite 8.1.x, TypeScript-first
- Test: JUnit 5 / Spring Boot Test / Spring Security Test / H2 MariaDB-mode fast tests; MariaDB runtime migration is a deployment verification gate

## Rationale
This stack supports transactionality, optimistic locking, validation, server-side authorization, reproducible migrations, and a modular-monolith deployment shape without introducing microservices or a broker prematurely. Spring Boot 3.5.16 is intentionally selected as a conservative Java 21 baseline rather than moving CP-01 directly to the newer Spring Boot 4.x line; a 4.x upgrade should be a separate compatibility decision after the foundation build is verified.

## Explicit non-decisions
- IdP vendor and claim contract
- production platform-admin bootstrap procedure
- tenant-code uniqueness scope
- RLS usage
- detailed CP-01 admin UX

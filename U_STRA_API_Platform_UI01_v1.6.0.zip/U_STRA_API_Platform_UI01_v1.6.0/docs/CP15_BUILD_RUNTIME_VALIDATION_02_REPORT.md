# CP-15 v1.5.2 — Build & Runtime Validation 02

**작성일:** 2026-09-22  
**입력 Source Baseline:** `U_STRA_API_Platform_CP15_v1.5.1.zip`  
**입력 ZIP SHA-256:** `7b791f440e58b429cbc682fb665d6c9de14bd9996058d45c58404d0ccbbdf872`  
**결과:** `ISOLATED JAVA DEFECT REPRODUCED AND FIXED / MAVEN+SPRING+JUNIT+MARIADB BLOCKED / NOT RELEASE-READY`

## 1. 실행 목표와 결과

기존 backend no-db/full 명령을 다시 실행했지만 Maven preflight에서 BLOCKED(exit2)였다. 실제 Spring 컴파일·JUnit·MariaDB를 완료하지 못했다. Maven Central 직접 연결은 DNS 해석 실패(exit6), 별도 Apache binary 다운로드도 실패했다. 저장소 artifact가 존재하지 않는다는 뜻은 아니다.

이 차단과 별개로 **실제 production Java 소스의 가변 리스트 공유 결함**을 JDK21로 재현해 최소 수정했다. 애노테이션 제거, Spring/JPA 가짜 클래스, 다른 라이브러리 대체, 업무정책 변경은 하지 않았다.

## 2. 확인한 결함 — Port가 원본 리스트를 그대로 보관

### BRV02-01
- `GatewayPort.Command.apiOperationIds` / `quotas`
- `ApprovalPort.CaseCommand.requestedApiOperationIds`
- `ApprovalPort.Decision.approvedApiOperationIds` / `quotaLimits`

원본 record는 전달받은 List reference를 그대로 보관한다. 생성 뒤 호출자가 같은 ArrayList를 수정하거나 accessor가 반환한 List를 수정하면 record 내용도 달라진다. `requestFingerprint` / `snapshotHash` 문자열은 그대로인데 operation/승인 quota 내용은 바뀔 수 있다. 이는 immutable handoff/snapshot intent와 맞지 않는다.

단, 실제 DB 승인 범위 확대나 운영 사고를 재현했다는 의미는 아니다. 현재 repository 경로에는 stream.toList()로 생성되는 입력도 있으며, 그 경로가 모두 가변 리스트를 전달한다고 단정하지 않는다. 이 검사는 **Port construction / adapter handoff boundary 자체**를 검증한다.

### 실제 재현
같은 typed assertion 22개를 원본 세 production Java 파일과 함께 javac로 컴파일했다. 원본은 10 PASS / 12 FAIL이었다. 12 FAIL은 독립된 12개 업무 결함이 아니라 입력·accessor 변경/record identity 안정성 결함의 여러 재현이다.

두 Port 파일에 compact constructor를 추가하여 리스트를 defensive copy하고 unmodifiable wrapper로 보관했다. 같은 assertion을 다시 컴파일·실행한 결과 22 PASS / 0 FAIL이다.

### 유지한 계약
- null list는 null 그대로, null 원소도 기존 validator에 전달한다. 무조건 빈 scope로 바꾸지 않는다.
- order, duplicate, case, whitespace를 정규화하지 않는다.
- scalar Tenant / ID / version / status / 기간 / key / hash를 변경하지 않는다.
- 기존 ApprovedSubscriptionDecision의 null→empty/immutable 정책도 변경하지 않는다.
- 외부 HTTP route, DB schema, response DTO, 상태전이, 권한, quota 계산은 변경하지 않는다.
- 공개 생성자·메서드 signature는 세 record의 실제 javap 비교에서 동일하다.
- **accessor를 통한 직접 수정은 의도적으로 불가능해진다.** custom adapter가 이를 기대했다면 자기 가변 복사본을 만들어야 하며 실제 adapter 회귀는 별도로 필요하다.

## 3. 변경 파일과 구현 순서

| 파일 | 변경 |
|---|---|
| `backend/src/main/java/.../subscription/approval/application/ApprovalPort.java` | CaseCommand·Decision 리스트 복사 |
| `backend/src/main/java/.../subscription/gateway/application/GatewayPort.java` | Command 리스트 복사 |
| `backend/src/test/java/.../PortSnapshotAssertions.java` | 실제 Java assertion22; JDK/JUnit에서 같은 논리 공유 |
| `backend/src/test/java/.../PortSnapshotIsolationTest.java` | JUnit @Test22 wrapper 작성, 엔진 미실행 |
| `scripts/verify_port_snapshots.py` | explicit production3파일+test helper만 compile/execute; 별도 상태 보고 |
| `scripts/runtime-test-inventory.json` | 현재 AST 인벤토리 재생성 |

순서: baseline hash 확인 → no-db 환경 재확인/확보시도 → source inspection → baseline actual Java 재현 → 최소 patch → 같은 Java 재검사 → 회귀 구조검사 → 증적/패키지 작성.

## 4. 실제 검증 증적

상대경로의 기준은 `docs/build-runtime-validation-02/evidence/`이다.

| 검사 | 실제 결과 | 증적 / 한계 |
|---|---|---|
| baseline 내부 checksum | 836개 일치 | `baseline-integrity.json` |
| 원본 Port typed javac/java | compile0, execution1; 22중10PASS/12FAIL | `baseline-port-reproduction/` |
| 수정 Port typed javac/java | compile0, execution0; 22/22PASS | `patched-port-execution/` |
| public API signatures | 세 record 동일 | `public-api-comparison.json`, javap text |
| 기존 source guard | 1146/1146PASS | `cumulative-source-check.log`; 정적구조검사 |
| CP15 source guard | 93/93PASS | `cp15-source-check.log`; 정적구조검사 |
| 기존 순수 Java probe | 29/29PASS | `cp15-pure-java-check.log`; 해당 요청/키/hash/enum 한정 |
| validation tooling unittest | 16/16PASS | `validation-tools-unit.log`; backend 테스트 아님 |
| Java syntax parse | 353파일/errors0 | `java-syntax.log`; dependency type검사 아님 |
| OpenAPI YAML | 15 parse | `ancillary-syntax.json`; HTTP 동작 검증 아님 |
| 신규 JUnit22 | 작성/엔진 실행0 | 동일 assertion은 JDK helper로만 실행 |
| backend no-db / full | BLOCKED(exit2) | `backend-no-db-attempt/`, `backend-full-attempt/` |
| Spring/JPA/MariaDB/Testcontainers | NOT_EXECUTED | 실제 backend runtime PASS 없음 |
| Vendor/OIDC/UI/restore/SAST/부하 | NOT_EXECUTED | 별도 범위 |

현재 AST 선언 인벤토리는 34 suites / @Test736 / @Disabled76이다. **작성 인벤토리이지 실행 결과가 아니다.**

## 5. Baseline 보존

운영 Java318개 중316개는 바이트 단위 동일하다. 변경은 위 Port2파일뿐이다. migration49개(V001~V049), POM1, Web11개, backend config3개는 동일하다. POM을 낮추거나 Spring 버전을 바꾸지 않았다.

원본 ZIP은 변경하지 않았다. 새 누적 ZIP은 historical evidence를 포함하며 이번 최신 결론은 이 보고서와 README를 따른다.

## 6. 잔여사항

- 실제 의존성으로 전체 main/test compile 및 JUnit 실행.
- MariaDB clean/upgrade/동시성/권한 HTTP matrix 및 실제 adapters 회귀.
- 기존 ApprovalStateService의 quota null 처리 비일관성은 별도 source finding으로 남겼다. 이번 copy patch가 이를 해소한 것은 아니다.
- immutable copy는 constructor 완료 후 리스트 변경을 격리한다. source list가 생성자 실행 중 동시 수정되는 상황의 atomic capture까지 보장하는 것은 아니다.
- 기존 legacy/new recovery API 공통 mutex, policy/vendor/UI/운영 Gate는 그대로다.
- Spring Boot3.5.x 지원 유지방안은 별도 release decision이 필요하다. 상세 공식 근거는 Feedback 참조.

## 7. 다음 입력/실행

실행 가능한 Java21/Maven3.9+ 환경에서 기존 backend runner를 실행하고 **현재 invocation의 summary, compiler log, Surefire XML, report-gate**를 기준으로 첫 실패를 수정해야 한다. 새 기능/CP/정적검사 수를 늘리는 것으로 이 Gate를 대체하지 않는다.

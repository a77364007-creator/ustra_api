# CP-12 As-Built Report — Search & Discovery

## 1. Baseline and scope
- Source baseline: `U_STRA_API_Platform_CP11_v1.1`.
- CP-12 Readiness working decisions were applied without reinterpreting CP-01~11 business rules.
- Implemented MVP keyword Search & Discovery only; semantic/vector/AI search remains deferred.

## 2. Database changes
- V041 `catalog_search_document` and `catalog_search_visibility` disposable projection tables.
- tenant-qualified canonical FKs with projection-side `ON DELETE CASCADE` where practical.
- source row/revision/hash evidence for staleness detection.
- V042 `CATALOG_SEARCH:REBUILD` permission vocabulary; no Role→Permission auto-seeding.

## 3. Application changes
- `CatalogSearchPort` / `CatalogSearchProjectionPort`.
- MariaDB/JPA projection entities/repositories and rebuild/reindex service.
- Product-level keyword/browse search across Product/Provider/PUBLISHED localization sources.
- canonical visibility recheck through `CatalogVisibilityService` using server-resolved organization.
- provider same-tenant filter, deterministic paging, bounded query/page size.
- localization display resolution reuses existing `LocalizationResolutionService`.
- full current-tenant rebuild and per-Product idempotent replacement.
- Product create/update + Publication activate/suspend/withdraw AFTER_COMMIT reindex triggers.

## 4. Deliberately not implemented
- UseCase, BusinessObject, Category, Tag, Synonym.
- Classification / AccessPolicy facets or inferred security grade.
- Sandbox/requestability/usage filters and popularity ranking.
- localization publication governance.
- semantic/vector/embedding search, AI recommendation/explanation.
- production asynchronous worker/retry/SLO/large-scale recovery orchestration.

## 5. Verification actually executed
- cumulative static verifier: **925/925 PASS**.
- CP12 source-contract verifier: **52 active PASS + 8 explicit design gates / 0 FAIL**.
- OpenAPI YAML parse: **12/12 PASS**.
- dependency-less javac diagnostic: **0 syntax-like / 0 type-like diagnostics** in the bounded diagnostic output; this is not a Maven compile PASS.
- environment: Java 21 available; Maven unavailable; Docker unavailable; Node 22.16.0 while CI reference target remains Node 24.

## 6. Runtime status
Not executed / not claimed PASS:
- Maven/Spring compile.
- JPA repository derived-query/runtime behavior.
- MariaDB/Flyway V001~V042.
- Testcontainers.
- CP01~CP12 JUnit runtime regression.
- representative search performance/EXPLAIN.

## 7. Design feedback / blockers
See `DESIGN_FEEDBACK_CP12.md`. Classification/AccessPolicy remains a security/release blocker. Search metadata facets and production reindex operations remain explicitly gated/deferred.

## 8. Final state
`SOURCE IMPLEMENTED / STATIC VERIFIED / METADATA+POLICY+RUNTIME BLOCKED / NOT RELEASE-READY`

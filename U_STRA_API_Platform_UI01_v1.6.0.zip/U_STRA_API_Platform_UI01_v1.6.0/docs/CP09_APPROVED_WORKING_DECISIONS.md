# CP-09 Approved Working Decisions — Provider/OpenAPI Import

- Scope: technical Provider/OpenAPI import only.
- Stable API identity: explicit `apiCode`, canonical `trim + uppercase(Locale.ROOT)`, unique per Tenant.
- Import requires same-Tenant Provider.
- OpenAPI target: 3.0.x and 3.1.x; Swagger 2.0 conversion excluded.
- Dedicated parser behind `OpenApiParserPort`.
- Upload source only; no URL, file path, archive, GitHub sync, or Gateway discovery.
- `$ref`: internal-document only. Remote/file/external-relative references fail closed.
- HTTP method uppercase. Only path parameter names normalize to `{}`. Case, trailing slash, repeated slash, percent encoding remain unchanged.
- Same API + version + source hash reuses the technical version. Different hash conflicts and never silently overwrites DRAFT/RELEASED data.
- Import creates only `API`, `APIVersion(DRAFT)`, and `APIOperation` under `APICandidate/APIImport` metadata.
- No APIProduct, ProductVersion, Publication, Release, Breaking Change judgment.
- Raw OpenAPI source is not persisted to canonical DB/Audit/Outbox.

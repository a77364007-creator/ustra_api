# CI Assets — CP-01 through CP-07

## Provider-neutral contract
Current verification entry point:

```bash
bash scripts/runtime-verify.sh
```

The command exits non-zero if any runtime prerequisite, backend test, MariaDB migration test, expected-test evidence check, or frontend reproducible build fails.

## Provider templates
- `templates/github-actions/cp01-verify.yml` — historical CP-01 reference
- `templates/github-actions/cp02-verify.yml` — CP-02 reference
- `templates/github-actions/cp03-verify.yml` — CP-03 reference
- `templates/github-actions/cp04-verify.yml` — CP-04 reference
- `templates/github-actions/cp05-verify.yml` — CP-05 reference
- `templates/github-actions/cp06-verify.yml` — CP-06 reference
- `templates/github-actions/cp07-verify.yml` — current CP-07 reference

All are **reference templates only**, not activated workflows. They remain outside `.github/workflows/` because the source package does not define the organization's CI provider, branch strategy, runner policy or action allowlist/full-SHA pinning policy.


## CP-14 reference template
`templates/github-actions/cp14-verify.yml` is REFERENCE TEMPLATE ONLY and is not activated automatically.

# CP-15 Runtime gate (manual integration with existing CI)
No workflow is automatically activated. Preserve CP01–CP14 suites and all existing design skips.

Run `bash scripts/runtime-verify.sh` only in the approved Java21/Maven3.9+/Node24/Docker environment.
Add all `Cp15*Test` reports and the V001–V049 MariaDB migration report as evidence. CP15ContractGateTest has 16 explicit disabled cases; these are not PASS or release acceptance.

Java parse and pure-domain probe are intentionally separate from Maven compilation / JUnit / JPA / MariaDB. The report inspector verifies report structure and counts; a historical source-text test does not become a behavior test merely by running under JUnit.
